<?php
/*
*数据提取 回调下载测试
*/

require_once('DataExtract.class.php');

try{

	$DE = new DataExtract(array(
		'user' => 'nobo.zhou',
		'pwd'  => '123456',
		'cookiePath' => './',
		'timeOut' => 0,
		'host' => 'http://192.168.118.89:8089/DataExtract'
	));
	
	$DE->login();
	
	$downLoadUrl = $_GET['downloadDataUrl'];
	
	if( $_GET['status'] != 0 ) {
		//提取失败
		exit;	
	}
	
	
	$content = $DE->download( $downLoadUrl );	
	file_put_contents('test.csv', $content);
	
} catch( Exception $e ) {
	 echo 'Message: ' .$e->getMessage();	
	  exit;
}
?>
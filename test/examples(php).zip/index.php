<?php
/*
*数据提取 创建提取任务测试
*/
require_once('DataExtract.class.php');

try {

	$DE = new DataExtract(array(
		'user' => 'nobo.zhou',
		'pwd'  => '123456',
		'cookiePath' => './',
		'timeOut' => 0,
		'host' => 'http://192.168.118.89:8089/DataExtract'
	));
	
	$DE->login();
	
	$data = $DE->post('/user/task/createTask', array(
		"appId" => 3,
		"templateId" => 1,
		"ageCond" => '>',
		"age" => '1',
		"url" => "http://192.168.118.87/ajax.uchome/Nex3.0/test/download.php"
	));
	
	var_dump( $data );

}catch(Exception $e) {
	 echo 'Message: ' .$e->getMessage();	
	  exit;
}


?>
;(function($,win,doc){
	var aliasNameMaps = {
		'Nex.Html' : 'Nex.html'	
	};   		   
})(jQuery,window,document);
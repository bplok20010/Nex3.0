<?php
sleep($_REQUEST['C']);
var_dump($_FILES);
echo "Hello World!".$_REQUEST['C'];
$define(function(){
	//$require('t8');
	//$require('t7');
	console.log(6);
});
/*
Nex.Container组件说明：
组件名称       : Nex.Container 可通过 new Nex.Container() 或者 Nex.Create('NexContainer') 来创建
组件别名xtype  : container  可通过Nex.Create('container')
加载名称       : Nex.Container 组件存放目录结构 {{nex目录}}/Container.js
*/
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	"use strict";
	var container = Nex.define('Nex.Container',{
		xtype : 'container'	
	});
	container.setOptions( function( opt ){
		return {
				//uiPrefix  : 'nex-ui',
				prefix : 'nexcontainer-',
				//tag : 'div',
				autoRender : true,//开启后直接创建对象就会渲染
				renderAfter : true,//true:append false:prepend
				
				selectionable : true,
				
				renderTo : document.body,
				//ui : 'defalut',//default = nex-ui-default
				//uiCls : [],//icon = nex-ui-default-icon
				//cls : '',
				cssText : '',
				//containerCls : 'nex-container',
				
				style : {},
				'class' : '',
				views : {}, //所有元素
				attrs : {},
				//html : '',
				
				autoScroll : true,
				cutHeight : 0,
				cutWidth : 0,
				autoSize : false,
				width : '100%',
				height : '100%',
				//maxWidth : 0,
				//maxHeight : 0,
				//minHeight : 0,
				//minWidth : 0,
				realWidth : null,//实际 ,width=auto时 如果max min width height 没起作用那么realWidth = auto
				realHeight : null,//同上
				_width : null,//和realWidth 不同的是 _width是一个数值
				_height : null,
				__width : 0,
				__height : 0,
			
				//一般做扩展用，有的组件items是不需要用到的
				//disabledItems : false,
				//items : [],
				//events : {}
			};
	} );
	container.fn.extend({
		_render : function( el,after ){
			var self = this;
			var opt = this.configs;
			//如果已经渲染则不能重复渲染
			if( this.rendered ) {
				return this;	
			}
			
			opt.renderTo = this._undef( el,opt.renderTo );
			opt.renderAfter = this._undef( after,opt.renderAfter );
			
			container.superclass.fn._render.apply( self,arguments );
			
			return this;	
		},
		_init : function(opt) {
			var self = this;
			
			opt.cls = 'nex-component-item '+opt.cls;
			opt.__width = opt.width;
			opt.__height = opt.height;
			
			self.setContainer();
			self.initComponent();
		},
		getContainer : function(){
			var self = this,
				opt = self.configs;
			return opt.views['container'];	
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return opt.views['container'];
		},
		_disableSelection : function(){
			this.el.disableSelection();	
		},
		setContainer : function(){
			var self = this;
			var opt = self.configs;	
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			var container;
			
			var cls = [
				opt.containerCls
			];
			
			if( opt.ui ) {
				var ui = [opt.uiPrefix,opt.ui].join('-')
				cls.push(ui);	
				var uiCls = $.isArray(opt.uiCls) ? opt.uiCls : [ opt.uiCls ];
				$.each( uiCls,function(i,uc){
					if( !uc ) return;
					cls.push( [ui,uc].join('-') );	
				} );
			}
			if( opt['cls'] ) {
				cls.push( opt['cls'] );	
			}
			if( opt['class'] ) {
				cls.push( opt['class'] );	
			}
			var tag = opt.tag || 'div';
			
			container = $('<'+tag+' class="'+ cls.join(' ') +'" id="'+opt.id+'"></'+tag+'>');
		
			if( opt.renderAfter ) {
				render.append(container);
			} else {
				render.prepend(container);
			}
			opt.views['container'] = container;
			//方便使用
			self.el = container;
			if( opt.cssText ) {
				container[0].style.cssText = opt.cssText;
			}
			container.attr( opt.attrs )
				     .css( opt.style );
			if( !opt.selectionable ) {
				self._disableSelection();	
			}
			
			self.fireEvent("onContainerCreate",[container,opt]);
			
			return self;
		},
		initComponent : function(func){
			var self = this;
			var opt = self.configs;	
			self.fireEvent('onInitComponent',[opt]);
			
			self._appendContent();
			
			if( $.isFunction( func ) ) {
				func.call(self);	
			}
			self.fireEvent('onCreate',[opt]);
			opt._isInit = false;
		},
	});
}));
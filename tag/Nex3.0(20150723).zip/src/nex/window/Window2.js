/*
Window.js
http://www.extgrid.com/window
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

*/
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([
			'Nex.showat.ShowAt',
			'Nex.drag.Drag',
			'Nex.resize.Resize',	
			'Nex.panel.Panel'
		], function(){
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	"use strict";
	//var panel = Nex.define('Nex.Panel','Nex.Html').setXType('panel');
	var win = Nex.define('Nex.window.Window','Nex.panel.Panel',{
		alias : 'Nex.Window',
		xtype : 'window'		
	});
	win.setOptions(function( opt,t ){
		return {
			prefix : 'nexwindow-',
			border : true,
			borderCls : [opt.borderCls,'nex-window-border'].join(' '),
			containerCls : [opt.containerCls,'nex-window'].join(' '),
			tabIndex : -1,
			autoScroll : false,
			autoShow : true,
			isFixed : false,
			refreshPosOnResize : true,//浏览器大小改变时 重新设置window的位置
			resetPosOnShow : true, //每次显示窗口时 都会重新设置位置
			showShadow : true,
			shadowCls : 'nex-window-shadow',
			focusOnToFront : true,
			constrain : false,//开启后 不能移出 父元素的空间
			constrainEdge : 0,
			constrainHeader : false,
			closeToRemove : true,
			actionOnEsc : 'close',
			closeOnEsc : true,//按Esc时 关闭
			draggable : true,
			dragCls : '',
			dragHelper : 'header',//header container body....
			_dragConfig : {},
			dragConfig : {},
			resizeable : false,
			resizeDelay : 50,
			_resizeConfig : {},
			resizeConfig : {},
			closable 	: true,
			minimizable : false,
			maximizable : false,
			maximized   : false,
			maximizedCls : '',
			minimized   : false,
			headerSelectionable : false,
			items : [],
			renderTo : window,
			animate : true,//开启动画显示 开启后可设置effect等参数
			animDuration : 200,
			animEasing   : $.easing.def ? $.easing.def : 'swing',
			//effect duration easing complete  queue .....
			_effect : {},//effect可参考jquery ui effects部分
			effect : {},
			showEffect : {},
			hideEffect : {},
			showFn : null,//自定义显示函数
			hideFn : null,//自定义关闭函数
			showMethod : 'fadeIn',
			hideMethod : 'fadeOut',
			_showAt : {
				xAlign : 'center',
				yAlign : 'center',
				zAlign : 'y',
				visibleable : true	
			},
			showAt : {},
			resetPositionDuration : 200,
			alwaysOnTop : false,//保持置顶
			zIndex : Nex['zIndex'],
			modal : false,
			modalCls : '',
			modalRenderTo : null,//默认同renderTo
			maxWidth : function(){
				var self = this;
				var opt = self.configs;
				var renderTo = this.C('renderTo');	
				if( $.isWindow(opt.renderTo) ) {
					return $(renderTo).width();
				} else {
					return 0;		
				}
			},
			maxHeight : function(){
				var self = this;
				var opt = self.configs;
				var renderTo = this.C('renderTo');
				if( $.isWindow(opt.renderTo) ) {
					return $(renderTo).height();
				} else {
					return 0;	
				}
			},
			denyEvents : ['scroll'],
			events : {}
		};	
	});
	win.fn.extend({ 
		//initComponent : function(){
			//var opt = this.configs;//cfg
			//触发了onCreate
			//Nex.panel.Panel.fn.initComponent.apply( this,arguments );
			
			//this.initWindow();
			
		//}, 
		//initWindow : function(){
		//	console.log('initWindow');	
		//},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			Nex.panel.Panel.fn._sysEvents.apply( this,arguments );
			//设置fixed样式 并且隐藏
			self.bind('onContainerCreate._sys',function(el){
				//isFixed	
				if( self.isFixed() ) {
					el.addClass('nex-window-fixed');	
				}
				self._initHidden();
				
			},self);
			//添加window 样式
			self.bind('onHeaderCreate._sys',function( el ){
				el.addClass('nex-window-header');
				$('>.nex-panel-tools',el).addClass('nex-window-tools')
			},self);
			self.bind('onBodyCreate._sys',function( el ){
				el.addClass('nex-window-body');
			},self);
			self.bind('onFooterCreate._sys',function( el ){
				el.addClass('nex-window-footer');
			},self);
			//设置refreshPosOnResize
			self.bind('onCreate._sys',self._refreshPosOnResize,self);
			//设置closeOnEsc
			self.bind('onKeyDown._sys',function(el,e){
				if( e.keyCode === 27 && opt.actionOnEsc ) {
					//self.close();	
					if( $.isFunction(opt.actionOnEsc) ) {
						opt.actionOnEsc.call( self );
					} else if( self[ opt.actionOnEsc ] ) {
						self[ opt.actionOnEsc ]();
					}
				}	
			},self);
			//显示或关闭Modal
			self.bind('onStartShow._sys',self.showModal,self);
			self.bind('onStartHide._sys',self.hideModal,self);
			//设置zindex
			self.bind('onFocusin._front',function(){
				if( opt.focusOnToFront ) {
					self.setzIndex();	
				}	
			},self);
			//autoSize 设置
			self.bind('onCreate._sys',self.checkToAutoSetSize,self);
			//拖拽设置
			self.bind('onCreate._sys',self._draggable,self);
			//resizeable
			self.bind('onCreate._sys',self._resizeable,self);
			//拖拽检测
			self.bind('onWindowDrag._sys',self._checkDragConstrain,self);
			
			return self;
		},
		_initHidden : function(){
			this.hidden = true;
			//this._defaultHide();
			this.el._hide();
		},
		checkToAutoSetSize : function(){
			var self = this;
			var opt = this.configs;	
			if( opt.width === 'auto' && opt.height === 'auto' ) {
				self.clearContainerSizeCache();
				self.autoSetSize();
			} else if( opt.width === 'auto' ) {
				self.clearContainerSizeCache();
				self.autoSetWidth();	
			} else if( opt.height === 'auto' ) {
				self.clearContainerSizeCache();
				self.autoSetHeight();	
			}
		},
		_afterCreate : function(){
			var self = this;
			var opt = this.configs;//cfg
			var el = this.el;
			//var container = opt.views['container'];
			
			//window 设置 width/height = auto 时会自动设置width height
			
			//self.checkToAutoSetSize();
			
			if( opt.autoShow ) {
				this.show();//需要重写show
			}
			if( opt.maximized ) {
				this.maximize();	
			}
			//折叠
			Nex.panel.Panel.fn._afterCreate.apply( this,arguments );	
			
			if( opt.minimized ) {
				el.stop(true,true);
				this.minimize(false);	
			}
		},
		__rpr : false, 
		__rptt : 0,
		_refreshPosOnResize : function(){
			var self = this;
			var opt = this.configs;
			if( !Nex.Manager ) return;
			if( self.__rpr ) return;
			self.__rpr = true;
			self.bind('onDestroy._sys',function(){
				Nex.Manager.unbind('._'+opt.id);	
			});
			Nex.Manager.bind('onBrowserResize._'+opt.id,function(){
				
				self.fireEvent('onBrowserSizeChange');
				
				if( !self.rendered || self.isHidden() ) return;
				
				if( opt.modal ) {	 
					self.refreshModalSizeAndPos();
				}
				
				if( !opt.refreshPosOnResize ) return;
				if( self.maximized ||
					 self.collapsed ) return;
				if( self.__rptt ) {	 
					clearTimeout( self.__rptt );
					self.__rptt = 0;
				}
				self.__rptt = setTimeout(function(){
					clearTimeout( self.__rptt );
					self.__rptt = 0;
					if( !self.isShowing ) {
						self.resetPosition();	
					} else {
						//onShow
						self.unbind('._resize__'+opt.id);
						self.one('onShow._resize__'+opt.id,function(){
							self.resetPosition();		
						})	
					}
				},0);		 
				
			});	
		},
		_checkDragConstrain : function(t,pos,e,_opt){
			var self = this,
				opt=this.configs;
			var el = self.el;
			var sLeft = $(opt.renderTo).scrollLeft();	
			var sTop = $(opt.renderTo).scrollTop();	
			var left = pos.left;
			var top = pos.top;
			
			var clientWidth = $.isWindow( opt.renderTo ) ? $(opt.renderTo).width() : $(opt.renderTo)[0].clientWidth;
			var clientHeight = $.isWindow( opt.renderTo ) ? $(opt.renderTo).height() : $(opt.renderTo)[0].clientHeight;
			
			//self.html( [clientWidth,clientHeight].join(':') )
			
			var ew = el.outerWidth();
			var eh = el.outerHeight();
			
			var edge = opt.constrainEdge;
			
			if( (left-sLeft)<edge ) {
				pos.left = sLeft + edge;	
			}
			if( (top-sTop)<edge ) {
				pos.top = sTop + edge;	
			}
			if( (ew + left - sLeft)>(clientWidth - edge) ) {
				pos.left = clientWidth - ew + sLeft - edge;	
			}
			//constrainHeader
			var header_h = 0;
			if( opt.constrainHeader && opt.views['header'] ) {
				header_h = opt.views['header'].outerHeight() 
							+ (parseFloat(el.css('borderTop')) || 0) 
							+  (parseFloat(el.css('paddingTop')) || 0);
				header_h = el.outerHeight() - header_h;			
			}
			if( (eh + top - sTop)>(clientHeight + header_h - edge) ) {
				pos.top = clientHeight - eh + sTop - edge + header_h;
			}
		},
		_setSysTools : function( tools ){
			var self = this,
				opt=this.configs;
			var header = opt.views['header'];			
			var $tools = $('>.nex-panel-tools',header);
			if( opt.collapsible ) {
				tools.push( {
					iconCls : 'tools-collapse-icon',
					handler : function(){
						self.toggleCollapse();	
					}
				} );	
				self.unbind('.collapse');
				self.bind('onCollapse.collapse',function(){
					$('>.tools-collapse-icon',$tools).addClass('tools-expand-icon');	
				},self);
				self.bind('onExpand.collapse',function(){
					$('>.tools-collapse-icon',$tools).removeClass('tools-expand-icon');	
				},self);
			}
			//min
			if( opt.minimizable ) {
				tools.push( {
					iconCls : 'tools-minimize-icon',
					handler : function(){
						self.minimize();	
					}
				} );	
			}
			//max
			if( opt.maximizable ) {
				tools.push( {
					iconCls : 'tools-maximize-icon',
					handler : function(){
						self.toggleMaximize();	
					}
				} );
				self.unbind('.maximize');
				self.bind('onMaximize.maximize',function(){
					$('>.tools-maximize-icon',$tools).addClass('tools-restore-icon');	
				},self);
				self.bind('onRestore.maximize',function(){
					$('>.tools-maximize-icon',$tools).removeClass('tools-restore-icon');	
				},self);	
			}
			//close
			if( opt.closable ) {
				tools.push( {
					iconCls : 'tools-close-icon',
					handler : function(){
						self.close();	
					}
				} );	
			}
			return tools;
		},
		setzIndex : function(){
			var self = this;
			var opt = self.configs;		
			var container = self.el;
			var zIndex = Nex[ opt.alwaysOnTop ? 'topzIndex' : 'zIndex' ]+2;
			Nex[opt.alwaysOnTop ? 'topzIndex' : 'zIndex'] = zIndex;
			opt.zIndex = zIndex; 
			
			container.css('z-index',opt.zIndex);
			
			var modal = opt.views['modal'];	
			if( modal ) {
				modal.css('z-index',opt.zIndex-1);
			}		
		},
		toFront : function(){
			var opt = this.configs;
			if( opt.focusOnToFront ) {
				this.focus();	
			}	
			return this;	
		},
		_drmodal : null,
		showDragAndResizeOuterModal : function(){
			var el = this.el;
			if( !this._drmodal ) {
				this._drmodal = $('<div class="nex-window-tmp-modal"></div>');
			}	
			var p = el.parent();
			p.append( this._drmodal );
			this._drmodal.css({
				width : p.width(),
				height : p.height()
			});
			return this._drmodal;
		},
		removeDragAndResizeOuterModal : function(){
			if( this._drmodal )	{
				this._drmodal.remove();
				this._drmodal = null;	
			}
		},
		dragger : null,
		_draggable : function(){
			var self = this;
			var el = this.el;
			var opt = self.configs;
			if( !opt.draggable || !Nex.drag.Drag ) return;
			var helper = opt.views[ opt.dragHelper ] || self.el;
			var dcfg = {
				helper : helper,
				target:el	
			};
			var cfg = {
				dragCls : opt.dragCls	
			};
			var dragModal = null;
			cfg[ 'onBeforeDrag._drag_'+opt.id ] = function(e,_opt){
				
					if( e.which !== 1 || !opt.draggable || self.maximized || self.isResizing ) return false;
					
					var r = self.fireEvent("onWindowBeforeDrag",[e,_opt]);	
					if( r === false) return r;
					
				};
			cfg[ 'onStartDrag._drag_'+opt.id ] = function(helper,e,_opt){
					self.fireEvent("onWindowStartDrag",[helper,e,_opt]);	
					helper.addClass('nex-window-dragging');
					if( !dragModal ) {
						dragModal = $('<div class="nex-window-drag-modal"></div>');	
						el.append( dragModal );
					}
					self.showDragAndResizeOuterModal();
				};	
			cfg[ 'onDrag._drag_'+opt.id ] = function(helper,pos,e,_opt){
					var r = self.fireEvent("onWindowDrag",[helper,pos,e,_opt]);	
					if( r === false) return r;
				};
			cfg[ 'onStopDrag._drag_'+opt.id ] = function(helper,pos,e,_opt){
					helper.removeClass('nex-window-dragging');
					var r = self.fireEvent("onWindowStopDrag",[helper,pos,e,_opt]);	
					if( r === false) return r;
				};
			cfg[ 'onAfterDrag._drag_'+opt.id ] = function(pos,e,_opt){
					if( self.isFixed() ) {
						el.css( {
							position : 'fixed',
							left : pos.left - $(window).scrollLeft(),	//parseFloat(el.css('left'))
							top : pos.top - $(window).scrollTop()  //parseFloat(el.css('top'))
						} );	
					}	
					if( dragModal ) {
						dragModal.remove();
					}
					self.removeDragAndResizeOuterModal();
					
					self.fireEvent("onWindowAfterDrag",[pos,e,_opt]);
				};				
			self.dragger = Nex.Create('draggable',$.extend(cfg,opt._dragConfig,opt.dragConfig ||　{},dcfg));
		},
		resizer : null,
		isResizing : false,
		_resizeable : function(){
			var self = this;
			var opt = self.configs;
			if( !opt.resizeable || !Nex.resize.Resize || opt.autoSize ) return;
			var container = self.el;
			//resizeConfig
			var dcfg = {
				target : container	
			};
			var cfg = {
				minWidth: self._getMinWidth(),	
				minHeight: self._getMinHeight(),
				maxWidth: self._getMaxWidth(),	
				maxHeight: self._getMaxHeight(),
				handles:'e, s, se'	
			};
			var dragModal = null;
			var delay = opt.resizeDelay;
			var dt = 0;
			cfg[ 'onBeforeResize._drag_'+opt.id ] = function(e,_opt){
					
					if( e.which !== 1 || !opt.resizeable || self.collapsed || self.maximized ) return false;
					
					var r = self.fireEvent("onWindowBeforeResize",[e,_opt]);	
					if( r === false) return r;	
					
					self.isResizing = true;
					
				};
			cfg[ 'onStartResize._drag_'+opt.id ] = function(e,_opt){
					self.fireEvent("onWindowStartResize",[e,_opt]);	
					dragModal = $('<div class="nex-window-drag-modal"></div>');	
					container.append( dragModal );
					self.showDragAndResizeOuterModal();
				};
			cfg[ 'onResize._drag_'+opt.id ] = function(w,h,e,_opt){
					var r = self.fireEvent("onWindowResize",[w,h,e,_opt]);	
					if( r === false) return r;	
					clearTimeout( dt );
					dt = setTimeout( function(){
						self.setWH( _opt.width,_opt.height );	
					},delay );
				};	
			cfg[ 'onStopResize._drag_'+opt.id ] = function(w,h,e,_opt){
					var r = self.fireEvent("onWindowStopResize",[w,h,e,_opt]);	
					if( r === false) return r;	
				};	
			cfg[ 'onAfterResize._drag_'+opt.id ] = function(w,h,e,_opt){
					self.isResizing = false;
					if( dragModal ) {
						dragModal.remove();
					}
					self.removeDragAndResizeOuterModal();
					
					self.fireEvent("onWindowAfterResize",[w,h,e,_opt]);	
				};			
			self.resizer = Nex.Create('resizable',$.extend( cfg, opt._resizeConfig, opt.resizeConfig || {}, dcfg ));
		},
		//检查是否fixed
		isFixed : function(){
			var opt = this.configs;	
			if( !$.isWindow(opt.renderTo) || (Nex.IEVer && Nex.IEVer<=6) ) {
				return false;	
			}
			return opt.isFixed;
		},
		/*
		*获取显示的位置
		*@param conf 配置参数
		*/
		getShowAtPos : function( conf ){
			var opt = this.configs;
			var conf = this._undef(conf,{});
			var cfg = $.extend( {},opt._showAt,opt.showAt,conf );
			cfg.parent = opt.renderTo;
			cfg.source = cfg.source || this.el;
			cfg.at = cfg.at || opt.renderTo;
			cfg.autoShow = false;
			var showAt = Nex.Create('showAt',cfg);
			var pos = showAt.getShowPos();
			if( this.isFixed() ) {
				pos.left -= $(window).scrollLeft();	
				pos.top -= $(window).scrollTop();
			}
			return pos;
		},
		showAt : function( conf ){
			var self = this,
				opt=this.configs;
			var el = self.el;
			var cfg = {};
			var at = {};
			
			//( 0,100 )
			if( typeof arguments[0] === 'number' ) {
				at.left = arguments[0];	
			}
			if( typeof arguments[1] === 'number' ) {
				at.top = arguments[1];	
			}
			// ( { left : 0,top:0 } )
			if( $.type(conf) === 'object' && !( 'at' in conf ) ) {
				if( !( 'at' in conf ) ) {
					at = conf;	
				} else {
					cfg = conf;
					at = conf.at;		
				}
			}
			if( $.isArray( conf ) ) {
				at.left = conf[0] || 0;	
				at.top = conf[1] || 0;
			}
			
			cfg.at = at;
			
			if( $.isEmptyObject( at ) ) {
				delete cfg.at;	
			}
			//这里应该加 如果等待队列
			if( opt.animate ) {
				el.stop(true,true);	
			}
			
			var pos = self.getShowAtPos( cfg );	
			
			if( !self.isVisible() ) {
				el.css( pos );	
				self._origShow();
			} else {
				opt.animate ? 
					el.animate( pos, opt.resetPositionDuration, $.easing.def ? $.easing.def : 'swing',function(){
						self.fireEvent("onResetPosition",[el,opt]);		
					} ) : 
					el.css( pos );		
			}
			return self;
		},
		resetPosition : function(){
			if( !this.rendered ) return this;
			return this.showAt.apply(this,arguments);	
		},
		//设置到指定显示位置 和 showAt不同在于 以当前坐标为显示坐标 ，不做计算
		setPosition : function( x,y ){
			if( !this.rendered ) return this;
			var opt = this.configs;	
			var el = this.el;
			var pos = {};
			if( x !== undefined ) {
				pos.left = x;	
			}
			if( y !== undefined ) {
				pos.top = y;	
			}
			opt.animate ? 
					el.stop(true,true).animate( pos, opt.resetPositionDuration, $.easing.def ? $.easing.def : 'swing') : 
					el.css( pos );		
			return this;
		},
		_initShow : false,
		_origShow : Nex.Html.fn.show,
		show : function(){
			var self = this;
			var opt = this.configs;
			var el = self.el;
			
			if( self.isVisible() ) {
				return self;	
			}
			//if( Nex.isIE6 ) {
			//	self.resetSize();
			//}
			//resetPosOnShow开启则每次都会重置位置
			//初始显示时 需要设置位置，
			if( (opt.resetPosOnShow && !self.collapsed) || !self._initShow ) {
				self._initShow = true;
				var pos = self.getShowAtPos();
				el.css( pos );
			}
			
			self.setzIndex();
			
			return self._origShow.apply( self,arguments );
		},
		maximized : false,
		maximize : function(){
			var self = this,
				el = self.el,
				opt = self.configs;
				
			if( !self.isVisible() || self.maximized || self.collapsed ) {
				return self;	
			}	
			
			if( self.fireEvent('onBeforeMaximize',[opt]) === false ) {
				return self;	
			}
			
			var props = {
				width : opt.width,
				height : opt.height,
				left : el.css('left') || 0,
				top : el.css('top') || 0	
			};
			el.data('_maxrestore',props);
			
			self.maximized = true;	
			
			//maximizedCls
			el.addClass( 'nex-window-maximized '+opt.maximizedCls );
			
			el.stop(true,true);
			self.setWH('100%','100%');
			
			var left = 0;
			var top = 0;
			//IE 下 window document 获取paddingLeft报错
			try{
				 left = $(opt.renderTo).css('paddingTop') || 0;	
				 top = $(opt.renderTo).css('paddingLeft') || 0;	
			}catch(e){}
			
			el.css( {
				left : left,
				top : top
			} );
			self.fireEvent('onMaximize', [ opt ]);
			return self;
		},
		restore : function(){
			var self = this,
				el = self.el,
				opt = self.configs;
			if( !self.isVisible() || !self.maximized || self.collapsed ) {
				return self;	
			}	
			
			if( self.fireEvent('onBeforeRestore',[opt]) === false ) {
				return self;	
			}
			
			var d = el.data( '_maxrestore' ) || {};
			el.removeData( '_maxrestore' );
			
			this.maximized = false;
			//maximizedCls
			el.removeClass( 'nex-window-maximized '+opt.maximizedCls );
			
			self.setWH(d.width,d.height);	
			
			//el.css( self.getShowAtPos() );
			el.css( {
				left : d.left,
				top : d.top	
			} );
			
			self.fireEvent('onRestore', [ opt ]);
			return self;	
		},
		toggleMaximize : function(){
			return this[ this.maximized ? 'restore' : 'maximize' ]();	
		},
		toggle : function(){
			return this[ this.hidden ? 'show' : 'hide' ].apply(this,arguments);		
		},
		minimize : function(){
			return this.hide.apply(this,arguments);	
		},
		toggleMinimize : function(){
			return this.toggle.apply(this,arguments);	
		},
		_getModalRenderTo : function(){
			var el = this.el;
			var opt = this.configs;
			var wraper = el.parent();
			if( opt.modalRenderTo ) {
				var modalWraper = $( opt.modalRenderTo );
				wraper = modalWraper.length ? modalWraper : wraper;	
			}
			return wraper;
		},
		_createModal : function (){
			var self = this;
			var opt = self.configs;	
			
			if( !opt.modal ) return null;
			if( opt.views['modal'] ) return null;
			
			
			var container = self.el;
			
			var modalRenderTo = !opt.modalRenderTo ? opt.renderTo : $(opt.modalRenderTo).length ? opt.modalRenderTo : opt.renderTo;
			
			var cls = ['nex-window-modal'];
			
			if( $.isWindow( modalRenderTo ) && self.isFixed() ) {
				cls.push('nex-window-modal-fixed');	
			}
			
			if( opt.modalCls ) {
				cls.push( opt.modalCls );	
			}
			
			var modal = $('<div class="'+cls.join(' ')+'" id="'+opt.id+'_modal"></div>');	
			opt.views['modal'] = modal;
			
			modal.css( 'zIndex',opt.zIndex-1 );

			modal.bind({
				'click._modal' : function(e){
					self.fireEvent('onModalClick',[modal,e,opt]);
					$(document).trigger('click',[e]);
					return false;
				},
				'dblclick._modal' : function(e){
					self.fireEvent('onModalDblClick',[modal,e,opt]);
					$(document).trigger('dblclick',[e]);
					return false;
				},
				'mousedown._modal' : function(e){
					self.fireEvent('onModalMouseDown',[modal,e,opt]);
					$(document).trigger('mousedown',[e]);
					return false;	
				},
				'mouseup._modal' : function(e){
					self.fireEvent('onModalMouseUp',[modal,e,opt]);
					$(document).trigger('mouseup',[e]);
					return false;	
				},
				'keydown._modal' : function(e){
					self.fireEvent('onModalKeyDown',[modal,e,opt]);
					$(document).trigger('keydown',[e]);
					return false;		
				},
				'keyup._modal' : function(e){
					self.fireEvent('onModalKeyUp',[modal,e,opt]);
					$(document).trigger('keyup',[e]);
					return false;		
				},
				'mousewheel._modal' : function(e){
					self.fireEvent('onModalMouseWheel',[modal,e,opt]);	
				},
				'mouseover._modal' : function(e){
					self.fireEvent('onModalMouseOver',[modal,e,opt]);
					$(document).trigger('mouseover',[e]);
					return false;		
				},
				'mouseout._modal' : function(e){
					self.fireEvent('onModalMouseOut',[modal,e,opt]);
					$(document).trigger('mouseout',[e]);
					return false;		
				}
			});
			var wraper = self._getModalRenderTo();
			wraper.append(modal);	
			self.fireEvent("onModelCreate",[modal,opt]);
			
			self.bind('onDestroy._sys',function(){
				modal.remove();	
			},self);
			
			return modal;
		},
		getModal : function(){
			var opt = this.configs;
			return opt.views['modal'] ? opt.views['modal'] : this._createModal();	
		},
		showModal : function(){
			var opt = this.configs;
			var modal = this.getModal();
			if( !modal ) return;
			modal.css( {
				zIndex  : opt.zIndex-1,
				opacity : 0
			} );
			modal.show();
			this.refreshModalSizeAndPos();
			
			modal.animate({
				opacity : 0.1	
			},opt.animDuration);
			
			this.fireEvent( 'onModalShow',[ modal,opt ] );
			
			return this;
		},
		hideModal : function(){
			var opt = this.configs;
			var modal = this.getModal();
			if( !modal ) return;
			modal.fadeOut(opt.animDuration);	
			this.fireEvent( 'onModalHide',[ modal,opt ] );
			return this;
		},
		refreshModalSizeAndPos : function(){
			var self = this,
				opt=this.configs,
				undef;
			
			var modal = self.getModal();
			
			if( !modal ) return self;	
			
			modal._removeStyle('width height');
			
			var render = !opt.modalRenderTo ? opt.renderTo : $(opt.modalRenderTo).length ? opt.modalRenderTo : opt.renderTo;
			
			var  isWin = $.isWindow( render );
			
			render = $(render);
			
			var w = isWin ? 0 : parseInt(render.css('paddingLeft')) + parseInt(render.css('paddingRight'));
			var h = isWin ? 0 : parseInt(render.css('paddingTop')) + parseInt(render.css('paddingBottom'));
			
			var mw = render._width() + w,
				mh = render._height() + h;
			
			if( isWin ) {
				var winWidth = $(window).width();
				var winHeight = $(window).height();
				w = parseInt($(document.body).css('paddingLeft')) + parseInt($(document.body).css('paddingRight'));
				h = parseInt($(document.body).css('paddingTop')) + parseInt($(document.body).css('paddingBottom'));
				mw = Math.max( winWidth,$(document.body).width() + w );
				mh = Math.max( winHeight,$(document.body).height() + h );
			}
			
			//if( Nex.isIE6 ) {
			//	modal._outerWidth( mw );
			//}
			modal._outerHeight( mh );
			
			self.fireEvent('onModalSizeChange',[ modal,opt ]);
			return self;
		}
	});
}));
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([
			'Nex.panel.Panel'
		], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	var table = Nex.define('Nex.grid.AbstractGrid',{
		extend : 'Nex.panel.Panel',
		xtype : 'abstractgrid',
		alias : 'Nex.AbstractGrid',
		configs : function(opt){
			return {
				prefix : 'abstable_',
				autoResize : true,
				disabledItems : true,
				border : true,
				borderCls : [opt.borderCls,'nex-grid-border'].join(' '),
				containerCls : [opt.containerCls,'datagrid-container nex-grid'].join(' '),
				autoScrollCls : [opt.autoScrollCls,'nex-grid-auto-scroll'].join(' '),
				autoWidthCls : [opt.autoWidthCls,'nex-grid-auto-width'].join(' '),
				autoHeightCls : [opt.autoHeightCls,'nex-grid-auto-height'].join(' '),
				autoScroll : false,
				cls : '',//自定义CSS
				nowrap : true,//是否换行
				rowTpl : '',//grid 自定义行模板
				showHeader : true,//显示header
				showFooter : false,
				clsOverRow : 'datagrid-row-over',
				clsSelectRow : 'datagrid-row-selected',
				stripeRows : false,//开启隔行变色
				clsSingleRow : 'datagrid-row-single',
				clsDoubleRow : 'datagrid-row-double',
				border : true,//开启后会 给grid添加 containerCss 的样式
				
				multiColumns : false,
				mulitEngine : 1,//第一种方法 可设置 1 2
				multiColumnsAlign : 'center',
				multiFromStr : true,//开启支持以字符串形式的方式实现 。multiColumns必须开启
				multiSplitStr : '_',//分割字符
				multiFromStrData : {},//multiFromStr 字符串开启后 可以为不同层数的单元格设置配置信息
				
				columns : [],//
				_columnsHash : {},//field=>column 这里包含所有的 会通过getColumns填充
				_colid : 1,//col 自增 参数
				moveColumnTm : 500,//按下多少秒后开始移动列
				moveColumns : true,
				forceFit:false,//自动设置列宽
				forceFitVisible : true,//列是否始终保持可见
				_columnMetaData : {//默认列信息
					field : '',
					index : '',//数据索引，默认==field
					title : '',
					width : '120px',//默认的列宽,
					_fieldWidth : 0,//如果width是百分比 那么这个就是计算百分比后的宽度
					minWidth : 20,//默认最小宽度
					maxWidth : null,
					align : 'left',
					valign : 'middle',//body里的垂直居中
					_expand : false,//自定义列内容
					callBack : $.noop,
					hcls : '',//header cell自定义css
					bcls : '',//body cell自定义css
					fcls : '',//footer cell自定义css
					_icon : '',
					iconCls : '',
					icon : '',
					sortable : false, 
					textLimit : false,//当处理大数据的时候 性能消耗比较厉害， 不建议开启了
					fitColumn : true,//改变列大小
					casePerChange : true,//如果当前列设置的是百分比大小，手动修改列大小后 设置为true:grid刷新会失去百分比作用,false:grid刷新时不会失去百分比作用，而是失去手动修改后的宽度
					reader : {},//映射 可直接使用Function 效果同formatter
					forceFit : true,//接受forceFit开启时自动设置列大小 checkbox edit 列会设置为false
					disabled : false//当前列不可用
				},
				//用户可针对某一列设置默认信息
				customColumnData : {},
				readerDef : '_default_',
				autoScrollToField : true,
				autoScrollToRow : true,
				fitColumns : true,//移动列总开关
				data : [],//列表数据 含有_expand的将作为扩展列 如果有 _openExpand=true 则会自动展开
				emptyGridMsg : '',//grid数据为空是的显示数据 可以是模板 opt 作为参数
				showEmptyGridMsg : true,
				pk : '_pk',//主键名称
				hideColumns : [],//已经隐藏的列
				selectRows : [],//设置默认选中的行
				_selectRows : {},//选择的行
				isCreate : false,//废弃
				isShow : false,
				views : {},
				method : 'post',
				url : '',
				loadMsg : '加载中,请稍后...',
				loadErrorMsg : '数据加载错误！',
				showErrorTime : 2000,
				_lmt : 0,//loadMsg 计时器id
				_colWidthExt : 0,//列宽精确位数
				cache : true,//缓存,
				pageNumber : 1,
				pageSize : 10,
				ajaxSend : null,//自定义ajax发送函数
				dataType : 'json',
				queryParams : {},
				singleSelect : false,//是否可以多选
				rowStyler : "",//行style 字符串作为 class function(rowid,rowdata)
				rowCallBack : $.noop,
				methodCall : {},//内部函数的回调函数
				denyRowEvents : false,//禁止触发的事件
				tpl : {
					'view' : '<table id="<%=id%>_gridview" class="nex-grid-table" cellpadding="0" cellspacing="0" border="0"><thead id="<%=id%>_dataview_h"></thead><tbody id="<%=id%>_dataview_b"></tbody></table>',	
				}
			};	
		}	
	});
	table.override({
		initComponent : function(){
			this.callParent(arguments);
			this.initAbstractTable();	
		},	
		initAbstractGrid : function(){
			var self = this;
			self._setGridLayout();
		},
		_setGridLayout : function(){
			var self = this;
			var opt = this.configs;
			var bd = self.getBody();
			var $view = self.tpl( 'view',{
				id : opt.id	
			} );
		}
	});
}));
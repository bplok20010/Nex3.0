/*
*列信息处理
*/
$define(['Nex.grid.Grid'],function(){
	
	grid.override({
		_columnsMap : function( columns ){
			var self = this
				,undef
				,opt = self.configs
				,columns = columns === undef ? opt.columns : columns
			;
			var fields = columns;
			var list = [];
			
			/*递归遍历*/
			var listMap = function( column,pid ){
				
				if( column.field === undef || column.field=='' ) {
					column.field = ['field',++Nex.aid].join('');	
				}
				
				if( pid === undef || pid === null ) {
					  pid = null;	
				} else {
					pid = $.isPlainObject( pid ) && (pid.field !== undef) ? pid.field : null;
				}
				
				if( opt.multiFromStr && opt.multiSplitStr != '' ) {
					//对列名有"_"的进行处理
					var _sp = opt.multiSplitStr;
					var _md = opt.multiFromStrData;
					var _field = column.field+'';
					column._ofield =  column._ofield===undef ? _field : column._ofield;
					
					var sl = column._hasSet?[]:_field.split(_sp);
					if( sl.length>1 ) {
						 column._hasSet = true;
						 column.field = sl[0];
						 var of = column._ofield.split(_sp);
						 var index = $.inArray( column.field,of );
						 column.field = of.slice(0,index+1).join(_sp); 
						 var tls = column.field.split(_sp);
						 var _realField = tls.pop();
						 column.title = column.title||_realField;
						 if( _realField in _md ) {
							$.extend( column,_md[ _realField ] ); 
						 }
						 if( column.field in _md ) {
							$.extend( column,_md[ column.field ] ); 
						 }
						 sl.splice(0,1);//删除第一个
						 column.columns = column.columns === undef ? [] : column.columns;
						 column.columns.push( { field : sl.join(_sp),_ofield:column._ofield } );
						
					} else {
						if( !column._hasSet && sl.length ) {
							   column._hasSet = true;
							   var of = column._ofield.split(_sp);
							   var index = $.inArray( column.field,of );
							   column.field = of.slice(0,index+1).join(_sp); 
							   var tls = column.field.split(_sp);
							   var _realField = tls.pop();
							   column.title = column.title||_realField;
							   
							   if( _realField in _md ) {
									$.extend( column,_md[ _realField ] ); 
							   }
							   if( column.field in _md ) {
									$.extend( column,_md[ column.field ] ); 
							   }
						}
					}
				}
				
				//设置默认值
				column = $.extend({},opt._columnMetaData,column);
				
				if( column.disabled===true  ) return;
				
				opt._columnsHash['nsort'+column.field] = column;
				column.__pid = column.__pid===undef ?  pid : column.__pid;
				
				if( ('columns' in column) && $.isArray( column.columns ) && column.columns.length ) {
					var ls = column.columns;
					var len = ls.length;
					for( var i=0;i<len;i++ ) {
						listMap( ls[i],column );	
					}
				} else {
					//console.log( column.field );
					list.push( column );	
				}
			}
			var i = 0,
				len = fields.length;
			for(;i<len;i++) {
				listMap( fields[i],null );
			}	
			//修正header和body如果columns设置不一致时顺序问题
			list = self._getLeafColumns();
			return list;
		},
		getColumns : function(s){
			var self = this,
				undef,
				opt = self.configs;
			var xcolumns = opt.columns;
			//console.log(xcolumns,xcolumns.length);
			
			
			//检测是否设置了 列 否则用data的key作为列名
			//var _mIndex = {}; //已经做了处理
			if(xcolumns.length<=0) {
				if(opt.data.length>0) {
					
					if( $.isPlainObject( opt.data[0] ) ) {
					
						for(var i in opt.data[0]) {
							xcolumns.push({'field':i});
						}
					}
					//已经做了处理
					//给每列添加数据映射 因为每列有可能以"_"分割 所以最后一个就是需要的列名
					/*var _hdata = opt.data[0];
					if( $.isPlainObject( _hdata ) ) {
						for(var _index in _hdata) {
							var _cl = _index.split('_');
							if( _cl.length>1 ) {
								_mIndex[ _cl[ _cl.length-1 ] ] = _index;
							} else {
								_mIndex[ _index ] = _index;
							}
						}
					}*/
				}
			}
			
			//对多级列进行处理 初次用时有效
			var columns = self._columnsMap(xcolumns);
			
			//var _columns = [];
			var _hasSetCk = false,
				_hasSetEd = false;
			var i = 0,
				len = columns.length;
			for(;i<len;i++) {
				
				//columns[i] = $.extend({},opt._columnMetaData,columns[i]);
				
				if( columns[i]['disabled'] === true ) continue;
				
				//if(typeof columns[i]['width'] == 'number') columns[i]['width'] += 'px';
				columns[i]['field'] = columns[i]['field'] === "" ?  i : columns[i]['field'];
				//已经做了处理
				//if( !$.isEmptyObject( _mIndex ) ) {
					//columns[i]['index'] = _mIndex[ columns[i]['field'] ] === undefined ?  columns[i]['index'] : _mIndex[ columns[i]['field'] ];
				//}
				
				//customColumnData
				if( columns[i]['field'] in opt.customColumnData ) {
					$.extend( columns[i],opt.customColumnData[columns[i]['field']] );
				}
				
				columns[i]['title'] = columns[i]['title'] === "" ?  columns[i]['field'] : columns[i]['title'];
				columns[i]['index'] = columns[i]['index'] === "" ?  columns[i]['field'] : columns[i]['index'];
				columns[i]['_colid'] = columns[i]['_colid'] === undef ? 'col'+(Nex.grid._colid++ || opt._colid++) : columns[i]['_colid'];
				
				//判断是否开启ck ed字段
				if( opt.checkBox !== false && columns[i]['field']=="ck" && _hasSetCk===false ) {
					if( !columns[i]['_hasSetCk'] ) {
						columns[i] = self.getCheckBoxColumn();
						opt._columnsHash[ 'nsort'+columns[i]['field'] ] = columns[i];
					}
					_hasSetCk = true;
				}
				if( opt.editColumn !== false  && columns[i]['field']=="ed" && _hasSetEd===false ) {
					if( !columns[i]['_hasSetEd'] ) {
						columns[i] = self.geteditColumn();
						opt._columnsHash[ 'nsort'+columns[i]['field'] ] = columns[i];
					}
					_hasSetEd = true;
				}
				
				//opt._columnsHash[ columns[i]['field'] ] = columns[i];
				//_columns.push(columns[i]);
			}
			
			//columns = _columns;
			
			//检测是否使用checkbox
			var ck = [],
				ed = [];
			if( opt.checkBox !== false && _hasSetCk===false ) {
				var copt = self.getCheckBoxColumn();
				if( copt !== false) {
					ck = [ copt ];
					opt._columnsHash[ 'nsort'+copt['field'] ] = copt;
					//$.merge(ck,columns);
					columns.unshift( copt );
					//columns = ck.concat( columns );
					//columns = ck;
				}
			}
			
			if( opt.editColumn !== false && _hasSetEd===false) {
				if(self.geteditColumn() !== false) {
					ed = [ self.geteditColumn() ];
					opt._columnsHash[ 'nsort'+ed[0]['field'] ] = ed[0];
					//$.merge(columns,ed);
					//columns = columns.concat( ed );
					columns.push(ed[0]);
				}
			}
			//opt.columns.length = 0;
			opt.columns = columns;
			
			self.fireEvent( 'onSetColumns',[columns] );
			
			return opt.columns;
		}
	});		
});
/*
Nex.Container组件说明：
组件名称       : Nex.Container 可通过 new Nex.Container() 或者 Nex.Create('NexContainer') 来创建
组件别名xtype  : container  可通过Nex.Create('container')
加载名称       : Nex.Container 组件存放目录结构 {{nex目录}}/Container.js
*/
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	"use strict";
	Nex.define('Nex.box.Box',{
		extend : 'Nex.Component',
		alias : 'Nex.Box',
		xtype : 'box',
		configs : function(){
			return {
				prefix : 'nexbox',
				containerCls : 'nex-box',	
			};	
		},
		onInitComponent : function() {
			var self = this;
			var opt = this.configs;
			self.callParent();
			//opt.cls = 'nex-component-item '+opt.cls;
			//opt.__width = opt.width;
			//opt.__height = opt.height;
			
			self.setContainer();
			
			self._appendContent();
		},
		setContainer : function(){
			var self = this;
			var opt = self.configs;	
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			var container;
			
			var cls = [
				opt.containerCls,
				'nex-component-item'
			];
			
			if( opt.ui ) {
				var ui = [opt.uiPrefix,opt.ui].join('-')
				cls.push(ui);	
				var uiCls = $.isArray(opt.uiCls) ? opt.uiCls : [ opt.uiCls ];
				$.each( uiCls,function(i,uc){
					if( !uc ) return;
					cls.push( [ui,uc].join('-') );	
				} );
			}
			if( opt['cls'] ) {
				cls.push( opt['cls'] );	
			}
			if( opt['class'] ) {
				cls.push( opt['class'] );	
			}
			var tag = opt.tag || 'div';
			
			container = $('<'+tag+' class="'+ cls.join(' ') +'" id="'+opt.id+'"></'+tag+'>');
		
			if( opt.renderAfter ) {
				render.append(container);
			} else {
				render.prepend(container);
			}
			opt.views['container'] = container;
			
			self.el = container;
			
			if( opt.cssText ) {
				container[0].style.cssText = opt.cssText;
			}
			container.attr( opt.attrs )
				     .css( opt.style );
			if( !opt.selectionable ) {
				self._disableSelection();	
			}
			
			self.fireEvent("onContainerCreate",[container,opt]);
			
			return self;
		}	
	});
}));
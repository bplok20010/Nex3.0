/*
*Util工具
*Nex.utils.Utils
*/
Nex.addUtils('Utils',{

});
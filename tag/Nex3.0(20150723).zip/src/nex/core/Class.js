/*Base Class*/
(function(){
	"use strict";
var makeCtor = function() {
		function constructor() {
			return this.constructor.apply(this, arguments);
		}
		return constructor;
	},
	Base = Nex.Base
	;
	Nex.apply( Nex, {
		baseChain : function(className){
			var basePrototype = Base.prototype;
			var cls = makeCtor();
			
			Base.extend.call( cls,Base );
			
			if( className ) {
				cls.$className = className;	
				cls.prototype.$className = className;	
			}
			return cls;
		},
		_preOverrides : function(subclass,overrides){
			var aliasName,configs,xtype,mconfigs = [];
			if( 'alias' in overrides && overrides.alias ) {
				aliasName = String(overrides.alias);
				delete overrides.alias; 	
			}
			if( 'configs' in overrides && overrides.configs ) {
				configs = overrides.configs;
				delete overrides.configs; 	
			}
			if( 'xtype' in overrides && overrides.xtype ) {
				xtype = overrides.xtype+'';
				delete overrides.xtype; 
			}
			var m_overrides = {};
			if( 'mixins' in overrides && overrides.mixins ) {
				overrides.mixins = $.isArray( overrides.mixins ) ? overrides.mixins : [overrides.mixins];
				$.each( overrides.mixins,function(i,d){
					if( $.isFunction( d ) ) {
						d = d( m_overrides );	
					}
					if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
						d = Nex.getMixins( d );
					}
					//组合对象的configs也会被当作组件的参数
					if( Nex.isObject( d ) ) {
						d = $.extend( true,{},d );
						if( 'configs' in d && d.configs ) {
							mconfigs.push( d.configs );
							delete d.configs; 	 	
						}
						$.extend( m_overrides,d );		
					}
				} );
				overrides.mixins.length = 0;
				delete overrides.mixins;
			}
			overrides = Nex.apply( {},overrides,m_overrides );
			if( aliasName ) {
				var aliasNames = $.trim(aliasName).split(/\s+/g);
				$.each( aliasNames,function(i,n){
					Nex.setNamespace( n,subclass );
					Nex.addClass( n,subclass );
				} );
			}
			if( xtype ) {
				var xtypes = $.trim(xtype).split(/\s+/g);
				$.each( xtypes,function(i,t){
					subclass.setXtype(t);		
				} );
			}
			$.each( mconfigs,function(i,c){
				subclass.setOptions(c);	
			} );
			if( configs ) {
				subclass.setOptions(configs);		
			}	
			return overrides;
		},
		extend : function(className, superName, members){
			var subClass,
				superClass,
				extendClass;
			if( arguments.length === 2 && Nex.isObject(superName) ) {
				members = superName;	
				superName  = null;//'Nex.Base';
			}
			if( typeof className === 'function' && className.$isClass ) {
				subClass = className;
			} else {
				subClass = Nex.getClass( className );
			}
			if( !subClass ) {
				throw new Error("class not defined");	
			}
			if( arguments.length === 1 ) return subClass;
			members = Nex.apply({},members) || {};
			extendClass = members.extend || superName;
			
			delete members.extend;
			
			if( extendClass && typeof extendClass === 'function' && extendClass.$isClass ) {
				superClass = extendClass;
			} else {
				superClass = extendClass ? Nex.getClass( extendClass ) : extendClass;
			}
			if( superClass ) {
				subClass.extend( superClass );
			}
			//处理members
			members = this._preOverrides( subClass,members );
			
			subClass.override( members );
			
			return subClass;
			
		},
		setNamespace : function(str,v){
			var undef,
				t = window,
				s = str+'';	
			s = s.split('.');
			for( var i=0,len=s.length-1;i<len;i++ ) {
				var e = s[i];
				if( !(e in t) || !t[e] ) {
					t[e] = {};	
				}
				t = t[e];	
			}	
			t[s[i]] = v;
		},
		//定义类
		define : function(className, superName, overrides){
			if( !arguments.length ) {
				throw new Error('className not exists!');	
			}
			var subClass = Nex.baseChain(className);
			
			this.setNamespace( className, subClass );
			
			this.classes[ className ] = subClass;
			this.extend.apply(this, arguments);
			return subClass;
		}
	} );
})();
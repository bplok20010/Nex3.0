Nex.apply( {
	//数组移动算法
	// pos 要移动的元素
	array_move : function(iarr,pos,target,t) {//t 代表是前还是后 1 代表前 0 代表后

		if(pos == target) return iarr;
		var __arr = iarr;
		//支持字符下标
		var _iarr = iarr = [].concat(__arr);
		iarr = [];
		var j=0,
			len = _iarr.length;
		for(;j<len;j++) {
			var _i = iarr.push(j);
			if( j == pos) {
				pos = _i-1;
			} else if( j == target ) {
				target = _i-1;
			}
		}
		//core
		var _p = iarr[pos];//记录元副本
		if( pos>target ) {
			if(!t) {
				target++;
			}
			for(var i=pos;i>=0;i--) {
				if(i == target) {
					iarr[i] = _p;
					break;
				}
				iarr[i] = iarr[i-1];
			}
		} else if( pos<target ) {
			if(t) {
				target--;
			}
			for(var i=pos;i<=target;i++) {
				
				if( i == target ) {
					iarr[i] = _p;
				} else {
					iarr[i] = iarr[i+1];
				}	
			}
		}
		//字符下标
		
		var new_arr = __arr;
		new_arr.length = 0;
		//new_arr.push.apply(new_arr,_iarr); //不建议用 因为 _iarr 会有长度限制 63444
		var k=0,
			len = iarr.length;
		for( ;k<len;k++ ) {
			new_arr.push( _iarr[ iarr[k] ] );
		}
		iarr = new_arr;
		return iarr;
	},
	/*
	*删除数组元素 index 为下标或者下标数组 或者回调函数 回调返回true即可
	*/
	array_splice : function(index,arr){
		var self = this,undef;
		if( !$.isArray( arr ) ) return arr;
		
		var call = index;
		
		if( $.isArray( index ) && index.length<=1 ) {
			index = index[0];
		}
		
		if( index === undef ) return arr;
		
		//如果index 不是数组或者不是回调时 直接调用splice;
		if( !$.isArray( index ) && !$.isFunction(index) ) {
			if( isNaN( parseInt( index ) ) ) return arr;
			arr.splice( parseInt(index),1 );
			return arr;
		}
		
		var _arr = self.copy( arr );
		var index = $.isArray( index ) ? index : ($.isFunction(index) ? [] : [index]);
		var _index = {};
		$.each(index,function(i,v){
			_index[v] = true;	
		});
		
		arr.length = 0;
		
		$.each( _arr,function(i,v){
			if( $.isFunction( call ) ) {
				var r = call.call(v,i,v);	
				if( r === true ) {
					_index[i] = true;	
				}
			}
			if( !(i in _index) ) {
				arr.push(v);	
			}	
		} );
		
		return arr;
	},
	/*				
	*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面 _arr 长度不要超过6W+
	*/
	array_insert : function(index,_arr,arr,t){
		var self = this,
			undef,
			t = t === undef ? 0 : t;
		if( !$.isArray( arr ) ) return arr;
		
		var call = index;
		
		if( !$.isArray( _arr ) ) _arr = [ _arr ];
		
		if( index === undef ) return arr;
		
		var len = arr.length;
		if( index<len ) {
			if( t )	{
				_arr = _arr.concat( [ arr[index] ] );	
			} else {
				_arr = [ arr[index] ].concat( _arr );
			}
		}
		_arr = [index,1].concat( _arr );
		arr.splice.apply(arr,_arr);
		return arr;
	},
	array_clear : function(arr){
		arr.length = 0;
		return arr;
	},
	array_copy : function(arr){
		var _ = [];
		return _.concat( arr );	
	},
	//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
	copyArray : function(arr){
		var _ = [];
		return _.concat( arr );
	},
	//copy只是对数组或对象只是增加一个引用计数，并不是深复制
	copy : function(data){
		if( $.isArray( data ) ) {
			return  [].concat(data);	
		} else if( $.isPlainObject(data) ) {
			return $.extend({},data);
		} else {
			return data;	
		}
	},
	str_number : function(num,elc){//elc 截取的小数位
		var num = num + '';
		if( $.type( num ) === 'string' ) {
			var n = num.split('.');
			if( n.length>1 ) {
				var ext = n[1].substring(0,elc);	
				if( ext !== '' ) {
					num = [n[0],ext].join('.');	
				} else {
					num = n[0];
				}
			}	
		}
		return Number(num);
	},
	/*
	*判断元素垂直滚动条是否滚动到底 @dom
	*/
	_checkYScrollEnd : function( el ){
		var scrollTop = 0;
		var clientHeight = 0;
		var scrollHeight = 0;	
		if( el === document.body || el === document || el === window ) {
			if (document.documentElement && document.documentElement.scrollTop) {
				scrollTop = document.documentElement.scrollTop;
			} else if (document.body) {
				scrollTop = document.body.scrollTop;
			}
			if (document.body.clientHeight && document.documentElement.clientHeight) {
				clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
			} else {
				clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
			}
			scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
		} else {
			if( !el.nodeType ) return false;
			scrollTop = el.scrollTop;
			clientHeight = el.clientHeight;
			scrollHeight = el.scrollHeight;
		}
		if( clientHeight >= scrollHeight ) {
			return false;
		} else if (scrollTop + clientHeight >= scrollHeight) {//必须要使用>= 因为缩放后会大于scrollHeight
			return true;
		} else {
			return false;
		}	
	},
	/*
	*判断元素水平滚动条是否滚动到底 @dom
	*/
	_checkXScrollEnd : function( el ){
		var scrollLeft = 0;
		var clientWidth = 0;
		var scrollWidth = 0;	
		if( el === document.body || el === document || el === window ) {
			if (document.documentElement && document.documentElement.scrollLeft) {
				scrollLeft = document.documentElement.scrollLeft;
			} else if (document.body) {
				scrollLeft = document.body.scrollLeft;
			}
			if (document.body.clientWidth && document.documentElement.clientHeight) {
				clientWidth = (document.body.clientWidth < document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
			} else {
				clientWidth = (document.body.clientWidth > document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
			}
			scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
		} else {
			if( !el.nodeType ) return false;
			scrollLeft = el.scrollLeft;
			clientWidth = el.clientWidth;
			scrollWidth = el.scrollWidth;
		}
		if( clientWidth >= scrollWidth ) {
			return false;
		} else if (scrollLeft + clientWidth >= scrollWidth) {//必须要使用>= 因为缩放后会大于scrollWidth
			return true;
		} else {
			return false;
		}		
	},
	/*
	*验证是否滚动到低 @el dom @a left/top
	*/
	isScrollEnd : function( el,a ){
		var self = this,
			undef;
		if( a == 'left' ) {
			return self._checkXScrollEnd( el );	
		} else {
			return self._checkYScrollEnd( el );		
		}
	},
	/*
	*判断是否出现滚动条
	* @param el dom
	* @param a left top
	* @param t boolean defalut:false 如果t=true则只要超出宽度就会认定有滚动条，但是未必有滚动条一般拿来检测是否子节点的宽度大于父节点
	*/
	hasScroll: function( el, a, t ) {
		
		var el = $(el)[0];//el 是dom
		
		//If overflow is hidden, the element might have extra content, but the user wants to hide it
		/*
		//IE下 只要overflow-x/overflow-y设置了hidden那么获得的overflow就是hidden 所以我们要只取-x -y
		if ( $( el ).css( "overflow" ) === "hidden") {
			return false;
		}
		*/
		if( t !== true ) {
			if( a === "left" ) {
				if ( $( el ).css( "overflow-x" ) === "hidden") {
					return false;
				}
			} else {
				if ( $( el ).css( "overflow-y" ) === "hidden") {
					return false;
				}	
			}
		}
		var scroll = ( a && a === "left" ) ? "scrollLeft" : "scrollTop",
			has = false;
		if ( el[ scroll ] > 0 ) {
			return true;
		}
		// TODO: determine which cases actually cause this to happen
		// if the element doesn't have the scroll set, see if it's possible to
		// set the scroll
		el[ scroll ] = 1;
		has = ( el[ scroll ] > 0 );
		el[ scroll ] = 0;
		return has;
	},
	//工具集合
	util : {},
	addUtil : function(n,v){
		return this.util[n] = v;	
	},
	getUtil : function(n){
		return this.util[n];	
	},
	extendUtil : function(n,v){
		return $.extend( this.util[n],v );
	},
	removeUtil : function(){
		this.util[n] = null;
		delete this.util[n];
		return this;
	},
	//所有组合mixins
	mixins : {},
	addMixins : function( n,v ){
		v = $.isFunction( v ) ? v.call( this ) : v;
		return this.mixins[n] = v;	
	},
	getMixins : function(n){
		return this.mixins[n]	
	},
	extendMixins : function(n,v){
		return $.extend( this.mixins[n],v );
	},
	removeMixins : function(){
		this.mixins[n] = null;
		delete this.mixins[n];
		return this;
	},
	/*直接使用jquery 的Deferred对象 所以要使用when需要确定jquery版本支持Deferred*/
	when : function(){
		var arr = [].slice.apply(arguments);
		for( var i=0,len=arr.length;i<len;i++ ) {
			if( Nex.isXtype(arr[i]) ) {
				arr[i] = Nex.Create( arr[i] ).getDeferred();	
				continue;
			}
			if( Nex.isNex( arr[i] ) ) {
				arr[i] = arr[i].getDeferred();
				continue;	
			}
			if( $.type(arr[i])=='string' && Nex.getClass( arr[i] ) ) {//Nex.classes //( arr[i] in Nex )
				arr[i] = Nex.Create( arr[i] ).getDeferred();	
				continue;		
			}
		}
		return $.extend($.when.apply( $,arr ),{
			success : function(){
				this.done.apply( this,arguments )	
			},
			error : function(){
				this.fail.apply( this,arguments )	
			},
			complete : function(){
				this.always.apply( this,arguments )	
			}	
		});	
	},
	emptyFn : function(){},
	error : function( msg ){
		var undef,
			e = new Error((msg===undef?'':msg));
		throw e;
		return e;	
	}	
} );
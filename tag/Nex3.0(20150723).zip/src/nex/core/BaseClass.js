/*Base Class*/
(function(){
	"use strict";
	function Base(){
		this.init.apply( this,arguments );	
	};	
	var base = Base;
	
	Base.fn = Base.prototype = {};
	/*Base.constructor = */Base.prototype.constructor = Base;
	Base.prototype.superclass = null;
	Base.superclass = null;
	Base.init = function(){ return this; };
	
	Base.extend = function(obj){
		$.extend(this,obj);	
	};
	Base.extend({
		//标识当前函数是属于Nex类
		_isNexConstructor : true,
		_optionsList : [],
		setOptions : function( options ){
			if( $.isPlainObject( options ) ) {
				var _opts = options;
				options = function(){
					return $.extend(true,{},_opts);
				}
			}
			if( $.isFunction( options ) ) {
				this._optionsList.push( function( opt,t ){
					return options.call( this,opt,t );
				} );
			}
			return this;
		},
		getSuperClassOptions : function(t){
			var ptype = this.getSuperClassXType();
			if( !ptype ) {//ptype === null || 
				return {};	
			}
			return Nex.getClass(ptype).getOptions(t);
		},
		getOptions : function(self){
			var list = this._optionsList || [];
			var opt = {};
			var len = list.length;
			if( len ) {
				for( var i=0;i<len;i++ ) {
					var o = list[i];
					$.extend( opt, o.call(this,opt,self||this)  );	
				}
			}
			return opt;
		},
		_undef : function (val, defaultVal) {
			return val === undefined ? defaultVal : val;
		},
		getSuperClassXType : function(){
			return null;	
		},
		getSuperClass : function(){
			return this.superclass;	
		},
		/*
		*调用当前类的API 
		*@param method api名称
		*@param scope 作用域
		*@param data 数组参数
		*/
		invokeMethod : function( method,scope,data ){
			var obj = this;
			var func = obj.fn[method];
			if( func && $.isFunction( func ) ) {
				return func.apply( scope,$.isArray(data) ? data : [ data ] );
			}
			return;
		},
		/*
		*调用父类的API
		*@param method api名称
		*@param scope 作用域
		*@param data 数组参数
		*/
		//无效--
		_super : function( method,scope,data ){
			var _super = this.superclass;
			if( !_super ) return;
			var func = _super.fn[method];
			if( func && $.isFunction( func ) ) {
				return func.apply( scope,$.isArray(data) ? data : [ data ] );
			}
			return;
		},
		setXType : function(xtype){
			var b = this,
				undef;
			if( xtype === undef ) return b;
			
			b.getXType = function(){
				return xtype;	
			};
			b.fn.getXType = function(){
				return xtype;	
			};
			
			Nex.classes[ xtype ] = b;
			
			return b;	
		},
		getXType : function(){
			return xtype;	
		},
		setAliasName : function( aliasName ){
			var self = this;
			if( aliasName ) {
				var __psc = Nex.__psc;
				Nex.__psc = true;
				var aliasNames = $.trim(aliasName).split(/\s+/g);
				$.each( aliasNames,function(i,n){
					Nex.setNamespace( n,self );
					Nex.addClass( n,self );
				} );
				Nex.__psc = __psc;
			}	
			return self;
		},
		create : function( opt ){
			return new this(opt||{});	
		},
		_Tpl : {}
		
	});
	/*参数设置*/
	Base.setOptions( function( opt ){
		return {
			$className : 'Base',
			_base : Base,
			prefix : 'nex_',
			id : '',
			//autoRender自动渲染 会自动调用_init
			autoRender : true,//--由于部分组件没有继承html 直接继承 base 所以有些属性 还是放在base 如果后面统一后再做修改
			renderAfter : true,//true:append false:prepend
			_isInit : false,
			_isResize : false,
			//设备上下文，慎用
			context : null,
			parent : null,//指定父组件的ID 如果不指定则自动获取
			//stopOnFalse : true,
			denyManager : false,//不受Manager管理组件 不建议开启
			//autoDestroy 自动回收机制 如果Nex在触发检查的时候检查不到当前元素存在时如果开启后就删除当前组件，所以如果你创建的是一个服务那就应该设为false
			autoDestroy : true,//自动回收 回收后通过Nex.get获取不到组件  autoRecovery
			autoSetResize : false,//是否根据用户的width height 自动设置autoResize --尚未实现
			autoResize : false, //接受Manager的resize调整
			autoScroll : false,
			groupName : '',//组件分组，一般有批量sendMessage 时会使用到
			//resizeOnHidden : Nex.resizeOnHidden,//作废
			//cls : '',
			//cutHeight : 0,
			//cutWidth : 0,
			deferred : $.Deferred ? $.Deferred() : null,
			autoSize : false,
			//width : '100%',
			//height : '100%',
			//maxWidth : 0,
			//maxHeight : 0,
			//minHeight : 0,
			//minWidth : 0,
			//realWidth : null,//实际 ,width=auto时 如果max min width height 没起作用那么realWidth = auto
			//realHeight : null,//同上
			//_width : null,//和realWidth 不同的是 _width是一个数值
			//_height : null,
			//__width : 0,
			//__height : 0,
			tpl : {},
			template : Nex.getTemplate(),//typeof template === 'undefined' ? Nex.template : template,//模板引擎对象
			//scrollbarSize : false,
			noop : $.noop,
			self : null,
			init : $.noop,//初始化调用
			renderTo : null,//helper
			views : {},
			defalutType : 'panel',//默认items的xtype 可通过defaluts覆盖
			defaluts : {},
			items : [],
			isEscape : false,
			cacheData : {},
			//_childrenList : [],//当前组件下的之组件，并不严禁， 一般做清除用
			_boxModel : true
			//eventMaps : {},
			//events : {}//事件组合 	
		};	
	} );
	
	Base.fn.extend = function(obj,overrides){
		var overrides = overrides === undefined ? true : overrides;
		if( $.isFunction( obj ) ) {
			obj = obj();	
		}
		if( typeof obj !== 'object' ) {
			return;	
		}
		if( 'configs' in obj && obj.configs ) {
			var configs = obj.configs;
			delete obj.configs; 	
			//setOptions
			this.constructor.setOptions( configs );
		}
		if( overrides ) {
			$.extend(this,obj);
		} else {
			for( var k in obj ) {
				if( k in this ) continue;
				this[k] = obj[k];	
			}
		}
	};
	
	Base.fn.extend( {
		//标识当前对象是Nex对象实例
		_isNex : true,
		getSuperClassXType : function(){
			return null;	
		},
		getSuperClass : function(){
			return this.superclass;	
		},
		getXType : function(){
			return xtype;	
		},
		//动态添加组合 动态组合的参数不会覆盖原有参数和方法，因为会把重复的参数和方法当作用户重载
		addMixins : function( d,dep ){
			var self = this;
			var opt = this.configs;
			var mconfigs = {};
			
			if( $.isFunction( d ) ) {
				d = d();	
			}
			if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
				d = Nex.getMixins( d );
			}
			
			//组合对象的configs也会被当作组件的参数
			if( $.isPlainObject( d ) && !$.isEmptyObject( d ) ) {
				d = $.extend( true,{},d );
				if( 'configs' in d && d.configs ) {
					mconfigs = $.extend(true,{},d.configs);
					delete d.configs; 	 	
				}
				for( var p in mconfigs ) {
					if( !dep && (p in opt) ) {
						continue;	
					}	
					opt[p] = mconfigs[p];//应该使用复制
				}
				for( var m in d ) {
					if( !dep && (m in self) ) {
						continue;	
					}	
					self[m] = d[m];//应该使用复制
				}
			}
			return self;
		},
		initConfigs : function(){
			var self = this;
			var argvs = [].slice.apply(arguments);
			var constructor = self.constructor;
			var opts = constructor.getOptions( self );
			var configs = $.extend({},opts);
			for( var i=0,len = argvs.length;i<len;i++ ) {
				var options = argvs[i];
				if( $.isFunction( options ) ) {
					options = options.call( self,configs ) || {};	
				} else {
					options = $.extend( {},options );//防止options不是一个对象 这里不建议深复制 因为怕大数据带来性能问题
				}
				//这里的event 不会被覆盖 --- 这里是否会有问题呢？
				//self.initEvents(options);//初始化用户自定义事件
				$.extend( configs,options );
			}
			//事件只初始化一次把， 会被后面的覆盖
			self.initEvents(configs);//初始化用户自定义事件
			
			if( Nex.isNex(configs.parent) ) {
				var pid = configs.parent.C('id');
				configs.parent = pid;	
			}
			
			self.configs = configs;
			
			if( 'mixins' in configs ) {
				var mixins = configs.mixins;
				delete configs.mixins;
				mixins = $.isArray( mixins ) ? mixins : [mixins];
				for( var t=0,n = mixins.length;t<n;t++ ) {
					 self.addMixins( mixins[t] );
				}
			}
			
			/*如果参数中有prototype,则当前属性会赋值到当前对象的prototype*/
			var prototype = configs.prototype;
			configs.prototype = null;
			delete configs.prototype;
			
			if( prototype && $.isFunction( prototype ) ) {
				prototype = prototype.call( self,configs );
			}
			
			if( prototype && $._isPlainObject( prototype ) ) {
				$.extend( self,prototype );	
			}
			
			return self;
		},
		init : function(options) {
			var self = this;
			var argvs = [].slice.apply(arguments);
			
			//var constructor = self.constructor;
			self.initConfigs.apply( self,argvs );
			var opt = self.configs;
			opt.self = self;

			self._eventLocks = {};
			self._executeEventMaps = {};

			opt.id = opt.id || self.getId();
			
			opt._isInit = true;
			
			$.support.boxModel = $.support.boxModel === null ? opt._boxModel : $.support.boxModel;
			
			if( opt.autoRender ) {
				self._render();
			}
		},
		_init : function(){},
		//private
		rendered : false,
		_render : function( el,after ){
			var self = this;
			var opt = this.configs;
			//如果已经渲染则不能重复渲染
			if( this.rendered ) {
				return this;	
			}
			var el = this._undef( el,opt.renderTo );
			var after = this._undef( after,opt.renderAfter );
			
			opt.renderTo = el;	
			opt.renderAfter = after;	
			
			//系统初始化调用
			if( $.isFunction( opt.init ) && opt.init!==$.noop ) {
				opt.init.call(self,opt);
			}
			
			//系统事件绑定
			self.sysEvents();
			
			self._onStart(opt);//设置用户自定义事件
			//这些应该是html组件信息 等所有组件都继承html后可以修改
			//保存初始设置值
			opt.__width = opt.width;
			opt.__height = opt.height;
			
			this.fireEvent("onStart",[opt]);
			
			//设置状态， 已经渲染
			this.rendered = true;
			//添加组件到组件管理器
			if( !opt.denyManager && Nex.Manager ) {
				Nex.Manager.addCmp( opt.id,self );
			}
			//此处应该触发onRender事件 or onAfterRender onBefreoRender
			opt.cls = 'nex-component-item '+opt.cls;
			
			this._init( opt );
			
			return this;	
		},
		render : function( el,after ){
			if( this.rendered ) {
				this.renderTo.apply( this,arguments );
			} else {
				this._render.apply( this,arguments );	
			}
			return this;	
		},
		//判断是否render
		isRendered : function(){
			return this.rendered;	
		},
		_checkToRender : function(){
			if( !this.rendered ) {
				this.render();	
			}	
		},
		/*
		* @m default=false true(更新层级关系)
		*/
		enableAutoResize : function(  ){	
			this.configs.autoResize = true;
			return this;
		},
		/*
		* @m default=false true(更新层级关系)
		*/
		disabledAutoResize : function( m ){
			this.configs.autoResize = false;
			return this;
		},
		//数组移动算法
		// pos 要移动的元素
		array_move : Nex.array_move,
		/*
		*删除数组元素 index 为下标或者下表数组 或者回调函数 回调返回true即可
		*/
		array_splice : Nex.array_splice,
		/*				
		*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面
		*/
		array_insert : Nex.array_insert,
		array_clear : Nex.array_clear,
		array_copy : Nex.array_copy,
		//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
		copyArray : Nex.copyArray,
		//copy只是对数组或对象只是增加一个引用计数，并不是深复制
		copy : Nex.copy,
		
		str_number : Nex.str_number,
		_undef : function (val, d) {
			return val === undefined ? d : val;
		},
		distArr : function( arr ){
			var obj={},temp=[];
			for(var i=0;i<arr.length;i++){
				if(!obj[arr[i]]){
					temp.push(arr[i]);
					obj[arr[i]] =true;
				}
			}
			return temp;	
		},
		//只接受 字符串 number 
		inArray : function(elem,arr){
			if( $.type( elem ) === 'number' ) {
				elem = elem+'';	
			}
			if ( arr ) {
				var len = arr.length;
				var i = 0;
				for ( ; i < len; i++ ) {
					// Skip accessing in sparse arrays
					var v = arr[ i ];
					if( $.type( v ) === 'number' ) {
						v = v+'';	
					}
					if ( i in arr && (v === elem) ) {
						return i;
					}
				}
			}
			return -1;
		},
		resize : function(){
			var self = this;
			var opt = self.configs;
			if( Nex.Manager ) {
				setTimeout(function(){
					Nex.Manager.fireEvent("onResize",[opt.id]);		
				},0);
			}	
		},	
		__ars : true,
		//判断当前组件是否接受autoResize
		isAcceptResize : function(){
			var opt = this.configs;
			return opt.autoResize && this.__ars;	
		},
		setAcceptResize : function(m){
			var m = m === undefined ? true : m;
			this.__ars = !!m;
			return this;	
		},
		/*
		*组件参数设置和获取
		*/
		C : function(key,value){
			if( typeof key == 'undefined') {
				return this.configs;	
			}
			if( typeof value == 'undefined' && typeof key !== 'object' ) {
				return this.configs[key];
			}
			if( $.isFunction( value ) ) {
				this.configs[key] = value.call( this,this.configs[key] );	
			} else if( $.isPlainObject( key ) ) {
				var conf = key;
				var opt = this.configs;
				
				if( value ) {
					$.extend( opt,conf );
					return this;	
				}
				
				for (var k in conf) {
					var newValue = conf[k];
					var oldValue = opt[k];
	
					if ( $.isArray( oldValue ) ) {
						oldValue.push.apply(oldValue, newValue);
					} else if ($.isPlainObject( oldValue )) {
						$.extend( oldValue, newValue)
					} else {
						opt[k] = newValue;
					}
				}
			} else {
				this.configs[key] = value;
			}
			return this;
		},
		set : function(){
			return this.C.apply(this,arguments);	
		},
		get : function(){
			return this.C.apply(this,arguments);	
		},
		setConfig : function(){
			return this.C.apply(this,arguments);		
		},
		getConfig : function(){
			return this.C.apply(this,arguments);		
		},
		/**
		 * 模板处理函数(用户自定义模版级别最高,其次模板函数,最后_Tpl中的模版)
		 *  @tpl {String,Function} 模板内容
		 *  @data {Object} 模板数据 如果tpl是Function data不一定需要Object
		 *  @return {String} 模板内容
		 */
		tpl : function(tpl,data){
			
			var self = this;
			var opt = self.configs;
			var constructor = self.constructor;
			if( typeof tpl == 'undefined' ) tpl = "";
			if( typeof data == 'undefined' ) data = {};
			
			var _tpl_ = {};
			if( typeof opt.cacheData['_tpl_'] == 'undefined' ) {
				opt.cacheData['_tpl_'] = {};
				_tpl_ = opt.cacheData['_tpl_'];
			} else {
				_tpl_ = opt.cacheData['_tpl_'];
			}
			
			var argvs = [];
			var len = arguments.length;
			for( var i=2;i<len;i++ ) {
				argvs.push( arguments[i] );	
			}
			var argvs = [data].concat( argvs );
			
			var html = "";
			
			if( !opt.template ) {
				if( $.isFunction(tpl) ){
					html = tpl.apply(self,argvs);
				} else if( tpl in self ) {
					html = self[tpl].apply(self,argvs);
				} else {
					html = 	tpl;
				}
				return html;
			}
			
			opt.template.isEscape = opt.isEscape;
			
			if( $.isFunction(tpl) ){
				html = tpl.apply(self,argvs);
			}else if( tpl in opt.tpl && opt.tpl[tpl] ) {
				if( opt.tpl[tpl] in _tpl_ ) {
					var render = _tpl_[ opt.tpl[tpl] ];
					html = render.apply(self,argvs);
				} else {
					var render = opt.template.compile( opt.tpl[tpl] );
					
					_tpl_[ opt.tpl[tpl] ] = render;
					
					html = render.apply(self,argvs);		
				}
			} else if( tpl in self ) {
				html = self[tpl].apply(self,argvs);
			} else if( tpl in constructor._Tpl && constructor._Tpl[tpl] ) {
				if( constructor._Tpl[tpl] in _tpl_ ) {
					var render = _tpl_[ constructor._Tpl[tpl] ];
					html = render.apply(self,argvs);
				} else {
					var render = opt.template.compile( constructor._Tpl[tpl] );
					
					_tpl_[ constructor._Tpl[tpl] ] = render;
					
					html = render.apply(self,argvs);		
				}
			} else {
				if( tpl.toString() in _tpl_ ) {
					var render = _tpl_[ tpl.toString() ];
					html = render.apply(self,argvs);
				} else {
					var render = opt.template.compile( tpl.toString() );
					
					_tpl_[ tpl.toString() ] = render;
					
					html = render.apply(self,argvs);		
				}
			}
			return html;
		},
		/*
		*  调用当前对象里的某个API，但是不会触发里面的事件(部分函数除外例如setGridBody,因为里面事件通过计时器触发)
		*  @param1 {String} 需要调用的API
		*  @param2~N 被调用的API参数(可选)
		*/
		denyEventInvoke : function(){//method,arg1,arg2....
			var self = this;
			var r;
			if( arguments.length ){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push(arguments[i]);	
				}
				var method = argvs[0];
				if( method in self ) {
					self._denyEvent = true;
					argvs.splice(0,1);
					r = self[method].apply(self,argvs);
					self._denyEvent = false;
				}
			}
			return r;
		},
		/*
		* API调用管理,作用在于通过该函数调用的会过滤被锁定的函数
		*  @param1 {String} 需要调用的API
		*  @param2~N 被调用的API参数(可选)
		*/
		methodInvoke : function(){//method,arg1,arg2....
			var self = this;
			var r;
			
			var methodLocks = self._methodLocks || {};
			
			if( arguments.length ){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push(arguments[i]);	
				}
				var method = argvs[0];
				
				if( methodLocks[method] ) {
					return;	
				}
				
				if( method in self ) {
					argvs.splice(0,1);
					r = self[method].apply(self,argvs);
				}
			}
			return r;
		},
		/*
		* 锁定API
		*  @method {String} API名
		*/
		lockMethod : function(method){
			var self = this;	
			//事件锁
			var methodLocks = self._methodLocks || {};
			methodLocks[method] = true;
			self._methodLocks = methodLocks;
			return true;	
		},
		/*
		* 取消锁定API
		*  @method {String} API名
		*/
		unLockMethod : function(method){
			var self = this;	
			//事件锁
			var methodLocks = self._methodLocks || {};
			methodLocks[method] = false;
			self._methodLocks = methodLocks;
			return true;	
		},
		__sleep : false,
		isSleep : function(){
			return this.__sleep;	
		},
		//睡眠 睡眠后无法通过sendMessageToGroup给组件发送消息 并不会影响fireEvent
		sleep : function(){
			this.__sleep = true;
			return this;	
		},
		//唤醒
		wakeup : function(){
			this.__sleep = false;
			return false;
		},
		loadPuglins : function(){
			/*var self = this;
			var constructor = self.constructor;
			$.each( constructor.puglins,function(i){
				if( $.isFunction( this ) )
					this.call(self);									
			} );*/
		},
		initEvents : function(opt){
			var self = this;
			var e = opt.events ? opt.events : {};
			opt.events = {};
			var events = {};
			if( $.isPlainObject(e) && !$.isEmptyObject(e) ) {
				for(var i in e){
					var _evt = String(i),
						fn = e[i],
						context = null;	
					if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
						context = fn.scope || fn.context || null;
						fn = fn.func || fn.fn || fn.callBack || fn.callback;
					}
					if( $.isFunction( fn ) && fn !== $.noop ) {
						self.bind(_evt,fn,context);	
					}
				}
			}
			//opt.events = events;
		},
		sysEvents : function(){
			var self = this;
			var opt = self.configs;
			//系统事件 注意：顺序不可随意更改
			if( '_sysEvents' in self ) {
				self._sysEvents();
			}
			
			//self.bind("onStart._sys",self.loadPuglins,self);	
		},
		generateMixed : function(n){
			 return Nex.generateMixed( n );	
		},
		_getId : function(){
			var aid = Nex.aid++;
			var self = this;
			var opt = self.configs;
			return opt.prefix + aid;	
		},
		getId : function(){
			if( this.configs.id === '' || this.configs.id === null || this.configs.id === undefined ) {
				return this._getId();	
			}
			return this.configs.id;	
		},
		//获取组件的父级组件
		getParent : function(  ){
			var el = this.getDom(),
				opt = this.configs,
				cmp = null;
			if( !el.length ) return cmp;
			if( opt.parent !== null ) {
				if( Nex.isNex( opt.parent ) ) {
					return opt.parent;	
				}
				var _p = Nex.get(opt.parent);
				if( _p ) return _p;
			}
			var p = el.parent('.nex-component-item'),
				_id = p.attr('id');
			cmp = _id ? Nex.get(id) : null;
			return cmp ? cmp : null;
		},
		unique : function(n){
			return Nex.unique(n);	
		},
		isNumber : function(value) {
			return Nex.isNumber( value );	
		},
		/*
		*系统事件
		*/
		_onStart : function(){
			var self = this;
			var opt = self.configs;
			var e = opt.events ? opt.events : {};
			var reg = /^@?on[A-Z][\S|\.]*$/;///^@?on[A-Z][\w|\.]*$/
			for(var x in opt ) {
				if( reg.test(x) ) {
					var fn = opt[x],
						context = null;
					
					if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
						context = fn.context || fn.scope || null;	
						fn = fn.func || fn.fn || fn.callBack || fn.callback;
					}
					if( $.isFunction(fn) && fn !== $.noop ){
						self.bind(x,fn,context);	
					}
				}
			}
		},
		isNexConstructor : function(obj){
			return  Nex.isNexConstructor( obj );
		},
		isNex : function(obj){
			return  Nex.isNex( obj );
		},
		isXtype : function(obj){
			return Nex.isXtype( obj );
		},
		isjQuery : function(obj){
			return Nex.isjQuery( obj );
		},
		//m @true 默认删除本身, false 删除子元素
		removeCmp :  function(m){
			var self = this,undef;
			var m = m === undef ? true : m;
			var opt = self.configs;
			//opt._childrenList.length = 0;
			if( Nex.Manager ) {
				Nex.gc();
			}
		},
		/*
		*移除组件 最好需要重载
		*/
		destroy : function( m ){
			this.removeCmp( m );
			return this;
		},
		getChildrens : function(){
			var opt = this.configs;
			return Nex.Manager.getChildrens( opt.id );	
		},
		getAllChildrens : function(){
			var opt = this.configs;
			return Nex.Manager.getAllChildrens( opt.id );	
		},
		getDeferred : function(){
			var opt = this.configs;
			return opt.deferred;
		}
	} );
	
	Base.fn.extend( Nex.createEventObject() );
	
	//Nex[name] = base;	
	Nex.classes[ 'Base' ] = Base;
	Nex.Base = Base;
})();
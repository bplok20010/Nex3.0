/*
Nex.base
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
v1.0
1.修正继承 fix不能继承父对象的所有属性 bug 严重
2.修正当_optionsList为空时，不在继承父级属性BUG 严重
3.新增getTemplate 返回一个模版对象实例 ,以前的template 不再建议，
4.新增baseUrl
5.新增deferred 和 getDeferred方法
6.修正由于继承时大部分属性和方法都是从父类直接copy过去 所有出现部分方法的变量还是父类的内容
7.通过参数绑定事件时可使用对象来设置上下文 { func,scope }
8.新增Nex.require API提供组件依赖加载
*/
/*********************
********Nex核心*******
*********************/
var Nex = Nex || {};
(function(win,$){
	"use strict";	
	var userAgent = navigator.userAgent.toLowerCase();
	var uaMatch = /msie ([\w.]+)/.exec( userAgent ) || [];
	function getCurrentScript(h) {
		var stack,
			DOC = document,
			undef,
			h = h === undef ? true : false,
			head = DOC.getElementsByTagName("head")[0]
			;
		try {
		  a._b.c(); //强制报错,以便捕获e.stack
		} catch (e) { //safari的错误对象只有line,sourceId,sourceURL
		  if( e.sourceURL ) {
			return e.sourceURL; //safari
		  }
		  stack = e.stack;
		  if (!stack && window.opera) {//opera
			  //opera 9没有e.stack,但有e.Backtrace,但不能直接取得,需要对e对象转字符串进行抽取
			  stack = (String(e).match(/of linked script \S+/g) || []).join(" ");
		  }
		}
		if (stack) {//chrome
		  stack = stack.split(/[@ ]/g).pop(); //取得最后一行,最后一个空格或@之后的部分
		  stack = stack[0] === "(" ? stack.slice(1, -1) : stack.replace(/\s/, ""); //去掉换行符
		  return stack.replace(/(:\d+)?:\d+$/i, ""); //去掉行号与或许存在的出错字符起始位置
		}
		//IE
		var context = h ? head : DOC;
		var nodes = context.getElementsByTagName("script");
		for (var i = nodes.length, node; node = nodes[--i]; ) {
		  if ( node.readyState === "interactive") {
			  return node.src;//node.className = 
		  }
		}
	}
	var baseUrl = getCurrentScript( false );
	baseUrl = baseUrl.split('/');
	baseUrl.pop();
	baseUrl = baseUrl.join('/');
	//baseUrl = baseUrl ? baseUrl+'/':baseUrl;
	/*如果是IE浏览器 加上各版本样式*/
	$(document).ready(function(){
		if( Nex.isIE && Nex.IEVer ) {
			var cls = ['nex-ie'];
			var bd = $(document.body);
			cls.push( 'nex-ie'+Nex.IEVer );
			if( Nex.IEVer<8 ) {
				cls.push( 'nex-ielt8' );
			}
			if( Nex.IEVer<9 ) {
				cls.push( 'nex-ielt9' );
			}
			bd.addClass( cls.join(' ') );
		}
	});
	
	Nex.apply = function( obj ){
		if( obj ) {
			$.extend( this, obj );	
		}	
	};
	//common
	Nex.apply( {
		userAgent : userAgent,
		aid : 1,
		tabIndex : 1,
		zIndex : 99999,
		topzIndex : 99999999,
		scrollbarSize : false,
		resizeOnHidden : true,	
		/*
		*根据参数返回模版对象
		*@param {Object} o ltag rtag simple(简单模式) 
		*@return {Object}
		*/
		getTemplate : function( o ){
			var o = o || {};
			return {
				cache1 : {},
				cache2 : {},
				helper : $.noop,//兼容用
				ltag : o.ltag || '<%',
				rtag : o.rtag || '%>',
				simple :  o.simple || false,
				compile1 : function(str, data){
					var fn = this.cache1[str] ? this.cache1[str] :
					 new Function("obj",
					"var p=[],print=function(){p.push.apply(p,arguments);};" +
					"with(obj){p.push('" +
					str
					  .replace(/[\r\t\n]/g, " ")
					  .split(this.ltag).join("\t")
					  .replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
					  .replace(new RegExp("\t=(.*?)"+this.rtag,"g"), "',$1,'")
					  .split("\t").join("');")
					  .split(this.rtag).join("p.push('")
					  .split("\r").join("\\'")
				  + "');}return p.join('');");
					this.cache1[str] = fn;
					return data ? fn( data ) : fn;
				},
				compile2 : function(str, data){//简单的模版
					var fn = this.cache2[str] ? this.cache2[str] :
					 new Function("obj",
					"var p=[],print=function(){p.push.apply(p,arguments);};" +
					"with(obj){p.push('" +
					str
					  .replace(/[\r\t\n]/g, " ")
					  .split(this.ltag).join("\t")
					  //.replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
					  .replace(new RegExp("\t(.*?)"+this.rtag,"g"), "',$1,'")
					  .split("\t").join("');")
					  .split(this.rtag).join("p.push('")
					  .split("\r").join("\\'")
				  + "');}return p.join('');");
					this.cache2[str] = fn;
					return data ? fn( data ) : fn;
				},
				compile : function(){
					if( this.simple ) {
						return this.compile2.apply(this,arguments);	
					} else {
						return this.compile1.apply(this,arguments);		
					}
				}	
			};	
		},
		/*
		*dirname
		*/
		dirname : function(baseUrl){
			baseUrl = baseUrl + '';
			baseUrl = baseUrl.split('/');
			baseUrl.pop();
			baseUrl = baseUrl.join('/');
			return baseUrl;
		},
		/*
		*private
		*safair不支持
		*/
		getcwd : function(h){
			return getCurrentScript(h);	
		},
		baseUrl : baseUrl,
		getCurrentScriptUrl : function(){
			return this.baseUrl;	
		},
		template : {
			cache : {},
			helper : $.noop,//兼容用
			ltag : '<%',//不能修改
			rtag : '%>',//不能修改
			compile : function(str, data){
				var fn = this.cache[str] ? this.cache[str] :
				 new Function("obj",
				"var p=[],print=function(){p.push.apply(p,arguments);};" +
				"with(obj){p.push('" +
				str
				  .replace(/[\r\t\n]/g, " ")
				  .split(this.ltag).join("\t")
				  .replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
				  .replace(new RegExp("\t=(.*?)"+this.rtag,"g"), "',$1,'")
				  .split("\t").join("');")
				  .split(this.rtag).join("p.push('")
				  .split("\r").join("\\'")
			  + "');}return p.join('');");
				this.cache[str] = fn;
				return data ? fn( data ) : fn;
			}
		},
		/*
		*返回随机字符串
		*@param {Number} 返回自定的长度的随机字符串 默认是6位
		*@return {String}
		*/
		generateMixed : function(n){
			var n = n || 6;
			var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
			var res = "";
			 for(var i = 0; i < n ; i ++) {
				 var id = Math.ceil(Math.random()*35);
				 res += chars[id];
			 }
			 return res;	
		},
		/*
		*返回一个不重复字符串,使用方法同generateMixed
		*/
		unique : function(n){
			var str = Nex.generateMixed(n||6);
			var aid = str+'-'+Nex.aid++;
			return aid;	
		},
		/*
		*判断是否数字格式
		*/
		isNumber : function(value) {
			return /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value) ? true : false;	
		},
		/*
		*检测当前对象是否是Nex类
		*/
		isNexConstructor : function(obj){
			return  $.type(obj) === 'function' && ('_isNexConstructor' in obj)  ? true : false;
		},
		/*
		*检测当前对象是否是Nex实例对象
		*/
		isNex : function(obj){
			return  $.type(obj) === 'object' && ('_isNex' in obj)  ? true : false;
		},
		/*
		*判断当前对象是否是xtype的对象类型 
		*/
		isXtype : function(obj){
			return ( $._isPlainObject( obj ) && ('xtype' in obj ) )	? true : false;
		},
		/*
		*检测是否是jquery实例
		*/
		isjQuery : function(obj){
			return $.type(obj) === 'object' && ('_outerWidth' in obj) ? true :　false;	
		},
		isElement : function(obj){
			return $.type(obj) === 'object' && (obj.nodeType === 1) ? true :　false;	
		},
		//所有Nex组件集合，目前Nex[className] 和 Nex.classes[className] 作用是一样的
		classes : {},
		getClass : function( cn ){
			return this.classes[cn];	
		},
		addClass : function( n,v ){
			this.classes[n] = v;
			return this;
		},
		_classesPaths : {},
		/*
		*动态加载组件时，设置组件路径
		*@param {String|Object} 组件名|组件和组件路径Map
		*@param {String} 组件路径
		*/
		setClassPath : function(){
			var self = this,
				argvs = arguments;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( self._classesPaths,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					self._classesPaths[argvs[0]] = argvs[1];
				}	
			}	
			return self;
		},
		/*
		*获取组件路径
		*@param {String} 组件名
		*@return {String} 组件路径
		*/
		getClassPath : function( n ){
			return this._classesPaths[n];	
		}
	} );
	//extend
	Nex.apply( {
		//把字符串转化成对象 并复制v
		setNamespace : function(str,v){
			var undef,
				t = window,
				s = str+'';	
			s = s.split('.');
			for( var i=0,len=s.length-1;i<len;i++ ) {
				var e = s[i];
				if( !(e in t) || !t[e] ) {
					t[e] = {};	
				}
				t = t[e];	
			}	
			t[s[i]] = v;
		},
		//继承组件 如果没指定superClass 默认superClass=Nex.widget()
		//subclass,superClass,overrides
		//superClass 这里只能是函数或者字符串
		extend : function(subclass,superClass,overrides){
			var undef,F = function(){};
			if( subclass === undef ) return F;
			var superClass = superClass === undef ? false : superClass;
			var overrides = overrides === undef ? {} : overrides;
			var subclassName = subclass,
				superClassName = superClass === false ? null : superClass;
			//不能继承到Nex
			if( subclass === 'Nex' ) {
				return Nex.Base;
			}
			var notExist = false;
			//如果不存在superClass 直接返回
			if( !superClass ) {
				superClass = Nex.Base;
				notExist = true;
			}
			//mixins
			//检查是否没设置overrides
			if( $._isPlainObject( superClass ) ) {
				overrides = superClass;	
				superClass = false;
				if( 'extend' in overrides && overrides.extend ) {
					superClass = overrides.extend;
					superClass = true;
					delete overrides.extend;
				}
			}
			if( Nex.isNexConstructor( superClass ) ) {
				
				superClass = superClass;
				
			} else if( superClass && Nex.getClass( superClass ) ) {//Nex.classes // (superClass in Nex)
				
				superClass = Nex.getClass( superClass );//Nex.classes
				
			} else {
				superClass = Nex.Base;
				notExist = true;
			}
			
			superClassName = notExist ? null : superClass.getXType();
			subclass = function() {
				//superClass.apply(this, arguments);
				this.superclass.apply( this, arguments );
			};
			Nex.classes[ subclassName ] = subclass;		
			//只复制数组和(深复制)对象
			var copy = function(data){
				if( $.isArray( data ) ) {
					return  [].concat(data);	
				} else if( $.isPlainObject(data) ) {
					return $.extend(true,{},data);
				} else {
					return data;	
				}
			};
			
			if( superClass ) {
				for( var k in superClass ) {
					subclass[k] = copy(superClass[k]);	
				}
				F.prototype = superClass.prototype;
				subclass.prototype = new F();
				subclass.prototype.superclass = superClass;
				subclass.prototype.$className = superClassName || 'Base';
				subclass.superclass = superClass;
			}
			//overrides 覆盖
			overrides = $.extend( {},overrides );
			var aliasName,configs,xtype,mconfigs = [];
			if( 'alias' in overrides && overrides.alias ) {
				aliasName = overrides.alias+'';
				delete overrides.alias; 	
			}
			if( 'configs' in overrides && overrides.configs ) {
				configs = overrides.configs;
				delete overrides.configs; 	
			}
			
			if( 'xtype' in overrides && overrides.xtype ) {
				xtype = overrides.xtype+'';
				delete overrides.xtype; 
			}
			var m_overrides = {};
			if( 'mixins' in overrides && overrides.mixins ) {
				overrides.mixins = $.isArray( overrides.mixins ) ? overrides.mixins : [overrides.mixins];
				$.each( overrides.mixins,function(i,d){
					if( $.isFunction( d ) ) {
						d = d( m_overrides );	
					}
					if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
						d = Nex.getMixins( d );
					}
					//组合对象的configs也会被当作组件的参数
					if( $.isPlainObject( d ) && !$.isEmptyObject( d ) ) {
						d = $.extend( true,{},d );
						if( 'configs' in d && d.configs ) {
							mconfigs.push( d.configs );
							delete d.configs; 	 	
						}
						$.extend( m_overrides,d );		
					}
				} );
				overrides.mixins.length = 0;
				delete overrides.mixins;
			}
			//overrides 可覆盖组合的属性
			overrides = $.extend( {},m_overrides,overrides );
			for( var m in overrides ) {
				subclass.prototype[m] = copy(overrides[m]);	
			}
			
			//清空父级的配置参数
			//subclass['_optionsList'] = [];
			
			/*getSuperClassXType设置*/
			subclass.prototype['getSuperClassXType'] = function(){
				return superClassName;
			};	
			subclass['getSuperClassXType'] = function(){
				return superClassName;
			};	
			/*getXType设置*/
			subclass.prototype['getXType'] = function(){
				return subclassName;
			};	
			subclass['getXType'] = function(){
				return subclassName;
			};

			subclass.prototype.constructor = subclass;
			//subclass.constructor = subclass;
			//兼容
			subclass.fn = subclass.prototype;
			
			//设置一个全局变量
			Nex.setNamespace( subclassName,subclass );
			
			if( aliasName ) {
				var aliasNames = $.trim(aliasName).split(/\s+/g);
				$.each( aliasNames,function(i,n){
					Nex.setNamespace( n,subclass );
					Nex.addClass( n,subclass );
				} );
			}
			if( xtype ) {
				var xtypes = $.trim(xtype).split(/\s+/g);
				$.each( xtypes,function(i,t){
					subclass.setXType(t);		
				} );
			}
			$.each( mconfigs,function(i,c){
				subclass.setOptions(c);	
			} );
			if( configs ) {
				subclass.setOptions(configs);		
			}
			
			return subclass;
		},
		define : function(){
			return this.extend.apply( this,arguments );	
		}	
	} );
	//EventObject
	Nex.apply( {
		createEventObject : function(){
			var Event = {
				configs : {
					context : null,
					stopOnFalse : true,
					/*
					*事件名映射：
					*	expamles : 
					*	Event.eventMaps.onWindowClick = 'onClick';
					*	Event.fireEvent('onWindowClick'); //实际触发的是onClick
					*	Event.bind('onWindowClick',func); //实际绑定的是onClick
					*/
					eventMaps : {},
					/*
					*事件列表
					* examples:
					*	events.onClick = [ {}... ]
					*/
					events : {}		
				},
				//绑定事件时,__eventIndex会自增
				__eventIndex : 1,
				/*
				* 事件绑定
				*  @eventType {String} 事件名
				*  @func      {Function|{ scope,fn }} 事件回调
				*  @scope     {Object} this对象(可选)
				*  @return    {int} 事件ID or false
				*/
				bind : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					if( eventType === '' || eventType === '@' ) {
						return false;	
					}
					var self = this;
					var opt = self.configs;
					var event = opt.events;
					//批量绑定支持
					if( $.type( eventType ) === 'object' ) {
						var ids = [];
						for( var ev in eventType ) {
							var context = scope;
							var fn = eventType[ev];
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.scope || fn.context || context;
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							var _i = self.bind( ev,fn,context );	
							ids.push( _i );
						}
						return ids;
					} else {//字符串 
						var _ev = String(eventType).split(/\s+|,/);	
						if( _ev.length>1 ) {
							var len = _ev.length;
							var ids = [];
							for( var _e=0;_e<len;_e++ ) {
								if( !_ev[_e] ) continue;
								ids.push( self.bind( _ev[_e],func,scope ) );
							}
							return ids;
						}					
					}
					
					var _f1 = eventType.charAt(0);
					if( _f1 === '@' ) {
						scope = self;
						eventType = eventType.slice(1);	
					}	
					
					var _type = eventType.split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');//_type.length == 2 ? _type[1] : '';
					
					if( !eventType ) {
						return false;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					event[eventType] = event[eventType] || [];
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
					}
					
					if( !$.isFunction( func ) || func === $.noop ) {
						return false;	
					}
					
					var _e = {
							scope : !!scope ? scope : null,
							func : func,
							ext : ext,
							_index : self.__eventIndex++
						};
					
					var id = event[eventType].push(_e);
				
					return _e._index;
				},
				on : function(){
					return this.bind.apply(this,arguments);	
				},
				/*
				*同bind 区别在于只执行一次
				*/
				one : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					var func = func || $.noop;
					var self = this;
					var scope = !!scope ? scope : self;
					
					var _ = function(){
							self.unbind(eventType,_.id);
							var r = func.apply(scope,arguments);
							return r;
						},
						id = null;
						
					id = self.bind( eventType,_,scope );
					_.id = id;
					return id;
				},
				/*
				* 取消事件绑定
				*  @eventType {String} 事件名,
				*  @id        Number 事件ID
				*/
				unbind : function(eventType,id){
					var self = this;
					var undef;
					var opt = self.configs;
					//...unbind('onClick onClick2.yrd')
					var _ev = String(eventType).split(/\s+|,/);	
					if( _ev.length>1 ) {
						var len = _ev.length;
						for( var _e=0;_e<len;_e++ ) {
							if( !_ev[_e] ) continue;
							self.unbind( _ev[_e] );
						}
						return self;
					}					
					
					var event = opt.events;
					var id = id === undef ? false : id;
					
					//...unbind(3)
					if( typeof eventType === 'number' ) {
						for( var tp in event ) {
							self.unbind( tp,eventType );	
						}
						return self;		
					}
					
					var _type = String(eventType).split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');
					//...unbind('.test')
					if( eventType === '' && ext !== '' ) {
						for( var tp in event ) {
							self.unbind( [tp,ext].join('.') );	
						}
						return self;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					if( !(eventType in event) ) {
						return self;	
					}
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
						return self;
					}
					var ves = [];
					if(id === false) {
						if( ext === '' ) {
							event[eventType] = [];
						} else {
							for(var i=0;i<event[eventType].length;i++) {
								var _e = event[eventType][i];
								if( (typeof _e === 'object') && _e.ext === ext ) {
									///event[eventType][i] = null;	
									continue;
								}
								ves.push( _e );
							}
						}
					} else {
						for(var i=0;i<event[eventType].length;i++) {
							var _e = event[eventType][i];
							if( (typeof _e === 'object') && _e._index === id ) {
								continue;
							}
							ves.push( _e );
						}
					}
					event[eventType] = ves;
					return self;
				},
				off : function(){
					return this.unbind.apply(this,arguments);	
				},
				/*
				* 锁定事件
				*  @eventType {String} 事件名
				*/
				lockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = true;
					self._eventLocks = eventLocks;
					return true;
				},
				/*
				* 取消锁定事件
				*  @eventType {String} 事件名
				*/
				unLockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = false;
					self._eventLocks = eventLocks;
					return true;
				},
				_eventLocks : null,
				_executeEventMaps : null,//正在的执行的事件
				/*
				* 事件触发
				*  @eventType {String} 事件名 如果事件名带@开头 说明当前事件是系统事件 不会因为睡眠而阻止
				*  @data      {Array} 事件参数(可选)
				*/
				fireEvent : function(eventType,data){
					var self = this;
					var undef;
					if( self._denyEvent ) {
						return;	
					}
					var opt = self.configs;
					
					var context = opt.context || self;
					
					var ct = String(eventType).charAt(0);
					var _sys = false;
					if( ct === '@' ) {
						_sys = true;
						eventType = String(eventType).slice(1);	
					}	
					
					if( !eventType ) {
						return;	
					}
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					var events = opt.events[eventType];
					var data = data === undef ? [] : data;
					
					//判断data 是否 arguments
					if( $.isArray( data ) ) {
						data = data;	
					} else if( $.type( data ) === 'object' ){
						if( 'callee' in data && 'length' in data ) {
							data = data	
						} else {
							data = [data];	
						}
					} else {
						data = [data];
					}
					//data = $.isArray( data ) ? data : [data];
					//添加事件锁
					var eventLocks = self._eventLocks || {};
					if( eventLocks[eventType] ) {
						return;	
					}
					self._executeEventMaps = self._executeEventMaps || {};
					//防止死循环事件
					if( self._executeEventMaps[eventType] ) {
						return;	
					}
					self._executeEventMaps[eventType] = true;
					
					var r = true;
					if($.isArray(events) ) {
						var len = events.length;
						for(var i=0;i<len;i++) {
							var _e = events[i];
							if( $.isPlainObject( _e ) ) {
								r = _e.func.apply(_e.scope || context,data);
							} else if( $.isFunction( _e ) ){
								r = _e.apply(self,data);
							}
							if( opt.stopOnFalse ) {
								if(r === false) break;	
							}
						}	
						
					} else if($.isFunction(events)) {
						r = events.apply(self,data);
					}
					
					self._executeEventMaps[eventType] = false;
					
					return r;
				},
				fire : function(){
					return this.fireEvent.apply(this,arguments);	
				}	
			};
			return Event;	
		}	
	} );
})(window,jQuery);

/*
*ExtJS 常用参数
*/
(function(){

    var check = function(regex){
            return regex.test(Nex.userAgent);
        },
		isStrict = document.compatMode == "CSS1Compat",
        version = function (is, regex) {
            var m;
            return (is && (m = regex.exec(Nex.userAgent))) ? parseFloat(m[1]) : 0;
        },
		docMode = document.documentMode,
        isOpera = check(/opera/),
        isOpera10_5 = isOpera && check(/version\/10\.5/),
        isChrome = check(/\bchrome\b/),
        isWebKit = check(/webkit/),
        isSafari = !isChrome && check(/safari/),
        isSafari2 = isSafari && check(/applewebkit\/4/), 
        isSafari3 = isSafari && check(/version\/3/),
        isSafari4 = isSafari && check(/version\/4/),
        isSafari5 = isSafari && check(/version\/5/),
        isIE = !isOpera && check(/msie/),
        isIE7 = isIE && ((check(/msie 7/) && docMode != 8 && docMode != 9) || docMode == 7),
        isIE8 = isIE && ((check(/msie 8/) && docMode != 7 && docMode != 9) || docMode == 8),
        isIE9 = isIE && ((check(/msie 9/) && docMode != 7 && docMode != 8) || docMode == 9),
        isIE6 = isIE && check(/msie 6/),
        isGecko = !isWebKit && check(/gecko/),
        isGecko3 = isGecko && check(/rv:1\.9/),
        isGecko4 = isGecko && check(/rv:2\.0/),
        isGecko5 = isGecko && check(/rv:5\./),
        isFF3_0 = isGecko3 && check(/rv:1\.9\.0/),
        isFF3_5 = isGecko3 && check(/rv:1\.9\.1/),
        isFF3_6 = isGecko3 && check(/rv:1\.9\.2/),
        isWindows = check(/windows|win32/),
        isMac = check(/macintosh|mac os x/),
        isLinux = check(/linux/),
        chromeVersion = version(true, /\bchrome\/(\d+\.\d+)/),
        firefoxVersion = version(true, /\bfirefox\/(\d+\.\d+)/),
        ieVersion = version(isIE, /msie (\d+\.\d+)/),
        operaVersion = version(isOpera, /version\/(\d+\.\d+)/),
        safariVersion = version(isSafari, /version\/(\d+\.\d+)/),
        webKitVersion = version(isWebKit, /webkit\/(\d+\.\d+)/),
        isSecure = /^https/i.test(window.location.protocol);

    
    try {
        document.execCommand("BackgroundImageCache", false, true);
    } catch(e) {}



    var nullLog = function () {};
    nullLog.info = nullLog.warn = nullLog.error = Nex.emptyFn;

    $.extend(Nex, {
        
		
        SSL_SECURE_URL : isSecure && isIE ? 'javascript:\'\'' : 'about:blank',


        USE_NATIVE_JSON : false,


        isStrict: isStrict,


        isIEQuirks: isIE && !isStrict,

        
        isOpera : isOpera,

        
        isOpera10_5 : isOpera10_5,

        
        isWebKit : isWebKit,

        
        isChrome : isChrome,

        
        isSafari : isSafari,

        
        isSafari3 : isSafari3,

        
        isSafari4 : isSafari4,

        
        isSafari5 : isSafari5,

        
        isSafari2 : isSafari2,

		IEVer : ieVersion,
        
        isIE : isIE,

        
        isIE6 : isIE6,

        
        isIE7 : isIE7,

        
        isIE8 : isIE8,

        
        isIE9 : isIE9,

        
        isGecko : isGecko,

        
        isGecko3 : isGecko3,

        
        isGecko4 : isGecko4,

        
        isGecko5 : isGecko5,

        
        isFF3_0 : isFF3_0,

        
        isFF3_5 : isFF3_5,

        
        isFF3_6 : isFF3_6,

        
        isFF4 : 4 <= firefoxVersion && firefoxVersion < 5,

        
        isFF5 : 5 <= firefoxVersion && firefoxVersion < 6,

        
        isLinux : isLinux,

        
        isWindows : isWindows,

        
        isMac : isMac,

        
        chromeVersion: chromeVersion,

        
        firefoxVersion: firefoxVersion,

        
        ieVersion: ieVersion,

        
        operaVersion: operaVersion,

        
        safariVersion: safariVersion,

        
        webKitVersion: webKitVersion,

        
        isSecure: isSecure,

        
        escapeRe : function(s) {
            return s.replace(/([-.*+?^${}()|[\]\/\\])/g, "\\$1");
        },
		
        
        log :
            nullLog,
		
        
        invoke : function(arr, methodName){
            var ret = [],
                args = Array.prototype.slice.call(arguments, 2);
            $.each(arr, function(i,v) {
                if (v && typeof v[methodName] == 'function') {
                    ret.push(v[methodName].apply(v, args));
                } else {
                    ret.push(undefined);
                }
            });
            return ret;
        }
		
		
    });
})();
/*
*常用函数
*/
(function(){
	$.extend(Nex, {
		htmlEncode: (function() {
			var entities = {
				'&': '&amp;',
				'>': '&gt;',
				'<': '&lt;',
				'"': '&quot;'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					return entities[capture];
				});
			};
		})(),
		htmlDecode: (function() {
			var entities = {
				'&amp;': '&',
				'&gt;': '>',
				'&lt;': '<',
				'&quot;': '"'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + '|&#[0-9]{1,5};' + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					if (capture in entities) {
						return entities[capture];
					} else {
						return String.fromCharCode(parseInt(capture.substr(2), 10));
					}
				});
			};
		})()	
	});	
})();

/*
Nex.base
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
v1.0
1.修正继承 fix不能继承父对象的所有属性 bug 严重
2.修正当_optionsList为空时，不在继承父级属性BUG 严重
3.新增getTemplate 返回一个模版对象实例 ,以前的template 不再建议，
4.新增baseUrl
5.新增deferred 和 getDeferred方法
6.修正由于继承时大部分属性和方法都是从父类直接copy过去 所有出现部分方法的变量还是父类的内容
7.通过参数绑定事件时可使用对象来设置上下文 { func,scope }
8.新增Nex.require API提供组件依赖加载
*/
/*********************
********Nex核心*******
*********************/
var Nex = Nex || (function(win,$){
	"use strict";	
	var userAgent = navigator.userAgent.toLowerCase();
	var uaMatch = /msie ([\w.]+)/.exec( userAgent ) || [];
	function getCurrentScript(h) {
		var stack,
			DOC = document,
			undef,
			h = h === undef ? true : false,
			head = DOC.getElementsByTagName("head")[0]
			;
		try {
		  a._b.c(); //强制报错,以便捕获e.stack
		} catch (e) { //safari的错误对象只有line,sourceId,sourceURL
		  if( e.sourceURL ) {
			return e.sourceURL; //safari
		  }
		  stack = e.stack;
		  if (!stack && window.opera) {//opera
			  //opera 9没有e.stack,但有e.Backtrace,但不能直接取得,需要对e对象转字符串进行抽取
			  stack = (String(e).match(/of linked script \S+/g) || []).join(" ");
		  }
		}
		if (stack) {//chrome
		  stack = stack.split(/[@ ]/g).pop(); //取得最后一行,最后一个空格或@之后的部分
		  stack = stack[0] === "(" ? stack.slice(1, -1) : stack.replace(/\s/, ""); //去掉换行符
		  return stack.replace(/(:\d+)?:\d+$/i, ""); //去掉行号与或许存在的出错字符起始位置
		}
		//IE
		var context = h ? head : DOC;
		var nodes = context.getElementsByTagName("script");
		for (var i = nodes.length, node; node = nodes[--i]; ) {
		  if ( node.readyState === "interactive") {
			  return node.src;//node.className = 
		  }
		}
	}
	var baseUrl = getCurrentScript( false );
	baseUrl = baseUrl.split('/');
	baseUrl.pop();
	baseUrl = baseUrl.join('/');
	//baseUrl = baseUrl ? baseUrl+'/':baseUrl;
	/*如果是IE浏览器 加上各版本样式*/
	$(document).ready(function(){
		if( Nex.isIE && Nex.IEVer ) {
			var cls = ['nex-ie'];
			var bd = $(document.body);
			cls.push( 'nex-ie'+Nex.IEVer );
			if( Nex.IEVer<8 ) {
				cls.push( 'nex-ielt8' );
			}
			if( Nex.IEVer<9 ) {
				cls.push( 'nex-ielt9' );
			}
			bd.addClass( cls.join(' ') );
		}
	});
	return {
		userAgent : userAgent,
		aid : 1,
		tabIndex : 1,
		zIndex : 99999,
		topzIndex : 99999999,
		scrollbarSize : false,
		resizeOnHidden : true,
		/*
		*根据参数返回模版对象
		*@param {Object} o ltag rtag simple(简单模式) 
		*@return {Object}
		*/
		getTemplate : function( o ){
			var o = o || {};
			return {
				cache1 : {},
				cache2 : {},
				helper : $.noop,//兼容用
				ltag : o.ltag || '<%',
				rtag : o.rtag || '%>',
				simple :  o.simple || false,
				compile1 : function(str, data){
					var fn = this.cache1[str] ? this.cache1[str] :
					 new Function("obj",
					"var p=[],print=function(){p.push.apply(p,arguments);};" +
					"with(obj){p.push('" +
					str
					  .replace(/[\r\t\n]/g, " ")
					  .split(this.ltag).join("\t")
					  .replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
					  .replace(new RegExp("\t=(.*?)"+this.rtag,"g"), "',$1,'")
					  .split("\t").join("');")
					  .split(this.rtag).join("p.push('")
					  .split("\r").join("\\'")
				  + "');}return p.join('');");
					this.cache1[str] = fn;
					return data ? fn( data ) : fn;
				},
				compile2 : function(str, data){//简单的模版
					var fn = this.cache2[str] ? this.cache2[str] :
					 new Function("obj",
					"var p=[],print=function(){p.push.apply(p,arguments);};" +
					"with(obj){p.push('" +
					str
					  .replace(/[\r\t\n]/g, " ")
					  .split(this.ltag).join("\t")
					  //.replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
					  .replace(new RegExp("\t(.*?)"+this.rtag,"g"), "',$1,'")
					  .split("\t").join("');")
					  .split(this.rtag).join("p.push('")
					  .split("\r").join("\\'")
				  + "');}return p.join('');");
					this.cache2[str] = fn;
					return data ? fn( data ) : fn;
				},
				compile : function(){
					if( this.simple ) {
						return this.compile2.apply(this,arguments);	
					} else {
						return this.compile1.apply(this,arguments);		
					}
				}	
			};	
		},
		/*
		*dirname
		*/
		dirname : function(baseUrl){
			baseUrl = baseUrl + '';
			baseUrl = baseUrl.split('/');
			baseUrl.pop();
			baseUrl = baseUrl.join('/');
			return baseUrl;
		},
		/*
		*private
		*safair不支持
		*/
		getcwd : function(h){
			return getCurrentScript(h);	
		},
		baseUrl : baseUrl,
		getCurrentScriptUrl : function(){
			return this.baseUrl;	
		},
		template : {
			cache : {},
			helper : $.noop,//兼容用
			ltag : '<%',//不能修改
			rtag : '%>',//不能修改
			compile : function(str, data){
				var fn = this.cache[str] ? this.cache[str] :
				 new Function("obj",
				"var p=[],print=function(){p.push.apply(p,arguments);};" +
				"with(obj){p.push('" +
				str
				  .replace(/[\r\t\n]/g, " ")
				  .split(this.ltag).join("\t")
				  .replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
				  .replace(new RegExp("\t=(.*?)"+this.rtag,"g"), "',$1,'")
				  .split("\t").join("');")
				  .split(this.rtag).join("p.push('")
				  .split("\r").join("\\'")
			  + "');}return p.join('');");
				this.cache[str] = fn;
				return data ? fn( data ) : fn;
			}
		},
		/*
		*返回随机字符串
		*@param {Number} 返回自定的长度的随机字符串 默认是6位
		*@return {String}
		*/
		generateMixed : function(n){
			var n = n || 6;
			var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
			var res = "";
			 for(var i = 0; i < n ; i ++) {
				 var id = Math.ceil(Math.random()*35);
				 res += chars[id];
			 }
			 return res;	
		},
		/*
		*返回一个不重复字符串,使用方法同generateMixed
		*/
		unique : function(n){
			var str = Nex.generateMixed(n||6);
			var aid = str+'-'+Nex.aid++;
			return aid;	
		},
		/*
		*判断是否数字格式
		*/
		isNumber : function(value) {
			return /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value) ? true : false;	
		},
		/*
		*检测当前对象是否是Nex类
		*/
		isNexConstructor : function(obj){
			return  $.type(obj) === 'function' && ('_isNexConstructor' in obj)  ? true : false;
		},
		/*
		*检测当前对象是否是Nex实例对象
		*/
		isNex : function(obj){
			return  $.type(obj) === 'object' && ('_isNex' in obj)  ? true : false;
		},
		/*
		*判断当前对象是否是xtype的对象类型 
		*/
		isXtype : function(obj){
			return ( $._isPlainObject( obj ) && ('xtype' in obj ) )	? true : false;
		},
		/*
		*检测是否是jquery实例
		*/
		isjQuery : function(obj){
			return $.type(obj) === 'object' && ('_outerWidth' in obj) ? true :　false;	
		},
		isElement : function(obj){
			return $.type(obj) === 'object' && (obj.nodeType === 1) ? true :　false;	
		},
		//所有Nex组件集合，目前Nex[className] 和 Nex.classes[className] 作用是一样的
		classes : {},
		getClass : function( cn ){
			return this.classes[cn];	
		},
		addClass : function( n,v ){
			this.classes[n] = v;
			return this;
		},
		_classesPaths : {},
		/*
		*动态加载组件时，设置组件路径
		*@param {String|Object} 组件名|组件和组件路径Map
		*@param {String} 组件路径
		*/
		setClassPath : function(){
			var self = this,
				argvs = arguments;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( self._classesPaths,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					self._classesPaths[argvs[0]] = argvs[1];
				}	
			}	
			return self;
		},
		/*
		*获取组件路径
		*@param {String} 组件名
		*@return {String} 组件路径
		*/
		getClassPath : function( n ){
			return this._classesPaths[n];	
		},
		/*
		*Nex组件基类包含事件机制
		*@param 组件名称
		*@param 设置组件的xtype
		*@return {NexClass}Nex组件类
		*/
		widget : function(name,xtype){
			var undef,
				//observe
				base = function(){
					this.init.apply(this,arguments);	
				},
				name = name === undef ? Nex.unique(8) : name,
				xtype = xtype === undef ? name : xtype;
			
			Nex[name] = base;	
			Nex.classes[ name ] = base;
			
			/*
			*添加xtype
			*/
			if( Nex.Manager ) {
				Nex.Manager.addXtype(xtype,function(opt){
					return new Nex.classes[name](opt);									   
				});	
			}
			
			base.fn = base.prototype = {};
			base.fn.extend = function(obj){
				$.extend(this,obj);
			};
			base.extend = function(obj){
				$.extend(this,obj);	
			};
			
			//原型设置
			base.constructor = base.prototype.constructor = base;
			base.prototype.superclass = null;
			base.superclass = null;
			
			base.fn = base.prototype;
			
			base.extend({
				//标识当前函数是属于Nex类
				_isNexConstructor : true,
				puglins : [],
				puglinsConf : {},
				puglinsEvent : {},
				defaults : {},
				eventMaps : {},//事件名映射或者别名 别名:映射名
				addExtConf : function(conf){
					var d = {};
					if( $.isFunction( conf ) ) {
						var d = conf.call( this ) || {};	
					} else {
						d = conf;	
					}
					$.extend( this.puglinsConf,d );
				},
				addExtEvent : function(events){	
					var d = {};
					if( $.isFunction( events ) ) {
						var d = events.call( this ) || {};	
					} else {
						d = events;	
					}
					$.extend( this.puglinsEvent,d );
				},
				addEventMaps : function(maps){	
					var d = {};
					if( $.isFunction( maps ) ) {
						var d = maps.call( this ) || {};	
					} else {
						d = maps;	
					}
					$.extend( this.eventMaps,d );
				},
				_optionsList : [],
				setOptions : function( options ){
					if( $.isPlainObject( options ) ) {//转化成函数方式
						var _opts = options;
						options = function(){
							return $.extend(true,{},_opts);//深复制对象
						}
					}
					if( $.isFunction( options ) ) {
						//方法一 ： 设置的时候确定superclass的参数 缺点 如果superclass做改变时不会更新  不要使用此方法！！
						//var popts = this.getSuperClassOptions();
						this._optionsList.push( function( opt,t ){
							//方法2 1.能够保证所有setOptions的第二个参数是当前对象 2.不会出现方法一的缺点
							var popts = this.getSuperClassOptions(t);
							popts = $.extend( {},popts,opt );//继承属性
							return $.extend(popts,options.call( this,popts,t ));
						} );
					}
					return this;
				},
				getSuperClassOptions : function(t){
					var ptype = this.getSuperClassXType();
					if( !ptype ) {//ptype === null || 
						return {};	
					}
					return Nex.getClass(ptype).getOptions(t);
				},
				getOptions : function(self){
					var list = this._optionsList;
					var opt = {};
					if( list.length ) {
						for( var i=0,len=list.length;i<len;i++ ) {
							var o = list[i];
							$.extend( opt, $.isFunction( o ) ? o.call(this,opt,self||this) : o  );	
						}
					} else {
						$.extend( opt, this.getSuperClassOptions( self||this )  );		
					}
					opt = this.getDefaults( opt,self || this );
					return opt;
				},
				/*
				*基础类默认参数
				*/
				_def : function(self){ 
					var self = self || this;
					return {
						_base : this.constructor,
						prefix : 'nex_',
						id : '',
						//autoRender自动渲染 会自动调用_init
						autoRender : true,//--由于部分组件没有继承html 直接继承 base 所以有些属性 还是放在base 如果后面统一后再做修改
						renderAfter : true,//true:append false:prepend
						_isInit : false,
						_isResize : false,
						//设备上下文，慎用
						context : null,
						parent : null,//指定父组件的ID 如果不指定则自动获取
						stopOnFalse : true,
						denyManager : false,//不受Manager管理组件 不建议开启
						//autoDestroy 自动回收机制 如果Nex在触发检查的时候检查不到当前元素存在时如果开启后就删除当前组件，所以如果你创建的是一个服务那就应该设为false
						autoDestroy : true,//自动回收 回收后通过Nex.get获取不到组件  autoRecovery
						autoSetResize : false,//是否根据用户的width height 自动设置autoResize --尚未实现
						autoResize : false, //接受Manager的resize调整
						autoScroll : false,
						groupName : '',//组件分组，一般有批量sendMessage 时会使用到
						resizeOnHidden : Nex.resizeOnHidden,//作废
						cls : '',
						cutHeight : 0,
						cutWidth : 0,
						deferred : $.Deferred ? $.Deferred() : null,
						autoSize : false,
						width : '100%',
						height : '100%',
						maxWidth : 0,
						maxHeight : 0,
						minHeight : 0,
						minWidth : 0,
						realWidth : null,//实际 ,width=auto时 如果max min width height 没起作用那么realWidth = auto
						realHeight : null,//同上
						_width : null,//和realWidth 不同的是 _width是一个数值
						_height : null,
						__width : 0,
						__height : 0,
						tpl : {},
						template : Nex.getTemplate(),//typeof template === 'undefined' ? Nex.template : template,//模板引擎对象
						scrollbarSize : false,
						noop : $.noop,
						self : null,
						init : $.noop,//初始化调用
						renderTo : null,//helper
						views : {},
						defalutType : 'panel',//默认items的xtype 可通过defaluts覆盖
						defaluts : {},
						items : [],
						isEscape : false,
						cacheData : {},
						//_childrenList : [],//当前组件下的之组件，并不严禁， 一般做清除用
						_boxModel : true,
						eventMaps : {},
						events : {}//事件组合 	
					};
				},
				extSet : function( opt,self ){
					
					var opt = $.extend( {},this._def(self),opt );
					//扩展事件
					$.extend( opt.events,this.puglinsEvent );	
					//事件名映射扩展
					$.extend( opt.eventMaps,this.eventMaps );	
					
					return $.extend({},this.puglinsConf,opt);
				},
				getDefaults : function(opt,self){
					var _opt = {};
					var _opt = this.extSet(_opt,self);
					
					return $.extend({},_opt,opt);
				},
				_undef : function (val, defaultVal) {
					return val === undefined ? defaultVal : val;
				},
				getSuperClassXType : function(){
					return null;	
				},
				getSuperClass : function(){
					return this.superclass;	
				},
				/*
				*调用当前类的API 
				*@param method api名称
				*@param scope 作用域
				*@param data 数组参数
				*/
				invokeMethod : function( method,scope,data ){
					var obj = this;
					var func = obj.fn[method];
					if( func && $.isFunction( func ) ) {
						return func.apply( scope,$.isArray(data) ? data : [ data ] );
					}
					return;
				},
				/*
				*调用父类的API
				*@param method api名称
				*@param scope 作用域
				*@param data 数组参数
				*/
				_super : function( method,scope,data ){
					var _super = this.superclass;
					if( !_super ) return;
					var func = _super.fn[method];
					if( func && $.isFunction( func ) ) {
						return func.apply( scope,$.isArray(data) ? data : [ data ] );
					}
					return;
				},
				setXType : function(xtype){
					var b = this,
						undef;
					if( xtype === undef ) return b;
					
					b.getXType = function(){
						return xtype;	
					};
					b.fn.getXType = function(){
						return xtype;	
					};
					
					Nex.classes[ xtype ] = b;
					
					/*
					*添加xtype
					*/
					if( Nex.Manager ) {
						Nex.Manager.addXtype(xtype,function(opt){
							return new b(opt);									   
						});	
					}
					return b;	
				},
				getXType : function(){
					return xtype;	
				},
				setAliasName : function( aliasName ){
					var self = this;
					if( aliasName ) {
						var __psc = Nex.__psc;
						Nex.__psc = true;
						var aliasNames = $.trim(aliasName).split(/\s+/g);
						$.each( aliasNames,function(i,n){
							Nex.parseSubClass( n,self );
							Nex.addClass( n,self );
						} );
						Nex.__psc = __psc;
					}	
					return self;
				},
				create : function( opt ){
					return new this(opt||{});	
				},
				_Tpl : {}
				
			});
			base.fn.extend({
				//标识当前对象是Nex对象实例
				_isNex : true,
				getSuperClassXType : function(){
					return null;	
				},
				getSuperClass : function(){
					return this.superclass;	
				},
				/*
				*调用父类
				*一定不能用this.superclass.fn.method.call( self )...因为js中没有虚函数的概念 里面的this 都是指向当前对象 ，
				*如果多级继承就会出现死循环 应该明确类名eg : Nex.Form.fn.method.call( self ) or Nex.Form._super(method,self,[  ])	-推荐
				*所以在fn中无法实现super的方法
				_super : function(){
				},
				*/
				getXType : function(){
					return xtype;	
				},
				//动态添加组合 动态组合的参数不会覆盖原有参数和方法，因为会把重复的参数和方法当作用户重载
				addMixins : function( d,dep ){
					var self = this;
					var opt = this.configs;
					var mconfigs = {};
					
					if( $.isFunction( d ) ) {
						d = d();	
					}
					if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
						d = Nex.getMixins( d );
					}
					
					//组合对象的configs也会被当作组件的参数
					if( $.isPlainObject( d ) && !$.isEmptyObject( d ) ) {
						d = $.extend( true,{},d );
						if( 'configs' in d && d.configs ) {
							mconfigs = $.extend(true,{},d.configs);
							delete d.configs; 	 	
						}
						for( var p in mconfigs ) {
							if( !dep && (p in opt) ) {
								continue;	
							}	
							opt[p] = mconfigs[p];//应该使用复制
						}
						for( var m in d ) {
							if( !dep && (m in self) ) {
								continue;	
							}	
							self[m] = d[m];//应该使用复制
						}
					}
					return self;
				},
				initConfigs : function(){
					var self = this;
					var argvs = [].slice.apply(arguments);
					var constructor = self.constructor;
					var opts = constructor.getOptions( self );
					var configs = $.extend({},opts);
					for( var i=0,len = argvs.length;i<len;i++ ) {
						var options = argvs[i];
						if( $.isFunction( options ) ) {
							options = options.call( self,configs ) || {};	
						} else {
							options = $.extend( {},options );//防止options不是一个对象 这里不建议深复制 因为怕大数据带来性能问题
						}
						//这里的event 不会被覆盖 --- 这里是否会有问题呢？
						//self.initEvents(options);//初始化用户自定义事件
						$.extend( configs,options );
					}
					//事件只初始化一次把， 会被后面的覆盖
					self.initEvents(configs);//初始化用户自定义事件
					
					if( Nex.isNex(configs.parent) ) {
						var pid = configs.parent.C('id');
						configs.parent = pid;	
					}
					
					self.configs = configs;
					
					if( 'mixins' in configs ) {
						var mixins = configs.mixins;
						delete configs.mixins;
						mixins = $.isArray( mixins ) ? mixins : [mixins];
						for( var t=0,n = mixins.length;t<n;t++ ) {
							 self.addMixins( mixins[t] );
						}
					}
					
					/*如果参数中有prototype,则当前属性会赋值到当前对象的prototype*/
					var prototype = configs.prototype;
					configs.prototype = null;
					delete configs.prototype;
					
					if( prototype && $.isFunction( prototype ) ) {
						prototype = prototype.call( self,configs );
					}
					
					if( prototype && $._isPlainObject( prototype ) ) {
						$.extend( self,prototype );	
					}
					
					return self;
				},
				init : function(options) {
					var self = this;
					var argvs = [].slice.apply(arguments);
					
					//var constructor = self.constructor;
					self.initConfigs.apply( self,argvs );
					var opt = self.configs;
					opt.self = self;
		
					self._eventLocks = {};
					self._executeEventMaps = {};
		
					opt.id = opt.id || self.getId();
					
					opt._isInit = true;
					
					$.support.boxModel = $.support.boxModel === null ? opt._boxModel : $.support.boxModel;
					
					if( opt.autoRender ) {
						self._render();
					}
				},
				_init : function(){},
				//private
				rendered : false,
				_render : function( el,after ){
					var self = this;
					var opt = this.configs;
					//如果已经渲染则不能重复渲染
					if( this.rendered ) {
						return this;	
					}
					var el = this._undef( el,opt.renderTo );
					var after = this._undef( after,opt.renderAfter );
					
					opt.renderTo = el;	
					opt.renderAfter = after;	
					
					//系统初始化调用
					if( $.isFunction( opt.init ) && opt.init!==$.noop ) {
						opt.init.call(self,opt);
					}
					
					//系统事件绑定
					self.sysEvents();
					
					self._onStart(opt);//设置用户自定义事件
					//这些应该是html组件信息 等所有组件都继承html后可以修改
					//保存初始设置值
					opt.__width = opt.width;
					opt.__height = opt.height;
					
					this.fireEvent("onStart",[opt]);
					
					//设置状态， 已经渲染
					this.rendered = true;
					//添加组件到组件管理器
					if( !opt.denyManager && Nex.Manager ) {
						Nex.Manager.addCmp( opt.id,self );
					}
					//此处应该触发onRender事件 or onAfterRender onBefreoRender
					opt.cls = 'nex-component-item '+opt.cls;
					
					this._init( opt );
					
					return this;	
				},
				render : function( el,after ){
					if( this.rendered ) {
						this.renderTo.apply( this,arguments );
					} else {
						this._render.apply( this,arguments );	
					}
					return this;	
				},
				//判断是否render
				isRendered : function(){
					return this.rendered;	
				},
				_checkToRender : function(){
					if( !this.rendered ) {
						this.render();	
					}	
				},
				/*
				* @m default=false true(更新层级关系)
				*/
				enableAutoResize : function(  ){	
					this.configs.autoResize = true;
					return this;
				},
				/*
				* @m default=false true(更新层级关系)
				*/
				disabledAutoResize : function( m ){
					this.configs.autoResize = false;
					return this;
				},
				//数组移动算法
				// pos 要移动的元素
				array_move : Nex.array_move,
				/*
				*删除数组元素 index 为下标或者下表数组 或者回调函数 回调返回true即可
				*/
				array_splice : Nex.array_splice,
				/*				
				*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面
				*/
				array_insert : Nex.array_insert,
				array_clear : Nex.array_clear,
				array_copy : Nex.array_copy,
				//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
				copyArray : Nex.copyArray,
				//copy只是对数组或对象只是增加一个引用计数，并不是深复制
				copy : Nex.copy,
				/*
				*判断元素垂直滚动条是否滚动到底 @dom
				*/
				_checkYScrollEnd : function( el ){
					return Nex._checkYScrollEnd( el );
				},
				/*
				*判断元素水平滚动条是否滚动到底 @dom
				*/
				_checkXScrollEnd : function( el ){
					return Nex._checkXScrollEnd( el );	
				},
				/*
				*验证是否滚动到低 @el dom @a left/top
				*/
				isScrollEnd : function( el,a ){
					return Nex.isScrollEnd( el,a );	
				},
				str_number : Nex.str_number,
				_undef : function (val, d) {
					return val === undefined ? d : val;
				},
				distArr : function( arr ){
					var obj={},temp=[];
					for(var i=0;i<arr.length;i++){
						if(!obj[arr[i]]){
							temp.push(arr[i]);
							obj[arr[i]] =true;
						}
					}
					return temp;	
				},
				//只接受 字符串 number 
				inArray : function(elem,arr){
					if( $.type( elem ) === 'number' ) {
						elem = elem+'';	
					}
					if ( arr ) {
						var len = arr.length;
						var i = 0;
						for ( ; i < len; i++ ) {
							// Skip accessing in sparse arrays
							var v = arr[ i ];
							if( $.type( v ) === 'number' ) {
								v = v+'';	
							}
							if ( i in arr && (v === elem) ) {
								return i;
							}
						}
					}
					return -1;
				},
				/*判断是否出现滚动条*/
				hasScroll: function( el, a ) {
					return Nex.hasScroll( el,a );
				},
				/*
				* 获取浏览器滚动条大小
				*/
				getScrollbarSize: function () {
					var self = this,
						opt = self.configs;
					if( Nex.scrollbarSize ) {//全局缓存
						opt.scrollbarSize = Nex.scrollbarSize;
					}	
					if (!opt.scrollbarSize) {
						var db = document.body,
							div = document.createElement('div');
		
						div.style.width = div.style.height = '100px';
						div.style.overflow = 'scroll';
						div.style.position = 'absolute';
		
						db.appendChild(div); 
						
						opt.scrollbarSize = {
							width: div.offsetWidth - div.clientWidth,//竖
							height: div.offsetHeight - div.clientHeight//横
						};
						//IE下 出现过有一边获取不到的情况 就是为0
						opt.scrollbarSize.width = opt.scrollbarSize.width || opt.scrollbarSize.height;
						opt.scrollbarSize.height = opt.scrollbarSize.height || opt.scrollbarSize.width;
						
						opt.scrollbarSize.x = opt.scrollbarSize.height;
						opt.scrollbarSize.y = opt.scrollbarSize.width;
						
						db.removeChild(div);
						
						Nex.scrollbarSize = opt.scrollbarSize;
					}
					return opt.scrollbarSize;
				},
				resize : function(){
					var self = this;
					var opt = self.configs;
					if( Nex.Manager ) {
						setTimeout(function(){
							Nex.Manager.fireEvent("onResize",[opt.id]);		
						},0);
					}	
				},	
				__ars : true,
				//判断当前组件是否接受autoResize
				isAcceptResize : function(){
					var opt = this.configs;
					return opt.autoResize && this.__ars;	
				},
				setAcceptResize : function(m){
					var m = m === undefined ? true : m;
					this.__ars = !!m;
					return this;	
				},
				//计算 max/min/cut width height 
				__getCalcSize : function( size,t ){
					var self = this,
						undef,
						opt = this.configs;	
					if( $.isFunction( size ) ) {
						size = size.call( self );	
					}
					if( size === undef ) size = 0;
					//暂不提供百分比支持
					size = parseInt(size);
					return 	isNaN(size)?0:size;	
				},
				_getCutWidth : function(){
					var self = this,
						opt = this.configs;	
					//var pw = opt.pWidth;
					var size = opt.cutWidth;
					return 	self.__getCalcSize(size,0);
				},
				_getCutHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.cutHeight;
					return 	self.__getCalcSize(size,1);
				},
				_getMinWidth : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.minWidth;
					return 	self.__getCalcSize(size,0);
				},
				_getMaxWidth : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.maxWidth;
					return 	self.__getCalcSize(size,0);	
				},
				_getMinHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.minHeight;
					return 	self.__getCalcSize(size,1);		
				},
				_getMaxHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.maxHeight;
					return 	self.__getCalcSize(size,1);			
				},
				/*
				*组件参数设置和获取
				*/
				C : function(key,value){
					if( typeof key == 'undefined') {
						return this.configs;	
					}
					if( typeof value == 'undefined' && typeof key !== 'object' ) {
						return this.configs[key];
					}
					if( $.isFunction( value ) ) {
						this.configs[key] = value.call( this,this.configs[key] );	
					} else if( $.isPlainObject( key ) ) {
						var conf = key;
						var opt = this.configs;
						
						if( value ) {
							$.extend( opt,conf );
							return this;	
						}
						
						for (var k in conf) {
							var newValue = conf[k];
							var oldValue = opt[k];
			
							if ( $.isArray( oldValue ) ) {
								oldValue.push.apply(oldValue, newValue);
							} else if ($.isPlainObject( oldValue )) {
								$.extend( oldValue, newValue)
							} else {
								opt[k] = newValue;
							}
						}
					} else {
						this.configs[key] = value;
					}
					return this;
				},
				set : function(){
					return this.C.apply(this,arguments);	
				},
				get : function(){
					return this.C.apply(this,arguments);	
				},
				setConfig : function(){
					return this.C.apply(this,arguments);		
				},
				getConfig : function(){
					return this.C.apply(this,arguments);		
				},
				/**
				 * 模板处理函数(用户自定义模版级别最高,其次模板函数,最后_Tpl中的模版)
				 *  @tpl {String,Function} 模板内容
				 *  @data {Object} 模板数据 如果tpl是Function data不一定需要Object
				 *  @return {String} 模板内容
				 */
				tpl : function(tpl,data){
					
					var self = this;
					var opt = self.configs;
					var constructor = self.constructor;
					if( typeof tpl == 'undefined' ) tpl = "";
					if( typeof data == 'undefined' ) data = {};
					
					var _tpl_ = {};
					if( typeof opt.cacheData['_tpl_'] == 'undefined' ) {
						opt.cacheData['_tpl_'] = {};
						_tpl_ = opt.cacheData['_tpl_'];
					} else {
						_tpl_ = opt.cacheData['_tpl_'];
					}
					
					var argvs = [];
					var len = arguments.length;
					for( var i=2;i<len;i++ ) {
						argvs.push( arguments[i] );	
					}
					var argvs = [data].concat( argvs );
					
					var html = "";
					
					if( !opt.template ) {
						if( $.isFunction(tpl) ){
							html = tpl.apply(self,argvs);
						} else if( tpl in self ) {
							html = self[tpl].apply(self,argvs);
						} else {
							html = 	tpl;
						}
						return html;
					}
					
					opt.template.isEscape = opt.isEscape;
					
					if( $.isFunction(tpl) ){
						html = tpl.apply(self,argvs);
					}else if( tpl in opt.tpl && opt.tpl[tpl] ) {
						if( opt.tpl[tpl] in _tpl_ ) {
							var render = _tpl_[ opt.tpl[tpl] ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( opt.tpl[tpl] );
							
							_tpl_[ opt.tpl[tpl] ] = render;
							
							html = render.apply(self,argvs);		
						}
					} else if( tpl in self ) {
						html = self[tpl].apply(self,argvs);
					} else if( tpl in constructor._Tpl && constructor._Tpl[tpl] ) {
						if( constructor._Tpl[tpl] in _tpl_ ) {
							var render = _tpl_[ constructor._Tpl[tpl] ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( constructor._Tpl[tpl] );
							
							_tpl_[ constructor._Tpl[tpl] ] = render;
							
							html = render.apply(self,argvs);		
						}
					} else {
						if( tpl.toString() in _tpl_ ) {
							var render = _tpl_[ tpl.toString() ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( tpl.toString() );
							
							_tpl_[ tpl.toString() ] = render;
							
							html = render.apply(self,argvs);		
						}
					}
					return html;
				},
				/*
				*  调用当前对象里的某个API，但是不会触发里面的事件(部分函数除外例如setGridBody,因为里面事件通过计时器触发)
				*  @param1 {String} 需要调用的API
				*  @param2~N 被调用的API参数(可选)
				*/
				denyEventInvoke : function(){//method,arg1,arg2....
					var self = this;
					var r;
					if( arguments.length ){
						var argvs = [];
						for( var i=0;i<arguments.length;i++ ) {
							argvs.push(arguments[i]);	
						}
						var method = argvs[0];
						if( method in self ) {
							self._denyEvent = true;
							argvs.splice(0,1);
							r = self[method].apply(self,argvs);
							self._denyEvent = false;
						}
					}
					return r;
				},
				/*
				* API调用管理,作用在于通过该函数调用的会过滤被锁定的函数
				*  @param1 {String} 需要调用的API
				*  @param2~N 被调用的API参数(可选)
				*/
				methodInvoke : function(){//method,arg1,arg2....
					var self = this;
					var r;
					
					var methodLocks = self._methodLocks || {};
					
					if( arguments.length ){
						var argvs = [];
						for( var i=0;i<arguments.length;i++ ) {
							argvs.push(arguments[i]);	
						}
						var method = argvs[0];
						
						if( methodLocks[method] ) {
							return;	
						}
						
						if( method in self ) {
							argvs.splice(0,1);
							r = self[method].apply(self,argvs);
						}
					}
					return r;
				},
				/*
				* 事件绑定
				*  @eventType {String} 事件名
				*  @func      {Function|{ scope,fn }} 事件回调
				*  @scope     {Object} this对象(可选)
				*  @return    {int} 事件ID or false
				*/
				bind : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					if( eventType === '' || eventType === '@' ) {
						return false;	
					}
					//var _f = func;
					//var func = func || $.noop;
					var self = this;
					var opt = self.configs;
					var event = opt.events;
					//批量绑定支持
					if( $.type( eventType ) === 'object' ) {
						var ids = [];
						for( var ev in eventType ) {
							var context = scope;
							var fn = eventType[ev];
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.scope || fn.context || context;
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							var _i = self.bind( ev,fn,context );	
							ids.push( _i );
						}
						return ids;
					} else {//字符串 但是没有做检查 
						var _ev = [ eventType ].join('').split(/\s+|,/);	
						if( _ev.length>1 ) {
							var len = _ev.length;
							var ids = [];
							for( var _e=0;_e<len;_e++ ) {
								if( !_ev[_e] ) continue;
								ids.push( self.bind( _ev[_e],func,scope ) );
							}
							return ids;
						}					
					}
					
					var _f1 = eventType.charAt(0);
					if( _f1 === '@' ) {
						scope = self;
						eventType = eventType.slice(1);	
					}	
					
					var _type = eventType.split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');//_type.length == 2 ? _type[1] : '';
					
					if( !eventType ) {
						return false;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					event[eventType] = self._undef(event[eventType],[]);
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
					}
					
					if( !$.isFunction( func ) || func === $.noop ) {
						return false;	
					}
					
					var _e = {
							scope : !!scope ? scope : null,
							func : func,
							ext : ext
						};
					
					var id = event[eventType].push(_e);
				
					return id-1;
				},
				on : function(){
					return this.bind.apply(this,arguments);	
				},
				/*
				*同bind 区别在于只执行一次
				*/
				one : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					var func = func || $.noop;
					var self = this;
					var scope = !!scope ? scope : self;
					
					var _ = function(){
							self.unbind(eventType,_.id);
							var r = func.apply(scope,arguments);
							return r;
						},
						id = null;
						
					id = self.bind( eventType,_,scope );
					_.id = id;
					return id;
				},
				/*
				* 取消事件绑定
				*  @eventType {String} 事件名
				*  @id        {int} 事件ID(可选)
				*/
				unbind : function(eventType,id){
					var self = this;
					var opt = self.configs;
					
					var _ev = [ eventType ].join('').split(/\s+|,/);	
					if( _ev.length>1 ) {
						var len = _ev.length;
						for( var _e=0;_e<len;_e++ ) {
							if( !_ev[_e] ) continue;
							self.unbind( _ev[_e] );
						}
						return self;
					}					
					
					var event = opt.events;
					var id = self._undef(id,false);
					
					var _type = String(eventType).split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');
					
					if( eventType === '' && ext !== '' ) {
						for( var tp in event ) {
							self.unbind( [tp,ext].join('.') );	
						}
						return self;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					if( !(eventType in event) ) {
						return self;	
					}
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
						return self;
					}
					
					if(id === false) {
						if( ext === '' ) {
							event[eventType] = [];
						} else {
							
							var j = 0;//用于splice
							for(var i=0;i<event[eventType].length;i++) {
								var _e = event[eventType][i];
								if( $.isPlainObject( _e ) && _e.ext === ext ) {
									event[eventType][i] = null;	
									j++;
								}
							}
						}
					} else {
						event[eventType][id] = null;	
					}
					return self;
				},
				off : function(){
					return this.unbind.apply(this,arguments);	
				},
				/*
				* 锁定API
				*  @method {String} API名
				*/
				lockMethod : function(method){
					var self = this;	
					//事件锁
					var methodLocks = self._methodLocks || {};
					methodLocks[method] = true;
					self._methodLocks = methodLocks;
					return true;	
				},
				/*
				* 取消锁定API
				*  @method {String} API名
				*/
				unLockMethod : function(method){
					var self = this;	
					//事件锁
					var methodLocks = self._methodLocks || {};
					methodLocks[method] = false;
					self._methodLocks = methodLocks;
					return true;	
				},
				/*
				* 锁定事件
				*  @eventType {String} 事件名
				*/
				lockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = true;
					self._eventLocks = eventLocks;
					return true;
				},
				/*
				* 取消锁定事件
				*  @eventType {String} 事件名
				*/
				unLockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = false;
					self._eventLocks = eventLocks;
					return true;
				},
				_eventLocks : {},
				_executeEventMaps : {},//正在的执行的事件
				/*
				* 事件触发
				*  @eventType {String} 事件名 如果事件名带@开头 说明当前事件是系统事件 不会因为睡眠而阻止
				*  @data      {Array} 事件参数(可选)
				*/
				fireEvent : function(eventType,data){
					var self = this;
					if( self._denyEvent ) {
						return;	
					}
					var opt = self.configs;
					
					var context = opt.context || self;
					
					var ct = String(eventType).charAt(0);
					var _sys = false;
					if( ct === '@' ) {
						_sys = true;
						eventType = String(eventType).slice(1);	
					}	
					/*
					if( !_sys && self._isSleep() ) {
						return;	
					}
					*/
					if( !eventType ) {
						return;	
					}
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					var events = opt.events[eventType];
					var data = self._undef(data,[]);
					
					//判断data 是否 arguments
					if( $.isArray( data ) ) {
						data = data;	
					} else if( $.type( data ) === 'object' ){
						if( 'callee' in data && 'length' in data ) {
							data = data	
						} else {
							data = [data];	
						}
					} else {
						data = [data];
					}
					//data = $.isArray( data ) ? data : [data];
					//添加事件锁
					var eventLocks = self._eventLocks || {};
					if( eventLocks[eventType] ) {
						return;	
					}
					//防止死循环事件
					if( self._executeEventMaps[eventType] ) {
						return;	
					}
					self._executeEventMaps[eventType] = true;
					
					var r = true;
					if($.isArray(events) ) {
						var len = events.length;
						for(var i=0;i<len;i++) {
							var _e = events[i];
							if( $.isPlainObject( _e ) ) {
								r = _e.func.apply(_e.scope || context,data);
							} else if( $.isFunction( _e ) ){
								r = _e.apply(self,data);
							}
							if( opt.stopOnFalse ) {
								if(r === false) break;	
							}
						}	
						
					} else if($.isFunction(events)) {
						r = events.apply(self,data);
					}
					
					self._executeEventMaps[eventType] = false;
					
					return r;
				},
				fire : function(){
					return this.fireEvent.apply(this,arguments);	
				},
				__sleep : false,
				isSleep : function(){
					return this.__sleep;	
				},
				//睡眠 睡眠后无法通过sendMessageToGroup给组件发送消息 并不会影响fireEvent
				sleep : function(){
					this.__sleep = true;
					return this;	
				},
				//唤醒
				wakeup : function(){
					this.__sleep = false;
					return false;
				},
				loadPuglins : function(){
					var self = this;
					var constructor = self.constructor;
					$.each( constructor.puglins,function(i){
						if( $.isFunction( this ) )
							this.call(self);									
					} );
				},
				initEvents : function(opt){
					var self = this;
					var e = opt.events ? opt.events : {};
					opt.events = {};
					var events = {};
					if( $.isPlainObject(e) && !$.isEmptyObject(e) ) {
						for(var i in e){
							var _evt = String(i),
								fn = e[i],
								context = null;	
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.scope || fn.context || null;
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							if( $.isFunction( fn ) && fn !== $.noop ) {
								self.bind(_evt,fn,context);	
							}
						}
					}
					//opt.events = events;
				},
				sysEvents : function(){
					var self = this;
					var opt = self.configs;
					//系统事件 注意：顺序不可随意更改
					if( '_sysEvents' in self ) {
						self._sysEvents();
					}
					
					self.bind("onStart._sys",self.loadPuglins,self);	
				},
				generateMixed : function(n){
					 return Nex.generateMixed( n );	
				},
				_getId : function(){
					var aid = Nex.aid++;
					var self = this;
					var opt = self.configs;
					return opt.prefix + aid;	
				},
				getDom : function(){
					var self = this,
						opt = self.configs;
					return $('#'+opt.id);
				},
				getEl : function(){
					return this.el || this.getDom();	
				},
				getId : function(){
					if( this.configs.id === '' || this.configs.id === null || this.configs.id === undefined ) {
						return this._getId();	
					}
					return this.configs.id;	
				},
				//获取组件的父级组件
				getParent : function(  ){
					var el = this.getDom(),
						opt = this.configs,
						cmp = null;
					if( !el.length ) return cmp;
					if( opt.parent !== null ) {
						if( Nex.isNex( opt.parent ) ) {
							return opt.parent;	
						}
						var _p = Nex.get(opt.parent);
						if( _p ) return _p;
					}
					var p = el.parent('.nex-component-item'),
						_id = p.attr('id');
					cmp = _id ? Nex.get(id) : null;
					return cmp ? cmp : null;
				},
				unique : function(n){
					return Nex.unique(n);	
				},
				isNumber : function(value) {
					return Nex.isNumber( value );	
				},
				/*
				*系统事件
				*/
				_onStart : function(){
					var self = this;
					var opt = self.configs;
					var e = opt.events ? opt.events : {};
					var reg = /^@?on[A-Z][\S|\.]*$/;///^@?on[A-Z][\w|\.]*$/
					for(var x in opt ) {
						if( reg.test(x) ) {
							var fn = opt[x],
								context = null;
							
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.context || fn.scope || null;	
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							if( $.isFunction(fn) && fn !== $.noop ){
								self.bind(x,fn,context);	
							}
						}
					}
				},
				isNexConstructor : function(obj){
					return  Nex.isNexConstructor( obj );
				},
				isNex : function(obj){
					return  Nex.isNex( obj );
				},
				isXtype : function(obj){
					return Nex.isXtype( obj );
				},
				isjQuery : function(obj){
					return Nex.isjQuery( obj );
				},
				/*
				*解析xtype 到容器
				*@param {String,Dom} 容器
				*@param {Array,Nex,Xtype} 组件列表 
				*@param {Boolean}  true:append(默认) false:prepend,
				*@param {Object} defaluts
				*/
				parseItems : function(renderTo,items,after,def){
					var self = this,
						opt = self.configs,
						undef;
					var after = (after === undef) || (after === null) ? true : after;
					
					var def = $.type(def) === 'object' ? def : {};
					
					var ac = after ? 'append' : 'prepend';
					if( $.isFunction( items ) && !Nex.isNexConstructor( items ) ) {
						items = items.call( self,renderTo );
					}
					var components = [];
					var items = $.isArray( items ) ? items : [items];
					if( renderTo && items.length ) {
						for( var i=0;i<items.length;i++ ) {
							var _item = items[i];
							if( _item === '' || _item === undef ) continue;
							if( $.isFunction( _item ) && !Nex.isNexConstructor( _item ) ) {
								_item = _item.call(self,renderTo,opt);	
								if( _item === '' 
								    || $.type( _item ) === 'boolean' 
									|| $.type( _item ) === 'null' 
									|| $.type( _item ) === 'undefined' 
								) {
									continue;	
								}
							}
							if( Nex.isNex( _item ) ) {
								//$( renderTo )[ac]( _item.getDom() );
								_item.render( renderTo,ac );
								components.push( _item );
								//self.addChildCmpList( _item );
							} else if( Nex.isNexConstructor( _item ) || Nex.isXtype( _item ) ){
								if( !Nex.Create ) continue;
								var cmp;
								if( Nex.isXtype( _item ) ) {
									cmp = Nex.Create( $.extend( $.extend({ parent : opt.id },def),_item,{renderTo:renderTo,autoRender:true} ) );	
								} else {
									cmp = Nex.Create( _item,$.extend({},def,{renderTo:renderTo,parent : opt.id,autoRender:true}) );		
								}
								components.push( cmp );
								//self.addChildCmpList( cmp );
								//这里可以改成设置参数 renderAfter : after
								if( !after ) {
									$( renderTo )[ac]( cmp.getDom() );	
								}
							} else if( Nex.isjQuery( _item ) || Nex.isElement( _item ) ) {
								$( renderTo )[ac]( _item );	
								components.push( _item );
							} else {
								_item = _item + '';
								var html = $._parseHTML( _item );//修正相同字符 不创建bug
								html = $(html).clone();
								components.push( html );
								$( renderTo )[ac]( html );				
							}	
						}
					}
					return components;
				},
				addComponent :　function( renderTo,items,after ){
					return this.parseItems( renderTo,items,after );
				},
				addCmp :　function( renderTo,items,after ){
					return this.parseItems( renderTo,items,after );
				},
				/*
				*解析xtype 到容器
				*@param {Array,Nex,Xtype} 组件列表 
				*@param {String,Dom} 容器
				*@param {Boolean} 内部插入 默认是 后 
				*/
				renderComponent : function( items,renderTo,after ){
					return this.parseItems( renderTo,items,after );	
				},
				//应该放到Html组件 因为有部分组件没有继承Html 所以先放在这里
				renderTo : function( obj,after ){
					var self = this;
					var opt = this.configs;
					var undef;
					var after = after === undef ? true : after;
					var ac = after ? 'append' : 'prepend';
					if( !obj ) return self;
					if( !self.isExists() ) return self;
					var _st = false;
					if( Nex.isNex( obj ) && obj.isExists() ) {
						var bd = obj.getBody();
						bd[ac]( self.getEl() );
						_st = true;
					} else {
						var el = $(obj);
						if( el.length ) {
							el[ac]( self.getEl() );	
							_st = true;
						}	
					}
					if( opt.autoResize && _st ) {
						self.resize();
						if( Nex.Manager ) {
							Nex.Manager.cmpChange();	
						}
					}
					return self;
				},
				/*
				addChildCmpList :　function(obj){
					var self = this;
					var opt = self.configs;
					opt._childrenList.push( obj );
				},
				*/
				//m @true 默认删除本身, false 删除子元素
				removeCmp :  function(m){
					var self = this,undef;
					var m = m === undef ? true : m;
					var opt = self.configs;
					//opt._childrenList.length = 0;
					if( Nex.Manager ) {
						Nex.gc();
					}
				},
				/*
				*移除组件 最好需要重载
				*/
				destroy : function( m ){
					this.removeCmp( m );
					return this;
				},
				getChildrens : function(){
					var opt = this.configs;
					return Nex.Manager.getChildrens( opt.id );	
				},
				getAllChildrens : function(){
					var opt = this.configs;
					return Nex.Manager.getAllChildrens( opt.id );	
				},
				//作废
				_setBodyOverflowHidden : function(){},
				getDeferred : function(){
					var opt = this.configs;
					return opt.deferred;
				},
				/*
				*获取异步数据 必须要加载Nex.Ajax
				*方式一 通过URL设置
				*getAsyncData(url[success,error,complete,options]);
				*success,error,complete {Function}  options {Object}
				*eg getAsyncData( 'a.json',function( data ){ console.log( data ) },{ dataType:'json' } );
				*/
				getAsyncData : function( url ){
					var self = this,
						undef,
						success,
						error,
						complete,
						options,
						args = [].slice.apply(arguments);	
					var ins = null;	
					//参数处理	
					var len = args.length;
					for( var i=1;i<len;i++ ) {
						if( typeof args[i] === 'object' ) {
							options = args[i];
							break;	
						}
						if( typeof args[i] === 'function' ){
							switch( i ) {
								case 1:
									success = args[1];
									break;
								case 2:
									error = args[2];
									break;
								case 3:
									complete = args[3];
									break;		
							}
						}
					}	
					//url的处理方式	
					if( $.type( url ) === 'string' ) {
						var obj = {
								xtype : 'ajax',
								url : url,
								context : self
							};
						if( options ) {
							$.extend( obj,options );	
						}
						if( success ) {
							obj['onSuccess.__async'] = success;
						}
						if( error ) {
							obj['onError.__async'] = error;
						}
						if( complete ) {
							obj['onComplete.__async'] = complete;
						}
						ins = Nex.Create( obj );
					} else if( $.type( url ) === 'function' ) {//用户自定义函数处理方式
						var _data = url.call(self,options,success,error,complete);
						if( _data !== undef ) {
							success( _data );	
							complete();
						}	
					} else if( typeof url === 'object' ) {
						var obj = {
							xtype : 'ajax'	
						};
						if( !Nex.isXtype( url ) ) {
							$.extend( obj,url )	
						} else {
							obj = url;	
						}
						if( success ) {
							obj['onSuccess.__async'] = success;
						}
						if( error ) {
							obj['onError.__async'] = error;
						}
						if( complete ) {
							obj['onComplete.__async'] = complete;
						}
						ins = Nex.Create( obj );
					}
					return ins;
				},
				//ajax api
				loadData : function(url,data,options){//loader
					var self = this,
						undef,
						opt = self.configs;
						
				}
			});
			return base;
		},
		//数组移动算法
		// pos 要移动的元素
		array_move : function(iarr,pos,target,t) {//t 代表是前还是后 1 代表前 0 代表后

			if(pos == target) return iarr;
			var __arr = iarr;
			//支持字符下标
			var _iarr = iarr = [].concat(__arr);
			iarr = [];
			var j=0,
				len = _iarr.length;
			for(;j<len;j++) {
				var _i = iarr.push(j);
				if( j == pos) {
					pos = _i-1;
				} else if( j == target ) {
					target = _i-1;
				}
			}
			//core
			var _p = iarr[pos];//记录元副本
			if( pos>target ) {
				if(!t) {
					target++;
				}
				for(var i=pos;i>=0;i--) {
					if(i == target) {
						iarr[i] = _p;
						break;
					}
					iarr[i] = iarr[i-1];
				}
			} else if( pos<target ) {
				if(t) {
					target--;
				}
				for(var i=pos;i<=target;i++) {
					
					if( i == target ) {
						iarr[i] = _p;
					} else {
						iarr[i] = iarr[i+1];
					}	
				}
			}
			//字符下标
			
			var new_arr = __arr;
			new_arr.length = 0;
			//new_arr.push.apply(new_arr,_iarr); //不建议用 因为 _iarr 会有长度限制 63444
			var k=0,
				len = iarr.length;
			for( ;k<len;k++ ) {
				new_arr.push( _iarr[ iarr[k] ] );
			}
			iarr = new_arr;
			return iarr;
		},
		/*
		*删除数组元素 index 为下标或者下标数组 或者回调函数 回调返回true即可
		*/
		array_splice : function(index,arr){
			var self = this,undef;
			if( !$.isArray( arr ) ) return arr;
			
			var call = index;
			
			if( $.isArray( index ) && index.length<=1 ) {
				index = index[0];
			}
			
			if( index === undef ) return arr;
			
			//如果index 不是数组或者不是回调时 直接调用splice;
			if( !$.isArray( index ) && !$.isFunction(index) ) {
				if( isNaN( parseInt( index ) ) ) return arr;
				arr.splice( parseInt(index),1 );
				return arr;
			}
			
			var _arr = self.copy( arr );
			var index = $.isArray( index ) ? index : ($.isFunction(index) ? [] : [index]);
			var _index = {};
			$.each(index,function(i,v){
				_index[v] = true;	
			});
			
			arr.length = 0;
			
			$.each( _arr,function(i,v){
				if( $.isFunction( call ) ) {
					var r = call.call(v,i,v);	
					if( r === true ) {
						_index[i] = true;	
					}
				}
				if( !(i in _index) ) {
					arr.push(v);	
				}	
			} );
			
			return arr;
		},
		/*				
		*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面 _arr 长度不要超过6W+
		*/
		array_insert : function(index,_arr,arr,t){
			var self = this,
				undef,
				t = t === undef ? 0 : t;
			if( !$.isArray( arr ) ) return arr;
			
			var call = index;
			
			if( !$.isArray( _arr ) ) _arr = [ _arr ];
			
			if( index === undef ) return arr;
			
			var len = arr.length;
			if( index<len ) {
				if( t )	{
					_arr = _arr.concat( [ arr[index] ] );	
				} else {
					_arr = [ arr[index] ].concat( _arr );
				}
			}
			_arr = [index,1].concat( _arr );
			arr.splice.apply(arr,_arr);
			return arr;
		},
		array_clear : function(arr){
			arr.length = 0;
			return arr;
		},
		array_copy : function(arr){
			var _ = [];
			return _.concat( arr );	
		},
		//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
		copyArray : function(arr){
			var _ = [];
			return _.concat( arr );
		},
		//copy只是对数组或对象只是增加一个引用计数，并不是深复制
		copy : function(data){
			if( $.isArray( data ) ) {
				return  [].concat(data);	
			} else if( $.isPlainObject(data) ) {
				return $.extend({},data);
			} else {
				return data;	
			}
		},
		str_number : function(num,elc){//elc 截取的小数位
			var num = num + '';
			if( $.type( num ) === 'string' ) {
				var n = num.split('.');
				if( n.length>1 ) {
					var ext = n[1].substring(0,elc);	
					if( ext !== '' ) {
						num = [n[0],ext].join('.');	
					} else {
						num = n[0];
					}
				}	
			}
			return Number(num);
		},
		/*
		*判断元素垂直滚动条是否滚动到底 @dom
		*/
		_checkYScrollEnd : function( el ){
			var scrollTop = 0;
			var clientHeight = 0;
			var scrollHeight = 0;	
			if( el === document.body || el === document || el === window ) {
				if (document.documentElement && document.documentElement.scrollTop) {
					scrollTop = document.documentElement.scrollTop;
				} else if (document.body) {
					scrollTop = document.body.scrollTop;
				}
				if (document.body.clientHeight && document.documentElement.clientHeight) {
					clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
				} else {
					clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
				}
				scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
			} else {
				if( !el.nodeType ) return false;
				scrollTop = el.scrollTop;
				clientHeight = el.clientHeight;
				scrollHeight = el.scrollHeight;
			}
			if( clientHeight >= scrollHeight ) {
				return false;
			} else if (scrollTop + clientHeight >= scrollHeight) {//必须要使用>= 因为缩放后会大于scrollHeight
				return true;
			} else {
				return false;
			}	
		},
		/*
		*判断元素水平滚动条是否滚动到底 @dom
		*/
		_checkXScrollEnd : function( el ){
			var scrollLeft = 0;
			var clientWidth = 0;
			var scrollWidth = 0;	
			if( el === document.body || el === document || el === window ) {
				if (document.documentElement && document.documentElement.scrollLeft) {
					scrollLeft = document.documentElement.scrollLeft;
				} else if (document.body) {
					scrollLeft = document.body.scrollLeft;
				}
				if (document.body.clientWidth && document.documentElement.clientHeight) {
					clientWidth = (document.body.clientWidth < document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
				} else {
					clientWidth = (document.body.clientWidth > document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
				}
				scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
			} else {
				if( !el.nodeType ) return false;
				scrollLeft = el.scrollLeft;
				clientWidth = el.clientWidth;
				scrollWidth = el.scrollWidth;
			}
			if( clientWidth >= scrollWidth ) {
				return false;
			} else if (scrollLeft + clientWidth >= scrollWidth) {//必须要使用>= 因为缩放后会大于scrollWidth
				return true;
			} else {
				return false;
			}		
		},
		/*
		*验证是否滚动到低 @el dom @a left/top
		*/
		isScrollEnd : function( el,a ){
			var self = this,
				undef;
			if( a == 'left' ) {
				return self._checkXScrollEnd( el );	
			} else {
				return self._checkYScrollEnd( el );		
			}
		},
		/*
		*判断是否出现滚动条
		* @param el dom
		* @param a left top
		* @param t boolean defalut:false 如果t=true则只要超出宽度就会认定有滚动条，但是未必有滚动条一般拿来检测是否子节点的宽度大于父节点
		*/
		hasScroll: function( el, a, t ) {
			
			var el = $(el)[0];//el 是dom
			
			//If overflow is hidden, the element might have extra content, but the user wants to hide it
			/*
			//IE下 只要overflow-x/overflow-y设置了hidden那么获得的overflow就是hidden 所以我们要只取-x -y
			if ( $( el ).css( "overflow" ) === "hidden") {
				return false;
			}
			*/
			if( t !== true ) {
				if( a === "left" ) {
					if ( $( el ).css( "overflow-x" ) === "hidden") {
						return false;
					}
				} else {
					if ( $( el ).css( "overflow-y" ) === "hidden") {
						return false;
					}	
				}
			}
			var scroll = ( a && a === "left" ) ? "scrollLeft" : "scrollTop",
				has = false;
			if ( el[ scroll ] > 0 ) {
				return true;
			}
			// TODO: determine which cases actually cause this to happen
			// if the element doesn't have the scroll set, see if it's possible to
			// set the scroll
			el[ scroll ] = 1;
			has = ( el[ scroll ] > 0 );
			el[ scroll ] = 0;
			return has;
		},
		//工具集合
		util : {},
		addUtil : function(n,v){
			return this.util[n] = v;	
		},
		getUtil : function(n){
			return this.util[n];	
		},
		extendUtil : function(n,v){
			return $.extend( this.util[n],v );
		},
		removeUtil : function(){
			this.util[n] = null;
			delete this.util[n];
			return this;
		},
		//所有组合mixins
		mixins : {},
		addMixins : function( n,v ){
			v = $.isFunction( v ) ? v.call( this ) : v;
			return this.mixins[n] = v;	
		},
		getMixins : function(n){
			return this.mixins[n]	
		},
		extendMixins : function(n,v){
			return $.extend( this.mixins[n],v );
		},
		removeMixins : function(){
			this.mixins[n] = null;
			delete this.mixins[n];
			return this;
		},
		/*直接使用jquery 的Deferred对象 所以要使用when需要确定jquery版本支持Deferred*/
		when : function(){
			var arr = [].slice.apply(arguments);
			for( var i=0,len=arr.length;i<len;i++ ) {
				if( Nex.isXtype(arr[i]) ) {
					arr[i] = Nex.Create( arr[i] ).getDeferred();	
					continue;
				}
				if( Nex.isNex( arr[i] ) ) {
					arr[i] = arr[i].getDeferred();
					continue;	
				}
				if( $.type(arr[i])=='string' && Nex.getClass( arr[i] ) ) {//Nex.classes //( arr[i] in Nex )
					arr[i] = Nex.Create( arr[i] ).getDeferred();	
					continue;		
				}
			}
			return $.extend($.when.apply( $,arr ),{
				success : function(){
					this.done.apply( this,arguments )	
				},
				error : function(){
					this.fail.apply( this,arguments )	
				},
				complete : function(){
					this.always.apply( this,arguments )	
				}	
			});	
		},
		/*
		*__psc=true
		*parseSubClass会把字符串直接转成对象
		*__psc=false
		*如果分割长度少于2则会把对象存放到Nex下
		*eg：parseSubClass('Test',5);__psc=true后会直接创建Test否则Nex.Test
		*/
		__psc : true,
		//把字符串转化成对象 并复制v
		parseSubClass : function(str,v){
			var undef,
				t = window,
				s = str+'';	
			s = s.split('.');
			if( s.length<2 && !this.__psc ) {
				return;	
			}
			for( var i=0,len=s.length-1;i<len;i++ ) {
				var e = s[i];
				if( !(e in t) || !t[e] ) {
					t[e] = {};	
				}
				t = t[e];	
			}	
			t[s[i]] = v;
			//return v;
		},
		//继承组件 如果没指定superClass 默认superClass=Nex.widget()
		//subclass，superClass，overrides
		extend : function(subclass,superClass,overrides){
			var undef,F = function(){};
			if( subclass === undef ) return F;
			var superClass = superClass === undef ? false : superClass;
			var overrides = overrides === undef ? {} : overrides;
			var subclassName = subclass,
				superClassName = superClass === false ? null : superClass;
			//不能继承到Nex
			if( subclass === 'Nex' ) {
				return 	Nex.widget();
			}
			var notExist = false;
			//如果不存在superClass 直接返回
			if( !superClass ) {
				superClass = Nex.widget();
				notExist = true;
				//Nex.parseSubClass( subclassName,subclass );
				//return subclass;
			}
			//mixins
			//检查是否没设置overrides
			if( $._isPlainObject( superClass ) ) {
				overrides = superClass;	
				superClass = false;
				if( 'extend' in overrides && overrides.extend ) {
					superClass = overrides.extend;
					superClass = true;
					delete overrides.extend;
				}
			}
			if( Nex.isNexConstructor( superClass ) ) {
				
				superClass = superClass;
				
			} else if( superClass && Nex.getClass( superClass ) ) {//Nex.classes // (superClass in Nex)
				
				superClass = Nex.getClass( superClass );//Nex.classes
				
			} else {
				//superClass = false;	
				superClass = Nex.widget();
				notExist = true;
			}
			
			superClassName = notExist ? null : superClass.getXType();
			
			subclass = Nex.widget(subclass);
			//只复制数组和(深复制)对象
			var copy = function(data){
				if( $.isArray( data ) ) {
					return  [].concat(data);	
				} else if( $.isPlainObject(data) ) {
					return $.extend(true,{},data);
				} else {
					return data;	
				}
			};
			
			if( superClass ) {
			
				for( var k in superClass ) {
					if( k === '_optionsList' ) {
						subclass[k] = [];
						continue;	
					}
					subclass[k] = copy(superClass[k]);	
				}
				var prototype = superClass['prototype'];
				for( var p in prototype ) {
					subclass.prototype[p] = copy(prototype[p]);		
				}
				subclass.prototype.superclass = superClass;
				subclass.superclass = superClass;
			}
			//overrides 覆盖
			overrides = $.extend( {},overrides );
			var aliasName,configs,xtype,mconfigs = [];
			if( 'alias' in overrides && overrides.alias ) {
				aliasName = overrides.alias+'';
				delete overrides.alias; 	
			}
			if( 'configs' in overrides && overrides.configs ) {
				configs = overrides.configs;
				delete overrides.configs; 	
			}
			
			if( 'xtype' in overrides && overrides.xtype ) {
				xtype = overrides.xtype+'';
				delete overrides.xtype; 
			}
			var m_overrides = {};
			if( 'mixins' in overrides && overrides.mixins ) {
				overrides.mixins = $.isArray( overrides.mixins ) ? overrides.mixins : [overrides.mixins];
				$.each( overrides.mixins,function(i,d){
					if( $.isFunction( d ) ) {
						d = d( m_overrides );	
					}
					if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
						d = Nex.getMixins( d );
					}
					//组合对象的configs也会被当作组件的参数
					if( $.isPlainObject( d ) && !$.isEmptyObject( d ) ) {
						d = $.extend( true,{},d );
						if( 'configs' in d && d.configs ) {
							mconfigs.push( d.configs );
							delete d.configs; 	 	
						}
						$.extend( m_overrides,d );		
					}
				} );
				overrides.mixins.length = 0;
				delete overrides.mixins;
			}
			//overrides 可覆盖组合的属性
			overrides = $.extend( {},m_overrides,overrides );
			for( var m in overrides ) {
				subclass.prototype[m] = copy(overrides[m]);	
			}
			
			//清空父级的配置参数
			subclass['_optionsList'] = [];
			
			/*getSuperClassXType设置*/
			subclass.prototype['getSuperClassXType'] = function(){
				return superClassName;
			};	
			subclass['getSuperClassXType'] = function(){
				return superClassName;
			};	
			/*getXType设置*/
			subclass.prototype['getXType'] = function(){
				return subclassName;
			};	
			subclass['getXType'] = function(){
				return subclassName;
			};

			subclass.prototype.constructor = subclass;
			subclass.constructor = subclass;
			//兼容
			subclass.fn = subclass.prototype;
			//设置一个全局变量
			Nex.parseSubClass( subclassName,subclass );
			
			if( aliasName ) {
				var __psc = Nex.__psc;
				Nex.__psc = true;
				var aliasNames = $.trim(aliasName).split(/\s+/g);
				$.each( aliasNames,function(i,n){
					Nex.parseSubClass( n,subclass );
					Nex.addClass( n,subclass );
				} );
				Nex.__psc = __psc;
			}
			if( xtype ) {
				var xtypes = $.trim(xtype).split(/\s+/g);
				$.each( xtypes,function(i,t){
					subclass.setXType(t);		
				} );
			}
			$.each( mconfigs,function(i,c){
				subclass.setOptions(c);	
			} );
			if( configs ) {
				subclass.setOptions(configs);		
			}
			
			return subclass;
		},
		define : function(){
			return this.extend.apply( this,arguments );	
		},
		emptyFn : function(){},
		error : function( msg ){
			var undef,
				e = new Error((msg===undef?'':msg));
			throw e;
			return e;	
		}
	};
})(window,jQuery);
/*
*ExtJS 常用参数
*/
(function(){

    var check = function(regex){
            return regex.test(Nex.userAgent);
        },
		isStrict = document.compatMode == "CSS1Compat",
        version = function (is, regex) {
            var m;
            return (is && (m = regex.exec(Nex.userAgent))) ? parseFloat(m[1]) : 0;
        },
		docMode = document.documentMode,
        isOpera = check(/opera/),
        isOpera10_5 = isOpera && check(/version\/10\.5/),
        isChrome = check(/\bchrome\b/),
        isWebKit = check(/webkit/),
        isSafari = !isChrome && check(/safari/),
        isSafari2 = isSafari && check(/applewebkit\/4/), 
        isSafari3 = isSafari && check(/version\/3/),
        isSafari4 = isSafari && check(/version\/4/),
        isSafari5 = isSafari && check(/version\/5/),
        isIE = !isOpera && check(/msie/),
        isIE7 = isIE && ((check(/msie 7/) && docMode != 8 && docMode != 9) || docMode == 7),
        isIE8 = isIE && ((check(/msie 8/) && docMode != 7 && docMode != 9) || docMode == 8),
        isIE9 = isIE && ((check(/msie 9/) && docMode != 7 && docMode != 8) || docMode == 9),
        isIE6 = isIE && check(/msie 6/),
        isGecko = !isWebKit && check(/gecko/),
        isGecko3 = isGecko && check(/rv:1\.9/),
        isGecko4 = isGecko && check(/rv:2\.0/),
        isGecko5 = isGecko && check(/rv:5\./),
        isFF3_0 = isGecko3 && check(/rv:1\.9\.0/),
        isFF3_5 = isGecko3 && check(/rv:1\.9\.1/),
        isFF3_6 = isGecko3 && check(/rv:1\.9\.2/),
        isWindows = check(/windows|win32/),
        isMac = check(/macintosh|mac os x/),
        isLinux = check(/linux/),
        chromeVersion = version(true, /\bchrome\/(\d+\.\d+)/),
        firefoxVersion = version(true, /\bfirefox\/(\d+\.\d+)/),
        ieVersion = version(isIE, /msie (\d+\.\d+)/),
        operaVersion = version(isOpera, /version\/(\d+\.\d+)/),
        safariVersion = version(isSafari, /version\/(\d+\.\d+)/),
        webKitVersion = version(isWebKit, /webkit\/(\d+\.\d+)/),
        isSecure = /^https/i.test(window.location.protocol);

    
    try {
        document.execCommand("BackgroundImageCache", false, true);
    } catch(e) {}



    var nullLog = function () {};
    nullLog.info = nullLog.warn = nullLog.error = Nex.emptyFn;

    $.extend(Nex, {
        
		
        SSL_SECURE_URL : isSecure && isIE ? 'javascript:\'\'' : 'about:blank',


        USE_NATIVE_JSON : false,


        isStrict: isStrict,


        isIEQuirks: isIE && !isStrict,

        
        isOpera : isOpera,

        
        isOpera10_5 : isOpera10_5,

        
        isWebKit : isWebKit,

        
        isChrome : isChrome,

        
        isSafari : isSafari,

        
        isSafari3 : isSafari3,

        
        isSafari4 : isSafari4,

        
        isSafari5 : isSafari5,

        
        isSafari2 : isSafari2,

		IEVer : ieVersion,
        
        isIE : isIE,

        
        isIE6 : isIE6,

        
        isIE7 : isIE7,

        
        isIE8 : isIE8,

        
        isIE9 : isIE9,

        
        isGecko : isGecko,

        
        isGecko3 : isGecko3,

        
        isGecko4 : isGecko4,

        
        isGecko5 : isGecko5,

        
        isFF3_0 : isFF3_0,

        
        isFF3_5 : isFF3_5,

        
        isFF3_6 : isFF3_6,

        
        isFF4 : 4 <= firefoxVersion && firefoxVersion < 5,

        
        isFF5 : 5 <= firefoxVersion && firefoxVersion < 6,

        
        isLinux : isLinux,

        
        isWindows : isWindows,

        
        isMac : isMac,

        
        chromeVersion: chromeVersion,

        
        firefoxVersion: firefoxVersion,

        
        ieVersion: ieVersion,

        
        operaVersion: operaVersion,

        
        safariVersion: safariVersion,

        
        webKitVersion: webKitVersion,

        
        isSecure: isSecure,

        
        escapeRe : function(s) {
            return s.replace(/([-.*+?^${}()|[\]\/\\])/g, "\\$1");
        },
		
        
        log :
            nullLog,
		
        
        invoke : function(arr, methodName){
            var ret = [],
                args = Array.prototype.slice.call(arguments, 2);
            $.each(arr, function(i,v) {
                if (v && typeof v[methodName] == 'function') {
                    ret.push(v[methodName].apply(v, args));
                } else {
                    ret.push(undefined);
                }
            });
            return ret;
        }
		
		
    });
})();
/*
*常用函数
*/
(function(){
	$.extend(Nex, {
		htmlEncode: (function() {
			var entities = {
				'&': '&amp;',
				'>': '&gt;',
				'<': '&lt;',
				'"': '&quot;'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					return entities[capture];
				});
			};
		})(),
		htmlDecode: (function() {
			var entities = {
				'&amp;': '&',
				'&gt;': '>',
				'&lt;': '<',
				'&quot;': '"'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + '|&#[0-9]{1,5};' + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					if (capture in entities) {
						return entities[capture];
					} else {
						return String.fromCharCode(parseInt(capture.substr(2), 10));
					}
				});
			};
		})()	
	});	
})();
/********************************************************
**************Nex.Manager组件****************************
**********管理创建的所有组件,常用来检测组件大小设置************
**********************************************************/
Nex.GET_CMPS_CLEAR = false;//每次调用getCmp()是会自动gc 
Nex.RESIZE_DELAY = 100;//每次调用getCmp()是会自动gc 
Nex.MAX_REMOVE_NUM = 5;// 组件的移除 并不会立刻刷新层级关系，而是达到一定数量后才执行 
Nex._Manager = Nex.widget('_manager');
Nex._Manager.fn.extend({
	compRoot : 'root',
	//所有组件列表				   
	components : {},
	//组件树形
	_levelCmps : {},
	/*autoResize的组件层次关系*/
	_autoResizeLevelCmps : {},
	//组件ID的所有可resize的父级组件
	_init :　function(opt){
		var self = this;
		opt.autoDestroy = false;
	},
	__wrt : 0,
	_sysEvents : function(){
		var self = this;
		$(function(){
			var winSize = {
				width : $(window).width(),	
				height : $(window).height()
			};		
			
			$(window).unbind("resize.Manager");
			$(window).bind("resize.Manager",function(){
				if( self.__wrt ) {
					clearTimeout( self.__wrt );	
					self.__wrt = 0;
				}
				self.__wrt = setTimeout(function(){
					clearTimeout( self.__wrt );	
					self.__wrt = 0;
					var win_w = $(window).width();
					var win_h = $(window).height();
					if( winSize.width === win_w && winSize.height === win_h ) {
						return;	
					}
					winSize.width = win_w;
					winSize.height = win_h;
					
					self.fireEvent("onResize");	
					self.fireEvent("onBrowserResize");	
				},Nex.RESIZE_DELAY);			
			});
							 
		});
		self.bind( 'onResize._sys',self._resize,self );
		return self;
	},
	//清理comps 删除无用的cmp
	_refreshCmps : function( m ){
		var self = this,undef;	
		var cmps = self.components;
		var i = 0;
		for( var id in cmps ) {
			if(!self.isExists( id )) {
				i++;	
			}
		}
		if( m || (i && i>=Nex.MAX_REMOVE_NUM) ) {
			self.cmpChange();	
		}
		return i;
	},
	/*
	*获取组件 获取所有组件时 每次都会调用_refreshCmps清空无效的组件
	*/
	getCmp : function(id){
		var self = this,undef;
		if( id === undef ) {
			if( Nex.GET_CMPS_CLEAR ) {
				self._refreshCmps();
			}
			return self.components;
		}
		self.isExists( id );	
		return self._undef(self.components[id],null);	
	},
	//获取当前分组名的所有组件
	getGroup : function(name){
		var self = this,undef;
		if( name === undef ) {
			return [];
		}
		var c = [];
		var comps = self.getCmp();
		if( name === '*' ) {
			$.each( comps,function(i,d){
				c.push(d);					   
			} );
			return c;	
		}
		
		name = $.trim(name+'').split(/\s+/g);
		
		if( !name ) return c;
		
		for( var id in comps ) {
			var obj = comps[id];
			if( obj ) {
				var gname = $.trim(obj.C('groupName')+'').split(/\s+/g);
				var str_gname = gname.toString();
				for( var i=0,len=name.length;i<len;i++ ) {
					var n = name[i];
					if( gname.length && str_gname.indexOf(n)!== -1 ) {// name === gname
						c.push( obj );
						break;
					}	
				}
			}
		}
		return c;
	},
	addCmp : function(id,cmp){
		this.components[id] = cmp;
		this.cmpChange();
	},
	/*
	*组件有变动 如 增 删 位置变动时应该调用 特别是 “增”其次是“位置变动”再次是“删” 
	*/
	cmpChange : function(){
		this.__disposed1 = false;
		this.__disposed2 = false;		
	},
	//删除组件
	removeCmp : function(id){
		//this._cmps[id] = null;
		if( this.components[id] && this.components[id]['fireEvent'] ) {
			this.components[id]['fireEvent']('onDestroy');	
		}
		this.components[id] = null;
		delete this.components[id];
		//delete this._cmps[id];
	},
	//判断id是否存在 如果不存在则删除
	isExists : function(id){
		var self = this;
		var cmp = self.components[id];
		
		if( cmp && (cmp.getDom()).length ) {
			return true;	
		}

		//autoDestroy 如果清除dom后组件就不再用，autoDestroy设置为true autoResize 应该也是为true的
		//这里可能存有bug 例如window按关闭后会销毁dom但是window组件还是存在的  --components
		//self._cmps[id] = null;//不再设置为null，而是获取dom是否存在
		if( cmp && cmp.C('autoDestroy') ) {
			self.removeCmp(id);	
		}
		//如果组件找不到dom 那么就从resize列表移除
		//delete self._cmps[id];	
		return false;
	},
	_getDomCmps : function( el ){//待更新
		var el = $(el);
		if( !el.length ) return false;
		var self = this	
			,undef
			,rlist = []
			,cmp = el.closest('.nex-component-item')
			,pid;
			
		pid = cmp.length ? cmp.attr('id') : self.compRoot;
		
		var cmps = self.components;
		var levelCmps = self.getLevelCmps();
		var list = (pid in levelCmps) ? levelCmps[pid] : [];
		
		for( var i=0;i<list.length;i++ ) {
			var d = list[i];
			var cmp = cmps[d.id];
			if( !cmp ) continue;
			rlist.push( cmp )	;
		}
		return rlist;	
	},
	//更新指定dom下的组件大小
	resizeDom : function(el){////待更新
		var rlist = this._getDomCmps( el );
		if( rlist === false ) return this;
		for( var i=0;i<rlist.length;i++ ) {
			var cmp = rlist[i];
			if( cmp && cmp.isAcceptResize() ) {
				cmp.resize();	
			}
		}
		return this;
	},
	//更新所有组件大小 如果指定cid 只更新指定组件下的所有组件的大小
	resize : function( cid ){
		this._resize( cid );	
		return this;
	},
	//更新组件的层级关系
	refreshComponents : function(){
		this.refreshLevelCmps();
		this.refreshAutoResizeLevelCmps();
	},
	//获取当前ID组件下的子组件 
	getChildrens : function( id ){//待更新
		var self = this,undef;
		var rlist = [];
		var cmps = self.components;
		var levelCmps = self.getLevelCmps();
		
		var pid = id;
		
		var list = (pid in levelCmps) ? levelCmps[pid] : [];
		
		for( var i=0;i<list.length;i++ ) {
			var d = list[i];
			var cmp = cmps[d.id];
			if( !cmp ) continue;
			rlist.push( cmp );
		}
		return rlist;
	},
	//获取当前ID组件下的所有子组件 
	getAllChildrens : function( id ){//待更新
		var self = this,undef;
		var list = [];
		var _list = self.getChildrens( id );
		list = list.concat( _list );
		for( var i=0,len=_list.length;i<len;i++ ) {
			var cmp = _list[i];
			if( !cmp ) continue;
			var id = cmp.C( 'id' );
			list = list.concat(self.getAllChildrens( id ));	
		}
		return list;
	},
	//获取当domID下的子组件
	getChildrensByDom : function( el ){
		var self = this,undef;
		return self._getDomCmps( el ) || [];
	},
	//获取当前domID组件下的所有子组件 
	getAllChildrensByDom : function( el ){
		var self = this,undef;
		//self.refreshComponents();
		var list = [];
		var _list = self._getDomCmps( el ) || [];
		list = list.concat( _list );
		for( var i=0,len=_list.length;i<len;i++ ) {
			var cmp = _list[i];
			if( !cmp ) continue;
			var id = cmp.C( 'id' );
			list = list.concat(self.getAllChildrens( id ));	
		}
		return list;
	},
	/*
	*刷新组件之间的层级关系 
	*/
	refreshLevelCmps : function(){
		this.__disposed1 = false;
		return this.getLevelCmps();	
	},
	/*
	*遍历组件之间的层级关系 
	*/
	__disposed1 : false,
	getLevelCmps : function(){
		var self = this,undef;

		if( self.__disposed1 ) {
			return self._levelCmps;	
		}
		
		self._refreshCmps();
		
		var cmps = self.components;
		var list = cmps;
		
		self._levelCmps = {};
		
		var lcs = self._levelCmps;

		for( var id in list ) {
			var cmp = list[id];
			if( cmp ) {
				
				var pid = self.compRoot;
				
				var parent = $("#"+id).parents(".nex-component-item:first");
				if( parent.length ) {
					var _id = parent.attr('id');
					var  _p = cmps[_id];
					if( _p ) {
						pid = _id;
					}
				}
				var data = {
					id : id,
					pid : pid
				};
				
				lcs[pid] = lcs[pid] === undef ? [] : lcs[pid];
				lcs[pid].push( data );
			}	
		}
		
		self.__disposed1 = true;

		return self._levelCmps;
	},
	/*
	*获取autoResize = true的组件
	*/
	getAutoResizeCmps : function(){
		var self = this,undef;
		var cmps = self.components;	
		var rlist = {};
		for( var id in cmps ) {
			var cmp = cmps[id];	
			if( cmp.configs.autoResize ) {
				rlist[id] = cmp;	
			}
		}
		return rlist;
	},
	/*
	*刷新autoResize组件之间的层级关系 
	*/
	refreshAutoResizeLevelCmps : function(){
		this.__disposed2 = false;
		return this.getAutoResizeLevelCmps();	
	},
	/*
	*遍历autoResize组件之间的层级关系 
	*/
	__disposed2 : false,
	getAutoResizeLevelCmps : function(){
		var self = this,undef;

		if( self.__disposed2 ) {
			return self._autoResizeLevelCmps;	
		}
		
		self._refreshCmps();
		
		var cmps = self.components;
		var list = self.getAutoResizeCmps();
		
		self._autoResizeLevelCmps = {};
		
		var lcs = self._autoResizeLevelCmps;

		for( var id in list ) {
			var cmp = list[id];
			if( cmp ) {
				
				var pid = self.compRoot;
				
				var parents = $("#"+id).parents(".nex-component-item");
				parents.each( function(){
					var id = $(this).attr('id');
					var  _p = cmps[id];
					if( _p && _p.configs.autoResize ) {//_p.C('autoResize')
						pid = id;
						return false;	
					}
				} );
				
				var data = {
					id : id,
					pid : pid
				};
				
				lcs[pid] = lcs[pid] === undef ? [] : lcs[pid];
				lcs[pid].push( data );
			}	
		}
		
		self.__disposed2 = true;

		return self._autoResizeLevelCmps;
	},
	/*
	*更新当前id下 autoResize=true的子组件大小
	*/
	_resize : function( cid ){
		var self = this,undef;
		var cmps = self.components;
		var cid = cid === undef ? self.compRoot : cid;
		
		var llcmps = self.getAutoResizeLevelCmps();
		
		var list = llcmps[cid];
		if( !$.isArray( list ) ) return;
		
		for( var i=0;i<list.length;i++ ) {
			var d = list[i];
			var cmp = cmps[ d.id ];
			if( cmp && cmp.isAcceptResize() ) {
				cmp.resize();
			}
		}
	},
	xtypes : {},
	addXtype : function(xtype,func){
		this.xtypes[xtype] = func;	
	},
	__def : {},
	//创建组件
	create : function(){
		var self = this,undef;
		var argvs = [].slice.apply(arguments);
		var len = argvs.length;
		if( len<=0 ) return false;
		var def = self.__def;
		self.__def = {};
		if( len > 1 ) {
			var xtype = argvs[0];
			var opt = $.extend({},typeof argvs[1] === 'object' ? argvs[1] : {},def);
			if( Nex.isNexConstructor( xtype ) ) {
				return new xtype( opt );
			}
			if( (xtype in self.xtypes) && $.isFunction( self.xtypes[ xtype ] ) ) {
				return self.xtypes[ xtype ]( opt );	
			}
		} else if( Nex.isNexConstructor( argvs[0] ) ) {
			return new argvs[0]( def );
		} else {
			argvs[0] = argvs[0] === undef ? {} : argvs[0];
			if( typeof argvs[0] === 'string' ) {
				argvs[0] = {
					xtype : argvs[0]	
				};		
			}
			argvs[0] = $.extend( {},argvs[0],def );
			if( 'xtype' in argvs[0] ){
				if( (argvs[0]['xtype'] in self.xtypes) && $.isFunction( self.xtypes[ argvs[0]['xtype'] ] ) ) {
					return self.xtypes[ argvs[0]['xtype'] ]( argvs[0] );	
				}
			}	
		}
		//如果在xtypes中找不到 就直接从Nex中创建
		if( len ) {
			var type= len>1?argvs[0]:argvs[0]['xtype'];
			var opt = len>1?argvs[1]:argvs[0];
			$.extend( opt,def );
			var o = Nex.getClass(type);
			if( o && $.isFunction( o )  ) {
				return new o( opt );
			}
		}
		return false;
	},
	//创建服务组件
	createServer : function(){
		this.__def = {
			autoDestroy : false,
			autoRender  : true	
		}	
		return this.create.apply( this,arguments );
	},
	/*
	给组件发送消息 一般当作自定义消息来使用
	@ *ids 发送的组件ID 可以是数组 或者是 组件对象，如果为"*"则发送给所有组件
	@ *evt 发送的消息事件
	@ params 发送的参数 可以是数组
	@ sender 发送者 这个参数可以通过 arguments[ arguments.length-1 ] 获得
	*/
	sendMessage : function( ids,evt,params,sender ){
		var self = this,undef;
		var cmps = self.getCmp();
		var params = self._undef( params,[] );
		params = $.isArray( params ) ? params : [ params ];
		if( sender ) {
			params.push( sender );		
		}
		if( ids === undef ) return false;
		
		if( ids === '*' ) {
			for( var obj in cmps ) {
				var cmp = cmps[obj];
				if( !cmp.isSleep() ) {
					cmp.fireEvent(evt,params);
				}
			}	
		}
		
		ids = $.isArray( ids ) ? ids : [ ids ];
		
		for( var i=0,len=ids.length;i<len;i++ ) {
			var cmpid = ids[i];
			if( Nex.isNex( cmpid ) ) {
				if( !cmpid.isSleep() ) {
					cmpid.fireEvent(evt,params);
				}
			} else {
				cmp = cmps[cmpid];
				if( cmp ) {
					if( !cmp.isSleep() ) {
						cmp.fireEvent(evt,params);	
					}
				}
			}
		}
		return true;
	},
	/*作用同sendMessage 只是会立即返回*/
	postMessage : function(ids,evt,params,sender){
		var self = this,undef;
		setTimeout(function(){
			self.sendMessage( ids,evt,params,sender );					
		},0);
		return true;
	},
	/*
	给组件发送消息 一般当作自定义消息来使用
	@ *name 组件的groupName
	@ *evt 发送的消息事件
	@ params 发送的参数 可以是数组
	@ sender 发送者 这个参数可以通过 arguments[ arguments.length-1 ] 获得
	*/
	sendMessageByGroupName : function(name,evt,params,sender){
		var self = this,undef;
		
		if( name === undef ) return false;
		
		var cmps = self.getGroup( name );
		
		var params = self._undef( params,[] );
		params = $.isArray( params ) ? params : [ params ];
		if( sender ) {
			params.push( sender );		
		}
		
		for( var i=0,len=cmps.length;i<len;i++ ) {
			var cmp = cmps[i];
			if( !cmp.isSleep() ) {
				cmp.fireEvent(evt,params);
			}
		}	
			
		return true;	
	},
	sendMessageToGroup : function(){
		return this.sendMessageByGroupName.apply( this,arguments );	
	},
	/*作用同sendMessageByGroupName 只是会立即返回*/
	postMessageByGroupName : function(name,evt,params,sender){
		var self = this,undef;
		setTimeout(function(){
			self.sendMessageByGroupName( name,evt,params,sender );					
		},0);
		return true;	
	},
	postMessageToGroup : function(){
		return this.postMessageByGroupName.apply( this,arguments );	
	}
});
Nex.Manager = new Nex._Manager( {
	autoDestroy : false,
	autoRender : true	
} );
/***************************************
****************Nex功能扩展**************
****************************************/
$.each( ['gc','create','Create','createserver','createServer','CreateServer','removeComponent'
			,'removeServer','get','getCmp','getGroup','getChildrens','getAllChildrens'
			,'getChildrensByDom','getAllChildrensByDom','refreshComponents','resize'
			,'sendMessage','postMessage','sendMessageByGroupName','sendMessageToGroup'
			,'postMessageByGroupName','postMessageToGroup'],function(i,method){
	var m = Nex.Manager;
	var alias = {
		gc 				: '_refreshCmps',
		Create 			: 'create',
		createserver 	: 'createServer',
		CreateServer 	: 'createServer',
		removeComponent	: 'removeCmp',
		removeServer	: 'removeCmp',
		get				: 'getCmp',
		resize			: '_resize'	
	};
	var returnself = {
		gc 							: true,
		removeComponent 			: true,
		removeServer				: true,
		resize 						: true,
		sendMessage 				: true,
		postMessage 				: true,
		sendMessageByGroupName 		: true,
		sendMessageToGroup 			: true,
		postMessageByGroupName 		: true,
		postMessageToGroup 			: true
	};
	Nex[ method ] = function(){
		var tmp = m[ alias[method] || method ].apply( m,arguments );
		return returnself[method] ? this : tmp;
	};
} );

/*
Nex-jquery插件
resizeCmp
sendMessage
postMessage
*/
jQuery.fn.extend({
	resizeCmp : function() {
		return this.each(function(){
			Nex.Manager.resizeDom( this );	
		});
	},
	sendMessage : function( eventType,params,sender ){
		var arg = [].slice.apply(arguments);
		
		if( !arg.length ) return this;
		
		var everyone = true;
		if( $.type(arg[ arg.length-1 ]) === 'boolean' ) {
			everyone = arg[ arg.length-1 ];
			arg.pop();
		}
		return this.each(function(){
			
			var cmps = everyone ? Nex.Manager.getAllChildrensByDom( this ) : Nex.Manager.getChildrensByDom( this );
			
			Nex.Manager.sendMessage.apply( Nex.Manager,[ cmps ].concat( arg ) );
		});	
	},
	postMessage : function( eventType,params,sender ){
		var arg = [].slice.apply(arguments);
		
		if( !arg.length ) return this;
		
		var everyone = true;
		if( $.type(arg[ arg.length-1 ]) === 'boolean' ) {
			everyone = arg[ arg.length-1 ];
			arg.pop();
		}
		return this.each(function(){
			
			var cmps = everyone ? Nex.Manager.getAllChildrensByDom( this ) : Nex.Manager.getChildrensByDom( this );
			
			Nex.Manager.postMessage.apply( Nex.Manager,[ cmps ].concat( arg ) );
		});		
	}
});
/*
jquery.easing.js
*/
jQuery.easing['jswing']=jQuery.easing['swing'];jQuery.extend(jQuery.easing,{def:'easeOutQuad',swing:function(x,t,b,c,d){return jQuery.easing[jQuery.easing.def](x,t,b,c,d);},easeInQuad:function(x,t,b,c,d){return c*(t/=d)*t+b;},easeOutQuad:function(x,t,b,c,d){return-c*(t/=d)*(t-2)+b;},easeInOutQuad:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t+b;return-c/2*((--t)*(t-2)-1)+b;},easeInCubic:function(x,t,b,c,d){return c*(t/=d)*t*t+b;},easeOutCubic:function(x,t,b,c,d){return c*((t=t/d-1)*t*t+1)+b;},easeInOutCubic:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t+b;return c/2*((t-=2)*t*t+2)+b;},easeInQuart:function(x,t,b,c,d){return c*(t/=d)*t*t*t+b;},easeOutQuart:function(x,t,b,c,d){return-c*((t=t/d-1)*t*t*t-1)+b;},easeInOutQuart:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t*t+b;return-c/2*((t-=2)*t*t*t-2)+b;},easeInQuint:function(x,t,b,c,d){return c*(t/=d)*t*t*t*t+b;},easeOutQuint:function(x,t,b,c,d){return c*((t=t/d-1)*t*t*t*t+1)+b;},easeInOutQuint:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t*t*t+b;return c/2*((t-=2)*t*t*t*t+2)+b;},easeInSine:function(x,t,b,c,d){return-c*Math.cos(t/d*(Math.PI/2))+c+b;},easeOutSine:function(x,t,b,c,d){return c*Math.sin(t/d*(Math.PI/2))+b;},easeInOutSine:function(x,t,b,c,d){return-c/2*(Math.cos(Math.PI*t/d)-1)+b;},easeInExpo:function(x,t,b,c,d){return(t==0)?b:c*Math.pow(2,10*(t/d-1))+b;},easeOutExpo:function(x,t,b,c,d){return(t==d)?b+c:c*(-Math.pow(2,-10*t/d)+1)+b;},easeInOutExpo:function(x,t,b,c,d){if(t==0)return b;if(t==d)return b+c;if((t/=d/2)<1)return c/2*Math.pow(2,10*(t-1))+b;return c/2*(-Math.pow(2,-10*--t)+2)+b;},easeInCirc:function(x,t,b,c,d){return-c*(Math.sqrt(1-(t/=d)*t)-1)+b;},easeOutCirc:function(x,t,b,c,d){return c*Math.sqrt(1-(t=t/d-1)*t)+b;},easeInOutCirc:function(x,t,b,c,d){if((t/=d/2)<1)return-c/2*(Math.sqrt(1-t*t)-1)+b;return c/2*(Math.sqrt(1-(t-=2)*t)+1)+b;},easeInElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d)==1)return b+c;if(!p)p=d*.3;if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);return-(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;},easeOutElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d)==1)return b+c;if(!p)p=d*.3;if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);return a*Math.pow(2,-10*t)*Math.sin((t*d-s)*(2*Math.PI)/p)+c+b;},easeInOutElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d/2)==2)return b+c;if(!p)p=d*(.3*1.5);if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);if(t<1)return-.5*(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;return a*Math.pow(2,-10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p)*.5+c+b;},easeInBack:function(x,t,b,c,d,s){if(s==undefined)s=1.70158;return c*(t/=d)*t*((s+1)*t-s)+b;},easeOutBack:function(x,t,b,c,d,s){if(s==undefined)s=1.70158;return c*((t=t/d-1)*t*((s+1)*t+s)+1)+b;},easeInOutBack:function(x,t,b,c,d,s){if(s==undefined)s=1.70158;if((t/=d/2)<1)return c/2*(t*t*(((s*=(1.525))+1)*t-s))+b;return c/2*((t-=2)*t*(((s*=(1.525))+1)*t+s)+2)+b;},easeInBounce:function(x,t,b,c,d){return c-jQuery.easing.easeOutBounce(x,d-t,0,c,d)+b;},easeOutBounce:function(x,t,b,c,d){if((t/=d)<(1/2.75)){return c*(7.5625*t*t)+b;}else if(t<(2/2.75)){return c*(7.5625*(t-=(1.5/2.75))*t+.75)+b;}else if(t<(2.5/2.75)){return c*(7.5625*(t-=(2.25/2.75))*t+.9375)+b;}else{return c*(7.5625*(t-=(2.625/2.75))*t+.984375)+b;}},easeInOutBounce:function(x,t,b,c,d){if(t<d/2)return jQuery.easing.easeInBounce(x,t*2,0,c,d)*.5+b;return jQuery.easing.easeOutBounce(x,t*2-d,0,c,d)*.5+c*.5+b;}});
/*
jquery.mousewheel.js
*/
(function($){var types=['DOMMouseScroll','mousewheel'];if($.event.fixHooks){for(var i=types.length;i;){$.event.fixHooks[types[--i]]=$.event.mouseHooks;}}
$.event.special.mousewheel={setup:function(){if(this.addEventListener){for(var i=types.length;i;){this.addEventListener(types[--i],handler,false);}}else{this.onmousewheel=handler;}},teardown:function(){if(this.removeEventListener){for(var i=types.length;i;){this.removeEventListener(types[--i],handler,false);}}else{this.onmousewheel=null;}}};$.fn.extend({mousewheel:function(fn){return fn?this.bind("mousewheel",fn):this.trigger("mousewheel");},unmousewheel:function(fn){return this.unbind("mousewheel",fn);}});function handler(event){var orgEvent=event||window.event,args=[].slice.call(arguments,1),delta=0,returnValue=true,deltaX=0,deltaY=0;event=$.event.fix(orgEvent);event.type="mousewheel";if(orgEvent.wheelDelta){delta=orgEvent.wheelDelta/120;}
if(orgEvent.detail){delta=-orgEvent.detail/3;}
deltaY=delta;if(orgEvent.axis!==undefined&&orgEvent.axis===orgEvent.HORIZONTAL_AXIS){deltaY=0;deltaX=-1*delta;}
if(orgEvent.wheelDeltaY!==undefined){deltaY=orgEvent.wheelDeltaY/120;}
if(orgEvent.wheelDeltaX!==undefined){deltaX=-1*orgEvent.wheelDeltaX/120;}
args.unshift(event,delta,deltaX,deltaY);return($.event.dispatch||$.event.handle).apply(this,args);}})(jQuery);
/*******************************************
***************jQuery功能扩展****************
********************************************/
/*
*因为父元素的display为none 那么隐藏的子元素获取高度为0
*可调用_display短暂的显示，要记得调用后也要_hidden返回原始状态
*@param {string} 如果设置就会对元素添加样式否则直接设置display:block
*/
$.fn._display = function(_e){
	var _e = _e || 'nex-hide2show';
	var $this = $(this);
	return $this.add( $this.parents(':hidden') ).each( function(){
		if( $(this).css('display') == 'none' ) {
			$(this).addClass(_e);		
		}	
	} );
};
/*状态
*@param {string} 如果设置就会对元素移除样式否则直接设置display:none
*/
$.fn._hidden = function(_e){
	var _e = _e || 'nex-hide2show';
	return this.each(function(i){
		$(this).removeClass(_e);	
	});
};
/*
*获取和设置元素宽高
*使用同$.fn.width,不同在于如果元素隐藏也能正确获取到宽高
*/
$.fn._width = function(_e){
	if(_e==undefined){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.width()||document.body.clientWidth;
		}
		var p = null,
			$f = $(f);
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var w = $f.width();
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return w||0;
	}
	return this.width(_e);
};
/*
*获取和设置元素宽高
*使用同$.fn.height,不同在于如果元素隐藏也能正确获取到宽高
*/
$.fn._height = function(_e){
	if(_e==undefined){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.height()||document.body.clientHeight;
		}
		var p = {},
			$f = $(f);
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var h = $(f).height();
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return h||0;
	}
	return this.height(_e);
}; 
/*
*获取和设置元素宽高
*@param {int} 设置宽高
*使用同$.fn.outerWidth,不同在于可以设置宽高
*/
$.fn._outerWidth = function(_e){
	if(_e==undefined || _e === false || _e === true){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.width()||document.body.clientWidth;
		}
		var $f = $(f),p = null;
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var w = this.outerWidth(!!_e)||0;
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return w;
	}
	var isIE= Nex.isIE;
	return this.each(function(){
		var $this = $(this);					  
		if( !$.support.boxModel ){
			$this.width(_e);
		}else{
			var $f = $this,
				p = null,
				isHidden = $f.is(":hidden");
			if( isHidden ) {
				p = $f._display('nex-hide2show');
			}
			var _w = _e-($f.outerWidth()-$f.width());
			_w = _w<0?0:_w;
			$f.width(_w);
			if( isHidden ) {
				p._hidden('nex-hide2show');	
			}
		}
	});
}; 
/*
*获取和设置元素宽高
*@param {int} 设置宽高
*使用同$.fn.outerHeight,不同在于可以设置宽高
*/
$.fn._outerHeight = function(_f){
	if(_f==undefined || _f === false || _f === true){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.height()||document.body.clientHeight;
		}
		var $f = $(f),p = null;
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var h = this.outerHeight(!!_f)||0;
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return h;
	}
	var isIE= Nex.isIE;
	return this.each(function(){
		var $this = $(this);					  
		if( !$.support.boxModel ){
			$this.height(_f);
		}else{
			var $f = $this,
				p = null,
				isHidden = $f.is(":hidden");
			if( isHidden ) {
				p = $f._display('nex-hide2show');
			}
			var _h = _f-($f.outerHeight()-$f.height());
			_h = _h<0?0:_h;
			$f.height(_h);
			if( isHidden ) {
				p._hidden('nex-hide2show');	
			}
		}
	});
};
/*
*返回相对offsetParent的绝对高度，而不是相对
*/
$.fn._position = function(_f){
	var undef;
	if( _f === undef ) {
		var t = this.eq(0);
		var op = t.offsetParent();
		if( op.is('body') || op.is('html') ) {
			return t.offset();	
		} else {
			var _a = t.offset(),
				_b = op.offset(),
				_c = parseFloat(op.css('borderLeftWidth')),
				_e = parseFloat(op.css('paddingLeft')),
				_c1 = parseFloat(op.css('borderTopWidth')),
				_e1 = parseFloat(op.css('paddingTop'));
			_c = isNaN( _c ) ? 0 : _c;
			_e = isNaN( _e ) ? 0 : _e;
			_c1 = isNaN( _c1 ) ? 0 : _c1;
			_e1 = isNaN( _e1 ) ? 0 : _e1;	
			var pos = {
				top : _a.top - _b.top - _c1 - _e1,
				left : _a.left - _b.left - _c - _e
			};
			return {
				top : pos.top + op.scrollTop(),	
				left : pos.left + op.scrollLeft()
			};
		}
	} else {
		return this.css( _f );	
	}
};
/*
*用CSS设置top=-100000px来达到隐藏的效果
*/
$.fn._show = function(fn){
	this.removeClass('nex-hidden');	
	if( fn && $.isFunction(fn) ) {
		fn.call(this);	
	}
	return this;
};
/*
*去除_show的隐藏效果
*/
$.fn._hide = function(fn){
	this.addClass('nex-hidden');	
	if( fn && $.isFunction(fn) ) {
		fn.call(this);	
	}
	return this;
};
/*
*检测是否是纯对象
*/
$._isPlainObject = function(obj){
	var r = $.isPlainObject(obj);
	if( r && '_outerWidth' in obj ) {
		r = false;	
	}
	return r;
};
/*
*兼容jquery低版本也支持parseHtml
*/
$._parseHTML = $.parseHTML = $.parseHTML || function( data, context, scripts ){
	var parsed,rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>)?$/;
	if ( !data || typeof data !== "string" ) {
		return null;
	}
	if ( typeof context === "boolean" ) {
		scripts = context;
		context = 0;
	}
	context = context || document;

	// Single tag
	if ( (parsed = rsingleTag.exec( data )) ) {
		return [ context.createElement( parsed[1] ) ];
	}

	parsed = jQuery.buildFragment( [ data ], context, scripts ? null : [] );
	return jQuery.merge( [],parsed.fragment.childNodes );

};
/*
*移除元素css内联样式扩展
*/
jQuery.fn.extend({
	/*
	*移除style属性(移除cssText的css)
	*@param {string} 需要移除的样式属性 可用 "," " " 分割
	*@param {boolean} 是否全匹配  否则模糊匹配 默认模糊匹配
	*/
	_removeStyle : function(proto,m){
		proto = proto+'';
		var _proto = $.trim(proto.toLowerCase());
		_proto = _proto.replace(/\s+/g,',').split(',');
		var proto = {};
		$.each( _proto,function(i,v){
			proto[v] = true;						
		} );
		return this.each(function(){
			var cssText = this.style.cssText;
			if( cssText ) {
				var css = cssText.split(';');
				var data = {};
				$.each( css , function(i,v){
					if( v ) {
						var d = v.split(':');
						if( d.length ) {
							data[$.trim(d[0].toLowerCase())] = $.trim(d[1]);
						}
					}
				} );
				var t = [];
				for( var k in data ) {
					if( m ) {
						if( k in proto ) continue;	
					} else {
						//if( k.indexOf(proto) === 0 ) continue;	
						var r = false;
						for( var key in proto ) {
							if( k.indexOf(key) === 0 ) r=true;	
						}
						if( r ) {
							continue;	
						}
					}
					t.push( k+":"+data[k]+';' );
				}
				this.style.cssText = t.join("");
			}
		});	
	},
	_visible : function( bool ){
		var undef;
		bool = bool === undef ? true : bool;
		var visible = !!bool;
		return this.each(function(){
			var $this = $(this);					  
			if( visible ) {
				$this._removeStyle('visibility');
			} else {
				$this.css('visibility','hidden');	
			}
		});	
	}				 
});
/*
selection扩展
*/
jQuery.support.selectstart = false;
jQuery.fn.extend({
	disableSelection: function() {
		return this.bind( ( $.support.selectstart ? "selectstart" : "mousedown" ) +
			".nex-disableSelection", function( event ) {
				event.preventDefault();
			});
	},
	enableSelection: function() {
		return this.unbind( ".nex-disableSelection" );
	}
});
/*
兼容 jquery 1.9 以上 移除 $.support.boxMoal
*/
if( jQuery.support.boxModel === undefined ) {
	jQuery.support.boxModel = document.compatMode === "CSS1Compat";
}
/*
是否支持 onselectstart 检查
*/
jQuery(function() {
	var body = document.body,
		div = body.appendChild( div = document.createElement( "div" ) );
		
	$.support.selectstart = "onselectstart" in div;

	// set display to none to avoid a layout bug in IE
	// http://dev.jquery.com/ticket/4014
	body.removeChild( div ).style.display = "none";
});

/*
Nex.base
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
v1.0
1.修正继承 fix不能继承父对象的所有属性 bug 严重
2.修正当_optionsList为空时，不在继承父级属性BUG 严重
3.新增getTemplate 返回一个模版对象实例 ,以前的template 不再建议，
4.新增baseUrl
5.新增deferred 和 getDeferred方法
6.修正由于继承时大部分属性和方法都是从父类直接copy过去 所有出现部分方法的变量还是父类的内容
7.通过参数绑定事件时可使用对象来设置上下文 { func,scope }
8.新增Nex.require API提供组件依赖加载
*/
/*********************
********Nex核心*******
*********************/
var Nex = Nex || (function(win,$){
	"use strict";	
	var userAgent = navigator.userAgent.toLowerCase();
	var uaMatch = /msie ([\w.]+)/.exec( userAgent ) || [];
	function getCurrentScript(h) {
		var stack,
			DOC = document,
			undef,
			h = h === undef ? true : false,
			head = DOC.getElementsByTagName("head")[0]
			;
		try {
		  a._b.c(); //强制报错,以便捕获e.stack
		} catch (e) { //safari的错误对象只有line,sourceId,sourceURL
		  if( e.sourceURL ) {
			return e.sourceURL; //safari
		  }
		  stack = e.stack;
		  if (!stack && window.opera) {//opera
			  //opera 9没有e.stack,但有e.Backtrace,但不能直接取得,需要对e对象转字符串进行抽取
			  stack = (String(e).match(/of linked script \S+/g) || []).join(" ");
		  }
		}
		if (stack) {//chrome
		  stack = stack.split(/[@ ]/g).pop(); //取得最后一行,最后一个空格或@之后的部分
		  stack = stack[0] === "(" ? stack.slice(1, -1) : stack.replace(/\s/, ""); //去掉换行符
		  return stack.replace(/(:\d+)?:\d+$/i, ""); //去掉行号与或许存在的出错字符起始位置
		}
		//IE
		var context = h ? head : DOC;
		var nodes = context.getElementsByTagName("script");
		for (var i = nodes.length, node; node = nodes[--i]; ) {
		  if ( node.readyState === "interactive") {
			  return node.src;//node.className = 
		  }
		}
	}
	var baseUrl = getCurrentScript( false );
	baseUrl = baseUrl.split('/');
	baseUrl.pop();
	baseUrl = baseUrl.join('/');
	//baseUrl = baseUrl ? baseUrl+'/':baseUrl;
	/*如果是IE浏览器 加上各版本样式*/
	$(document).ready(function(){
		if( Nex.isIE && Nex.IEVer ) {
			var cls = ['nex-ie'];
			var bd = $(document.body);
			cls.push( 'nex-ie'+Nex.IEVer );
			if( Nex.IEVer<8 ) {
				cls.push( 'nex-ielt8' );
			}
			if( Nex.IEVer<9 ) {
				cls.push( 'nex-ielt9' );
			}
			bd.addClass( cls.join(' ') );
		}
	});
	return {
		userAgent : userAgent,
		aid : 1,
		tabIndex : 1,
		zIndex : 99999,
		topzIndex : 9999999,
		scrollbarSize : false,
		resizeOnHidden : true,
		/*
		*根据参数返回模版对象
		*@param {Object} o ltag rtag simple(简单模式) 
		*@return {Object}
		*/
		getTemplate : function( o ){
			var o = o || {};
			return {
				cache1 : {},
				cache2 : {},
				helper : $.noop,//兼容用
				ltag : o.ltag || '<%',
				rtag : o.rtag || '%>',
				simple :  o.simple || false,
				compile1 : function(str, data){
					var fn = this.cache1[str] ? this.cache1[str] :
					 new Function("obj",
					"var p=[],print=function(){p.push.apply(p,arguments);};" +
					"with(obj){p.push('" +
					str
					  .replace(/[\r\t\n]/g, " ")
					  .split(this.ltag).join("\t")
					  .replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
					  .replace(new RegExp("\t=(.*?)"+this.rtag,"g"), "',$1,'")
					  .split("\t").join("');")
					  .split(this.rtag).join("p.push('")
					  .split("\r").join("\\'")
				  + "');}return p.join('');");
					this.cache1[str] = fn;
					return data ? fn( data ) : fn;
				},
				compile2 : function(str, data){//简单的模版
					var fn = this.cache2[str] ? this.cache2[str] :
					 new Function("obj",
					"var p=[],print=function(){p.push.apply(p,arguments);};" +
					"with(obj){p.push('" +
					str
					  .replace(/[\r\t\n]/g, " ")
					  .split(this.ltag).join("\t")
					  //.replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
					  .replace(new RegExp("\t(.*?)"+this.rtag,"g"), "',$1,'")
					  .split("\t").join("');")
					  .split(this.rtag).join("p.push('")
					  .split("\r").join("\\'")
				  + "');}return p.join('');");
					this.cache2[str] = fn;
					return data ? fn( data ) : fn;
				},
				compile : function(){
					if( this.simple ) {
						return this.compile2.apply(this,arguments);	
					} else {
						return this.compile1.apply(this,arguments);		
					}
				}	
			};	
		},
		/*
		*dirname
		*/
		dirname : function(baseUrl){
			baseUrl = baseUrl + '';
			baseUrl = baseUrl.split('/');
			baseUrl.pop();
			baseUrl = baseUrl.join('/');
			return baseUrl;
		},
		/*
		*private
		*safair不支持
		*/
		getcwd : function(h){
			return getCurrentScript(h);	
		},
		baseUrl : baseUrl,
		getCurrentScriptUrl : function(){
			return this.baseUrl;	
		},
		template : {
			cache : {},
			helper : $.noop,//兼容用
			ltag : '<%',//不能修改
			rtag : '%>',//不能修改
			compile : function(str, data){
				var fn = this.cache[str] ? this.cache[str] :
				 new Function("obj",
				"var p=[],print=function(){p.push.apply(p,arguments);};" +
				"with(obj){p.push('" +
				str
				  .replace(/[\r\t\n]/g, " ")
				  .split(this.ltag).join("\t")
				  .replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
				  .replace(new RegExp("\t=(.*?)"+this.rtag,"g"), "',$1,'")
				  .split("\t").join("');")
				  .split(this.rtag).join("p.push('")
				  .split("\r").join("\\'")
			  + "');}return p.join('');");
				this.cache[str] = fn;
				return data ? fn( data ) : fn;
			}
		},
		/*
		*返回随机字符串
		*@param {Number} 返回自定的长度的随机字符串 默认是6位
		*@return {String}
		*/
		generateMixed : function(n){
			var n = n || 6;
			var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
			var res = "";
			 for(var i = 0; i < n ; i ++) {
				 var id = Math.ceil(Math.random()*35);
				 res += chars[id];
			 }
			 return res;	
		},
		/*
		*返回一个不重复字符串,使用方法同generateMixed
		*/
		unique : function(n){
			var str = Nex.generateMixed(n||6);
			var aid = str+'-'+Nex.aid++;
			return aid;	
		},
		/*
		*判断是否数字格式
		*/
		isNumber : function(value) {
			return /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value) ? true : false;	
		},
		/*
		*检测当前对象是否是Nex类
		*/
		isNexConstructor : function(obj){
			return  $.type(obj) === 'function' && ('_isNexConstructor' in obj)  ? true : false;
		},
		/*
		*检测当前对象是否是Nex实例对象
		*/
		isNex : function(obj){
			return  $.type(obj) === 'object' && ('_isNex' in obj)  ? true : false;
		},
		/*
		*判断当前对象是否是xtype的对象类型 
		*/
		isXtype : function(obj){
			return ( $._isPlainObject( obj ) && ('xtype' in obj ) )	? true : false;
		},
		/*
		*检测是否是jquery实例
		*/
		isjQuery : function(obj){
			return $.type(obj) === 'object' && ('_outerWidth' in obj) ? true :　false;	
		},
		//所有Nex组件集合，目前Nex[className] 和 Nex.classes[className] 作用是一样的
		classes : {},
		getClass : function( cn ){
			return this.classes[cn];	
		},
		addClass : function( n,v ){
			this.classes[n] = v;
			return this;
		},
		_classesPaths : {},
		/*
		*动态加载组件时，设置组件路径
		*@param {String|Object} 组件名|组件和组件路径Map
		*@param {String} 组件路径
		*/
		setClassPath : function(){
			var self = this,
				argvs = arguments;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( self._classesPaths,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					self._classesPaths[argvs[0]] = argvs[1];
				}	
			}	
			return self;
		},
		/*
		*获取组件路径
		*@param {String} 组件名
		*@return {String} 组件路径
		*/
		getClassPath : function( n ){
			return this._classesPaths[n];	
		},
		/*
		*Nex组件基类包含事件机制
		*@param 组件名称
		*@param 设置组件的xtype
		*@return {NexClass}Nex组件类
		*/
		widget : function(name,xtype){
			var undef,
				//observe
				base = function(){
					this.init.apply(this,arguments);	
				},
				name = name === undef ? Nex.unique(8) : name,
				xtype = xtype === undef ? name : xtype;
			
			Nex[name] = base;	
			Nex.classes[ name ] = base;
			
			/*
			*添加xtype
			*/
			if( Nex.Manager ) {
				Nex.Manager.addXtype(xtype,function(opt){
					return new Nex.classes[name](opt);									   
				});	
			}
			
			base.fn = base.prototype = {};
			base.fn.extend = function(obj){
				$.extend(this,obj);
			};
			base.extend = function(obj){
				$.extend(this,obj);	
			};
			
			//原型设置
			base.constructor = base.prototype.constructor = base;
			base.prototype.superclass = null;
			base.superclass = null;
			
			base.fn = base.prototype;
			
			base.extend({
				//标识当前函数是属于Nex类
				_isNexConstructor : true,
				puglins : [],
				puglinsConf : {},
				puglinsEvent : {},
				defaults : {},
				eventMaps : {},//事件名映射或者别名 别名:映射名
				addExtConf : function(conf){
					var d = {};
					if( $.isFunction( conf ) ) {
						var d = conf.call( this ) || {};	
					} else {
						d = conf;	
					}
					$.extend( this.puglinsConf,d );
				},
				addExtEvent : function(events){	
					var d = {};
					if( $.isFunction( events ) ) {
						var d = events.call( this ) || {};	
					} else {
						d = events;	
					}
					$.extend( this.puglinsEvent,d );
				},
				addEventMaps : function(maps){	
					var d = {};
					if( $.isFunction( maps ) ) {
						var d = maps.call( this ) || {};	
					} else {
						d = maps;	
					}
					$.extend( this.eventMaps,d );
				},
				_optionsList : [],
				setOptions : function( options ){
					if( $.isPlainObject( options ) ) {//转化成函数方式
						var _opts = options;
						options = function(){
							return $.extend(true,{},_opts);//深复制对象
						}
					}
					if( $.isFunction( options ) ) {
						//方法一 ： 设置的时候确定superclass的参数 缺点 如果superclass做改变时不会更新  不要使用此方法！！
						//var popts = this.getSuperClassOptions();
						this._optionsList.push( function( opt,t ){
							//方法2 1.能够保证所有setOptions的第二个参数是当前对象 2.不会出现方法一的缺点
							var popts = this.getSuperClassOptions(t);
							popts = $.extend( {},popts,opt );//继承属性
							return $.extend(popts,options.call( this,popts,t ));
						} );
					}
					return this;
				},
				getSuperClassOptions : function(t){
					var ptype = this.getSuperClassXType();
					if( !ptype ) {//ptype === null || 
						return {};	
					}
					return Nex.getClass(ptype).getOptions(t);
				},
				getOptions : function(self){
					var list = this._optionsList;
					var opt = {};
					if( list.length ) {
						for( var i=0,len=list.length;i<len;i++ ) {
							var o = list[i];
							$.extend( opt, $.isFunction( o ) ? o.call(this,opt,self||this) : o  );	
						}
					} else {
						$.extend( opt, this.getSuperClassOptions( self||this )  );		
					}
					opt = this.getDefaults( opt,self || this );
					return opt;
				},
				/*
				*基础类默认参数
				*/
				_def : function(self){ 
					var self = self || this;
					return {
						_base : this.constructor,
						prefix : 'nex_',
						id : '',
						//autoRender自动渲染 会自动调用_init
						autoRender : true,//--由于部分组件没有继承html 直接继承 base 所以有些属性 还是放在base 如果后面统一后再做修改
						renderAfter : true,//true:append false:prepend
						_isInit : false,
						_isResize : false,
						//设备上下文，慎用
						context : null,
						parent : null,//指定父组件的ID 如果不指定则自动获取
						stopOnFalse : true,
						denyManager : false,//不受Manager管理组件 不建议开启
						//autoDestroy 自动回收机制 如果Nex在触发检查的时候检查不到当前元素存在时如果开启后就删除当前组件，所以如果你创建的是一个服务那就应该设为false
						autoDestroy : true,//自动回收 回收后通过Nex.get获取不到组件  autoRecovery
						autoSetResize : false,//是否根据用户的width height 自动设置autoResize --尚未实现
						autoResize : false, //接受Manager的resize调整
						autoScroll : false,
						groupName : '',//组件分组，一般有批量sendMessage 时会使用到
						resizeOnHidden : Nex.resizeOnHidden,//作废
						cls : '',
						cutHeight : 0,
						cutWidth : 0,
						deferred : $.Deferred ? $.Deferred() : null,
						autoSize : false,
						width : '100%',
						height : '100%',
						maxWidth : 0,
						maxHeight : 0,
						minHeight : 0,
						minWidth : 0,
						realWidth : null,//实际 ,width=auto时 如果max min width height 没起作用那么realWidth = auto
						realHeight : null,//同上
						_width : null,//和realWidth 不同的是 _width是一个数值
						_height : null,
						__width : 0,
						__height : 0,
						tpl : {},
						template : Nex.getTemplate(),//typeof template === 'undefined' ? Nex.template : template,//模板引擎对象
						scrollbarSize : false,
						noop : $.noop,
						self : null,
						init : $.noop,//初始化调用
						renderTo : null,//helper
						views : {},
						items : [],
						isEscape : false,
						cacheData : {},
						//_childrenList : [],//当前组件下的之组件，并不严禁， 一般做清除用
						_boxModel : true,
						eventMaps : {},
						events : {}//事件组合 	
					};
				},
				extSet : function( opt,self ){
					
					var opt = $.extend( {},this._def(self),opt );
					//扩展事件
					$.extend( opt.events,this.puglinsEvent );	
					//事件名映射扩展
					$.extend( opt.eventMaps,this.eventMaps );	
					
					return $.extend({},this.puglinsConf,opt);
				},
				getDefaults : function(opt,self){
					var _opt = {};
					var _opt = this.extSet(_opt,self);
					
					return $.extend({},_opt,opt);
				},
				_undef : function (val, defaultVal) {
					return val === undefined ? defaultVal : val;
				},
				getSuperClassXType : function(){
					return null;	
				},
				getSuperClass : function(){
					return this.superclass;	
				},
				/*
				*调用当前类的API 
				*@param method api名称
				*@param scope 作用域
				*@param data 数组参数
				*/
				invokeMethod : function( method,scope,data ){
					var obj = this;
					var func = obj.fn[method];
					if( func && $.isFunction( func ) ) {
						return func.apply( scope,$.isArray(data) ? data : [ data ] );
					}
					return;
				},
				/*
				*调用父类的API
				*@param method api名称
				*@param scope 作用域
				*@param data 数组参数
				*/
				_super : function( method,scope,data ){
					var _super = this.superclass;
					if( !_super ) return;
					var func = _super.fn[method];
					if( func && $.isFunction( func ) ) {
						return func.apply( scope,$.isArray(data) ? data : [ data ] );
					}
					return;
				},
				setXType : function(xtype){
					var b = this,
						undef;
					if( xtype === undef ) return b;
					
					b.getXType = function(){
						return xtype;	
					};
					b.fn.getXType = function(){
						return xtype;	
					};
					
					Nex.classes[ xtype ] = b;
					
					/*
					*添加xtype
					*/
					if( Nex.Manager ) {
						Nex.Manager.addXtype(xtype,function(opt){
							return new b(opt);									   
						});	
					}
					return b;	
				},
				getXType : function(){
					return xtype;	
				},
				setAliasName : function( aliasName ){
					var self = this;
					if( aliasName ) {
						var __psc = Nex.__psc;
						Nex.__psc = true;
						var aliasNames = $.trim(aliasName).split(/\s+/g);
						$.each( aliasNames,function(i,n){
							Nex.parseSubClass( n,self );
							Nex.addClass( n,self );
						} );
						Nex.__psc = __psc;
					}	
					return self;
				},
				create : function( opt ){
					return new this(opt||{});	
				},
				_Tpl : {}
				
			});
			base.fn.extend({
				//标识当前对象是Nex对象实例
				_isNex : true,
				getSuperClassXType : function(){
					return null;	
				},
				getSuperClass : function(){
					return this.superclass;	
				},
				/*
				*调用父类
				*一定不能用this.superclass.fn.method.call( self )...因为js中没有虚函数的概念 里面的this 都是指向当前对象 ，
				*如果多级继承就会出现死循环 应该明确类名eg : Nex.Form.fn.method.call( self ) or Nex.Form._super(method,self,[  ])	-推荐
				*所以在fn中无法实现super的方法
				_super : function(){
				},
				*/
				getXType : function(){
					return xtype;	
				},
				//动态添加组合 动态组合的参数不会覆盖原有参数和方法，因为会把重复的参数和方法当作用户重载
				addMixins : function( d ){
					var self = this;
					var opt = this.configs;
					var mconfigs = {};
					
					if( $.isFunction( d ) ) {
						d = d();	
					}
					if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
						d = Nex.getMixins( d );
					}
					
					//组合对象的configs也会被当作组件的参数
					if( $.isPlainObject( d ) && !$.isEmptyObject( d ) ) {
						d = $.extend( true,{},d );
						if( 'configs' in d && d.configs ) {
							mconfigs = $.extend(true,{},d.configs);
							delete d.configs; 	 	
						}
						for( var p in mconfigs ) {
							if( p in opt ) {
								continue;	
							}	
							opt[p] = mconfigs[p];//应该使用复制
						}
						for( var m in d ) {
							if( m in self ) {
								continue;	
							}	
							self[m] = d[m];//应该使用复制
						}
					}
					return self;
				},
				initConfigs : function(){
					var self = this;
					var argvs = [].slice.apply(arguments);
					var constructor = self.constructor;
					var opts = constructor.getOptions( self );
					var configs = $.extend({},opts);
					for( var i=0,len = argvs.length;i<len;i++ ) {
						var options = argvs[i];
						if( $.isFunction( options ) ) {
							options = options.call( self,configs ) || {};	
						} else {
							options = $.extend( {},options );//防止options不是一个对象 这里不建议深复制 因为怕大数据带来性能问题
						}
						//这里的event 不会被覆盖 --- 这里是否会有问题呢？
						//self.initEvents(options);//初始化用户自定义事件
						$.extend( configs,options );
					}
					//事件只初始化一次把， 会被后面的覆盖
					self.initEvents(options);//初始化用户自定义事件
					
					if( Nex.isNex(configs.parent) ) {
						var pid = configs.parent.C('id');
						configs.parent = pid;	
					}
					
					self.configs = configs;
					
					if( 'mixins' in configs ) {
						var mixins = configs.mixins;
						delete configs.mixins;
						mixins = $.isArray( mixins ) ? mixins : [mixins];
						for( var t=0,n = mixins.length;t<n;t++ ) {
							 self.addMixins( mixins[t] );
						}
					}
					
					/*如果参数中有prototype,则当前属性会赋值到当前对象的prototype*/
					var prototype = configs.prototype;
					configs.prototype = null;
					delete configs.prototype;
					
					if( prototype && $.isFunction( prototype ) ) {
						prototype = prototype.call( self,configs );
					}
					
					if( prototype && $._isPlainObject( prototype ) ) {
						$.extend( self,prototype );	
					}
					
					return self;
				},
				init : function(options) {
					var self = this;
					var argvs = [].slice.apply(arguments);
					
					//var constructor = self.constructor;
					self.initConfigs.apply( self,argvs );
					var opt = self.configs;
					opt.self = self;
		
					self._eventLocks = {};
		
					opt.id = opt.id || self.getId();
					
					opt._isInit = true;
					
					$.support.boxModel = $.support.boxModel === null ? opt._boxModel : $.support.boxModel;
					
					if( opt.autoRender ) {
						self._render();
					}
				},
				_init : function(){},
				//private
				__isRendering : false,
				_render : function( el,after ){
					var self = this;
					var opt = this.configs;
					//如果已经渲染则不能重复渲染
					if( this.__isRendering ) {
						return this;	
					}
					var el = this._undef( el,opt.renderTo );
					var after = this._undef( after,opt.renderAfter );
					
					opt.renderTo = el;	
					opt.renderAfter = after;	
					
					//系统初始化调用
					if( $.isFunction( opt.init ) && opt.init!==$.noop ) {
						opt.init.call(self,opt);
					}
					
					//系统事件绑定
					self.sysEvents();
					
					self._onStart(opt);//设置用户自定义事件
					//这些应该是html组件信息 等所有组件都继承html后可以修改
					//保存初始设置值
					opt.__width = opt.width;
					opt.__height = opt.height;
					
					this.fireEvent("onStart",[opt]);
					
					//设置状态， 已经渲染
					this.__isRendering = true;
					//添加组件到组件管理器
					if( !opt.denyManager && Nex.Manager ) {
						Nex.Manager.addCmp( opt.id,self );
					}
					//此处应该触发onRender事件 or onAfterRender onBefreoRender
					opt.cls = 'nex-component-item '+opt.cls;
					
					this._init( opt );
					
					return this;	
				},
				render : function( el,after ){
					if( this.__isRendering ) {
						this.renderTo.apply( this,arguments );
					} else {
						this._render.apply( this,arguments );	
					}
					return this;	
				},
				//判断是否rendering
				isRendering : function(){
					return this.__isRendering;	
				},
				/*
				* @m default=false true(更新层级关系)
				*/
				enableAutoResize : function(  ){	
					this.configs.autoResize = true;
					return this;
				},
				/*
				* @m default=false true(更新层级关系)
				*/
				disabledAutoResize : function( m ){
					this.configs.autoResize = false;
					return this;
				},
				//数组移动算法
				// pos 要移动的元素
				array_move : Nex.array_move,
				/*
				*删除数组元素 index 为下标或者下表数组 或者回调函数 回调返回true即可
				*/
				array_splice : Nex.array_splice,
				/*				
				*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面
				*/
				array_insert : Nex.array_insert,
				array_clear : Nex.array_clear,
				array_copy : Nex.array_copy,
				//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
				copyArray : Nex.copyArray,
				//copy只是对数组或对象只是增加一个引用计数，并不是深复制
				copy : Nex.copy,
				/*
				*判断元素垂直滚动条是否滚动到底 @dom
				*/
				_checkYScrollEnd : function( el ){
					return Nex._checkYScrollEnd( el );
				},
				/*
				*判断元素水平滚动条是否滚动到底 @dom
				*/
				_checkXScrollEnd : function( el ){
					return Nex._checkXScrollEnd( el );	
				},
				/*
				*验证是否滚动到低 @el dom @a left/top
				*/
				isScrollEnd : function( el,a ){
					return Nex.isScrollEnd( el,a );	
				},
				str_number : Nex.str_number,
				_undef : function (val, d) {
					return val === undefined ? d : val;
				},
				distArr : function( arr ){
					var obj={},temp=[];
					for(var i=0;i<arr.length;i++){
						if(!obj[arr[i]]){
							temp.push(arr[i]);
							obj[arr[i]] =true;
						}
					}
					return temp;	
				},
				//只接受 字符串 number 
				inArray : function(elem,arr){
					if( $.type( elem ) === 'number' ) {
						elem = elem+'';	
					}
					if ( arr ) {
						var len = arr.length;
						var i = 0;
						for ( ; i < len; i++ ) {
							// Skip accessing in sparse arrays
							var v = arr[ i ];
							if( $.type( v ) === 'number' ) {
								v = v+'';	
							}
							if ( i in arr && (v === elem) ) {
								return i;
							}
						}
					}
					return -1;
				},
				/*判断是否出现滚动条*/
				hasScroll: function( el, a ) {
					return Nex.hasScroll( el,a );
				},
				/*
				* 获取浏览器滚动条大小
				*/
				getScrollbarSize: function () {
					var self = this,
						opt = self.configs;
					if( Nex.scrollbarSize ) {//全局缓存
						opt.scrollbarSize = Nex.scrollbarSize;
					}	
					if (!opt.scrollbarSize) {
						var db = document.body,
							div = document.createElement('div');
		
						div.style.width = div.style.height = '100px';
						div.style.overflow = 'scroll';
						div.style.position = 'absolute';
		
						db.appendChild(div); 
						
						opt.scrollbarSize = {
							width: div.offsetWidth - div.clientWidth,//竖
							height: div.offsetHeight - div.clientHeight//横
						};
						//IE下 出现过有一边获取不到的情况 就是为0
						opt.scrollbarSize.width = opt.scrollbarSize.width || opt.scrollbarSize.height;
						opt.scrollbarSize.height = opt.scrollbarSize.height || opt.scrollbarSize.width;
						
						opt.scrollbarSize.x = opt.scrollbarSize.height;
						opt.scrollbarSize.y = opt.scrollbarSize.width;
						
						db.removeChild(div);
						
						Nex.scrollbarSize = opt.scrollbarSize;
					}
					return opt.scrollbarSize;
				},
				resize : function(){
					var self = this;
					var opt = self.configs;
					if( Nex.Manager ) {
						setTimeout(function(){
							Nex.Manager.fireEvent("onResize",[opt.id]);		
						},0);
					}	
				},	
				__ars : true,
				//判断当前组件是否接受autoResize
				isAcceptResize : function(){
					var opt = this.configs;
					return opt.autoResize && this.__ars;	
				},
				setAcceptResize : function(m){
					var m = m === undefined ? true : m;
					this.__ars = !!m;
					return this;	
				},
				//计算 max/min/cut width height 
				__getCalcSize : function( size,t ){
					var self = this,
						undef,
						opt = this.configs;	
					if( $.isFunction( size ) ) {
						size = size.call( self );	
					}
					if( size === undef ) size = 0;
					//暂不提供百分比支持
					size = parseInt(size);
					return 	isNaN(size)?0:size;	
				},
				_getCutWidth : function(){
					var self = this,
						opt = this.configs;	
					//var pw = opt.pWidth;
					var size = opt.cutWidth;
					return 	self.__getCalcSize(size,0);
				},
				_getCutHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.cutHeight;
					return 	self.__getCalcSize(size,1);
				},
				_getMinWidth : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.minWidth;
					return 	self.__getCalcSize(size,0);
				},
				_getMaxWidth : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.maxWidth;
					return 	self.__getCalcSize(size,0);	
				},
				_getMinHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.minHeight;
					return 	self.__getCalcSize(size,1);		
				},
				_getMaxHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.maxHeight;
					return 	self.__getCalcSize(size,1);			
				},
				/*
				*组件参数设置和获取
				*/
				C : function(key,value){
					if( typeof key == 'undefined') {
						return this.configs;	
					}
					if( typeof value == 'undefined' && typeof key !== 'object' ) {
						return this.configs[key];
					}
					if( $.isFunction( value ) ) {
						this.configs[key] = value.call( this,this.configs[key] );	
					} else if( $.isPlainObject( key ) ) {
						var conf = key;
						var opt = this.configs;
						
						if( value ) {
							$.extend( opt,conf );
							return this;	
						}
						
						for (var k in conf) {
							var newValue = conf[k];
							var oldValue = opt[k];
			
							if ( $.isArray( oldValue ) ) {
								oldValue.push.apply(oldValue, newValue);
							} else if ($.isPlainObject( oldValue )) {
								$.extend( oldValue, newValue)
							} else {
								opt[k] = newValue;
							}
						}
					} else {
						this.configs[key] = value;
					}
					return this;
				},
				set : function(){
					return this.C.apply(this,arguments);	
				},
				get : function(){
					return this.C.apply(this,arguments);	
				},
				setConfig : function(){
					return this.C.apply(this,arguments);		
				},
				getConfig : function(){
					return this.C.apply(this,arguments);		
				},
				/**
				 * 模板处理函数(用户自定义模版级别最高,其次模板函数,最后_Tpl中的模版)
				 *  @tpl {String,Function} 模板内容
				 *  @data {Object} 模板数据 如果tpl是Function data不一定需要Object
				 *  @return {String} 模板内容
				 */
				tpl : function(tpl,data){
					
					var self = this;
					var opt = self.configs;
					var constructor = self.constructor;
					if( typeof tpl == 'undefined' ) tpl = "";
					if( typeof data == 'undefined' ) data = {};
					
					var _tpl_ = {};
					if( typeof opt.cacheData['_tpl_'] == 'undefined' ) {
						opt.cacheData['_tpl_'] = {};
						_tpl_ = opt.cacheData['_tpl_'];
					} else {
						_tpl_ = opt.cacheData['_tpl_'];
					}
					
					var argvs = [];
					var len = arguments.length;
					for( var i=2;i<len;i++ ) {
						argvs.push( arguments[i] );	
					}
					var argvs = [data].concat( argvs );
					
					var html = "";
					
					if( !opt.template ) {
						if( $.isFunction(tpl) ){
							html = tpl.apply(self,argvs);
						} else if( tpl in self ) {
							html = self[tpl].apply(self,argvs);
						} else {
							html = 	tpl;
						}
						return html;
					}
					
					opt.template.isEscape = opt.isEscape;
					
					if( $.isFunction(tpl) ){
						html = tpl.apply(self,argvs);
					}else if( tpl in opt.tpl && opt.tpl[tpl] ) {
						if( opt.tpl[tpl] in _tpl_ ) {
							var render = _tpl_[ opt.tpl[tpl] ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( opt.tpl[tpl] );
							
							_tpl_[ opt.tpl[tpl] ] = render;
							
							html = render.apply(self,argvs);		
						}
					} else if( tpl in self ) {
						html = self[tpl].apply(self,argvs);
					} else if( tpl in constructor._Tpl && constructor._Tpl[tpl] ) {
						if( constructor._Tpl[tpl] in _tpl_ ) {
							var render = _tpl_[ constructor._Tpl[tpl] ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( constructor._Tpl[tpl] );
							
							_tpl_[ constructor._Tpl[tpl] ] = render;
							
							html = render.apply(self,argvs);		
						}
					} else {
						if( tpl.toString() in _tpl_ ) {
							var render = _tpl_[ tpl.toString() ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( tpl.toString() );
							
							_tpl_[ tpl.toString() ] = render;
							
							html = render.apply(self,argvs);		
						}
					}
					return html;
				},
				/*
				*  调用当前对象里的某个API，但是不会触发里面的事件(部分函数除外例如setGridBody,因为里面事件通过计时器触发)
				*  @param1 {String} 需要调用的API
				*  @param2~N 被调用的API参数(可选)
				*/
				denyEventInvoke : function(){//method,arg1,arg2....
					var self = this;
					var r;
					if( arguments.length ){
						var argvs = [];
						for( var i=0;i<arguments.length;i++ ) {
							argvs.push(arguments[i]);	
						}
						var method = argvs[0];
						if( method in self ) {
							self._denyEvent = true;
							argvs.splice(0,1);
							r = self[method].apply(self,argvs);
							self._denyEvent = false;
						}
					}
					return r;
				},
				/*
				* API调用管理,作用在于通过该函数调用的会过滤被锁定的函数
				*  @param1 {String} 需要调用的API
				*  @param2~N 被调用的API参数(可选)
				*/
				methodInvoke : function(){//method,arg1,arg2....
					var self = this;
					var r;
					
					var methodLocks = self._methodLocks || {};
					
					if( arguments.length ){
						var argvs = [];
						for( var i=0;i<arguments.length;i++ ) {
							argvs.push(arguments[i]);	
						}
						var method = argvs[0];
						
						if( methodLocks[method] ) {
							return;	
						}
						
						if( method in self ) {
							argvs.splice(0,1);
							r = self[method].apply(self,argvs);
						}
					}
					return r;
				},
				/*
				* 事件绑定
				*  @eventType {String} 事件名
				*  @func      {Function|{ scope,fn }} 事件回调
				*  @scope     {Object} this对象(可选)
				*  @return    {int} 事件ID or false
				*/
				bind : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					if( eventType === '' || eventType === '@' ) {
						return false;	
					}
					//var _f = func;
					//var func = func || $.noop;
					var self = this;
					var opt = self.configs;
					var event = opt.events;
					//批量绑定支持
					if( $.type( eventType ) === 'object' ) {
						var ids = [];
						for( var ev in eventType ) {
							var context = scope;
							var fn = eventType[ev];
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.scope || fn.context || context;
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							var _i = self.bind( ev,fn,context );	
							ids.push( _i );
						}
						return ids;
					} else {//字符串 但是没有做检查 
						var _ev = [ eventType ].join('').split(/\s+|,/);	
						if( _ev.length>1 ) {
							var len = _ev.length;
							var ids = [];
							for( var _e=0;_e<len;_e++ ) {
								if( !_ev[_e] ) continue;
								ids.push( self.bind( _ev[_e],func,scope ) );
							}
							return ids;
						}					
					}
					
					var _f1 = eventType.charAt(0);
					if( _f1 === '@' ) {
						scope = self;
						eventType = eventType.slice(1);	
					}	
					
					var _type = eventType.split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');//_type.length == 2 ? _type[1] : '';
					
					if( !eventType ) {
						return false;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					event[eventType] = self._undef(event[eventType],[]);
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
					}
					
					if( !$.isFunction( func ) || func === $.noop ) {
						return false;	
					}
					
					var _e = {
							scope : !!scope ? scope : null,
							func : func,
							ext : ext
						};
					
					var id = event[eventType].push(_e);
				
					return id-1;
				},
				on : function(){
					return this.bind.apply(this,arguments);	
				},
				/*
				*同bind 区别在于只执行一次
				*/
				one : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					var func = func || $.noop;
					var self = this;
					var scope = !!scope ? scope : self;
					
					var _ = function(){
							self.unbind(eventType,_.id);
							var r = func.apply(scope,arguments);
							return r;
						},
						id = null;
						
					id = self.bind( eventType,_,scope );
					_.id = id;
					return id;
				},
				/*
				* 取消事件绑定
				*  @eventType {String} 事件名
				*  @id        {int} 事件ID(可选)
				*/
				unbind : function(eventType,id){
					var self = this;
					var opt = self.configs;
					
					var _ev = [ eventType ].join('').split(/\s+|,/);	
					if( _ev.length>1 ) {
						var len = _ev.length;
						for( var _e=0;_e<len;_e++ ) {
							if( !_ev[_e] ) continue;
							self.unbind( _ev[_e] );
						}
						return self;
					}					
					
					var event = opt.events;
					var id = self._undef(id,false);
					
					var _type = String(eventType).split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');
					
					if( eventType === '' && ext !== '' ) {
						for( var tp in event ) {
							self.unbind( [tp,ext].join('.') );	
						}
						return self;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					if( !(eventType in event) ) {
						return self;	
					}
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
						return self;
					}
					
					if(id === false) {
						if( ext === '' ) {
							event[eventType] = [];
						} else {
							
							var j = 0;//用于splice
							for(var i=0;i<event[eventType].length;i++) {
								var _e = event[eventType][i];
								if( $.isPlainObject( _e ) && _e.ext === ext ) {
									event[eventType][i] = null;	
									j++;
								}
							}
						}
					} else {
						event[eventType][id] = null;	
					}
					return self;
				},
				off : function(){
					return this.unbind.apply(this,arguments);	
				},
				/*
				* 锁定API
				*  @method {String} API名
				*/
				lockMethod : function(method){
					var self = this;	
					//事件锁
					var methodLocks = self._methodLocks || {};
					methodLocks[method] = true;
					self._methodLocks = methodLocks;
					return true;	
				},
				/*
				* 取消锁定API
				*  @method {String} API名
				*/
				unLockMethod : function(method){
					var self = this;	
					//事件锁
					var methodLocks = self._methodLocks || {};
					methodLocks[method] = false;
					self._methodLocks = methodLocks;
					return true;	
				},
				/*
				* 锁定事件
				*  @eventType {String} 事件名
				*/
				lockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = true;
					self._eventLocks = eventLocks;
					return true;
				},
				/*
				* 取消锁定事件
				*  @eventType {String} 事件名
				*/
				unLockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = false;
					self._eventLocks = eventLocks;
					return true;
				},
				_eventLocks : {},
				_executeEventMaps : {},//正在的执行的事件
				/*
				* 事件触发
				*  @eventType {String} 事件名 如果事件名带@开头 说明当前事件是系统事件 不会因为睡眠而阻止
				*  @data      {Array} 事件参数(可选)
				*/
				fireEvent : function(eventType,data){
					var self = this;
					if( self._denyEvent ) {
						return;	
					}
					var opt = self.configs;
					
					var context = opt.context || self;
					
					var ct = String(eventType).charAt(0);
					var _sys = false;
					if( ct === '@' ) {
						_sys = true;
						eventType = String(eventType).slice(1);	
					}	
					/*
					if( !_sys && self._isSleep() ) {
						return;	
					}
					*/
					if( !eventType ) {
						return;	
					}
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					var events = opt.events[eventType];
					var data = self._undef(data,[]);
					
					//判断data 是否 arguments
					if( $.isArray( data ) ) {
						data = data;	
					} else if( $.type( data ) === 'object' ){
						if( 'callee' in data && 'length' in data ) {
							data = data	
						} else {
							data = [data];	
						}
					} else {
						data = [data];
					}
					//data = $.isArray( data ) ? data : [data];
					//添加事件锁
					var eventLocks = self._eventLocks || {};
					if( eventLocks[eventType] ) {
						return;	
					}
					//防止死循环事件
					if( self._executeEventMaps[eventType] ) {
						return;	
					}
					self._executeEventMaps[eventType] = true;
					
					var r = true;
					if($.isArray(events) ) {
						var len = events.length;
						for(var i=0;i<len;i++) {
							var _e = events[i];
							if( $.isPlainObject( _e ) ) {
								r = _e.func.apply(_e.scope || context,data);
							} else if( $.isFunction( _e ) ){
								r = _e.apply(self,data);
							}
							if( opt.stopOnFalse ) {
								if(r === false) break;	
							}
						}	
						
					} else if($.isFunction(events)) {
						r = events.apply(self,data);
					}
					
					self._executeEventMaps[eventType] = false;
					
					return r;
				},
				fire : function(){
					return this.fireEvent.apply(this,arguments);	
				},
				__sleep : false,
				isSleep : function(){
					return this.__sleep;	
				},
				//睡眠 睡眠后无法通过sendMessageToGroup给组件发送消息 并不会影响fireEvent
				sleep : function(){
					this.__sleep = true;
					return this;	
				},
				//唤醒
				wakeup : function(){
					this.__sleep = false;
					return false;
				},
				loadPuglins : function(){
					var self = this;
					var constructor = self.constructor;
					$.each( constructor.puglins,function(i){
						if( $.isFunction( this ) )
							this.call(self);									
					} );
				},
				initEvents : function(opt){
					var self = this;
					var e = opt.events ? opt.events : {};
					opt.events = {};
					var events = {};
					if( $.isPlainObject(e) && !$.isEmptyObject(e) ) {
						for(var i in e){
							var _evt = String(i),
								fn = e[i],
								context = null;	
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.scope || fn.context || null;
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							if( $.isFunction( fn ) && fn !== $.noop ) {
								self.bind(_evt,fn,context);	
							}
						}
					}
					//opt.events = events;
				},
				sysEvents : function(){
					var self = this;
					var opt = self.configs;
					//系统事件 注意：顺序不可随意更改
					if( '_sysEvents' in self ) {
						self._sysEvents();
					}
					
					self.bind("onStart._sys",self.loadPuglins,self);	
				},
				generateMixed : function(n){
					 return Nex.generateMixed( n );	
				},
				_getId : function(){
					var aid = Nex.aid++;
					var self = this;
					var opt = self.configs;
					return opt.prefix + aid;	
				},
				getDom : function(){
					var self = this,
						opt = self.configs;
					return $('#'+opt.id);
				},
				getEl : function(){
					return this.el || this.getDom();	
				},
				getId : function(){
					if( this.configs.id === '' || this.configs.id === null || this.configs.id === undefined ) {
						return this._getId();	
					}
					return this.configs.id;	
				},
				//获取组件的父级组件
				getParent : function(  ){
					var el = this.getDom(),
						opt = this.configs,
						cmp = null;
					if( !el.length ) return cmp;
					if( opt.parent !== null ) {
						if( Nex.isNex( opt.parent ) ) {
							return opt.parent;	
						}
						var _p = Nex.get(opt.parent);
						if( _p ) return _p;
					}
					var p = el.parent('.nex-component-item'),
						_id = p.attr('id');
					cmp = _id ? Nex.get(id) : null;
					return cmp ? cmp : null;
				},
				unique : function(n){
					return Nex.unique(n);	
				},
				isNumber : function(value) {
					return Nex.isNumber( value );	
				},
				/*
				*系统事件
				*/
				_onStart : function(){
					var self = this;
					var opt = self.configs;
					var e = opt.events ? opt.events : {};
					var reg = /^@?on[A-Z][\S|\.]*$/;///^@?on[A-Z][\w|\.]*$/
					for(var x in opt ) {
						if( reg.test(x) ) {
							var fn = opt[x],
								context = null;
							
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.context || fn.scope || null;	
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							if( $.isFunction(fn) && fn !== $.noop ){
								self.bind(x,fn,context);	
							}
						}
					}
				},
				isNexConstructor : function(obj){
					return  Nex.isNexConstructor( obj );
				},
				isNex : function(obj){
					return  Nex.isNex( obj );
				},
				isXtype : function(obj){
					return Nex.isXtype( obj );
				},
				isjQuery : function(obj){
					return Nex.isjQuery( obj );
				},
				/*
				*解析xtype 到容器
				*@param {String,Dom} 容器
				*@param {Array,Nex,Xtype} 组件列表 
				*@param {Boolean} 内部插入 默认是 后 
				*/
				parseItems : function(renderTo,items,after){
					var self = this,
						opt = self.configs,
						undef;
					var after = after === undef ? true : after;
					var ac = after ? 'append' : 'prepend';
					if( $.isFunction( items ) && !self.isNexConstructor( items ) ) {
						items = items.call( self,renderTo );
					}
					var components = [];
					var items = $.isArray( items ) ? items : [items];
					if( renderTo && items.length ) {
						for( var i=0;i<items.length;i++ ) {
							var _item = items[i];
							if( _item === '' || _item === undef ) continue;
							if( $.isFunction( _item ) && !self.isNexConstructor( _item ) ) {
								_item = _item.call(self,renderTo,opt);	
								if( _item === '' 
								    || $.type( _item ) === 'boolean' 
									|| $.type( _item ) === 'null' 
									|| $.type( _item ) === 'undefined' 
								) {
									continue;	
								}
							}
							if( self.isNex( _item ) ) {
								//$( renderTo )[ac]( _item.getDom() );
								_item.render( renderTo,ac );
								components.push( _item );
								//self.addChildCmpList( _item );
							} else if( self.isNexConstructor( _item ) || self.isXtype( _item ) ){
								if( !Nex.Create ) continue;
								var cmp;
								if( self.isXtype( _item ) ) {
									cmp = Nex.Create( $.extend( { parent : opt.id },_item,{renderTo:renderTo,autoRender:true} ) );	
								} else {
									cmp = Nex.Create( _item,{renderTo:renderTo,parent : opt.id,autoRender:true} );		
								}
								components.push( cmp );
								//self.addChildCmpList( cmp );
								//这里可以改成设置参数 renderAfter : after
								if( !after ) {
									$( renderTo )[ac]( cmp.getDom() );	
								}
							} else if( self.isjQuery( _item ) ) {
								$( renderTo )[ac]( _item );	
								components.push( _item );
							} else {
								_item = _item + '';
								var html = $._parseHTML( _item );//修正相同字符 不创建bug
								html = $(html).clone();
								components.push( html );
								$( renderTo )[ac]( html );				
							}	
						}
					}
					return components;
				},
				addComponent :　function( renderTo,items,after ){
					return this.parseItems( renderTo,items,after );
				},
				/*
				*解析xtype 到容器
				*@param {Array,Nex,Xtype} 组件列表 
				*@param {String,Dom} 容器
				*@param {Boolean} 内部插入 默认是 后 
				*/
				renderComponent : function( items,renderTo,after ){
					return this.parseItems( renderTo,items,after );	
				},
				//应该放到Html组件 因为有部分组件没有继承Html 所以先放在这里
				renderTo : function( obj,after ){
					var self = this;
					var opt = this.configs;
					var undef;
					var after = after === undef ? true : after;
					var ac = after ? 'append' : 'prepend';
					if( !obj ) return self;
					if( !self.isExists() ) return self;
					var _st = false;
					if( Nex.isNex( obj ) && obj.isExists() ) {
						var bd = obj.getBody();
						bd[ac]( self.getEl() );
						_st = true;
					} else {
						var el = $(obj);
						if( el.length ) {
							el[ac]( self.getEl() );	
							_st = true;
						}	
					}
					if( opt.autoResize && _st ) {
						self.resize();
						if( Nex.Manager ) {
							Nex.Manager.cmpChange();	
						}
					}
					return self;
				},
				/*
				addChildCmpList :　function(obj){
					var self = this;
					var opt = self.configs;
					opt._childrenList.push( obj );
				},
				*/
				//m @true 默认删除本身, false 删除子元素
				removeCmp :  function(m){
					var self = this,undef;
					var m = m === undef ? true : m;
					var opt = self.configs;
					//opt._childrenList.length = 0;
					if( Nex.Manager ) {
						Nex.gc();
					}
				},
				/*
				*移除组件 最好需要重载
				*/
				destroy : function( m ){
					this.removeCmp( m );
					return this;
				},
				getChildrens : function(){
					var opt = this.configs;
					return Nex.Manager.getChildrens( opt.id );	
				},
				getAllChildrens : function(){
					var opt = this.configs;
					return Nex.Manager.getAllChildrens( opt.id );	
				},
				//作废
				_setBodyOverflowHidden : function(){},
				getDeferred : function(){
					var opt = this.configs;
					return opt.deferred;
				},
				/*
				*获取异步数据 必须要加载Nex.Ajax
				*方式一 通过URL设置
				*getAsyncData(url[success,error,complete,options]);
				*success,error,complete {Function}  options {Object}
				*eg getAsyncData( 'a.json',function( data ){ console.log( data ) },{ dataType:'json' } );
				*/
				getAsyncData : function( url ){
					var self = this,
						undef,
						success,
						error,
						complete,
						options,
						args = [].slice.apply(arguments);	
					var ins = null;	
					//参数处理	
					var len = args.length;
					for( var i=1;i<len;i++ ) {
						if( typeof args[i] === 'object' ) {
							options = args[i];
							break;	
						}
						if( typeof args[i] === 'function' ){
							switch( i ) {
								case 1:
									success = args[1];
									break;
								case 2:
									error = args[2];
									break;
								case 3:
									complete = args[3];
									break;		
							}
						}
					}	
					//url的处理方式	
					if( $.type( url ) === 'string' ) {
						var obj = {
								xtype : 'ajax',
								url : url,
								context : self
							};
						if( options ) {
							$.extend( obj,options );	
						}
						if( success ) {
							obj['onSuccess.__async'] = success;
						}
						if( error ) {
							obj['onError.__async'] = error;
						}
						if( complete ) {
							obj['onComplete.__async'] = complete;
						}
						ins = Nex.Create( obj );
					} else if( $.type( url ) === 'function' ) {//用户自定义函数处理方式
						var _data = url.call(self,options,success,error,complete);
						if( _data !== undef ) {
							success( _data );	
							complete();
						}	
					} else if( typeof url === 'object' ) {
						var obj = {
							xtype : 'ajax'	
						};
						if( !Nex.isXtype( url ) ) {
							$.extend( obj,url )	
						} else {
							obj = url;	
						}
						if( success ) {
							obj['onSuccess.__async'] = success;
						}
						if( error ) {
							obj['onError.__async'] = error;
						}
						if( complete ) {
							obj['onComplete.__async'] = complete;
						}
						ins = Nex.Create( obj );
					}
					return ins;
				},
				//ajax api
				loadData : function(url,data,options){//loader
					var self = this,
						undef,
						opt = self.configs;
						
				}
			});
			return base;
		},
		//数组移动算法
		// pos 要移动的元素
		array_move : function(iarr,pos,target,t) {//t 代表是前还是后 1 代表前 0 代表后

			if(pos == target) return iarr;
			var __arr = iarr;
			//支持字符下标
			var _iarr = iarr = [].concat(__arr);
			iarr = [];
			var j=0,
				len = _iarr.length;
			for(;j<len;j++) {
				var _i = iarr.push(j);
				if( j == pos) {
					pos = _i-1;
				} else if( j == target ) {
					target = _i-1;
				}
			}
			//core
			var _p = iarr[pos];//记录元副本
			if( pos>target ) {
				if(!t) {
					target++;
				}
				for(var i=pos;i>=0;i--) {
					if(i == target) {
						iarr[i] = _p;
						break;
					}
					iarr[i] = iarr[i-1];
				}
			} else if( pos<target ) {
				if(t) {
					target--;
				}
				for(var i=pos;i<=target;i++) {
					
					if( i == target ) {
						iarr[i] = _p;
					} else {
						iarr[i] = iarr[i+1];
					}	
				}
			}
			//字符下标
			
			var new_arr = __arr;
			new_arr.length = 0;
			//new_arr.push.apply(new_arr,_iarr); //不建议用 因为 _iarr 会有长度限制 63444
			var k=0,
				len = iarr.length;
			for( ;k<len;k++ ) {
				new_arr.push( _iarr[ iarr[k] ] );
			}
			iarr = new_arr;
			return iarr;
		},
		/*
		*删除数组元素 index 为下标或者下标数组 或者回调函数 回调返回true即可
		*/
		array_splice : function(index,arr){
			var self = this,undef;
			if( !$.isArray( arr ) ) return arr;
			
			var call = index;
			
			if( $.isArray( index ) && index.length<=1 ) {
				index = index[0];
			}
			
			if( index === undef ) return arr;
			
			//如果index 不是数组或者不是回调时 直接调用splice;
			if( !$.isArray( index ) && !$.isFunction(index) ) {
				if( isNaN( parseInt( index ) ) ) return arr;
				arr.splice( parseInt(index),1 );
				return arr;
			}
			
			var _arr = self.copy( arr );
			var index = $.isArray( index ) ? index : ($.isFunction(index) ? [] : [index]);
			var _index = {};
			$.each(index,function(i,v){
				_index[v] = true;	
			});
			
			arr.length = 0;
			
			$.each( _arr,function(i,v){
				if( $.isFunction( call ) ) {
					var r = call.call(v,i,v);	
					if( r === true ) {
						_index[i] = true;	
					}
				}
				if( !(i in _index) ) {
					arr.push(v);	
				}	
			} );
			
			return arr;
		},
		/*				
		*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面 _arr 长度不要超过6W+
		*/
		array_insert : function(index,_arr,arr,t){
			var self = this,
				undef,
				t = t === undef ? 0 : t;
			if( !$.isArray( arr ) ) return arr;
			
			var call = index;
			
			if( !$.isArray( _arr ) ) _arr = [ _arr ];
			
			if( index === undef ) return arr;
			
			var len = arr.length;
			if( index<len ) {
				if( t )	{
					_arr = _arr.concat( [ arr[index] ] );	
				} else {
					_arr = [ arr[index] ].concat( _arr );
				}
			}
			_arr = [index,1].concat( _arr );
			arr.splice.apply(arr,_arr);
			return arr;
		},
		array_clear : function(arr){
			arr.length = 0;
			return arr;
		},
		array_copy : function(arr){
			var _ = [];
			return _.concat( arr );	
		},
		//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
		copyArray : function(arr){
			var _ = [];
			return _.concat( arr );
		},
		//copy只是对数组或对象只是增加一个引用计数，并不是深复制
		copy : function(data){
			if( $.isArray( data ) ) {
				return  [].concat(data);	
			} else if( $.isPlainObject(data) ) {
				return $.extend({},data);
			} else {
				return data;	
			}
		},
		str_number : function(num,elc){//elc 截取的小数位
			var num = num + '';
			if( $.type( num ) === 'string' ) {
				var n = num.split('.');
				if( n.length>1 ) {
					var ext = n[1].substring(0,elc);	
					if( ext !== '' ) {
						num = [n[0],ext].join('.');	
					} else {
						num = n[0];
					}
				}	
			}
			return Number(num);
		},
		/*
		*判断元素垂直滚动条是否滚动到底 @dom
		*/
		_checkYScrollEnd : function( el ){
			var scrollTop = 0;
			var clientHeight = 0;
			var scrollHeight = 0;	
			if( el === document.body || el === document || el === window ) {
				if (document.documentElement && document.documentElement.scrollTop) {
					scrollTop = document.documentElement.scrollTop;
				} else if (document.body) {
					scrollTop = document.body.scrollTop;
				}
				if (document.body.clientHeight && document.documentElement.clientHeight) {
					clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
				} else {
					clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
				}
				scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
			} else {
				if( !el.nodeType ) return false;
				scrollTop = el.scrollTop;
				clientHeight = el.clientHeight;
				scrollHeight = el.scrollHeight;
			}
			if( clientHeight >= scrollHeight ) {
				return false;
			} else if (scrollTop + clientHeight >= scrollHeight) {//必须要使用>= 因为缩放后会大于scrollHeight
				return true;
			} else {
				return false;
			}	
		},
		/*
		*判断元素水平滚动条是否滚动到底 @dom
		*/
		_checkXScrollEnd : function( el ){
			var scrollLeft = 0;
			var clientWidth = 0;
			var scrollWidth = 0;	
			if( el === document.body || el === document || el === window ) {
				if (document.documentElement && document.documentElement.scrollLeft) {
					scrollLeft = document.documentElement.scrollLeft;
				} else if (document.body) {
					scrollLeft = document.body.scrollLeft;
				}
				if (document.body.clientWidth && document.documentElement.clientHeight) {
					clientWidth = (document.body.clientWidth < document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
				} else {
					clientWidth = (document.body.clientWidth > document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
				}
				scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
			} else {
				if( !el.nodeType ) return false;
				scrollLeft = el.scrollLeft;
				clientWidth = el.clientWidth;
				scrollWidth = el.scrollWidth;
			}
			if( clientWidth >= scrollWidth ) {
				return false;
			} else if (scrollLeft + clientWidth >= scrollWidth) {//必须要使用>= 因为缩放后会大于scrollWidth
				return true;
			} else {
				return false;
			}		
		},
		/*
		*验证是否滚动到低 @el dom @a left/top
		*/
		isScrollEnd : function( el,a ){
			var self = this,
				undef;
			if( a == 'left' ) {
				return self._checkXScrollEnd( el );	
			} else {
				return self._checkYScrollEnd( el );		
			}
		},
		/*
		*判断是否出现滚动条
		* @param el dom
		* @param a left top
		* @param t boolean defalut:false 如果t=true则只要超出宽度就会认定有滚动条，但是未必有滚动条一般拿来检测是否子节点的宽度大于父节点
		*/
		hasScroll: function( el, a, t ) {
			
			var el = $(el)[0];//el 是dom
			
			//If overflow is hidden, the element might have extra content, but the user wants to hide it
			/*
			//IE下 只要overflow-x/overflow-y设置了hidden那么获得的overflow就是hidden 所以我们要只取-x -y
			if ( $( el ).css( "overflow" ) === "hidden") {
				return false;
			}
			*/
			if( t !== true ) {
				if( a === "left" ) {
					if ( $( el ).css( "overflow-x" ) === "hidden") {
						return false;
					}
				} else {
					if ( $( el ).css( "overflow-y" ) === "hidden") {
						return false;
					}	
				}
			}
			var scroll = ( a && a === "left" ) ? "scrollLeft" : "scrollTop",
				has = false;
			if ( el[ scroll ] > 0 ) {
				return true;
			}
			// TODO: determine which cases actually cause this to happen
			// if the element doesn't have the scroll set, see if it's possible to
			// set the scroll
			el[ scroll ] = 1;
			has = ( el[ scroll ] > 0 );
			el[ scroll ] = 0;
			return has;
		},
		//工具集合
		util : {},
		addUtil : function(n,v){
			return this.util[n] = v;	
		},
		getUtil : function(n){
			return this.util[n];	
		},
		extendUtil : function(n,v){
			return $.extend( this.util[n],v );
		},
		removeUtil : function(){
			this.util[n] = null;
			delete this.util[n];
			return this;
		},
		//所有组合mixins
		mixins : {},
		addMixins : function( n,v ){
			v = $.isFunction( v ) ? v.call( this ) : v;
			return this.mixins[n] = v;	
		},
		getMixins : function(n){
			return this.mixins[n]	
		},
		extendMixins : function(n,v){
			return $.extend( this.mixins[n],v );
		},
		removeMixins : function(){
			this.mixins[n] = null;
			delete this.mixins[n];
			return this;
		},
		/*直接使用jquery 的Deferred对象 所以要使用when需要确定jquery版本支持Deferred*/
		when : function(){
			var arr = [].slice.apply(arguments);
			for( var i=0,len=arr.length;i<len;i++ ) {
				if( Nex.isXtype(arr[i]) ) {
					arr[i] = Nex.Create( arr[i] ).getDeferred();	
					continue;
				}
				if( Nex.isNex( arr[i] ) ) {
					arr[i] = arr[i].getDeferred();
					continue;	
				}
				if( $.type(arr[i])=='string' && Nex.getClass( arr[i] ) ) {//Nex.classes //( arr[i] in Nex )
					arr[i] = Nex.Create( arr[i] ).getDeferred();	
					continue;		
				}
			}
			return $.extend($.when.apply( $,arr ),{
				success : function(){
					this.done.apply( this,arguments )	
				},
				error : function(){
					this.fail.apply( this,arguments )	
				},
				complete : function(){
					this.always.apply( this,arguments )	
				}	
			});	
		},
		/*
		*__psc=true
		*parseSubClass会把字符串直接转成对象
		*__psc=false
		*如果分割长度少于2则会把对象存放到Nex下
		*eg：parseSubClass('Test',5);__psc=true后会直接创建Test否则Nex.Test
		*/
		__psc : true,
		//把字符串转化成对象 并复制v
		parseSubClass : function(str,v){
			var undef,
				t = window,
				s = str+'';	
			s = s.split('.');
			if( s.length<2 && !this.__psc ) {
				return;	
			}
			for( var i=0,len=s.length-1;i<len;i++ ) {
				var e = s[i];
				if( !(e in t) || !t[e] ) {
					t[e] = {};	
				}
				t = t[e];	
			}	
			t[s[i]] = v;
			//return v;
		},
		//继承组件 如果没指定superClass 默认superClass=Nex.widget()
		//subclass，superClass，overrides
		extend : function(subclass,superClass,overrides){
			var undef,F = function(){};
			if( subclass === undef ) return F;
			var superClass = superClass === undef ? false : superClass;
			var overrides = overrides === undef ? {} : overrides;
			var subclassName = subclass,
				superClassName = superClass === false ? null : superClass;
			//不能继承到Nex
			if( subclass === 'Nex' ) {
				return 	Nex.widget();
			}
			var notExist = false;
			//如果不存在superClass 直接返回
			if( !superClass ) {
				superClass = Nex.widget();
				notExist = true;
				//Nex.parseSubClass( subclassName,subclass );
				//return subclass;
			}
			//mixins
			//检查是否没设置overrides
			if( $._isPlainObject( superClass ) ) {
				overrides = superClass;	
				superClass = false;
				if( 'extend' in overrides && overrides.extend ) {
					superClass = overrides.extend;
					superClass = true;
					delete overrides.extend;
				}
			}
			if( Nex.isNexConstructor( superClass ) ) {
				
				superClass = superClass;
				
			} else if( superClass && Nex.getClass( superClass ) ) {//Nex.classes // (superClass in Nex)
				
				superClass = Nex.getClass( superClass );//Nex.classes
				
			} else {
				//superClass = false;	
				superClass = Nex.widget();
				notExist = true;
			}
			
			superClassName = notExist ? null : superClass.getXType();
			
			subclass = Nex.widget(subclass);
			//只复制数组和(深复制)对象
			var copy = function(data){
				if( $.isArray( data ) ) {
					return  [].concat(data);	
				} else if( $.isPlainObject(data) ) {
					return $.extend(true,{},data);
				} else {
					return data;	
				}
			};
			
			if( superClass ) {
			
				for( var k in superClass ) {
					if( k === '_optionsList' ) {
						subclass[k] = [];
						continue;	
					}
					subclass[k] = copy(superClass[k]);	
				}
				var prototype = superClass['prototype'];
				for( var p in prototype ) {
					subclass.prototype[p] = copy(prototype[p]);		
				}
				subclass.prototype.superclass = superClass;
				subclass.superclass = superClass;
			}
			//overrides 覆盖
			overrides = $.extend( {},overrides );
			var aliasName,configs,xtype,mconfigs = [];
			if( 'alias' in overrides && overrides.alias ) {
				aliasName = overrides.alias+'';
				delete overrides.alias; 	
			}
			if( 'configs' in overrides && overrides.configs ) {
				configs = overrides.configs;
				delete overrides.configs; 	
			}
			
			if( 'xtype' in overrides && overrides.xtype ) {
				xtype = overrides.xtype+'';
				delete overrides.xtype; 
			}
			var m_overrides = {};
			if( 'mixins' in overrides && overrides.mixins ) {
				overrides.mixins = $.isArray( overrides.mixins ) ? overrides.mixins : [overrides.mixins];
				$.each( overrides.mixins,function(i,d){
					if( $.isFunction( d ) ) {
						d = d( m_overrides );	
					}
					if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
						d = Nex.getMixins( d );
					}
					//组合对象的configs也会被当作组件的参数
					if( $.isPlainObject( d ) && !$.isEmptyObject( d ) ) {
						d = $.extend( true,{},d );
						if( 'configs' in d && d.configs ) {
							mconfigs.push( d.configs );
							delete d.configs; 	 	
						}
						$.extend( m_overrides,d );		
					}
				} );
				overrides.mixins.length = 0;
				delete overrides.mixins;
			}
			//overrides 可覆盖组合的属性
			overrides = $.extend( {},m_overrides,overrides );
			for( var m in overrides ) {
				subclass.prototype[m] = copy(overrides[m]);	
			}
			
			//清空父级的配置参数
			subclass['_optionsList'] = [];
			
			/*getSuperClassXType设置*/
			subclass.prototype['getSuperClassXType'] = function(){
				return superClassName;
			};	
			subclass['getSuperClassXType'] = function(){
				return superClassName;
			};	
			/*getXType设置*/
			subclass.prototype['getXType'] = function(){
				return subclassName;
			};	
			subclass['getXType'] = function(){
				return subclassName;
			};

			subclass.prototype.constructor = subclass;
			subclass.constructor = subclass;
			//兼容
			subclass.fn = subclass.prototype;
			//设置一个全局变量
			Nex.parseSubClass( subclassName,subclass );
			
			if( aliasName ) {
				var __psc = Nex.__psc;
				Nex.__psc = true;
				var aliasNames = $.trim(aliasName).split(/\s+/g);
				$.each( aliasNames,function(i,n){
					Nex.parseSubClass( n,subclass );
					Nex.addClass( n,subclass );
				} );
				Nex.__psc = __psc;
			}
			if( xtype ) {
				var xtypes = $.trim(xtype).split(/\s+/g);
				$.each( xtypes,function(i,t){
					subclass.setXType(t);		
				} );
			}
			$.each( mconfigs,function(i,c){
				subclass.setOptions(c);	
			} );
			if( configs ) {
				subclass.setOptions(configs);		
			}
			
			return subclass;
		},
		define : function(){
			return this.extend.apply( this,arguments );	
		},
		emptyFn : function(){},
		error : function( msg ){
			var undef,
				e = new Error((msg===undef?'':msg));
			throw e;
			return e;	
		}
	};
})(window,jQuery);
/*
*ExtJS 常用参数
*/
(function(){

    var check = function(regex){
            return regex.test(Nex.userAgent);
        },
		isStrict = document.compatMode == "CSS1Compat",
        version = function (is, regex) {
            var m;
            return (is && (m = regex.exec(Nex.userAgent))) ? parseFloat(m[1]) : 0;
        },
		docMode = document.documentMode,
        isOpera = check(/opera/),
        isOpera10_5 = isOpera && check(/version\/10\.5/),
        isChrome = check(/\bchrome\b/),
        isWebKit = check(/webkit/),
        isSafari = !isChrome && check(/safari/),
        isSafari2 = isSafari && check(/applewebkit\/4/), 
        isSafari3 = isSafari && check(/version\/3/),
        isSafari4 = isSafari && check(/version\/4/),
        isSafari5 = isSafari && check(/version\/5/),
        isIE = !isOpera && check(/msie/),
        isIE7 = isIE && ((check(/msie 7/) && docMode != 8 && docMode != 9) || docMode == 7),
        isIE8 = isIE && ((check(/msie 8/) && docMode != 7 && docMode != 9) || docMode == 8),
        isIE9 = isIE && ((check(/msie 9/) && docMode != 7 && docMode != 8) || docMode == 9),
        isIE6 = isIE && check(/msie 6/),
        isGecko = !isWebKit && check(/gecko/),
        isGecko3 = isGecko && check(/rv:1\.9/),
        isGecko4 = isGecko && check(/rv:2\.0/),
        isGecko5 = isGecko && check(/rv:5\./),
        isFF3_0 = isGecko3 && check(/rv:1\.9\.0/),
        isFF3_5 = isGecko3 && check(/rv:1\.9\.1/),
        isFF3_6 = isGecko3 && check(/rv:1\.9\.2/),
        isWindows = check(/windows|win32/),
        isMac = check(/macintosh|mac os x/),
        isLinux = check(/linux/),
        chromeVersion = version(true, /\bchrome\/(\d+\.\d+)/),
        firefoxVersion = version(true, /\bfirefox\/(\d+\.\d+)/),
        ieVersion = version(isIE, /msie (\d+\.\d+)/),
        operaVersion = version(isOpera, /version\/(\d+\.\d+)/),
        safariVersion = version(isSafari, /version\/(\d+\.\d+)/),
        webKitVersion = version(isWebKit, /webkit\/(\d+\.\d+)/),
        isSecure = /^https/i.test(window.location.protocol);

    
    try {
        document.execCommand("BackgroundImageCache", false, true);
    } catch(e) {}



    var nullLog = function () {};
    nullLog.info = nullLog.warn = nullLog.error = Nex.emptyFn;

    $.extend(Nex, {
        
		
        SSL_SECURE_URL : isSecure && isIE ? 'javascript:\'\'' : 'about:blank',


        USE_NATIVE_JSON : false,


        isStrict: isStrict,


        isIEQuirks: isIE && !isStrict,

        
        isOpera : isOpera,

        
        isOpera10_5 : isOpera10_5,

        
        isWebKit : isWebKit,

        
        isChrome : isChrome,

        
        isSafari : isSafari,

        
        isSafari3 : isSafari3,

        
        isSafari4 : isSafari4,

        
        isSafari5 : isSafari5,

        
        isSafari2 : isSafari2,

		IEVer : ieVersion,
        
        isIE : isIE,

        
        isIE6 : isIE6,

        
        isIE7 : isIE7,

        
        isIE8 : isIE8,

        
        isIE9 : isIE9,

        
        isGecko : isGecko,

        
        isGecko3 : isGecko3,

        
        isGecko4 : isGecko4,

        
        isGecko5 : isGecko5,

        
        isFF3_0 : isFF3_0,

        
        isFF3_5 : isFF3_5,

        
        isFF3_6 : isFF3_6,

        
        isFF4 : 4 <= firefoxVersion && firefoxVersion < 5,

        
        isFF5 : 5 <= firefoxVersion && firefoxVersion < 6,

        
        isLinux : isLinux,

        
        isWindows : isWindows,

        
        isMac : isMac,

        
        chromeVersion: chromeVersion,

        
        firefoxVersion: firefoxVersion,

        
        ieVersion: ieVersion,

        
        operaVersion: operaVersion,

        
        safariVersion: safariVersion,

        
        webKitVersion: webKitVersion,

        
        isSecure: isSecure,

        
        escapeRe : function(s) {
            return s.replace(/([-.*+?^${}()|[\]\/\\])/g, "\\$1");
        },
		
        
        log :
            nullLog,
		
        
        invoke : function(arr, methodName){
            var ret = [],
                args = Array.prototype.slice.call(arguments, 2);
            $.each(arr, function(i,v) {
                if (v && typeof v[methodName] == 'function') {
                    ret.push(v[methodName].apply(v, args));
                } else {
                    ret.push(undefined);
                }
            });
            return ret;
        }
		
		
    });
})();
/*
*常用函数
*/
(function(){
	$.extend(Nex, {
		htmlEncode: (function() {
			var entities = {
				'&': '&amp;',
				'>': '&gt;',
				'<': '&lt;',
				'"': '&quot;'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					return entities[capture];
				});
			};
		})(),
		htmlDecode: (function() {
			var entities = {
				'&amp;': '&',
				'&gt;': '>',
				'&lt;': '<',
				'&quot;': '"'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + '|&#[0-9]{1,5};' + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					if (capture in entities) {
						return entities[capture];
					} else {
						return String.fromCharCode(parseInt(capture.substr(2), 10));
					}
				});
			};
		})()	
	});	
})();
/********************************************************
**************Nex.Manager组件****************************
**********管理创建的所有组件,常用来检测组件大小设置************
**********************************************************/
Nex.GET_CMPS_CLEAR = false;//每次调用getCmp()是会自动gc 
Nex.RESIZE_DELAY = 100;//每次调用getCmp()是会自动gc 
Nex.MAX_REMOVE_NUM = 5;// 组件的移除 并不会立刻刷新层级关系，而是达到一定数量后才执行 
Nex._Manager = Nex.widget('_manager');
Nex._Manager.fn.extend({
	compRoot : 'root',
	//所有组件列表				   
	components : {},
	//组件树形
	_levelCmps : {},
	/*autoResize的组件层次关系*/
	_autoResizeLevelCmps : {},
	//组件ID的所有可resize的父级组件
	_init :　function(opt){
		var self = this;
		opt.autoDestroy = false;
	},
	__wrt : 0,
	_sysEvents : function(){
		var self = this;
		$(window).unbind("resize.Manager");
		$(window).bind("resize.Manager",function(){
			if( self.__wrt ) {
				clearTimeout( self.__wrt );	
				self.__wrt = 0;
			}
			self.__wrt = setTimeout(function(){
				self.fireEvent("onResize");	
			},Nex.RESIZE_DELAY);								 
		});
		self.bind( 'onResize',self._resize,self );
		return self;
	},
	//清理comps 删除无用的cmp
	_refreshCmps : function( m ){
		var self = this,undef;	
		var cmps = self.components;
		var i = 0;
		for( var id in cmps ) {
			if(!self.isExists( id )) {
				i++;	
			}
		}
		if( m || (i && i>=Nex.MAX_REMOVE_NUM) ) {
			self.cmpChange();	
		}
		return i;
	},
	/*
	*获取组件 获取所有组件时 每次都会调用_refreshCmps清空无效的组件
	*/
	getCmp : function(id){
		var self = this,undef;
		if( id === undef ) {
			if( Nex.GET_CMPS_CLEAR ) {
				self._refreshCmps();
			}
			return self.components;
		}
		self.isExists( id );	
		return self._undef(self.components[id],null);	
	},
	//获取当前分组名的所有组件
	getGroup : function(name){
		var self = this,undef;
		if( name === undef ) {
			return [];
		}
		var c = [];
		var comps = self.getCmp();
		if( name === '*' ) {
			$.each( comps,function(i,d){
				c.push(d);					   
			} );
			return c;	
		}
		
		name = $.trim(name+'').split(/\s+/g);
		
		if( !name ) return c;
		
		for( var id in comps ) {
			var obj = comps[id];
			if( obj ) {
				var gname = $.trim(obj.C('groupName')+'').split(/\s+/g);
				var str_gname = gname.toString();
				for( var i=0,len=name.length;i<len;i++ ) {
					var n = name[i];
					if( gname.length && str_gname.indexOf(n)!== -1 ) {// name === gname
						c.push( obj );
						break;
					}	
				}
			}
		}
		return c;
	},
	addCmp : function(id,cmp){
		this.components[id] = cmp;
		this.cmpChange();
	},
	/*
	*组件有变动 如 增 删 位置变动时应该调用 特别是 “增”其次是“位置变动”再次是“删” 
	*/
	cmpChange : function(){
		this.__disposed1 = false;
		this.__disposed2 = false;		
	},
	//删除组件
	removeCmp : function(id){
		//this._cmps[id] = null;
		if( this.components[id] && this.components[id]['fireEvent'] ) {
			this.components[id]['fireEvent']('onDestroy');	
		}
		this.components[id] = null;
		delete this.components[id];
		//delete this._cmps[id];
	},
	//判断id是否存在 如果不存在则删除
	isExists : function(id){
		var self = this;
		var cmp = self.components[id];
		
		if( cmp && (cmp.getDom()).length ) {
			return true;	
		}

		//autoDestroy 如果清除dom后组件就不再用，autoDestroy设置为true autoResize 应该也是为true的
		//这里可能存有bug 例如window按关闭后会销毁dom但是window组件还是存在的  --components
		//self._cmps[id] = null;//不再设置为null，而是获取dom是否存在
		if( cmp && cmp.C('autoDestroy') ) {
			self.removeCmp(id);	
		}
		//如果组件找不到dom 那么就从resize列表移除
		//delete self._cmps[id];	
		return false;
	},
	_getDomCmps : function( el ){//待更新
		var el = $(el);
		if( !el.length ) return false;
		var self = this	
			,undef
			,rlist = []
			,cmp = el.closest('.nex-component-item')
			,pid;
			
		pid = cmp.length ? cmp.attr('id') : self.compRoot;
		
		var cmps = self.components;
		var levelCmps = self.getLevelCmps();
		var list = (pid in levelCmps) ? levelCmps[pid] : [];
		
		for( var i=0;i<list.length;i++ ) {
			var d = list[i];
			var cmp = cmps[d.id];
			if( !cmp ) continue;
			rlist.push( cmp )	;
		}
		return rlist;	
	},
	//更新指定dom下的组件大小
	resizeDom : function(el){////待更新
		var rlist = this._getDomCmps( el );
		if( rlist === false ) return this;
		for( var i=0;i<rlist.length;i++ ) {
			var cmp = rlist[i];
			if( cmp && cmp.isAcceptResize() ) {
				cmp.resize();	
			}
		}
		return this;
	},
	//更新所有组件大小 如果指定cid 只更新指定组件下的所有组件的大小
	resize : function( cid ){
		this._resize( cid );	
		return this;
	},
	//更新组件的层级关系
	refreshComponents : function(){
		this.refreshLevelCmps();
		this.refreshAutoResizeLevelCmps();
	},
	//获取当前ID组件下的子组件 
	getChildrens : function( id ){//待更新
		var self = this,undef;
		var rlist = [];
		var cmps = self.components;
		var levelCmps = self.getLevelCmps();
		
		var pid = id;
		
		var list = (pid in levelCmps) ? levelCmps[pid] : [];
		
		for( var i=0;i<list.length;i++ ) {
			var d = list[i];
			var cmp = cmps[d.id];
			if( !cmp ) continue;
			rlist.push( cmp );
		}
		return rlist;
	},
	//获取当前ID组件下的所有子组件 
	getAllChildrens : function( id ){//待更新
		var self = this,undef;
		var list = [];
		var _list = self.getChildrens( id );
		list = list.concat( _list );
		for( var i=0,len=_list.length;i<len;i++ ) {
			var cmp = _list[i];
			if( !cmp ) continue;
			var id = cmp.C( 'id' );
			list = list.concat(self.getAllChildrens( id ));	
		}
		return list;
	},
	//获取当domID下的子组件
	getChildrensByDom : function( el ){
		var self = this,undef;
		return self._getDomCmps( el ) || [];
	},
	//获取当前domID组件下的所有子组件 
	getAllChildrensByDom : function( el ){
		var self = this,undef;
		//self.refreshComponents();
		var list = [];
		var _list = self._getDomCmps( el ) || [];
		list = list.concat( _list );
		for( var i=0,len=_list.length;i<len;i++ ) {
			var cmp = _list[i];
			if( !cmp ) continue;
			var id = cmp.C( 'id' );
			list = list.concat(self.getAllChildrens( id ));	
		}
		return list;
	},
	/*
	*刷新组件之间的层级关系 
	*/
	refreshLevelCmps : function(){
		this.__disposed1 = false;
		return this.getLevelCmps();	
	},
	/*
	*遍历组件之间的层级关系 
	*/
	__disposed1 : false,
	getLevelCmps : function(){
		var self = this,undef;

		if( self.__disposed1 ) {
			return self._levelCmps;	
		}
		
		self._refreshCmps();
		
		var cmps = self.components;
		var list = cmps;
		
		self._levelCmps = {};
		
		var lcs = self._levelCmps;

		for( var id in list ) {
			var cmp = list[id];
			if( cmp ) {
				
				var pid = self.compRoot;
				
				var parent = $("#"+id).parents(".nex-component-item:first");
				if( parent.length ) {
					var _id = parent.attr('id');
					var  _p = cmps[_id];
					if( _p ) {
						pid = _id;
					}
				}
				var data = {
					id : id,
					pid : pid
				};
				
				lcs[pid] = lcs[pid] === undef ? [] : lcs[pid];
				lcs[pid].push( data );
			}	
		}
		
		self.__disposed1 = true;

		return self._levelCmps;
	},
	/*
	*获取autoResize = true的组件
	*/
	getAutoResizeCmps : function(){
		var self = this,undef;
		var cmps = self.components;	
		var rlist = {};
		for( var id in cmps ) {
			var cmp = cmps[id];	
			if( cmp.configs.autoResize ) {
				rlist[id] = cmp;	
			}
		}
		return rlist;
	},
	/*
	*刷新autoResize组件之间的层级关系 
	*/
	refreshAutoResizeLevelCmps : function(){
		this.__disposed2 = false;
		return this.getAutoResizeLevelCmps();	
	},
	/*
	*遍历autoResize组件之间的层级关系 
	*/
	__disposed2 : false,
	getAutoResizeLevelCmps : function(){
		var self = this,undef;

		if( self.__disposed2 ) {
			return self._autoResizeLevelCmps;	
		}
		
		self._refreshCmps();
		
		var cmps = self.components;
		var list = self.getAutoResizeCmps();
		
		self._autoResizeLevelCmps = {};
		
		var lcs = self._autoResizeLevelCmps;

		for( var id in list ) {
			var cmp = list[id];
			if( cmp ) {
				
				var pid = self.compRoot;
				
				var parents = $("#"+id).parents(".nex-component-item");
				parents.each( function(){
					var id = $(this).attr('id');
					var  _p = cmps[id];
					if( _p && _p.configs.autoResize ) {//_p.C('autoResize')
						pid = id;
						return false;	
					}
				} );
				
				var data = {
					id : id,
					pid : pid
				};
				
				lcs[pid] = lcs[pid] === undef ? [] : lcs[pid];
				lcs[pid].push( data );
			}	
		}
		
		self.__disposed2 = true;

		return self._autoResizeLevelCmps;
	},
	/*
	*更新当前id下 autoResize=true的子组件大小
	*/
	_resize : function( cid ){
		var self = this,undef;
		var cmps = self.components;
		var cid = cid === undef ? self.compRoot : cid;
		
		var llcmps = self.getAutoResizeLevelCmps();
		
		var list = llcmps[cid];
		if( !$.isArray( list ) ) return;
		
		for( var i=0;i<list.length;i++ ) {
			var d = list[i];
			var cmp = cmps[ d.id ];
			if( cmp && cmp.isAcceptResize() ) {
				cmp.resize();
			}
		}
	},
	xtypes : {},
	addXtype : function(xtype,func){
		this.xtypes[xtype] = func;	
	},
	//创建组件
	create : function(){
		var self = this,undef;
		var argvs = [].slice.apply(arguments);
		var len = argvs.length;
		if( len<=0 ) return false;
		if( len > 1 ) {
			var xtype = argvs[0];
			if( Nex.isNexConstructor( xtype ) ) {
				return new xtype( argvs[1] );
			}
			if( (xtype in self.xtypes) && $.isFunction( self.xtypes[ xtype ] ) ) {
				return self.xtypes[ xtype ]( argvs[1] );	
			}
		} else if( Nex.isNexConstructor( argvs[0] ) ) {
			return new argvs[0]();
		} else {
			argvs[0] = argvs[0] === undef ? {} : argvs[0];
			if( typeof argvs[0] === 'string' ) {
				argvs[0] = {
					xtype : argvs[0]	
				};		
			}
			if( 'xtype' in argvs[0] ){
				if( (argvs[0]['xtype'] in self.xtypes) && $.isFunction( self.xtypes[ argvs[0]['xtype'] ] ) ) {
					return self.xtypes[ argvs[0]['xtype'] ]( argvs[0] );	
				}
			}	
		}
		//如果在xtypes中找不到 就直接从Nex中创建
		if( len ) {
			var type= len>1?argvs[0]:argvs[0]['xtype'];
			var opt = len>1?argvs[1]:argvs[0];
			var o = Nex.getClass(type);
			if( o && $.isFunction( o )  ) {
				return new o( opt );
			}
		}
		return false;
	},
	//创建服务组件
	createServer : function(){
		var self = this;
		var argvs = [].slice.apply(arguments);
		var len = argvs.length;
		if( len > 1 ) {
			var xtype = argvs[0];
			if( (xtype in self.xtypes) && $.isFunction( self.xtypes[ xtype ] ) ) {
				return self.xtypes[ xtype ]( $.extend({},argvs[1],{ autoDestroy:false,autoRender:true }) );	
			}
		} else {
			if( typeof argvs[0] === 'string' ) {
				argvs[0] = {
					xtype : argvs[0]	
				};		
			}
			argvs[0]['autoDestroy'] = false;
			argvs[0]['autoRender'] = true;
			if( 'xtype' in argvs[0] ){
				if( (argvs[0]['xtype'] in self.xtypes) && $.isFunction( self.xtypes[ argvs[0]['xtype'] ] ) ) {
					return self.xtypes[ argvs[0]['xtype'] ]( argvs[0] );	
				}
			}	
		}
		//如果在xtypes中找不到 就直接从Nex中创建
		if( len ) {
			var type= len>1?argvs[0]:argvs[0]['xtype'];
			var opt = len>1?argvs[1]:argvs[0];
			opt.autoDestroy = false;
			opt.autoRender = true;
			var o = Nex.getClass(type);
			if( o && $.isFunction( o )  ) {
				return new o( opt );
			}
		}
		return false;
	},
	/*
	给组件发送消息 一般当作自定义消息来使用
	@ *ids 发送的组件ID 可以是数组 或者是 组件对象，如果为"*"则发送给所有组件
	@ *evt 发送的消息事件
	@ params 发送的参数 可以是数组
	@ sender 发送者 这个参数可以通过 arguments[ arguments.length-1 ] 获得
	*/
	sendMessage : function( ids,evt,params,sender ){
		var self = this,undef;
		var cmps = self.getCmp();
		var params = self._undef( params,[] );
		params = $.isArray( params ) ? params : [ params ];
		if( sender ) {
			params.push( sender );		
		}
		if( ids === undef ) return false;
		
		if( ids === '*' ) {
			for( var obj in cmps ) {
				var cmp = cmps[obj];
				if( !cmp.isSleep() ) {
					cmp.fireEvent(evt,params);
				}
			}	
		}
		
		ids = $.isArray( ids ) ? ids : [ ids ];
		
		for( var i=0,len=ids.length;i<len;i++ ) {
			var cmpid = ids[i];
			if( Nex.isNex( cmpid ) ) {
				if( !cmpid.isSleep() ) {
					cmpid.fireEvent(evt,params);
				}
			} else {
				cmp = cmps[cmpid];
				if( cmp ) {
					if( !cmp.isSleep() ) {
						cmp.fireEvent(evt,params);	
					}
				}
			}
		}
		return true;
	},
	/*作用同sendMessage 只是会立即返回*/
	postMessage : function(ids,evt,params,sender){
		var self = this,undef;
		setTimeout(function(){
			self.sendMessage( ids,evt,params,sender );					
		},0);
		return true;
	},
	/*
	给组件发送消息 一般当作自定义消息来使用
	@ *name 组件的groupName
	@ *evt 发送的消息事件
	@ params 发送的参数 可以是数组
	@ sender 发送者 这个参数可以通过 arguments[ arguments.length-1 ] 获得
	*/
	sendMessageByGroupName : function(name,evt,params,sender){
		var self = this,undef;
		
		if( name === undef ) return false;
		
		var cmps = self.getGroup( name );
		
		var params = self._undef( params,[] );
		params = $.isArray( params ) ? params : [ params ];
		if( sender ) {
			params.push( sender );		
		}
		
		for( var i=0,len=cmps.length;i<len;i++ ) {
			var cmp = cmps[i];
			if( !cmp.isSleep() ) {
				cmp.fireEvent(evt,params);
			}
		}	
			
		return true;	
	},
	sendMessageToGroup : function(){
		return this.sendMessageByGroupName.apply( this,arguments );	
	},
	/*作用同sendMessageByGroupName 只是会立即返回*/
	postMessageByGroupName : function(name,evt,params,sender){
		var self = this,undef;
		setTimeout(function(){
			self.sendMessageByGroupName( name,evt,params,sender );					
		},0);
		return true;	
	},
	postMessageToGroup : function(){
		return this.postMessageByGroupName.apply( this,arguments );	
	}
});
Nex.Manager = new Nex._Manager( {
	autoDestroy : false,
	autoRender : true	
} );
/***************************************
****************Nex功能扩展**************
****************************************/
$.extend( Nex,{
	gc : function() {
		Nex.Manager._refreshCmps();
		return this;
	},
	create :　function(){
		return Nex.Manager.create.apply(Nex.Manager,arguments);
	},
	Create : function(){
		return this.create.apply( this,arguments );	
	},
	//创建一个Nex服务 
	createserver : function(){
		return Nex.Manager.createServer.apply(Nex.Manager,arguments);//	
	},
	createServer : function(){
		return this.createserver.apply( this,arguments );		
	},
	removeComponent : function(id){
		Nex.Manager.removeCmp(id);
		return this;
	},
	removeServer : function(id){
		Nex.Manager.removeCmp(id);
		return this;
	},
	get : function(id){
		return 	Nex.Manager.getCmp(id);
	},
	getCmp : function(id){
		return 	Nex.Manager.getCmp(id);
	},
	getGroup : function( name ){
		return 	Nex.Manager.getGroup(name);	
	},
	/*
	* 获取autoResize=true的组件
	*/
	getChildrens : function(id){
		return 	Nex.Manager.getChildrens(id);		
	},
	getAllChildrens : function(id){
		return 	Nex.Manager.getAllChildrens(id);		
	},
	getChildrensByDom : function( el ){
		return 	Nex.Manager.getChildrensByDom( el );		
	},
	getAllChildrensByDom : function( el ){
		return 	Nex.Manager.getAllChildrensByDom( el );		
	},
	refreshComponents : function(){
		return 	Nex.Manager.refreshComponents(name);		
	},
	resize : function(id){
		Nex.Manager._resize(id);
		return this;
	},
	sendMessage : function(){
		var mg = Nex.Manager;
		mg.sendMessage.apply(mg,arguments);	
		return this;
	},
	postMessage : function(){
		var mg = Nex.Manager;
		mg.postMessage.apply(mg,arguments);	
		return this;
	},
	sendMessageByGroupName : function(){
		var mg = Nex.Manager;
		mg.sendMessageByGroupName.apply(mg,arguments);	
		return this;
	},
	sendMessageToGroup : function(){
		var mg = Nex.Manager;
		mg.sendMessageByGroupName.apply(mg,arguments);	
		return this;
	},
	postMessageByGroupName : function(){
		var mg = Nex.Manager;
		mg.postMessageByGroupName.apply(mg,arguments);	
		return this;
	},
	postMessageToGroup : function(){
		var mg = Nex.Manager;
		mg.postMessageByGroupName.apply(mg,arguments);	
		return this;
	}
} );

/*
Nex-jquery插件
resizeCmp
sendMessage
postMessage
*/
jQuery.fn.extend({
	resizeCmp : function() {
		return this.each(function(){
			Nex.Manager.resizeDom( this );	
		});
	},
	sendMessage : function( eventType,params,sender ){
		var arg = [].slice.apply(arguments);
		
		if( !arg.length ) return this;
		
		var everyone = true;
		if( $.type(arg[ arg.length-1 ]) === 'boolean' ) {
			everyone = arg[ arg.length-1 ];
			arg.pop();
		}
		return this.each(function(){
			
			var cmps = everyone ? Nex.Manager.getAllChildrensByDom( this ) : Nex.Manager.getChildrensByDom( this );
			
			Nex.Manager.sendMessage.apply( Nex.Manager,[ cmps ].concat( arg ) );
		});	
	},
	postMessage : function( eventType,params,sender ){
		var arg = [].slice.apply(arguments);
		
		if( !arg.length ) return this;
		
		var everyone = true;
		if( $.type(arg[ arg.length-1 ]) === 'boolean' ) {
			everyone = arg[ arg.length-1 ];
			arg.pop();
		}
		return this.each(function(){
			
			var cmps = everyone ? Nex.Manager.getAllChildrensByDom( this ) : Nex.Manager.getChildrensByDom( this );
			
			Nex.Manager.postMessage.apply( Nex.Manager,[ cmps ].concat( arg ) );
		});		
	}
});
/***************************************************
****************AMD 组件加载(单例模式)****************
****************************************************
****************************************************/
var require,$require,$module,$import,$define,$exports,Module,define,Define,Require,exports,Exports;
;(function($){
	"use strict";
	var Loader = Nex.define('Nex.Loader').setXType('loader');
	//扩展Nex
	$.extend( Nex,{
		_getLoader : function(){
			return this.Loader._getLoader();	
		},
		getLoader : function(){
			return this.Loader._getLoader();	
		},
		/*
		*新增一个路径变量
		*@param string 路径变量名称 eg nex
		*@param string 路径地址 eg ./src/nex/
		*/
		setLoaderPath : function(){
			this.Loader.setPath.apply( this.Loader,arguments );	
			return this;
		},
		/*
		*新增需要加载的脚本别名
		*@param string 别名 eg Nex.Html
		*@param string 实名路径 eg {{nex}}/Html/Html 此处的{{nex}}引用 path里的
		*/
		setLoaderAlias : function(){
			this.Loader.setAlias.apply( this.Loader,arguments );	
			return this;
		},
		setLoaderShims : function(){
			this.Loader.setShims.apply( this.Loader,arguments );	
			return this;
		},
		/*
		*加载组件或脚本
		*如果加载的是组件 则 如果组件存在则不会加载 如果你加载的是组件，名称一定要对上
		*@param {Array} 组件列表 eg ['Nex.Ajax','Nex.Html']
		*@param {func} 回调
		*@param {boolean} 是否强制加载 默认 false  
		*/
		require : function(deps,callback,errback){
			var loader = this._getLoader();
			return loader.require( deps,callback,errback );
		},
		module : function(){
			var loader = this._getLoader();
			return loader.define.apply( loader,arguments );	
		},
		exports : function(o){
			var loader = this._getLoader();
			return loader.exports( o );	
		},
		setLoaderConfig : function(){
			this.Loader.setConfig.apply( this.Loader,arguments );	
			return this;	
		},
		getLoaderConfig : function(){
			return this.Loader.getConfig.apply( this.Loader,arguments );	
		}
	} );
	Loader.extend({
		version : '1.0',
		template : Nex.getTemplate({ ltag : '{',rtag:'}',simple:true }),
		__NexLoader : null,//Nex的Loader
		__loader : null,//单例模式的缓存
		_loadCache : {},//加载缓存
		exports : {},//所有加载的模块
		getDefaults : function(opt){
			var head = document.getElementsByTagName('head')[0] ||  document.documentElement;
			var _opt = {
				prefix : 'nexloader-',
				denyManager : true,//不需要Manager管理
				autoDestroy : true,
				autoScroll : false,
				autoResize : true,
				_lmt : 0,
				singleModel : true,//默认开启单例模式
				debug : false,
				strictDeps : true,//严格依赖 如果依赖加载失败就不会执行回调
				commentRegExp : /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg,
       			cjsRequireRegExp : /[^.]\s*(?:\$require|\$include)\s*\(\s*["']([^'"\s]+)["']\s*\)/g,
				exportsName : '_$export',// 做导出用 最好是没创建一个Loader exportsName都应该设置不同 因为在IE下会有onload 通知不及时问题
				exportsApi : '$exports',//全局导出api 最好用这个因为支持IE
				requireApi : '$require $include',//全局加载api 
				defineApi : '$define $module $import',
				head : head,
				baseElement : head.getElementsByTagName("base")[0],
				//是否检测文件类型后缀
				checkExt : true,
				defaultExt : '.js',
				//显示指定可以加载的文件类型后缀 eg：['json','xml'] 新增对josn xml的支持 如果不设置 当加载 a.json时会变成a.json.js
				loadExts : [],
				//默认支持的文件后缀 如果不存在则默认会使用 defaultExt来填充到后面
				_checkExtReg : /(\.css|\.js|\.php|\.jsp|\.py|\.txt|\.htm|\.html|\.php4|\.php5|\.php3|\.do|\.asp|\.aspx)$/,
				//显示指定当前路径采用那种扩展来加载 默认只支持 js css txt eg: 'lib/a.php?loadExt=txt'
				loadTypeName : 'loadExt',
				//强制统一所有加载都用该过程
				//自定义加载方法 function 或者指定当前对象的 api名称来加载
				//loadType定义后loadMaps无效
				loadType : '',
				//自定义模块或脚本的加载过程 {'a.json':function(url,s,f,c,m){},'b.txt2':'txt'}
				//做扩展用
				loadMaps : {},
				//对路径提前做写处理
				//例如:如果加载的模块都是以Nex.开头 那么我们就直接把"."替换"/"
				// [{ regexp : /^Nex./,process : function(path){ return path.repalce(/\./ig,'/'); } }]
				pathProcess : [],
				baseUrl : '',
				loadOrder : false,//是否按顺序加载脚本(串联加载，阻塞加载) 默认 false 
				scriptType : 'text/javascript',
				charset : 'utf-8',
				items : [],
				_list : [],//缓存list
				loadQueues : [],
				_loadCache : {},//判断是否加载ok
				module2path : {},//路径对应模块 
				currScriptAliasName : null,
				currScriptName : null,
				total : 0,//当前加载脚本数
				completeNum : 0,//脚本完成数
				progress : 0,//进度百分比
				_sysPaths : {
					'_nex_' : Nex.baseUrl
				},//Nex默认路径
				paths : {},//路径别名 eg:{ app:'lib/app' } items使用 {{app}}/a.js
				alias : {},//加载别名 eg:{ nex : '{{app}}/nex.js' }
				param : {},
				urlArgs : {},
				shim : {},//依赖机制
				template : Loader.template,
				autoLoad : false,//初始化后自动加载
				//pending : null,
				events : {
					onStart : $.noop,
					onCreate : $.noop,
					onInitComponent : $.noop,
					onParseScriptName : $.noop,
					onSuccess : $.noop,
					onError : $.noop,
					onComplete : $.noop
				}
			};
			var _opt = this.extSet(_opt);
			return $.extend({},_opt,opt);
		},
		_Tpl : {},
		_getLoader : function(){
			var self = this,undef;
			if( !self.__NexLoader ) {
				self.__NexLoader = Nex.Create('Nex.Loader',{
					autoLoad : false,
					loadOrder : false,
					cjsRequireRegExp : /[^.]\s*(?:Require|require|\$require|Nex\.require)\s*\(\s*["']([^'"\s]+)["']\s*\)/g,
					exportsName : '_export',
					exportsApi : '$exports Exports',
					requireApi : '$require Require',
					defineApi : '$module $define Module Define $import',
					pathProcess : [
						{
							regexp : function( path ){
								if( path === 'Nex' ) {
									return true;	
								}	
								if( /^Nex\./.test( path ) 
									&& !/\.css/.test( path )
									&& !/\.js/.test( path )
								   ) {
									return true;	   
								}
								return false;
							},
							process : function(path){
								var p = path.split('.');
								if( p.length === 1 ) {
									p.push( p[0] );	
								}
								return p.join('/');	
							}		
						}
					],
					'onBeforeParseScriptName.require' : function( name,moduleName,opt ){
						var classPath = Nex.getClassPath( name );
						if( classPath )	{
							classPath = classPath + '';
							classPath = classPath.split('.').join('/');
							opt.currScriptName = classPath;
						}
					},
					/*
					*加载组件时检测当前组件如果已经存在则不需要设置缓存
					*/
					'onBeforeLoadScript.require' : function( deps,opt ){
						var loader = this;
						$.each( deps,function(i,v){
							if( Nex.getClass(v) ) {
								if( !Nex.Loader.isLoad( v ) ) {
									Nex.Loader.setLoadCache( v,Nex.getClass(v) );
								} 
							} else {
								//是否加载工具Nex.util
								var s = (v+'').replace(/^Nex\.util\./,'');
								if( Nex.getUtil( s ) ) {
									if( !Nex.Loader.isLoad( v ) ) {
										Nex.Loader.setLoadCache( v,Nex.getUtil(s) );
									}	
								}
								//是否加载组合Nex.mixins
								var s = (v+'').replace(/^Nex\.mixins\./,'');
								if( Nex.getMixins( s ) ) {
									if( !Nex.Loader.isLoad( v ) ) {
										Nex.Loader.setLoadCache( v,Nex.getMixins(s) );
									}	
								}
							}		
						} );
					},
					nex : Nex.baseUrl
				});
				if( !self.__NexLoader ) {
					return null;	
				}
				self.__NexLoader.setPath('baseUrl',Nex.baseUrl)
							    .setPath('Nex',Nex.baseUrl);
			}
			return self.__NexLoader;
		},
		getLoader : function(){
			return this._getLoader();	
		},
		/*
		*key
		*value
		*/
		setConfig : function(k,v){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.C.apply(loader,arguments);
			return this;		
		},
		getConfig : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return null;	
			}
			return loader.C.apply(loader,arguments);
		},
		/*
		*新增一个路径变量
		*@param string 路径变量名称 eg nex
		*@param string 路径地址 eg ./src/nex/
		*/
		setPath : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.setPath.apply(loader,arguments);
			return this;	
		},
		/*
		*新增需要加载的脚本别名
		*@param string 别名 eg Nex.Html
		*@param string 实名路径 eg {{nex}}/Html/Html 此处的{{nex}}引用 path里的
		*/
		setAlias : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.setAlias.apply(loader,arguments);
			return this;		
		},
		package : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.package.apply(loader,arguments);
			return this;			
		},
		setPackage : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.package.apply(loader,arguments);
			return this;			
		},
		setShims : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.setShims.apply(loader,arguments);
			return this;		
		},
		/*添加加载扩展*/
		addExts : function( iarr ){
			var self = this,
				opt = self.configs,
				undef;
			iarr = iarr && $.isArray( iarr ) ? iarr : [ iarr ];
			$.each( iarr,function(i,ext){
				opt.loadExts.push( ext );	
			} );	
			return self;	
		},
		/*
		*判断模块是否已经加载
		*@param {String} 模块
		*/
		isLoad : function(moduleName){
			var self = this,
				undef;
			if( moduleName === undef ) {
				return false;	
			}	
			if( Nex.Loader._loadCache[ moduleName ]===true 
				//|| Nex.Loader.exports[ moduleName ] !== undef 
			  ) {
				return true;	
			}
			return false;
		},
		/*
		*获取导出对象
		*/
		getExports : function( name ){
			var self = this,undef;
			var exports = this.exports;
			
			if( name === undef ) {
				return exports;	
			}
			
			if( !(name in exports) || exports[name] === undef ) {
				if( Nex.getClass( name ) ) {
					exports[ name ] = Nex.getClass( name );	
				} else {
					//是否加载工具Nex.util
					var s = (name+'').replace(/^Nex\.util\./,'');	
					if( Nex.getUtil( s ) ) {
						exports[ name ] = Nex.getUtil( s );		
					}
					//是否加载组合Nex.mixins
					var s = (name+'').replace(/^Nex\.mixins\./,'');
					if( Nex.getMixins( s ) ) {
						exports[ name ] = Nex.getMixins( s );	
					}
				}
			}		
			
			return exports[ name ];
		},
		getModule : function( n ){
			return this.getExports( n );	
		},
		/*
		*设置模块加载缓存 
		*@param {String} 需要设置的模块缓存
		*@param {...} 模块对象
		*/
		setLoadCache : function(moduleName,exports){
			var self = this,
				undef;
			if( moduleName === undef ) {
				return self;	
			} else {
				moduleName = moduleName + '';	
			}
			Nex.Loader._loadCache[ moduleName ]	= true;
			Nex.Loader.exports[ moduleName ] = exports;
			return self;
		},
		/*
		*清空模块加载缓存 
		*@param {moduleName} 需要设置的模块缓存
		*/
		unsetLoadCache : function( moduleName ){
			var self = this,
				undef;
			if( moduleName === undef ) {
				return self;	
			} else {
				moduleName = moduleName + '';	
			}
			delete Nex.Loader._loadCache[ moduleName ];
			delete Nex.Loader.exports[ moduleName ];
			return self;	
		},
		/*
		*清空所有加载缓存
		*/
		clearLoadCache : function(){
			var self = this,
				undef;
			Nex.Loader._loadCache = {};	
			Nex.Loader.exports = {};
			return self;	
		},
		/*
		*设置自定义文件扩展加载函数
		*eg: Nex.Loader.setExtFunction( 'php',function(url,success,fail,complete,module){} );
		*/
		setExtFunction : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.setExtFunction.apply(loader,arguments);
			return this;			
		},
		/*
		*设置模块的自定义加载过程 eg :
		*Nex.Loader.setLoadMaps('a.json',function( url,success,error,complete,module ){自定义加载过程});
		*/
		setLoadMaps : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.setLoadMaps.apply(loader,arguments);
			return this;				
		},
		bind : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.bind.apply(loader,arguments);
			return this;				
		},
		one : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.one.apply(loader,arguments);
			return this;				
		},
		unbind : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.unbind.apply(loader,arguments);
			return this;				
		},
		fireEvent : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.fireEvent.apply(loader,arguments);
			return this;				
		},
		on : function(){
			return this.bind.apply(this,arguments);
		},
		off : function(){
			return this.unbind.apply(this,arguments);
		},
		fire : function(){
			return this.fireEvent.apply(this,arguments);	
		},
		abort : function(){
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.abort.apply(loader,arguments);
			return this;				
		},
		/*
		*设置路径处理流程
		*@param {RegExp,Function} 检测当前路径是否需要处理 true则需要处理
		*@process 处理过程
		*/
		setPathProcess : function( regexp, process ){	
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return null;	
			}
			return loader.setPathProcess.apply(loader,arguments);
		},
		unsetPathProcess : function( id ){	
			var self = this;
			var loader = Nex._getLoader();
			if( !loader ) {
				return this;	
			}
			loader.unsetPathProcess.apply(loader,arguments);
			return this;					
		}
	});
	Loader.fn.extend({
		_init : function(opt) {
			var self = this;
			
			if( Loader.__loader && opt.singleModel ) {
				$.extend( self,Loader.__loader );
				return;
			}
			if( opt.singleModel ) {
				Loader.__loader = Loader.__loader ? Loader.__loader : self;
			}
			
			window[opt.exportsName] = {};
			window[opt.exportsName+'CallBack'] = {};
			
			var config = function(){
				var conf = arguments[0];
				if( $.isPlainObject(conf) ) {
					conf.urlArgs = $.isPlainObject( conf.urlArgs ) ? conf.urlArgs : { '*':conf.urlArgs };
				}
				 return self.C.apply( self,arguments );
			};
			
			$.each( opt.requireApi.split(/\s+/),function(i,v){
				window[v] = function(){
					return self.require.apply( self,arguments );	
				};	
				window[v]['config'] = config;
			} );
			$.each( opt.exportsApi.split(/\s+/),function(i,v){
				window[v] = function(){
					return self.exports.apply( self,arguments );	
				};	
			} );
			$.each( opt.defineApi.split(/\s+/),function(i,v){
				window[v] = function(){
					return self.define.apply( self,arguments );	
				};	
			} );
			
			self.initComponent();
		},
		__loaderCallBack : [],
		resetExports : function(){
			var self = this,
				opt = self.configs;	
			window[opt.exportsName] = {};
			window[opt.exportsName+'CallBack'] = {};
			return self;
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			
			self.bind("onCreate",self._autoLoad,self);
			
			return self;
		},
		getExports : function( name ){ 
			var self = this;
			var opt = this.configs;
			self.fireEvent('onRequireModule',[ name,Nex.Loader.exports,opt ]);
			return Nex.Loader.getExports( name );
		},
		_checkLoad : function(){
			var self = this,
				opt = self.configs;
				
			self._checkLoad1();		
			/*
			if( opt.loadOrder ) {
				self._checkLoad2();	//无效
			} else {
				self._checkLoad1();	
			}	
			*/
			return self;
		},
		//回调实现方式1 ，等所有脚本加载完后才执行 适合所有模式
		/*
		*回调使用了延时机制，解决内嵌require死循环问题但是不再支持模块打包
		*/
		_checkLoad1 : function(){
			var self = this,
				opt = self.configs;
			var cache = opt._loadCache;
			var callbacks = self.__loaderCallBack;
			self.__loaderCallBack = [];
			//成功后回调执行状态
			var exec = {};
			var maps = {};
			var maps2 = {};
			$.each( callbacks,function(i,d){
				if( d.moduleName ) {
					maps[ d.moduleName ] = { deps : [].concat(d.deps) };
					maps2[ d.moduleName ] = d;
				}	
			} );
			/*
			*计算依赖的执行顺序算法草稿:
			eg:
			var exec = {};
			var maps = {
					A : {
						deps : [ 'C','E','F','B' ],
						callBack : function (){
							console.log('A');	
						}	
					},
					B : {
						deps : [ 'A' ],
						callBack : function (){
							console.log('B');	
						}	
					},
					C : {
						deps : [ 'F' ],
						callBack : function (){
							console.log('C');	
						}	
					},
					D : {
						deps : [ 'T' ],
						callBack : function (){
							console.log('D');	
						}		
					},
					E : {
						deps : [ 'C','D','F' ],
						callBack : function (){
							console.log('E');	
						}	
					},
					F : {
						deps : [  ],
						callBack : function (){
							console.log('F');	
						}	
					}
				};
				var execDeps = function(){
					var i = 0;
					$.each( maps,function( mod,data ){
						var  deps = data.deps;
						if( mod in exec ) {
							return;	
						}
						Nex.array_splice( function(i,v){
							if( v in exec ) {
								return true;	
							}
							if( !(v in maps) ) {
								return true;	
							}	
						},deps );	
						if( !deps.length ) {
							data.callBack();
							exec[mod] = true;
							console.log( mod,'--执行ok' );	
						} else {
							//console.log( mod,'--执行' )	
							i++;
						}
					} )	;
					return i;
				};
				var t = 0;
				var x = 0;
				while( t=execDeps() ) {
					if( t == x ) {
						break;	
					}	
					x = t;
				}
				console.log( '剩余的（循环依赖）：',t );
				if( t>0 ) {
					$.each( maps,function( mod,data ){
							var  deps = data.deps;
							if( mod in exec ) {
								return;	
							}
							data.callBack();
							console.log( mod,'--执行ok' );	
					} )	;
				}
				step1:应该先执行 没有依赖的模块，那应该是 D和F 注：D 所依赖的T 因为不是在本次加载中，所以早就已经加载好了
				step2:C,E可以执行
				step3:A,B出现了循环引用，那么我们就不要寻找了 直接执行A , B
			*/
			/***********依赖的执行顺序代码实现***********/
			var execQueues = [];
			var execDeps = function(){
				var i = 0;
				//这里的mod是指module  deps是指依赖
				$.each( maps,function( mod,data ){
					var  deps = data.deps;
					//如果已经执行，就跳过
					if( mod in exec ) {
						return;	
					}
					//在deps中删除已经执行好了的模块
					Nex.array_splice( function(i,v){
						if( v in exec ) {
							return true;	
						}
						if( !(v in maps) ) {
							return true;	
						}	
					},deps );
					//如果deps已经没有依赖，那就可以执行当前模块	
					if( !deps.length ) {
						execQueues.push( maps2[mod] );
						exec[mod] = true;	
					} else {//记录当前还有多少待计算的依赖模块，用于下次循环
						i++;
					}
				} )	;
				return i;
			};
			var t = 0;
			var x = 0;
			//循环计算依赖模块的执行顺序
			while( t=execDeps() ) {
				if( t == x ) {
					break;	
				}	
				x = t;
			}
			//如果t>0 说明出现了循环依赖
			//这个时候 我们不再计算，直接执行
			if( t>0 ) {
				$.each( maps,function( mod,data ){
					if( mod in exec ) {
						return;	
					}
					execQueues.push( maps2[mod] );
					exec[mod] = true;	
				} )	;	
			}
			//把没有moduleName($require(...))的模块放到最后执行
			$.each( callbacks,function(i,d){
				if( !d.moduleName ) {
					execQueues.push( d );
				}	
			} );
			//以上已经把依赖执行顺序存放execQueues，后续只要执行
			//console.log( execQueues );
			/***********执行所有模块的回调***********/
			$.each( execQueues,function(i,data){
				var isSuccess = true,
					errDeps = [],
					deps = data.deps;	
				//检测是否所有依赖都加载成功	
				$.each( deps,function(i,d){				 
					if( (d in cache) && cache[d] === false ) {
						isSuccess = false;
						errDeps.push( d );
					}					 
				} );	
				//如果严格模式下 当前模块应该是没有加载成功
				if( opt.strictDeps && !isSuccess ) {
					Nex.Loader.unsetLoadCache( data.moduleName );
				}
				isSuccess = opt.strictDeps ? isSuccess : true;
				if( isSuccess ) {
					if( $.isFunction( data.callBack ) ) {
						data.callBack.call(data);	
					}
				} else {
					if( $.isFunction( data.errBack ) ) {
						data.errBack.call(data,errDeps);
					}	
				}
			} );
			
			return self;
		},
		//以废弃
		_checkLoad2 : function(){},
		_autoLoad : function(){
			var self = this,
				opt = self.configs;
			
			if( opt.autoLoad ) {
				self.load( opt.items );	
			}	
		},
		//判断当前状态是否加载完
		_isLoadScript : function( status ){
			return ( status === true || status === false ) ? true : false;	
		},
		_isLoadPending : function( status ){
			return status === 'pending' ? true : false;	
		},
		/*
		*计算当前的加载进度
		*/
		getProgress : function(){
			var self = this,
				opt = this.configs;
			var cache = opt._loadCache,total=0,completeNum=0;
			for( var n in cache ) {
				total++;
				completeNum =  !self._isLoadScript( cache[n] ) ? completeNum : ++completeNum;
			}
			opt.total = total;
			opt.completeNum = completeNum;
			opt.progress = completeNum*100/total;
			return opt.progress;
		},
		/*
		*新增一个路径变量
		*@param string 路径变量名称 eg nex
		*@param string 路径地址 eg ./src/nex/
		*/
		setPath : function(/* name,value */){
			var self = this,
				argvs = arguments,
				opt = this.configs;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( opt.paths,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					opt.paths[argvs[0]] = argvs[1];
				}	
			}
			return self;
		},
		/*
		*新增需要加载的脚本别名
		*@param string 别名 eg Nex.Html
		*@param string 实名路径 eg {{nex}}/Html/Html 此处的{{nex}}引用 path里的
		*/
		setAlias : function(/* name,value */){
			var self = this,
				argvs = arguments,
				opt = this.configs;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( opt.alias,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					opt.alias[argvs[0]] = argvs[1];
				}	
			}
			return self;
		},
		/*设置包名和路径*/
		package : function( pkg,path ){
			var self = this,
				opt = this.configs;	
			Nex.Loader.setPath(pkg,path);	
			Nex.Loader.setPathProcess( new RegExp('/^'+pkg+'\./') );
			Nex.Loader.setPathProcess( new RegExp('/^'+Com+'$/') );
			return self;
		},
		setPackage : function(){
			return this.package.apply( this,arguments );	
		},
		/*
		*设置强制依赖
		*@param string 需要加载的脚本
		*@param string 强制依赖的脚本
		*/
		setShims : function(/* name,value */){
			var self = this,
				argvs = arguments,
				opt = this.configs;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( opt.shim,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					opt.shim[argvs[0]] = argvs[1];
				}	
			}
			return self;
		},
		/*
		*脚本加载失败时调用
		*@param object 事件对象
		*@param func 成功后调用
		*@param func 失败后调用
		*@param func 完成后调用
		*@param string 当前脚本名
		*/
		onScriptLoad : function(evt,s,f,c,_currName){
			var node = evt.currentTarget || evt.srcElement,
				opt = this.configs;
			if (evt.type === 'load' ||
                        (/^(complete|loaded)$/.test(node.readyState))) {
				if($.isFunction(s)) {
					s(null,c);	
				}	
             }
			 return this;
		},
		/*
		*脚本加载失败时调用
		*@param object 事件对象
		*@param func 成功后调用
		*@param func 失败后调用
		*@param func 完成后调用
		*@param string 当前脚本名
		*/
		onScriptError : function(evt,s,f,c,_currName){
			var node = evt.currentTarget || evt.srcElement,
				opt = this.configs;
			if($.isFunction(s)) {
				f();	
			}	
			return this;
		},
		/*
		*单个脚本加载完后必须调用，检测是否所有脚本都已经加载完
		*@param func 回调
		*@param string 当前脚本名
		*/
		onScriptComplete : function(c,_currName){
			var self = this,
				opt = this.configs,
				cache = opt._loadCache,
				complete = true,
				successDeps = [],
				errDeps = [],
				success = true;	
				
			//此事件一定不能用延迟 
			self.fireEvent('onLoadScriptComplete',[_currName,opt]);	
			//如果所有模块都已经缓存，那么通过.progress()不会触发 如果需要触发这里需要延迟执行 setTimeout
			var _pr = self.getProgress();
			setTimeout(function(){
				self.fireEvent('onProgress',[ _pr,_currName,opt ]);	
			},0);
			//检测是否所有脚本加载完成
			for( var k in cache ) {
				if( !self._isLoadScript(cache[k]) ) {
					complete = false;
					break;	
				}
			}
			
			if( $.isFunction(c) ) {
				c();
			}
			
			if( opt.loadOrder ) {
				self._load();
			} else {
				//BUG代码注释 _clearLoadCache提前释放了_loadCache，导致_checkLoad检查的时候 _loadCache已经被清空
				//if( complete ) {
//					self._clearLoadCache();	
//				}
			}
			
			if( complete ) {
				//清空
				opt.items.length = 0;	
				//checkLoad机制检查
				self._checkLoad();
				
				for( var k in cache ) {
					if( cache[k]===false ) {
						success = false;
						errDeps.push( k );
					} else if( cache[k]===true ) {
						successDeps.push( k );
					}	
				}	
				var sback = function(){
					self.fireEvent('onSuccess',[successDeps,opt]);	
					if( opt.deferred ) {
						opt.deferred.resolve([ opt ]);	
					}	
					self._isLoading = false;
					self.fireEvent('onComplete',[successDeps,errDeps,opt]);	
				};
				var eback = function(){
					self.fireEvent('onError',[errDeps,opt]);	
					if( opt.deferred ) {
						opt.deferred.reject([ opt ]);
					}	
					self._isLoading = false;
					self.fireEvent('onComplete',[successDeps,errDeps,opt]);		
				};
				if( success ) {
					//解决缓存问题导致链式调用的.done 无效
					setTimeout(function(){
						sback();	
					},0);
				} else {
					setTimeout(function(){
						eback();	
					},0);
				}
				//修改BUG 注意此处_clearLoadCache应该在调用sback之前调用，但是使用了计时器所以可以在此执行
				if( !opt.loadOrder && complete ) {
					self._clearLoadCache();	
				}
			}	
			
			return self;
		},
		/*
		*添加自定义加载函数
		*/
		setExtFunction : function( ext,func ){
			function replaceReg(reg,str){
				str = str.toLowerCase();
				return str.replace(reg,function(m){return m.toUpperCase()})
			}
			if( ext === 'js' || ext === 'css' ) {
				return this;	
			}
			ext = replaceReg( /\b(\w)|\s(\w)/g,ext );
			this['load'+ext] = func;
			
			return this;
		},
		/*
		*设置自定义加载过程 eg :
		*Nex.getLoader().setLoadMaps('a.json',function( url,success,error,complete,module ){自定义加载过程});
		*/
		setLoadMaps : function(k,v){
			var self = this,
				opt = this.configs;
			if( arguments.length>1 ) {
				opt.loadMaps[ arguments[0] ] = arguments[1]	
			}else if( $.isPlainObject( arguments[0] ) ) {
				$.extend( opt.loadMaps,arguments[0] );
			}
			return self;	
		},
		/*
		*设置路径处理流程
		*@param {RegExp,Function} 检测当前路径是否需要处理 true则需要处理
		*@process 处理过程
		*/
		setPathProcess : function( regexp, process ){
			var self = this,
				opt = this.configs;	
			return opt.pathProcess.push( {
				regexp : regexp,
				process : process || null	
			} );	
		},
		unsetPathProcess : function( id ){
			var self = this,
				opt = this.configs,
				id = parseInt(id) - 1;
			if( opt.pathProcess[id] ) {
				opt.pathProcess[id] = null;	
			}
			return this;
		},
		/*
		*加载脚本
		*@param string 脚本地址
		*@param func 成功后调用
		*@param func 失败后调用
		*@param string 当前脚本名称
		*/
		loadScript : function(name,s,f,c,_currName){
			var self = this,
				undef,
				node,
				isOpera = Nex.isOpera,
				url = name,
				opt = this.configs,
				head = opt.head || document.getElementsByTagName('head')[0] ||  document.documentElement
				;	
				
			node = document.createElement('script');	
			node.type = opt.scriptType || 'text/javascript';
            node.charset = opt.charset || 'utf-8';
            node.async = true;
			/*
			*IE下有脚本执行的onload触发时，未必是当前脚本直接结束。可能是好几个脚本同时执行结束后才触发。。。
			*/
			node.scriptName = _currName;
			
			var complete = function(){
				opt.head.removeChild(node);
				if( $.isFunction(c) ) {
					c();
				}
			};
			
			if (node.attachEvent &&
                    !(node.attachEvent.toString && node.attachEvent.toString().indexOf('[native code') < 0) &&
                    !isOpera) {
                node.attachEvent('onreadystatechange', function(evt){
					self.onScriptLoad(evt,s,f,complete,_currName);	
				});
            } else {
                node.addEventListener('load', function(evt){
					self.onScriptLoad(evt,s,f,complete,_currName);
				});
                node.addEventListener('error', function(evt){
					self.onScriptError(evt,s,f,complete,_currName);
					if( opt.debug ) {
						Nex.error(name+' load error!');
					}
				});
            }
			self.currentlyAddingScript = node;
			//baseElement
            node.src = url;
			// ref: #185 & http://dev.jquery.com/ticket/2709
		    opt.baseElement ?
			  	head.insertBefore(node, opt.baseElement) :
			 	head.appendChild(node)
			//head.appendChild(node);
			
			self.currentlyAddingScript = null;
			
			return node;
		},
		/*
		*加载样式
		*@param string 脚本地址
		*@param func 成功后调用
		*@param func 失败后调用
		*@param string 当前脚本名称
		*/
		loadCss : function(name,s,f,c,_currName){
			var self = this,
				undef,
				url = name,
				node,
				opt = this.configs,
				head = opt.head || document.getElementsByTagName('head')[0] ||  document.documentElement
				;	
				
			node = document.createElement("link");
			node.charset = opt.charset || 'utf-8';
			node.rel = "stylesheet";
    		node.href = url;
			head.appendChild(node);
			
			setTimeout(function() {
			 	 if($.isFunction(s)) {
					 s();	
			 	 }
			}, 1);
			return node;
		},
		/*
		*ajax扩展类型加载
		*@param string 脚本地址
		*@param func 成功后调用
		*@param func 失败后调用
		*@param string 当前脚本名称
		*/
		loadAjax : function( url,success,fail,complete,alias ){
			var self = this,
				undef,
				opt = this.configs
				;
				
			var ajax = Nex.Create('Nex.Ajax',{
				url : url,
				'onSuccess._sys' : function(data){
					if($.isFunction(success)) {
						success(data);	
					}
				},
				'onError._sys' : function(){
					if($.isFunction(fail)) {
						fail();	
					}
				}
			});
			
			return ajax;
		},
		loadTxt : function(){
			return this.loadAjax.apply( this,arguments );	
		},
		/*
		*获取模块加载顺序
		*/
		getLoadQueues : function(){
			return this.configs.loadQueues.reverse();	
		},
		isLoading : function(){
			return this._isLoading;	
		},
		_isLoading : false,
		/*
		*开始加载脚本
		*/
		startLoad : function(){
			var self = this,
				undef,
				opt = this.configs;
			//opt.loadOrder = true;//只支持依赖加载 按顺序加载	
			opt.items = $.isArray( opt.items ) ? opt.items : [ opt.items ];
			opt._list = opt.items.concat([]);	
			opt._loadCache = {};

			//opt.pending = true;
			
			if( !opt.items.length ) {
				return self;	
			}
			
			var r = self.fireEvent('onBeforeStartLoad',[ opt ]);
			if( r === false ) {
				return self;	
			}
			
			for( var i=0,len=opt._list.length;i<len;i++ ) {
				if( opt._list[i] === '' ) continue;
				opt._loadCache[opt._list[i] + ''] = null;
			}
			opt.loadQueues.length = 0;	
			self._load();
			self._isLoading = true;
			return self;
		},
		_clearLoadCache : function(){
			var self = this,
				undef,
				opt = this.configs;
			opt.currScriptAliasName = null;
			opt.currScriptName = null;
			opt._list.length = 0;	
			opt._loadCache = {};
			return self;
		},
		/*
		*判断当前当前脚本是否都加载完
		*/
		isLoadComplete : function(){
			var self = this,
				undef,
				finish = true,
				opt = this.configs;
			if( !opt._list.length ) {
				return true;	
			}
			$.each( opt._list,function(i,d){
				if( d in opt._loadCache && !self._isLoadScript(opt._loadCache[d]) ) {
					finish = false;	
					return false;
				}						   
			} );
			return finish;
		},
		/*
		*判断当前队里是否还有正在等待的脚本
		*/
		isAllPending : function(){
			var self = this,
				undef,
				pending = true,
				opt = this.configs;
			$.each( opt._list,function(i,d){
				if( opt._loadCache[d] === null ) {
					pending = false;	
					return false;
				}						   
			} );
			return pending;	
		},
		//获取下一个需要加载的脚本
		getNextLoadScript : function(){
			var self = this,
				undef,
				script = null,
				opt = this.configs;
			if( !opt._list.length ) {
				return script;	
			}
			$.each( opt._list,function(i,d){
				if( d in opt._loadCache && !self._isLoadScript(opt._loadCache[d]) && !self._isLoadPending(opt._loadCache[d]) ) {
					script = d;	
					return false;
				}
			} );
			return script;
		},
		//扩展用
		loadExtension : function(name,success,error,complete,_currName){
			var self = this;
			return self.loadScript( name,success,error,complete,_currName );	
		},
		/*
		*判断模块是否已经加载
		*@param {String} 模块
		*/
		isLoad : function(moduleName){
			return Nex.Loader.isLoad(moduleName);		
		},
		/*
		*设置模块加载缓存 
		*@param {String} 需要设置的模块缓存
		*@param {...} 模块对象
		*/
		setLoadCache : function(moduleName,exports){
			return Nex.Loader.setLoadCache(moduleName,exports);		
		},
		/*
		*清空模块加载缓存 
		*@param {moduleName} 需要设置的模块缓存
		*/
		unsetLoadCache : function( moduleName ){
			return Nex.Loader.unsetLoadCache(moduleName);		
		},
		/*
		*清空所有加载缓存
		*/
		clearLoadCache : function(){
			return Nex.Loader.clearLoadCache();	
		},
		_getShim : function( moduleName ){
			var self = this,
				undef,
				opt = this.configs,
				deps = [];
			
			var modules = $.isArray( moduleName ) ? moduleName : [moduleName];
			$.each( modules,function( i,n ){
				var shim = opt.shim[ n ] === undef ? "" : opt.shim[ n ];
				if( shim ) {
					shim = $.isArray( shim ) ? shim : [shim];	
				} else {
					shim = [];	
				}
				deps.push.apply( deps,shim );
			} );
			
			//清除为空的模块或者以及加载的模块
			Nex.array_splice( function(i,v){
				if( $.trim( v ) === '' ) return true;	
				if( Nex.Loader._loadCache[v] === true || Nex.Loader._loadCache[v] === false ) {
					return true;	
				}
			},deps );
			
			return deps;	
		},
		_addDeps : function( deps ){
			var self = this,
				undef,
				opt = this.configs;
				
			$.each( deps,function(i,d){
				if( !(d in opt._loadCache) ) {
					opt._loadCache[d + ''] = null;
				}
			} );
			
			Nex.array_insert( 0,deps,opt._list,1 );
			
			return self;
		},
		_currentPath : null,
		/*
		*加载单个脚本
		*因为需要加载的文件都会存入一个堆栈(后进先出) 文件加载成功后都会出堆 直到堆栈为空则停止
		*/
		_load : function(){
			var self = this,
				undef,
				opt = this.configs,
				ext = opt.defaultExt.replace('.',"");
			
			if( !opt.loadOrder && self.isAllPending() ) {
				return self;	
			}
			
			if( self.isLoadComplete() ) {
				if( opt.loadOrder ) {
					self._clearLoadCache();
				}
				return self;	
			}
			
			var _currName = self.getNextLoadScript();
			
			_currName = _currName + '';
			var name = _currName;
			opt.currScriptAliasName = name;
			
			//是否加上baseUrL
			var baseUrl = true;
			
			if( name in opt.alias ) {
				name = opt.alias[name];	
				baseUrl = false;
			} else {
				//name = opt.baseUrl + name;	
			}
			
			var _extReg = null;
			if( opt.loadExts.length ) {
				_extReg = new RegExp('\.('+opt.loadExts.join('|')+')$','i');	
			}
			
			function getScriptExt(url){
				var _url = url;
				
				url = url.replace(/[?#].*/, "");
				
				if( opt._checkExtReg.test( url ) 
					|| ( _extReg ? _extReg.test( url ) : false ) 
				) {
					return url.split('.').pop();	
				}
				
				if( opt._checkExtReg.test( _url ) 
					|| ( _extReg ? _extReg.test( _url ) : false ) 
				) {
					return _url.split('.').pop();	
				}
				
				return '';
			}
			
			opt.currScriptName = name;//当前脚本名
			
			opt.loadQueues.push( _currName );
			//{ module : _currName,path : name }
			var r = self.fireEvent('onBeforeParseScriptName',[ name,_currName,opt ]);
			
			name = opt.currScriptName;
			
			if( r !== false ) {
				//处理用户自定义模块路径解析
				//if( !((name in opt.paths) && opt.paths[name]) ) {
				var pathProcess = opt.pathProcess.concat([]).reverse();
				$.each( pathProcess , function(i,d){
					if( d && $.isPlainObject( d ) ) {
						var c = false;
						if( $.type(d.regexp) === 'regexp' ) {
							c = d.regexp.test( name );	
						} else if( $.isFunction( d.regexp ) ) {
							c = d.regexp.call( self,name );
						} else if( d.regexp === name ) {
							c = true;	
						}
						if( c ) {
							var _path;
							if( $.isFunction( d.process ) ) {
								_path = d.process.call( self,name,_currName,opt );	
							} else if( $.type( d.process ) === 'string' ) {
								_path = d.process;	
							} else {
								var p = name.split('.');
								if( p.length === 1 ) {
									p.push( p[0] );	
								}
								_path = p.join('/');		
							}
							name = _path ? _path+'' : name;
							return false;//跳出 break
						}
					}	
				} );
				//}
				//paths 替换
				name = name.split('/');
				if( name[0] === '.' && name[1] !=='' ) {
					if( name[1] in opt.paths ) {
						name[1] = opt.paths[name[1]];	
						baseUrl = false;
					}	
					name.splice(0,1);
				}
				if( name[0] !== '..' && name[0] !== '' ) {
					if( name[0] in opt.paths ) {
						name[0] = opt.paths[name[0]];	
						baseUrl = false;
					}	
				}
				name = name.join('/');
				
				try{
					name = opt.template.compile( name,opt.paths );
				} catch(e) {}
				
				var _ext = getScriptExt( name );
				
				//检测如果最后没有.css .js .php ...会自动加上默认后缀
				if( opt.checkExt 
					&& !opt._checkExtReg.test( name ) 
					&& (_extReg ? !_extReg.test( name ) : true)
					&& !_ext 
				) {
					name += opt.defaultExt;	
				}
				
				//opt.currScriptName = name;//当前脚本名
				
				var _paths = {
					path : _currName,
					url : name,
					module : _currName
				};
				
				self.fireEvent('onParseScriptName',[ _paths,opt ]);
				
				name = _paths.url;
				//name = opt.currScriptName;
				
				var ishttp = /^(http|\/\/)/;
				if( !ishttp.test( name ) && baseUrl ) {
					name = opt.baseUrl+	name;
				}
			}
			
			ext = getScriptExt( name ) || 'js';
			
			var complete = function(){};
			var _complete = complete;
			var success = function(data,complete){
				var name = _currName;
				//扩展加载时用到
				if( data ) {
					self._exports( name,data );		
				}
				
				opt._loadCache[name] = true;	
				Nex.Loader._loadCache[ name ] = true;
				
				if( !Nex.isIE ) {//如果不是IE 保存导出对象
					var ep = $.isPlainObject( window[opt.exportsName] ) && $.isEmptyObject( window[opt.exportsName] ) ? undef : window[opt.exportsName];
					if( ep ) {
						Nex.Loader.exports[ name ] =  ep;
					}
					window[opt.exportsName+'CallBack']['moduleName'] = name;
					//window[opt.exportsName+'CallBack'] = {};
				}
				
				self.resetExports();
				self.fireEvent('onLoadScriptSuccess',[name,opt]);
				self.onScriptComplete( complete || _complete,name );
			};
			var error = function(complete){
				var name = _currName;
				opt._loadCache[name] = false;	
				Nex.Loader._loadCache[ name ] = false;
				//window[opt.exportsName+'CallBack'] = {};
				self.fireEvent('onLoadScriptError',[name,opt]);
				self.onScriptComplete( complete || _complete,name );
			};
			
			var query = $.param( $.extend(opt.param,opt.params,opt.urlArgs) );
			if( query ) {
				query = name.indexOf('?') === -1 ? '?'+query : '&'+query;
			}
			
			//再次获取扩展名 以确定调用对应的扩展函数加载
			var extReg = new RegExp( opt.loadTypeName+'=[^&]+','ig' );
			if( $.isArray( extReg ) && extReg.length ) {
				ext = extReg.pop().replace('.','');
			}
			var __ext = {
				ext : ext,
				url : name,
				module : _currName	
			};
			self.fireEvent('onGetExtName',[ __ext,opt ]);
			ext = __ext.ext;
			
			name = opt.currScriptName = $.trim(name + query);
			
			opt.module2path[ opt.currScriptAliasName ] = name;
			/********************************/
			var loadType = opt.loadType;
			
			var _map = opt.loadMaps[ _currName ];
			if( _map ) {
				if( $.isFunction( _map ) ) {
					loadType = _map;
				} else {
					loadType = null;
					ext = _map;	
				}
			}
			
			var __d = {
				url : name,
				module : _currName,
				ext : ext,
				loadType : 	loadType,
				success : success,
				error : error,
				complete : complete,
				cache : false
			};
			
			var cache = false;
			//检查加载缓存
			if( self._isLoadScript(opt._loadCache[_currName])                 
				|| ((_currName in Nex.Loader._loadCache) && (Nex.Loader._loadCache[_currName]===true)) 
				//|| (_currName in Nex.Loader.exports) 
			  ) {
				cache = true;
			}
			/*缓存加载流程*/
			if( cache ) {
				__d.cache = true;
				var __r = self.fireEvent('onLoadScriptStart',[__d,opt]);
				if( __r !== false ) {
					opt._loadCache[_currName] = true;//必须
					self.fireEvent('onLoadScriptSuccess',[_currName,opt]);
					
					self.onScriptComplete( function(){
						self._load();	
					},_currName );
				}
				if( !opt.loadOrder ) {
					self._load();	
				}
				return self;
			}
			
			//设置默认值 这一步或许不必要 但是按理来说都应该有导出模块 只是默认是{}
			//Nex.Loader.exports[ _currName ] = {};
			//首字母大写
			function replaceReg(reg,str){
				str = str.toLowerCase();
				return str.replace(reg,function(m){return m.toUpperCase()})
			}
			
			if( !opt.loadOrder ) {
				opt._loadCache[opt.currScriptAliasName] = 'pending';	
			}	
			
			var __r = self.fireEvent('onLoadScriptStart',[__d,opt]);
			if( __r !== false ) {
				loadType = __d.loadType;
				ext = __d.ext;
				if( !loadType ) {
					//加载css
					if( ext === 'css' ) {
						self.loadCss( name,success,error,complete,_currName );	
					} else if( ext === 'js' ) {//加载js
						self.loadScript( name,success,error,complete,_currName );		
					} else {
						var method = 'load'+replaceReg( /\b(\w)|\s(\w)/g,ext );
						if( (method in self) && $.isFunction( self[method] ) ) {
							self[method].call( self,name,success,error,complete,_currName );
						} else {
							self.loadExtension( name,success,error,complete,_currName );		
						}
					}
				} else {
					if( $.isFunction( loadType ) ) {
						loadType.call(self,name,success,error,complete,_currName);
					} else {
						if( loadType in self ) {
							self[loadType].call( self,name,success,error,complete,_currName );
						} else {
							self.loadScript( name,success,error,complete,_currName );	
						}
					}
				}
			}
			
			if( !opt.loadOrder ) {
				self._load();	
			}
			return self;
		},
		//取消加载
		abort : function(){
			var self = this,
				undef,
				errDeps = [],
				successDeps = [],
				opt = this.configs,
				cache = opt._loadCache,
				pendings = [], //正在加载的脚本
				_pendings = {}
				;
			for( var k in cache ) {
				if( cache[k]===false ) {
					success = false;
					errDeps.push( k );
				} else if( cache[k]===true ) {
					successDeps.push( k );
				} else if( cache[k]==='pending' ) {
					pendings.push( k ); 
					_pendings[k] = true;	
				}
			}	
			if( pendings.length ) {
				opt._isAbort = true;
				var eid,eid2;
				eid = self.bind('onLoadScriptComplete._abort',function(module){
					_pendings[ module ] = false;
					var end = true;
					$.each( _pendings,function(k,v){
						if( v ) {
							end = false;
							return false;	
						}	
					} );
					if( end ) {
						opt._isAbort = false;	
						self.unbind('onLoadScriptComplete',eid);	
						self.unbind('onBeforeLoadScript',eid2);	
					}
				});	
				eid2 = self.bind('onBeforeLoadScript._abort',function(list,fn,errback){
					var currExports = Nex.isIE ? self.getInteractiveName() : null;
					$.each( list,function(i,m){
						cache[m] = false;	
					} );
					if( $.isFunction(fn) ) {
						var exports = list.concat([]);
						window[opt.exportsName+'CallBack'] = {
							moduleName : currExports,
							deps : exports,
							errBack : errback,
							callBack : function(){
								var argvs = [];
								$.each( this.deps,function(i,v){
									//argvs.push( Nex.Loader.exports[v] );				
									argvs.push( self.getExports( v ) );				  
								} );
								argvs.push( window[opt.exportsName] );
								fn.apply(self,argvs);	
								var ep = $.isPlainObject( window[opt.exportsName] ) && $.isEmptyObject( window[opt.exportsName] ) ? undef : window[opt.exportsName];
								//如果模块存在 执行回调 并且回调里面的exports保持到当前模块中
								if( this.moduleName ) {//&& !( this.moduleName in Nex.Loader.exports ) 
									Nex.Loader.exports[ this.moduleName ] = ep;	//window[opt.exportsName];	
								}
								//清空exports
								self.resetExports();
							}
						};
						Nex.array_insert( 0,[ window[opt.exportsName+'CallBack'] ],self.__loaderCallBack,1 );
					}
					return false;	
				});
			}
			$.each( opt._list,function(i,m){
				if( cache[m] === null ) cache[m] = false;	
			} );
			self.fireEvent('onAbort',[opt]);	
			return self;
		},
		/*
		*加载脚本
		*@param {Array} 组件列表 eg ['Nex.Ajax','Nex.Html']
		*@param {func} 回调
		*/
		"load" : function( list,fn,errback,module ){//deps,callback,errback
			var self = this,
				undef,
				opt = this.configs;
			
			if( $.isFunction(list) ) {
				var __list = self.getInlineDeps( list );
				fn = list;
				errback = fn;
				module = errback;
				list = __list;
			}	
		
			var r = self.fireEvent('onBeforeLoadScript',[list,fn,errback,opt]);
			if( r === false ) return self;
			
			if( $.type( errback ) === 'string' && module === undef ) {
				module = errback;
				errback = undef;
			}
				
			//由于IE的onload事件回调不准确，我们只能在执行脚本的时候 确定当前执行的脚本名称
			var currExports = Nex.isIE ? self.getInteractiveName() : null;
			
			if( list !== undef ) {	
				list = $.isArray( list ) ? list : [ list ];	
			} else {
				list = opt.items;	
			}
			
			var exports = list.concat([]);
			
			//如果有强制依赖 就检测是否有多级依赖
			var checkCircle = {};//检测环形回路 暂时没有处理
			var shimDeps = [];
			function checkToShimLoad( deps ){
				var _shimLoadCache={},
					eid,
					//是否有强制依赖
					nlist = [];
				$.each( deps,function(i,m){
					var shims = self._getShim( m );	
					if( shims.length ) {
						nlist.push.apply( nlist,shims );	
						$.each( shims,function(i,d){
							checkCircle[d] = true;
							_shimLoadCache[d] = false;	
						} )
					}
				} );
				//简单检测一下
				/*Nex.array_splice(function(i,d){
					if( checkCircle[d] ) {
						return true;	
					}	
				},nlist);*/
				
				if( nlist.length ) {
					list = nlist;
					shimDeps = nlist;
					var eventType = opt.strictDeps ? 'onLoadScriptSuccess' : 'onLoadScriptComplete';
					eid = self.bind( eventType+'._load',function( m ){
						_shimLoadCache[m] = true;
						var complete = true;
						$.each( _shimLoadCache,function(m,r){
							if( !r ) {
								complete = false;
								return false;	
							}		
						} );
						if( complete ) {
							self._addDeps( deps );
							self.load( deps );
							self.unbind( eventType,eid );	
						}
					} );
					checkToShimLoad( nlist );
				}	
			}
			//检测是否设置了shim 强依赖
			if( list.length ) {
				checkToShimLoad( list );	
				//清除为空的模块
				Nex.array_splice( function(i,v){
					if( $.trim( v ) === '' ) return true;	
				},list );
				Nex.array_splice( function(i,v){
					if( $.trim( v ) === '' ) return true;	
				},exports );
			}
			
			if( $.isFunction(fn) ) {
				window[opt.exportsName+'CallBack'] = {
					loader : self,
					moduleName : currExports,
					_module : module,//显示定义的模块名称
					deps : exports,
					errBack : errback,
					callBack : function(){
						var argvs = [];
						$.each( this.deps,function(i,v){
							//argvs.push( Nex.Loader.exports[v] );	
							argvs.push( self.getExports( v ) );					  
						} );
						argvs.push( window[opt.exportsName] );
						var r = fn.apply(this,argvs);	
						if( r !== undef ) {
							window[opt.exportsName] = r;	
						}
						//如果模块存在 执行回调 并且回调里面的exports保持到当前模块中
						var ep = $.isPlainObject( window[opt.exportsName] ) && $.isEmptyObject( window[opt.exportsName] ) ? undef : window[opt.exportsName];
						if( this.moduleName && ep ) {
							Nex.Loader.exports[ this.moduleName ] = ep;
						}
						
						if( this._module && ep ) {
							var mextra = this._module.split(/\s+/);
							$.each( mextra,function(i,v){
								Nex.Loader.exports[ v ] = ep;	
								Nex.Loader._loadCache[ v ] = true;	
							} );
						}
						//清空exports
						self.resetExports();
					}
				};
				Nex.array_insert( 0,[ window[opt.exportsName+'CallBack'] ],self.__loaderCallBack,1 );
			} else {
				window[opt.exportsName+'CallBack'] = {};	
			}
			
			if( opt._list.length ) {
				$.each( list,function(i,d){
					if( !(d in opt._loadCache) ) {
						opt._loadCache[d + ''] = null;
					}
				} );
				if( opt.loadOrder ) {
					Nex.array_insert( 0,list,opt._list,1 );
				} else {
					opt._list.push.apply( opt._list,list );	
					//如果考虑./是相对路径的话 就要考虑用延迟，当前Loader不考虑./ 所有路径都是相对当前页面路径
					//setTimeout(function(){
						self._load();//如果这里能确定是文件形式加载 可以考虑用延迟	
					//},0);
				}
			} else {
				opt.items = list;

				self.startLoad();
			}
			return self;	
		},
		/*
		*获取内置加载模块
		*param {func} 回调
		*/
		getInlineDeps : function(callback){
			var self = this,
				undef,	
				deps = [],
				opt = this.configs;
			if( $.isFunction( callback ) ) {
				callback
						.toString()
						.replace(opt.commentRegExp, '')
						.replace(opt.cjsRequireRegExp, function (match, dep) {
							deps.push(dep);
						});
			} 	
			return deps;
		},
		/*
		*加载模块
		*@param {Array} 需要加载的依赖 {String} 直接获取已经加载的模块 {func} 定义一个模块
		*@param {func} 依赖加载完回调
		*@param {func} 依赖加载失败回调
		*/
		require : function( deps,callback,errback ){
			var self = this,
				undef,	
				opt = this.configs;
			if( !arguments.length ) {
				return self;	
			}	
			var args = arguments;
			if( $.isArray( deps ) ) {
				if( deps.length ) {
					if( self.isLoading() ) {
						self.one('onComplete._rsys',function(){
							self.load.apply( self,args );	
							window[opt.exportsName+'CallBack'] = {};	
						});	
					} else {
						this.load.apply( this,arguments );	
						window[opt.exportsName+'CallBack'] = {};
					}
				} else {
					if( $.isFunction( callback ) ) {
						self.require( callback );	
					}	
				}
			} else if( $.type( deps ) === 'string' ) {
				if( $.isFunction( callback ) ) {
					return self.require( [ deps ],callback,errback );
				}
				
				var __export =  self.getExports( deps );
				
				return __export;	
			} else if( $.isFunction( deps ) ) {
				var _deps = self.getInlineDeps( deps );
				if( _deps.length ) {
					self.require( _deps,deps );	
				} else {
					deps();	
				}
			}
			return self;
		},
		/*
		*定义一个模块
		*@param {Array} deps 依赖模块
		*@param {Function} callback 依赖加载后调用回调
		*@param {Function} errback 依赖加载失败后调用回调 不建议用
		*/
		define : function(deps,callback,errback){
			var self = this,
				undef,
				argvs = arguments,	
				opt = this.configs;
			if( !argvs.length ) {
				return self;	
			}	
			if( argvs.length === 1 && !$.isFunction( argvs[0] ) ) {
				self.exports( argvs[0] );
			} else if( $.isArray( deps ) /*&& deps.length*/ ) {
				if( deps.length ) {
					this.load.apply( this,arguments );
				} else {
					if( $.isFunction( callback ) ) {
						var d = callback();
						if( d !== undef ) {
							self.exports( d );	
						}		
					}	
				}
			} else if( $.type( deps ) === 'string' ) {
				//定义模块
				if( argvs.length>2 && $.isArray( callback ) ) {
					var exports = argvs[1].concat([]),
						currExports = argvs[0],
						errBack = argvs[3],
						fn = argvs[2];
					self.load( exports,fn,undef,currExports );
				} else if( callback!==undef ) {
					Nex.Loader.setLoadCache(deps,callback);	
				}
			} else if( $.isFunction( deps ) ) {
				var _deps = self.getInlineDeps( deps );
				if( _deps.length ) {
					self.define( _deps,deps );	
				} else {
					var d = deps();
					if( d !== undef ) {
						self.exports( d );	
					}	
				}
			} else {
				self.exports( deps );		
			}
			return self;
		},
		//IE下获取currScriptAliasName
		currentlyAddingScript : null,
		interactiveScript : null,
		getInteractiveName : function(){
			var self = this,	
				opt = this.configs;
			if (self.currentlyAddingScript) {
				return self.currentlyAddingScript.scriptName;
			}
			else if (
				self.interactiveScript
				&& self.interactiveScript.readyState === 'interactive'
			) {
				return self.interactiveScript.scriptName;
			}
			//var name = Nex.getcwd(true);	
			var nodes = opt.head.getElementsByTagName("script");
			for (var i = nodes.length, node; node = nodes[--i]; ) {
			  if ( node.readyState === "interactive") {
				  self.interactiveScript = node;
				  return node.scriptName;
			  }
			}
			return null;
		},
		include : function(){
			return this.require.apply( this,arguments );
		},
		//主要是针对IE 导出模块
		exports : function(o){
			var self = this,
				undef,
				opt = this.configs;
			if( Nex.isIE ) {
				var currExports = self.getInteractiveName();
				if( !currExports ) {
					window[opt.exportsName] = o;		
				} else {
					Nex.Loader.exports[ currExports ] = o;	
					window[opt.exportsName] = o;	
					self.resetExports();
				}
			} else {
				window[opt.exportsName] = o;
			}
		},
		/*
		*对特殊导出的接口非IE
		*/
		_exports : function(currExports,o){
			var self = this,
				undef,
				opt = this.configs;	
			Nex.Loader.exports[ currExports ] = o;	
		},
		/*返回Deferred对象 Nex.when会用到*/
		getDeferred : function(){
			return this.configs.deferred;	
		},
		initComponent : function(){
			var self = this,
				undef,
				opt = this.configs;
			
			$.extend(opt.paths,opt._sysPaths);
			opt.items = $.isArray( opt.items ) ? opt.items : [ opt.items ];
				
			self.fireEvent('onCreate',[opt]);
		},
		done : function(){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.one('onSuccess._deferred',argvs[i]);
				}		
			}
			return this;	
		},
		success : function(){
			this.done.apply(this,arguments);	
			return this;	
		},
		fail : function(){	
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.one('onError._deferred',argvs[i]);
				}		
			}
			return this;	
		},
		error : function(){
			this.fail.apply(this,arguments);	
			return this;	
		},
		then : function(s,f,p){	
			if( $.isFunction( s ) ) {
				this.one('onSuccess._deferred',argvs[i]);
			}	
			if( $.isFunction( argvs[i] ) ) {
				this.one('onError._deferred',f);
			}		
			return this;	
		},
		always : function(){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.one('onComplete._deferred',argvs[i]);
				}		
			}
			return this;
		},
		progress : function(){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.bind('onProgress._deferred',argvs[i]);
				}		
			}
			this.always('onComplete._deferred',function(){
				this.unbind('onProgress._deferred');
			});
			return this;	
		},
		complete : function(){
			return this.always.apply(this,arguments);	
		}
	});
	//创建Loader
	var _loader = Nex.getLoader();
	//不要占用其他加载器的require
	if( !define ) {
		if( !require ) {
			require = function(){
				_loader.require.apply( _loader,arguments );	
			};
			require.config = function(){
				var conf = arguments[0];
				if( $.isPlainObject(conf) ) {
					conf.urlArgs = $.isPlainObject( conf.urlArgs ) ? conf.urlArgs : { '*':conf.urlArgs };
				}
				return _loader.C.apply( _loader,arguments );	
			}
		}
		
		define = function(){
			_loader.define.apply( _loader,arguments );	
		};
		
		if( !exports ) {
			exports = function(){
				_loader.exports.apply( _loader,arguments );	
			};
		}
	}
})(jQuery);
/*
Nex.ajax
*/
;$define([],function(){
	"use strict";
	//var ajax = Nex.widget('ajax');
	var ajax = Nex.define('Nex.Ajax').setXType('ajax');
	ajax.extend({
		version : '1.0',
		getDefaults : function(opt){
			var _opt = {
				prefix : 'nexajax-',
				autoDestroy : false,
				ajax : null,
				data : {},
				_qdata : {},
				events : {
					onStart : $.noop,
					onAjaxReady : $.noop,
					onCreate : $.noop,
					onBeforeSend : $.noop,
					onSuccess : $.noop,
					onError : $.noop,
					onComplete : $.noop,
					onAjaxStart : $.noop,
					onAjaxStop : $.noop
				}
			};
			var _opt = this.extSet(_opt);
			return $.extend({},_opt,opt);
		},
		_Tpl : {},
		/*直接使用jquery 的Deferred对象 所以要使用when需要确定jquery版本支持Deferred*/
		when : function(){
			return Nex.when.apply(Nex,arguments);	
		}
	});
	ajax.fn.extend({
		_init : function(opt) {
			var self = this,undef;
			
			opt._beforeSend = opt.beforeSend || null;
			opt._error = opt.error || null;
			opt._success = opt.success || null;
			opt._abort = opt.abort || null;
			opt._complete = opt.complete || null;
			
			if( $.isPlainObject(opt.data) ) {
				$.extend( opt.data,opt._qdata );
			} else if( typeof opt.data === 'string' && typeof opt._qdata === 'string' ) {
				opt.data = opt.data.length ? '&'+opt._qdata : opt._qdata;
			}
			
			opt.abort = function(){
				var argvs = [];
				//var argvs = [].slice.apply(arguments);
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push( arguments[i] );	
				}
				argvs.push( this );
				var r = self.fireEvent('onAbort',argvs);	
				if( r === false ) return r;	
				if( $.isFunction( opt._abort ) ) {
					return opt._abort.apply( self,argvs );
				}
			}
			opt.success = function(){
				var argvs = [];
				//var argvs = [].slice.apply(arguments);
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push( arguments[i] );	
				}
				argvs.push( this );
				if( self._customAbort === true ) {
					opt.abort.apply( this,argvs );
					return;
				}
				var r = self.fireEvent('onSuccess',argvs);	
				if( r === false ) return r;	
				if( $.isFunction( opt._success ) ) {
					return opt._success.apply( self,argvs );
				}
			}
			opt.beforeSend = function(){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push( arguments[i] );	
				}
				argvs.push( this );
				var r = self.fireEvent('onBeforeSend',argvs);	
				if( r === false ) return r;
				var rf;
				if( $.isFunction( opt._beforeSend ) ) {
					rf = opt._beforeSend.apply( self,argvs );
				}
				if( rf === false ) return false;
				self.fireEvent('onAjaxStart',argvs);	
			}
			opt.error = function(){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push( arguments[i] );	
				}
				argvs.push( this );
				if( self._customAbort === true ) {
					opt.abort.apply( this,argvs );
					return;
				}
				var r = self.fireEvent('onError',argvs);	
				if( r === false ) return r;
				if( $.isFunction( opt._error ) ) {
					return opt._error.apply( self,argvs );
				}
			}
			opt.complete = function(){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push( arguments[i] );	
				}
				argvs.push( this );
				self.fireEvent('onAjaxStop',argvs);
				var r = self.fireEvent('onComplete',argvs);	
				if( r === false ) return r;	
				if( $.isFunction( opt._complete ) ) {
					return opt._complete.apply( self,argvs );
				}
			}
			
			self.fireEvent('onAjaxReady',[ opt ]);	
			//检测url是否是用户自定义函数
			if( $.isFunction( opt.url ) ) {
				opt.ajax = $.Deferred ? $.Deferred() : opt.url;	
				var success = function(data){
					if( $.isFunction( opt.dataFilter ) ) {
						data = opt.dataFilter.call( self,data,opt.dataType || 'json' );	
					}
					opt.success.apply( self,[ data ] );
					opt.complete.call( self,self,self._customAbort === true?'abort':'success' );
					if( $.Deferred ) {
						opt.ajax.resolve([ data ]);	
					}
				}; 
				var error = function( data ){
					var argvs = [];
					for( var i=0;i<arguments.length;i++ ) {
						argvs.push( arguments[i] );	
					}
					opt.error.apply( self,[ data ] );
					opt.complete.call( self,self,self._customAbort === true?'abort':'error' );
					if( $.Deferred ) {
						opt.ajax.reject([ data ]);
					}
				};
				var rf = opt.beforeSend.call( self,opt );
				if( rf !== false ) {
					setTimeout( function(){
						var undef,d = opt.url.apply( self,[opt.data,success,error,opt] );	 
						if( d !== undef ) {
							if( d===false ) {
								error(null);	
							} else {
								success(d);		
							}
						}
					},0 );
				}
			} else {
				var rf = opt.beforeSend.call( self,opt );
				opt.beforeSend = null;
				delete opt.beforeSend; 
				if( rf !== false ) {
					opt.ajax = $.ajax( opt );	
				}
			}
			
			self.fireEvent('onCreate',[ opt.ajax,opt ]);	
		},
		getAjax : function(){
			return this.C('ajax');	
		},
		getDeferred : function(){
			return this.getAjax();	
		},
		//设置是否用户自己调用abort来取消请求
		_customAbort : false,
		//如果传递了参数则说明是绑定取消事件
		abort : function(){
			var self = this;
			var argvs = arguments;
			if( argvs.length ) {
				for( var i=0,len = argvs.length;i<len;i++ ) {
					if( $.isFunction( argvs[i] ) ) {
						this.bind('onAbort.deferred',argvs[i]/*,this*/);
					}		
				}
			} else {
				var ajax = self.getAjax();
				if( ajax && ajax.abort ) {
					self._customAbort = true;
					ajax.abort();	
				}
			}
			return self;
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.bind("onComplete",self._removeAjax,self);
			return self;
		},
		_removeAjax : function(){
			this.configs.autoDestroy = true;
			this.configs.context = null;
			this.removeCmp(true);	
		},
		done : function(func){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.bind('onSuccess.deferred',argvs[i]/*,this*/);
				}		
			}
			return this;	
		},
		success : function(){
			this.done.apply(this,arguments);	
			return this;	
		},
		fail : function(){	
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.bind('onError.deferred',argvs[i]/*,this*/);
				}		
			}
			return this;	
		},
		error : function(){
			this.fail.apply(this,arguments);	
			return this;	
		},
		then : function(s,f,p){	
			if( $.isFunction( s ) ) {
				this.bind('onSuccess.deferred',s/*,this*/);
			}	
			if( $.isFunction( f ) ) {
				this.bind('onError.deferred',f/*,this*/);
			}		
			return this;	
		},
		always : function(){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.bind('onComplete.deferred',argvs[i]/*,this*/);
				}		
			}
			return this;
		},
		complete : function(){
			return this.always.apply(this,arguments);	
		}
	});
});
/*
Nex.location
eg
index.html#/Home/Login
*/

;(function($){
	"use strict";
	var route = Nex.define('Nex.route.Route').setXType('route').setAliasName('Nex.Route');
	route.extend({
		version : '1.0',
		getDefaults : function(opt){
			var _opt = {
				prefix : 'nexroute-',
				ajax : null,
				data : {},
				_qdata : {},
				autoDestroy : false,
				removeHTag : true,//删除 #
				removeHTagData : '#', 
				location : window.location,
				doc : document,
				timeout_id : null,
				hash : '',
				_iframe : null,
				_delay : 50,
				_currentHash : '',
				caseInsensitiveMatch : false,
				supportHashChange : (function(win){
					var  documentMode = document.documentMode;
					return ('onhashchange' in window) && ( documentMode === void 0 || documentMode > 7 );	
				})(window),
				events : {
					onStart : $.noop,
					onCreate : $.noop,
					onGetHash : $.noop,
					onInitHashChange : $.noop,
					onVisitPage : $.noop,
					onHashChange : $.noop
				}
			};
			var _opt = this.extSet(_opt);
			return $.extend({},_opt,opt);
		},
		_Tpl : {}
	});
	route.fn.extend({
		_init : function(opt) {
			var self = this;
			self.initRoute();
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.bind('onGetHash._sys',function(opt){
				if( opt.removeHTag ) {
					opt.hash = opt.hash.replace( opt.removeHTagData ,'');	
				}
			});	
			self.bind('onInitHashChange._sys', self.checkRoute );
			self.bind('onHashChange._sys', self.checkRoute );	
			return self;
		},
		_getHash : function( url ) {
			var self = this;
			var opt = self.C();
            url = url || opt.location.href;
			return '#' + decodeURIComponent(url).replace( /^[^#]*#?(.*)$/, '$1' );
        },
		getHash : function( url ){
			var self = this;	
			var opt = self.C();
			opt.hash = self._getHash( url );
			self.fireEvent('onGetHash',[ opt ]);	
			return opt.hash;
		},
		/*
		*@description url分解
		*@param {string} url 需要分解的url地址
		*@return {object} 返回分解后的url
	    *
	    *   | member name   | Description    |
	    *   |---------------|----------------|
	    *   | href          | A normalized version of the provided URL if it was not an absolute URL |
	    *   | protocol      | The protocol including the trailing colon                              |
	    *   | host          | The host and port (if the port is non-default) of the normalizedUrl    |
	    *   | search        | The search params, minus the question mark                             |
	    *   | hash          | The hash string, minus the hash symbol
	    *   | hostname      | The hostname
	    *   | port          | The port, without ":"
	    *   | pathname      | The pathname, beginning with "/"
		*/
		urlResolve : function( url ){
			var self = this,
				opt = this.configs,
				href = url+'',
				reg = /^http/,
				urlNode = document.createElement("a");
			if( !href ) {
				href = opt.location.href;	
			}	
			if ( Nex.isIE ) {
				// Normalize before parse.  Refer Implementation Notes on why this is
				// done in two steps on IE.
				if( Nex.IEVer<8 && !reg.test( href ) ) {
					if( href.charAt(0) !== '/' ) {
						href = opt.location.protocol.replace(/:$/, '')+'://'+location.hostname+'/'+href;
					} else {
						href = opt.location.protocol.replace(/:$/, '')+'://'+location.hostname+href;	
					}
				}
				urlNode.setAttribute("href", href);
				href = urlNode.href;
			}	
			urlNode.setAttribute('href', href);
			return {
				href: urlNode.href,
				protocol: urlNode.protocol ? urlNode.protocol.replace(/:$/, '') : '',
				host: urlNode.host,
				search: urlNode.search ? urlNode.search.replace(/^\?/, '') : '',
				hash: urlNode.hash ? urlNode.hash.replace(/^#/, '') : '',
				hostname: urlNode.hostname,
				port: urlNode.port,
				pathname: urlNode.pathname && urlNode.pathname.charAt(0) === '/' ? urlNode.pathname : '/' + urlNode.pathname
			};
		},
		_initHashChange : function(){
			var self = this;
			var opt = self.C();	
			var iframe, timeoutID;
			
			opt.last_hash = self._getHash();
			
			iframe = $('<iframe tabindex="-1" title="empty"/>').hide()
			
				.one( 'load', function(){
					 self.history_set( self._getHash() );
					//计时器监控hanschange
					self._poll();
				})
				// Load Iframe src if specified, otherwise nothing.
				.attr( 'src', 'javascript:0' )
				// Append Iframe after the end of the body to prevent unnecessary
				// initial page scrolling (yes, this works).
				.insertAfter( 'body' );
			
			opt._iframe = iframe;
			opt._iframe_win = iframe[0].contentWindow;
			
		},
		history_get : function() {
			var self = this;
			var opt = self.C();	
			return self._getHash( opt._iframe_win.location.href );
		},
		history_set : function( hash, history_hash ) {
			var self = this;
			var opt = self.C();	
			var iframe = opt._iframe_win;
			var iframe_doc = iframe.document;
			var doc = opt.doc;
			if ( hash !== history_hash ) {
			  // Update Iframe with any initial `document.title` that might be set.
			  iframe_doc.title = doc.title;
			  
			  // Opening the Iframe's document after it has been closed is what
			  // actually adds a history entry.
			  iframe_doc.open();
			  
			  // Set document.domain for the Iframe document as well, if necessary.
			  //domain && iframe_doc.write( '<script>document.domain="' + domain + '"</script>' );//''
			  
			  iframe_doc.close();
			  
			  // Update the Iframe's hash, for great justice.
			  iframe.location.hash = hash;
			}
		  },
		_poll : function() {
			var self = this;
			var opt = self.C();	
			  var hash = self._getHash(),
			  	last_hash = opt.last_hash,
				history_hash = self.history_get( last_hash );
			  
			  if ( hash !== last_hash ) {
				self.history_set( opt.last_hash = hash, history_hash );
				self.fireEvent('onHashChange',[self.getHash(),opt]);
			  } else if ( history_hash !== last_hash ) {
				location.href = location.href.replace( /#.*/, '' ) + history_hash;
			  }
			  
			  opt.timeout_id = setTimeout( function(){
					self._poll();									
				}, opt._delay );
		},
		initRoute : function(){
			var self = this;
			var opt = self.C();	
			if( opt.supportHashChange ) {
				$(window).bind('hashchange.'+opt.id,function(){
					self.fireEvent('onHashChange',[ self.getHash(),opt ]);	
				});	
				setTimeout( function(){
					self.fireEvent('onInitHashChange',[ self.getHash(),opt ]);	
				},10 );
				self.fireEvent('onCreate',[ opt ]);
			} else {
				$(document).ready(function(){
					self._initHashChange();		
					setTimeout( function(){
						self.fireEvent('onInitHashChange',[ self.getHash(),opt ]);	
					},10 );
					self.fireEvent('onCreate',[ opt ]);						   
				});
			}
		},
		'reload' : function(){
			var self = this,
				opt = this.configs;
				self.checkRoute( self.currentUrl );
			return self;		
		}, 
		//@m true 默认产生历史记录 false 不产生历史记录
		redirectTo : function( path, m ){
			var m = this._undef( m,true );
			if( m ) {
				this.configs.location.hash = path;
			} else {
				this.checkRoute( path );
			}
			return this;	
		},
		path : function( path, m ){
			this.redirectTo.apply( this,arguments );
			return this;		
		},
		checkRoute : function( hash,opt ){
			var self = this,
				opt = opt || this.configs,
				path = '/';	
			if( hash.charAt(0) !== '/' ) {
				hash = '/'+hash;	
			}
			
			self.currentUrl = hash;
			self.history.push( hash );
			
			var _hash = {
				hash : hash
			};
			
			var e = self.fireEvent('onVisitPage',[ _hash ]);
			if( e === false ) {
				return;	
			}
			
			self.currentUrl = _hash.hash === hash ? self.currentUrl : _hash.hash;
			
			if( hash ) {
				var ourl = self.urlResolve(hash);
				path = ourl.pathname ? ourl.pathname : path;
			}
			
			self.currentUrlInfo = ourl;
			
			var params = {};
			if( ourl.search ) {
				var p = ourl.search.split('&');
				$.each( p,function(i,v){
					if( !v ) return;
					var param = v.split('=');
					params[ param[0] ] = param[1] ? param[1] : '';
				} );	
			}
			
			var r = self.parseRoute( path ) || {};
			
			self.currentUrlData = r;
			
			self.currentParams = $.extend(r.pathParams,params);
			
			if( r && $.isFunction(r.callback) ) {
				r.callback.call( self,self.currentParams );
			}
		},
		routes : {},
		//历史记录
		history : [],
		currentUrl : '/',
		currentUrlInfo : {},
		currentUrlData : {},
		currentParams : {},
		pathRegExp : function(path, opts) {
		  var insensitive = opts.caseInsensitiveMatch,
			  ret = {
					originalPath: path,
					regexp: path
				  },
				  keys = ret.keys = [];
			
			  path = path
				.replace(/([().])/g, '\\$1')
				.replace(/(\/)?:(\w+)([\?|\*])?/g, function(_, slash, key, option){
				  var optional = option === '?' ? option : null;
				  var star = option === '*' ? option : null;
				  keys.push({ name: key, optional: !!optional });
				  slash = slash || '';
				  return ''
					+ (optional ? '' : slash)
					+ '(?:'
					+ (optional ? slash : '')
					+ (star && '(.+?)' || '([^/]+)')
					+ (optional || '')
					+ ')'
					+ (optional || '');
				})
				.replace(/([\/$\*])/g, '\\$1');
			
			  ret.regexp = new RegExp('^' + path + '$', insensitive ? 'i' : '');
			  return ret;
		},
		/*
		*实际路径根据route匹配出参数
		*/
		switchRouteMatcher : function(on, route) {
			  var keys = route.keys,
				  params = {};
		
			  if (!route.regexp) return null;
		
			  var m = route.regexp.exec(on);
			  if (!m) return null;
		
			  for (var i = 1, len = m.length; i < len; ++i) {
				var key = keys[i - 1];
		
				var val = 'string' == typeof m[i]
					  ? decodeURIComponent(m[i])
					  : m[i];
		
				if (key && val) {
				  params[key.name] = val;
				}
			  }
			  return params;
		},
		/*
		*匹配正确的url
		*/
		parseRoute : function(url) {
			var self = this,
				opt = this.configs,
				routes = this.routes;	
			  // Match a route
			  var params, match;
			  $.each(routes, function(path, route) {
					if (!match && (params = self.switchRouteMatcher(url, route))) {
					  match = $.extend({
						  		pathParams : params,
								params : params
						 	},route);
					}
			  });
			  // No route matched; fallback to "otherwise" route
			  return match || routes[null] && $.extend(routes[null], {params: {}, pathParams:{}});
		},
		when : function( path,func ){
			var self = this,
				opt = this.configs;	
			//批量添加
			if( arguments.length === 1 ) {
				if( $.isPlainObject( path ) ) {
					$.each( path,function(k,v){
						self.when( k,v );	
					} );	
				}
				if( $.isFunction( path ) ) {
					var r = path.call( self );
					if( r ) {
						self.when( r );	
					}	
				}
				return self;
			}
			//如果是字符串 表示当前地址会重定向到后面地址的解析这样的重定向不触发历史记录
			if( $.type( func ) === 'string' ) {
				var redirectTo = func;
				func = function(){
					self.redirectTo( redirectTo, false );	
				};
			}
			self.routes[ path ] = $.extend( {
					callback : func
				},path && self.pathRegExp( path,{
				caseInsensitiveMatch : opt.caseInsensitiveMatch	
			} ) );
			if (path) {
				var redirectPath = path+'';
				if( redirectPath.charAt(0) !== '/' ) {
					redirectPath = '/'+redirectPath;	
				}
				self.routes[redirectPath] = $.extend( {
						callback : func
					},self.pathRegExp( redirectPath,{
					caseInsensitiveMatch : opt.caseInsensitiveMatch	
				} ) );
			}
			return self;
		},
		otherwise : function( func ){
			var self = this;
			return self.when( null,func );
		},
		destroy : function(  ){
			var self = this,
				opt = this.configs;	
			if( opt.supportHashChange ) {	
				$(window).unbind('.'+opt.id);
			} else {
				clearTimeout( opt.timeout_id );	
			}
			self.removeCmp();
			return this;
		}
	});
})(jQuery);
/*
Nex.html组件说明：
组件名称       : Nex.Html 可通过 new Nex.Html() 或者 Nex.Create('Nex.Html') 来创建
组件别名xtype  : html  可通过Nex.Create('html')
加载名称       : Nex.Html 组件存放目录结构 {{nex目录}}/Html.js
*/
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	
	"use strict";
	var html = Nex.define('Nex.Html').setXType('container').setXType('html');
	//兼容以前版本
	Nex.html = html;
	html.extend({
		version : '1.0',
		getDefaults : function(opt){
			var _opt = {
				uiPrefix  : 'nex-html',
				prefix : 'nexhtml-',
				tag : 'div',
				autoRender : true,//开启后直接创建对象就会渲染
				renderAfter : true,
				autoDestroy : true,//自动回收 ，如果el 不存在时会触发
				autoScroll : false,
				autoResize : true,//如果你的组件大小都是一个固定值应该设置为false 如果可以是百分比或者auto 则应该设置true 
				selectionable : true,
				_checkScrollBar : false,//检查是否出现滚动条 如果出现会触发onViewSizeChange
				_hasBodyView : false,//是否有view部分 html 没有这部分 应该关闭 提高效率 关闭后不会触发onViewSizeChange
				_initSetSize : false,//容器刚创建时会设置容器宽度
				tabIndex : -1,
				hideMode : 'offsets',//display visibility offsets(IE6下会使用display+offsets)
				renderTo : document.body,
				ui : '',//default = nex-html-default
				uiCls : [],//icon = nex-html-default-icon
				cls : '',
				overCls : '',
				cssText : '',
				width : 'auto',// 设为auto后 大小将不会设置 宽度 高度都是auto 或者css控制的,设为0 相当于100% 
				height : 'auto',
				border : false,
				borderCls : 'nex-html-border',
				containerCls : 'nex-html',
				autoScrollCls : 'nex-html-auto-scroll',
				autoWidthCls : 'nex-html-auto-width',
				autoHeightCls : 'nex-html-auto-height',
				_initMethod : [],//初始时扩展调用
				padding : null,
				margin  : null,
				style : {},
				'class' : '',
				views : {},
				attrs : {},
				html : '',
				//一般做扩展用，有的组件items是不需要用到的
				disabledItems : false,
				items : [],
				loadMsg : 'Loading...',
				//自定义loading显示容器
				loadContainer : null,//跟一个函数 返回一个dom元素
				_lmt : 0,//无效
				denyEvents : false,//禁止绑定事件 或者指定那些事件不需要绑定 eg [ 'click',dblclick,scroll ]
				events : {
					onStart : $.noop,
					onCreate : $.noop,
					onInitComponent : $.noop,
					onSetContainerSize : $.noop,
					onSizeChange : $.noop,
					onSetContainerEvent : $.noop
				}
			};
			var _opt = this.extSet(_opt);
			return $.extend({},_opt,opt);
		},
		_Tpl : {}
	});
	html.fn.extend({
		_init : function(opt) {
			var self = this;
			var methods = opt._initMethod;
			self.setContainer();
			/*调用扩展api*/
			if( methods.length ) {
				var i=0,len = methods.length;
				for( ;i<len;i++ ) {
					var m = methods[i];
					if( !m ) continue;
					if( $.isFunction( m ) ) {
						m.call( self );	
					} else if( ($.type( m ) === 'string') && $.isFunction( self[m] ) ) {
						self[m].call( self );	
					}
				}	
			}
			self.initComponent();
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.bind("onStart",function(){
				if( opt.autoSize ) {
					opt.width = 'auto';
					opt.height = 'auto';
				}
			},self);
			self.bind("onCreate",function(){
				opt._isInit = false;	
			},self);
			self.bind("onMouseEnter",self._setOverCls,self);
			self.bind("onMouseLeave",self._unsetOverCls,self);
			return self;
		},
		_setHeightAuto : function(){
			var self = this;
			var opt = self.configs;	
			var views = opt.views;	
			var bd = self.getBody();
			var container = self.getContainer();
			container._removeStyle('height',true);
			if( bd ) {
				bd._removeStyle('height',true);	
			}
		},
		_setWidthAuto : function(){
			var self = this;
			var opt = self.configs;	
			var views = opt.views;	
			var bd = self.getBody();
			var container = self.getContainer();
			container._removeStyle('width',true);
			if( bd ) {
				bd._removeStyle('width',true);	
			}
		},
		/*如果width height 设置的是百分比那么将返回百分比值，只对resize和初始创建时有效*/
		getResizeWH : function(){
			var self = this;
			var opt = self.configs;	
			var views = opt.views;
			var container = self.getContainer();
			var renderTo = $(opt.renderTo);
			var width =  renderTo._width();
			var height =  renderTo._height();
			
			var isChange = true;
			if( opt.pWidth === width && opt.pHeight === height && opt._isResize ) {//resize 时才判断 setWH 都会执行
				isChange = false;	
			}
			if( !isChange ) {
				return {
					width:opt._width,
					height:opt._height,
					isChange : isChange
				};	
			}
			
			opt.pWidth = width;
			opt.pHeight = height;
			//opt.width opt.height 等于0是 默认就是 100%
			var w = parseFloat(opt.width) === 0 ? width : opt.width
				,h = parseFloat(opt.height) === 0 ? height : opt.height;

			if( opt.width.toString().indexOf("%") != -1 ) {
				w = parseFloat(opt.width)*width/100;
			}
			if( opt.height.toString().indexOf("%") != -1 ) {
				h = parseFloat(opt.height)*height/100;
			}
			//opt.views 是容器下的所有子容器，如果宽高设置为auto时 会把容器下的所有views设置为auto
			//如果opt.width 设置的是 auto时。
			var bd = self.getBody();
			if( w === 'auto' || isNaN(parseFloat(w)) ) {
				/*$.each( views , function(key,_item){
					_item._removeStyle('width',true);	
				} );*/
				if( !self.__containerCreate ) {
					self._setWidthAuto();
				}
				w = container._outerWidth();	
			}
			//如果opt.height 设置的是 auto时。
			if( h === 'auto' || isNaN(parseFloat(h)) ) {
				if( !self.__containerCreate ) {
					self._setHeightAuto();
				}
				/*$.each( views , function(key,_item){
					_item._removeStyle('height',true);	
				} );*/
				h = container._outerHeight();	
			}
			//因为浏览器会对像素进行 四舍五入 处理 所以应该用parseInt对像素取整 
			return {
				width:parseInt(w),
				height:parseInt(h),
				isChange : isChange
			};
		},
		checkSize : function(width,height){
			var self = this;
			var opt = self.configs;	
			//var renderTo = $(opt.renderTo);
			var cutHeight = self._getCutHeight(opt.cutHeight);
			var cutWidth = self._getCutWidth(opt.cutWidth);
			height -= isNaN(parseFloat(opt.cutHeight)) ? 0 : opt.cutHeight;
			width -= isNaN(parseFloat(opt.cutWidth)) ? 0 : opt.cutWidth;
			
			var minWidth = self._getMinWidth();
			var minHeight = self._getMinHeight();
			var maxHeight = self._getMaxHeight();
			var maxWidth = self._getMaxWidth();
			
			if( maxWidth>0 ) {
				width = Math.min(width,maxWidth);
			}
			if( maxHeight>0 ) {
				height = Math.min(height,maxHeight);
			}
			if( minWidth>0 ) {
				width = Math.max(width,minWidth);
			}
			if( minHeight>0 ) {
				height = Math.max(height,minHeight);
			}
			
			return {
					//width : isNaN(width)?'auto':width,
					//height : isNaN(height)?'auto':height
					width : parseInt(isNaN(width)?opt.pWidth:width),//实际上 width,height 一直不会是NaN
					height : parseInt(isNaN(height)?opt.pHeight:height)
				};
		},
		setContainerSize : function(w,h){
			var self = this,
				undef,
				opt = self.configs,	
				//render = $(opt.renderTo),
				container = self.getContainer()
				;
			
			opt.width = w === undef ? opt.width : w;	
			opt.height = h === undef ? opt.height : h;
			
			var size = self.getResizeWH();
			//注：如果width,height 为auto是 size 和 wh 的 width height 应该是一样的 除非设置了 max/min/cut width height 
			var wh = self.checkSize( size.width,size.height );
			
			self.fireEvent('onSetContainerSize',[wh,opt]);
			//判断宽高大小是否有变更
			if( !size.isChange ) {
				return false;	
			}
			//缓存
			if( opt._containerWidth && opt._containerHeight ) {
				if( opt._containerWidth === wh.width && opt._containerHeight === wh.height ) {
					return false;	
				}	
			}
			
			opt._width = wh.width;
			opt._height = wh.height;
			
			var _w = opt.width.toString().toLowerCase(),
				_h = opt.height.toString().toLowerCase();
				
			//判断是否设置了 max/min/cut width height 
			if( _w === 'auto' && size.width !== wh.width ) {
				_w = wh.width;	
			}	
			if( _h === 'auto' && size.height !== wh.height ) {
				_h = wh.height;	
			}
			
			opt.realWidth = _w;
			opt.realHeight = _h;	
			
			container.removeClass(opt.autoHeightCls+' '+opt.autoWidthCls);
			
			//最终判断 如果 _w _h 已然是auto 那么参数  max/min/cut width height  根本没有设置 width heigth 可以设为auto 否则就设为对应的数
			if( _w !== 'auto') {
				container._outerWidth(opt._width);	
			} else {
				container._removeStyle('width',true);
				container.addClass(opt.autoWidthCls);
			}
			if( _h !== 'auto') {
				container._outerHeight(opt._height);	
			} else {
				container._removeStyle('height',true);
				container.addClass(opt.autoHeightCls);
			}
			//缓存
			opt._containerWidth = wh.width;
			opt._containerHeight = wh.height;
			
			return true;
		},
		/*
		*判断当前是否自适应高度
		*/
		isAutoHeight : function(){
			var self = this,
				opt = this.configs;
			return 	opt.realHeight === 'auto' ? true : false;
		},
		/*
		*判断当前是否自适应宽度
		*/
		isAutoWidth : function(){
			var self = this,
				opt = this.configs;
			return 	opt.realWidth === 'auto' ? true : false;
		},
		/*
		*设置容器大小  @w 宽度 @h 高度 如果传的是func 则作为回调 并且只作为刷新用 @m如果为false 则触发onResize让子组件改变大小
		* resize(callback)->setContainerSize ->是/否->resetViewSize->onViewSizeChange->是/否->_setViewSize->callback
		*/
		resetHtmlSize : function(w,h,m){
			var self = this,
				undef,
				container = self.getContainer(),
				opt = self.configs,
				m = m === undef ? true : m;	
				
			var func = false;
			if( $.isFunction(w) ) {
				func = w;
				h = w = undef;
			}
			
			//如果不需要设置会返回false
			var r = self.setContainerSize(w,h);
			
			if( r ) {
				self.methodInvoke('resetViewSize',function(){
					self.fireEvent("onSizeChange",[container,opt]);	
					if( func ) {
						func.call( self );
					}
					if( Nex.Manager && !opt._isInit && m ) {
						if( opt.__onresize ) {
							clearTimeout( opt.__onresize );	
						}
						opt.__onresize = setTimeout(function(){
							Nex.Manager.fireEvent("onResize",[opt.id]);		
						},0);
					}	
				});	
			}
			if( !opt._isInit ) {
				self.fireEvent('onResize',[ opt ]);
			}
			return r;
		},
		refreshViewSize : function( func ){
			var self = this,
				undef,
				opt = self.configs;
			self.methodInvoke('resetViewSize',function(){
				if( func ) {
					func.call( self );
				}
				if( Nex.Manager && !opt._isInit ) {
					if( opt.__onresize ) {
						clearTimeout( opt.__onresize );	
					}
					opt.__onresize = setTimeout(function(){
						Nex.Manager.fireEvent("onResize",[opt.id]);		
					},0);
				}	
			});		
		},
		setHtmlSize : function(w,h){
			return this.resetHtmlSize(w,h);
		},
		//兼容以前的代码
		onSizeChange : function(w,h){
			return this.resetHtmlSize(w,h);	
		},
		/*
		* 更新html视图既Body部分宽高 由于Html和container和body是一样的 所有不做处理
		*  触发onViewSizeChange事件
		*/
		resetViewSize : function( func ){
			var self = this,
				opt = self.configs;	
			var r = self.onViewSizeChange();
			self.fireEvent("onResetViewSize",[opt]);
			if(r ) {
				//var vbody = self.getBody();
				self.fireEvent("onViewSizeChange",[opt]);
			}
			if( func && $.isFunction(func) ) {
				func.call( self );
			}
			return self;
		},
		//设置body大小 
		_setViewSize : function(){
			var self = this,
				opt = self.configs;
			self.fireEvent("onSetViewSize",[opt]);	
		},
		onViewSizeChange : function(func){
			var self = this,
				undef,
				opt = self.configs,
				vbody = self.getBody();
				
			self.methodInvoke('_setViewSize');		
			
			if( !opt._hasBodyView ) {
				return false;	
			}
				
			//事件检查滚动条 滚动条出现也会触发viewSize事件
			if( opt._checkScrollBar ) {
				//缓存机制
				//因为grid特殊 所以应该判断是否出现滚动条
				var hasScrollLeft = self.hasScroll( vbody,'left' );
				var hasScrollTop = self.hasScroll( vbody,'top' );
				var barSize = self.getScrollbarSize();
				
				var _vbodyWidth = vbody._width() - ( hasScrollTop ? barSize.y : 0 );
				var _vbodyHeight = vbody._height() - ( hasScrollLeft ? barSize.x : 0 );
			} else {
				var _vbodyWidth = vbody._width();
				var _vbodyHeight = vbody._height();
			}
			
			if( opt._vbodyWidth && opt._vbodyHeight ) {
				if( (opt._vbodyWidth == _vbodyWidth) && (opt._vbodyHeight == _vbodyHeight) ) {
					return false;
				}
			} 
				
			//设置缓存
			opt._vbodyWidth = _vbodyWidth;
			opt._vbodyHeight = _vbodyHeight;
			
			return true;
		},
		_loadCounter : 0,
		showLoading : function(msg){
			var self = this,
				opt = self.configs;
			var msg = self._undef( msg,opt.loadMsg );//typeof msg === 'undefined' ? opt.loadMsg : msg;
			var render = null;
			if( $.isFunction(opt.loadContainer) ) {
				render = opt.loadContainer.call( self );	
			}
			render = render || self.getBody();
			
			self._loadCounter++;
			
			var isExists = $("#"+opt.id+"-laoding-mask-wraper");
			if( isExists.length ) {
				var maskMsg = $("#"+opt.id+"-laoding-mask-msg");
				maskMsg.html( msg );
				self.resizeLoadMask();
				return self;
			}
			var maskWraper = $('<div id="'+opt.id+'-laoding-mask-wraper" class="nex-loading-mask-wraper"><div id="'+opt.id+'-mask" class="nex-loading-mask"></div><div id="'+opt.id+'-laoding-mask-msg" class="nex-loading-mask-msg">'+msg+'</div><div>');
			$(render).append(maskWraper);
			
			maskWraper.click(function(e){
				e.stopPropagation();
				e.preventDefault();											 
			});
			
			self.resizeLoadMask();
			
			return self;
		},
		resizeLoadMask : function(){
			var self = this,
				opt = self.configs;	
			if( self.isAutoWidth() && Nex.isIE6 ) {
				var maskWraper = $("#"+opt.id+"-laoding-mask-wraper");	
				maskWraper._outerHeight( maskWraper.outerHeight() );
			}
			var maskMsg = $("#"+opt.id+"-laoding-mask-msg");
			var w = maskMsg.outerWidth();
			maskMsg.css("marginLeft",-w/2+"px");
			return self;
		},
		hideLoading : function(render){
			var self = this,
				opt = self.configs;
			self._loadCounter--;
			self._loadCounter = self._loadCounter<0?0:self._loadCounter;
			if( self._loadCounter<=0 ) {
				$("#"+opt.id+"-laoding-mask-wraper").remove();	
			}
			return self;
		},
		getContainer : function(){
			var self = this,
				opt = self.configs;
			return opt.views['container'];	
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return opt.views['container'];
		},
		setWH : function(w,h,m){
			var self = this,
				opt = self.configs;
			self.resetHtmlSize(w,h,m);
			return true;
		},
		setWidth : function( w ){
			this.resetHtmlSize(w);	
			return this;
		},
		setHeight : function( h ){
			var undef;
			this.resetHtmlSize(undef,h);	
			return this;
		},
		getWidth : function(){
			//最好用 this.C('_width')
			return this.getDom().outerWidth() || 0;	
		},
		getHeight : function(){
			//最好用 this.C('_height')
			return this.getDom().outerHeight() || 0;	
		},
		width : function( w ){
			var undef;
			if( w === undef ) {
				return this.getWidth();	
			} else {
				var ft = String(w).charAt(0);
				if( ft === '+' || ft === '-' ) {
					w = w.slice(1);
					var _w = this.getWidth();
					w = ft == '+' ? _w + parseInt(w) : _w - parseInt(w);
				}
				this.setWidth(w);	
			}
		},
		height : function( w ){
			var undef;
			if( w === undef ) {
				return this.getHeight();	
			} else {
				var ft = String(w).charAt(0);
				if( ft === '+' || ft === '-' ) {
					w = w.slice(1);
					var _w = this.getHeight();
					w = ft == '+' ? _w + parseInt(w) : _w - parseInt(w);
				}
				this.setHeight(w);	
			}
		},
		setSize : function( o,s ){
			if( $.isPlainObject( o ) ) {
				this.setWH( o.width,o.height );	
			} else {
				this.setWH( o,s );		
			}
			return this;
		},
		getSize : function(){
			return {
				width : this.getWidth(),
				height : this.getHeight()
			};
		},
		autoSize : function(){
			this.setWH('auto','auto');	
			return this;
		},
		autoHeight : function(){
			var undef;
			this.setWH(undef,'auto');	
			return this;	
		},
		autoWidth : function(){
			var undef;
			this.setWH('auto',undef);	
			return this;	
		},
		//m : true 默认改变子组件的大小
		resize : function(m){
			var self = this,
				opt = self.configs,
				undef;
			
			self.__rt = self.__rt || 0;
			
			if( self.__rt ) {
				clearTimeout( self.__rt );	
			}
			
			self.__rt = setTimeout(function(){
				opt._isResize = true;
				self.setWH(undef,undef,m);
				opt._isResize = false;
			},0);
		},
		setContainerEvent : function(){
			var self = this;
			var opt = self.configs;
			var container = self.getContainer();
			
			//事件绑定
			if( opt.denyEvents === true ) {
				return false;
			} else if( $.isFunction(opt.denyEvents) ) {
				opt.denyEvents.call(self);	
				return false;
			}
			
			var callBack = function(type,e){
				var r = self.fireEvent(type,[ this,e,opt ]);
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				}
			};
			var events = {
				'focusin.html' : function(e) {
					callBack.call(this,'onFocusin',e);
				},
				'focusout.html' : function(e) {
					callBack.call(this,'onFocusout',e);
				},
				'focus.html' : function(e) {
					callBack.call(this,'onFocus',e);
				},
				'blur.html' : function(e) {
					callBack.call(this,'onBlur',e);
				},
				'click.html' : function(e) {
					callBack.call(this,'onClick',e);
				},
				'dblclick.html' : function(e) {
					callBack.call(this,'onDblClick',e);
				},
				'scroll.html' : function(e){
					callBack.call(this,'onScroll',e);
					var $this = $(this);
					if( $this.scrollTop()<=0 ) {
						self.fireEvent('onScrollTopStart',[ this,e,opt ]);		
					} else if( $this.scrollLeft()<=0 ) {
						self.fireEvent('onScrollLeftStart',[ this,e,opt ])
					}
					if( self.isScrollEnd( this,'top' ) ) {
						self.fireEvent('onScrollTopEnd',[ this,e,opt ]);	
					}
					if( self.isScrollEnd( this,'left' ) ) {
						self.fireEvent('onScrollLeftEnd',[ this,e,opt ]);	
					}
				},
				'keydown.html' : function(e) {
					callBack.call(this,'onKeyDown',e);
				},
				'keyup.html' : function(e) {
					callBack.call(this,'onKeyUp',e);
				},
				'keypress.html' : function(e){
					callBack.call(this,'onKeyPress',e);
				},
				'mousewheel.html' : function(e){
					callBack.call(this,'onMouseWheel',e);	
				},
				'mouseenter.html' : function(e){
					callBack.call(this,'onMouseEnter',e);
				},
				'mouseleave.html' : function(e){
					callBack.call(this,'onMouseLeave',e);
				},
				'mouseover.html' : function(e){
					callBack.call(this,'onMouseOver',e);
				},
				'mouseout.html' : function(e){
					callBack.call(this,'onMouseOut',e);
				},
				'mousedown.html' : function(e) {
					callBack.call(this,'onMouseDown',e);
				},
				'mouseup.html' : function(e) {
					callBack.call(this,'onMouseUp',e);
				},
				'contextmenu.html' : function(e){	
					callBack.call(this,'onContextMenu',e);
				}
			};
			
			if( $.isArray( opt.denyEvents ) ) {
				$.each( opt.denyEvents,function(i,e){
					delete events[e];
				} );	
			}
			container.unbind('.html');
			container.bind(events);
			self.fireEvent("onSetContainerEvent",[container,opt]);
			return true;
		},
		_disableSelection : function(){
			var self = this;
			var opt = self.configs;	
			var container = self.getContainer();	
			container.disableSelection();	
		},
		__containerCreate : false,
		//容器创建时就应该立刻设置宽度
		_initSetContainerSize : function(){
			var self = this;
			var opt = self.configs;	
			
			self.__containerCreate = true;
			
			self.setContainerSize();
			
			self.__containerCreate = false;
			//清除缓存
			opt._containerWidth = null;
			opt._containerHeight = null;
		},
		setContainer : function(){
			var self = this;
			var opt = self.configs;	
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			//如果有ID重复的组件 则覆盖
			var container;
			//var container = $('#'+opt.id);
			//if( !container.length ) {
				var cls = [
					opt.containerCls
				];
				if( opt.autoScroll ) {
					cls.push( opt.autoScrollCls );	
				}
				if( opt.border ) {
					cls.push( opt.borderCls );	
				}
				if( opt.ui ) {
					var ui = [opt.uiPrefix,opt.ui].join('-')
					cls.push(ui);	
					var uiCls = $.isArray(opt.uiCls) ? opt.uiCls : [ opt.uiCls ];
					$.each( uiCls,function(i,uc){
						if( !uc ) return;
						cls.push( [ui,uc].join('-') );	
					} );
				}
				if( opt['cls'] ) {
					cls.push( opt['cls'] );	
				}
				if( opt['class'] ) {
					cls.push( opt['class'] );	
				}
				var tag = opt.tag || 'div';
				container = $('<'+tag+' class="'+ cls.join(' ') +'" id="'+opt.id+'"></'+tag+'>');
			/*} else {
				container.html('');	//Nex.gc();
			}*/
			if( opt.renderAfter ) {
				render.append(container);
			} else {
				render.prepend(container);
			}
			opt.views['container'] = container;
			//方便使用
			self.el = container;
			
			self._setPadding();
			self._setMargin();
			
			container[0].style.cssText = opt.cssText;
			
			//container.css('padding',opt.padding);
			
			if( opt.tabIndex !== false ) {
				//设置tabIndex=-1 
				container.attr( {
					tabIndex : opt.tabIndex	   
				} );
			}
			container.attr( opt.attrs )
				     .css( opt.style );
			//container.data('_nexInstance_',self);
			if( opt._initSetSize ) {
				self._initSetContainerSize();
			}
			self.setContainerEvent();	 
			
			if( !opt.selectionable ) {
				self._disableSelection();	
			}
			
			self.fireEvent("onContainerCreate",[container,opt]);
			return self;
		},
		_autoSize : function(){
			var self = this;
			var opt = self.configs;	
			var minWidth = self._getMinWidth();
			var minHeight = self._getMinHeight();
			var maxHeight = self._getMaxHeight();
			var maxWidth = self._getMaxWidth();	
			//如果都没有设置 最大 最小 宽度和高度 那么就不用调用onSizeChange 容器不会去设置宽度和高度
			//发现一个BUG创建时如果min max都没设置 但是由于height是auto 导致出现了滚动条 所以需要再次确实的resize
			/*if( !minWidth && !minHeight && !maxHeight && !maxWidth ) {
				return false;	
			}*/
			
			if( opt.width === 'auto' || opt.height==='auto' ) {
				var r = self.resetHtmlSize();
				if( r ) {
					return true;	
				}
			}
			
			return false;
		},
		//判断当前是否正在初始化
		_isInit : function(){
			return 	this.configs._isInit;
		},
		initComponent : function(func){
			var self = this;
			var opt = self.configs;	
			self.fireEvent('onInitComponent',[opt]);
			//初始是不应该触发onSizeChange事件
			self.lockEvent('onSizeChange');
			self.resetHtmlSize();
			self._appendContent();
			self._autoSize();
			self.unLockEvent('onSizeChange');
			if( $.isFunction( func ) ) {
				func.call(self);	
			}
			self.fireEvent('onCreate',[opt]);
			opt._isInit = false;
		},
		_appendContent : function(){
			var self = this;
			var opt = self.configs;	
			var lbody = self.getBody();
			if( opt.disabledItems ) return lbody;
			var items = opt['html'];
			self.addComponent( lbody,items );
			var items = opt['items'];
			self.addComponent( lbody,items );
			return lbody;
		},
		_add : function( item , after ){
			return this._insert.apply(this,arguments );	
		},
		add : function( item , after ){
			return this.insert.apply(this,arguments );	
		},
		_insert : function( item , after ){
			var self = this;
			var opt = self.C();	
			var lbody = self.getBody();
			var list = self.addComponent( lbody,item,after );
			
			if( opt.__insertVt ) {
				clearTimeout(opt.__insertVt);	
			}
			opt.__insertVt = setTimeout( function(){
				var r = self._autoSize();
				if( !r && opt._checkScrollBar ) {
					self.methodInvoke('resetViewSize');		
				}						 
			},0 );
			
			return list;
		},
		insert : function(item , after ){
			var self = this;
			var opt = self.configs;	
			var list = self._insert.apply(self,arguments );	
			self.fireEvent('onAddComponent',[ list,opt ]);
			return list;
		},
		_empty : function(){
			var self = this;
			var opt = self.configs;	
			var lbody = self.getBody();	
			
			lbody.empty();
			
			self.removeCmp( false );
			
			if( opt.__insertVt ) {
				clearTimeout(opt.__insertVt);	
			}
			opt.__insertVt = setTimeout( function(){
				var r = self._autoSize();
				if( !r && opt._checkScrollBar ) {
					self.methodInvoke('resetViewSize');		
				}						 
			},0 );
			
			return self;
		},
		empty : function(){
			var self = this;
			var opt = self.configs;	
			var x = self._empty.apply(self,arguments );	
			self.fireEvent('onClearComponent',[ opt ]);
			return x;
		},
		_html : function( item , after ){
			this._empty();
			this._insert( item,after );
		},
		html : function( item , after ){
			this.empty();
			this.insert( item,after );
		},
		removeAll : function(){
			return this.empty.apply(this,arguments );		
		},
		//判断当前对象是否还存在
		isExists : function(){
			var self = this,
				opt = self.configs,
				dom = self.getDom();
			if( !self.isRendering() ) {
				return true;	
			}	
			if( dom.length ) {
				return true;	
			} else {
				if( opt.autoDestroy ) {
					self.removeCmp(opt.id);	
				}	
			}
			return false;
		},
		_setOverCls : function(){
			var self = this,
				opt = self.configs,
				container = this.el;
			if( opt.overCls ) {
				container.addClass( opt.overCls );	
			}
		},
		_unsetOverCls : function(){
			var self = this,
				opt = self.configs,
				container = this.el;
			if( opt.overCls ) {
				container.removeClass( opt.overCls );	
			}
		},
		_setPadding : function(){
			var self = this,
				opt = self.configs;
			var ct = self.el;
			if( opt.padding !== null ) {
				ct.css('padding',opt.padding);
			}
		},
		_setMargin : function(){
			var self = this,
				opt = self.configs;
			var ct = self.el;
			if( opt.margin !== null ) {
				ct.css('margin',opt.margin);
			}
		},
		focus : function(){
			var self = this,
				opt = this.configs,
				el;
			if( el = self.getBody() ) {
				if( opt.tabIndex === false || opt.tabIndex===null ) {
					el.attr({
						tabIndex : -1   
					});	
				}	
				el.focus();
			}	
			return self;
		},
		scrollLeft : function( sLeft ){
			var self = this,
				undef;
			self.scrollBy( sLeft,undef );	
			return self;
		},
		scrollToLeftEnd : function(){
			var self = this;
			var bd = $(self.getBody())[0];
			if( !bd ) {
				return self;	
			}
			var ch = bd.clientWidth;
			var sh = bd.scrollWidth;
			if( sh <= ch ){
				return self;	
			}
			
			var sTop = sh - ch;
			self.scrollLeft( sTop );
			return self;
		},
		scrollTop : function( sTop ){
			var self = this,
				undef;
			self.scrollBy( undef,sTop );	
			return self;	
		},
		scrollToTopEnd : function(){
			var self = this;
			var bd = $(self.getBody())[0];
			if( !bd ) {
				return self;	
			}
			var ch = bd.clientHeight;
			var sh = bd.scrollHeight;
			
			if( sh <= ch ){
				return self;	
			}
			
			var sTop = sh - ch;
			self.scrollTop( sTop );
			return self;
		},
		scrollBy : function(x,y,ani,func){
			var self = this,
				opt = this.configs,
				undef,
				func = func || $.noop,
				el = self.getBody();
			var pos = {};
			if( x !== undef ) {
				pos['scrollLeft'] = x;	
			}
			if( y !== undef ) {
				pos['scrollTop'] = y;	
			}
			
			if( !$.isEmptyObject( pos ) ) {
				if( ani === undef || ani <= 0 || !ani ) {
					/*el.animate( pos , 1 , function(){	
						func.call( self,el );
					});		*/
					for( var ac in pos ) {
						el[ac]( pos[ac] );
					}
					func.call( self,el );
				} else {
					el.animate( pos , Math.abs(ani) , function(){
						func.call( self,el );
					} );	
				}
			}
			return self;
		},
		setStyle : function( style ){
			this.el.css(style || {});
			return this;		
		},
		setBorder : function( str ){
			this.el.css('border',str);	
			return this;
		},
		setAutoScroll : function(){
			var self = this,
				opt = this.configs;
			self.removeCls(opt.autoScrollCls);	
			return self;
		},
		addCls : function( s ){
			this.el.addClass( s );
			return this;	
		},
		addClass : function( s ){
			this.addCls( s );	
			return this;
		},
		removeCls : function( s ){
			this.el.removeClass( s );
			return this;		
		},
		removeClass : function( s ){
			this.removeCls( s );
			return this;		
		},
		destroy : function(  ){
			//this.el.data('_nexInstance_',null);
			this.el.remove();
			this.removeCmp(  );
			return this;
		},
		isHidden : function(){
			return this.getEl().is(':hidden');	
		},
		isVisible : function(){
			return !this.isHidden();	
		},
		setPosition : function(){},
		getPosition : function(){},
		setOverflowXY : function(){},
		showAt : function(){
			//	
		},
		hide : function(){
			var self = this;
			var opt = this.configs;
			var container = self.getContainer();
			
			var r = self.fireEvent('onBeforeHide',[ container,opt ]);
			if( r === false ) return self;
			
			var hide_display = function(){
				container.hide();	
			}
			var hide_offsets = function(){
				container._hide();		
			}
			var hide_visibility = function(){
				container._visible(false);	
			}
			switch( opt.hideMode ) {
				case 'display' :
					hide_display();
					break;
				case 'offsets' : 
					if( Nex.isIE6 ) {
						hide_display();	
					}
					hide_offsets();
					break
				case 'visibility' :
					hide_visibility();
					break;
				default :
				hide_display();			
			}
			
			self.setAcceptResize( false );
			
			self.fireEvent('onHide',[ container,opt ]);
			
			return self;	
		},
		show : function(){
			var self = this;
			var opt = this.configs;
			var container = self.getContainer();
			
			var r = self.fireEvent('onBeforeShow',[ container,opt ]);
			if( r === false ) return self;
			
			var show_display = function(){
				container.show();	
			}
			var show_offsets = function(){
				container._show();		
			}
			var show_visibility = function(){
				container._visible(true);	
			}
			switch( opt.hideMode ) {
				case 'display' :
					show_display();
					break;
				case 'offsets' : 
					if( Nex.isIE6 ) {
						show_display();	
					}
					show_offsets();
					break
				case 'visibility' :
					show_visibility();
					break;
				default :
				show_display();			
			}
			
			self.setAcceptResize( true );
			
			if( opt.autoResize ) {
				self.resize();
			}
			
			self.fireEvent('onShow',[ container,opt ]);
			
			return self;		
		}
	});
}));
/*
Nex.Separator
*/
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([
			'Nex.Html'
		], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	"use strict";
	var separator = Nex.define('Nex.Separator','Nex.Html').setXType('separator');
	separator.setOptions( function(opt){
		return 	{
			autoResize : false,
			tabIndex : false,
			disabledItems : true,
			denyEvents : true,
			cls : opt.containerCls+' nex-separator',
			width : 'atuo',
			height : 'auto'
		};
	} );
}));
/*
*
*Nex.util.Date
*/
Nex.addUtil('Date',{
	/*
	*返回当前时间对象
	*/
	now : function( d ){
		var date = new Date();
		if( d ) {
			this.add( date,'d',d );	
		}
		return date;	
	},
	isArray : function( obj ){
		var nativeIsArray = Array.isArray;	
		var toString = Object.prototype.toString;
		return nativeIsArray ? nativeIsArray.call( Array,obj ) : (toString.call(obj) == '[object Array]');
	},
	isFunction : function(obj){
		var toString = Object.prototype.toString;
		return toString.call(obj) == '[object Function]';	
	},
	/*
	*日期填充0
	*/
	pad : function(v,len){
		var res = "" + v;
		var len = len || 2;
		for (; res.length < len; res = '0' + res) {
		}
		return res;	
	},
	/*
	*判断是否日期对象
	*/
	isDate : function( date ){
		return Object.prototype.toString.call(date)	== '[object Date]';
	},
	/*
	*判断当前年份是否闰年
	*@param {Int} year
	*/
	isLeapYear : function(year){
		year = this.isDate( year ) ? year.getFullYear() : parseInt(year,10);
		return (year%4 === 0 && year%100 !== 0) || year%400 === 0;	
	},
	/*
	*日期格式处理
	*@param {Date}		日期对象			默认：当前时间
	*@param {String}	格式化字符串		默认：YYYY-MM-DD
	*@param {Array}		格式化周时文字	默认：['日','一','二','三','四','五','六']
	*	YYYY/yyyy 		年份 	eg:2014
	*	YY/yy  			年份 	eg:14
	*	MM/M			月份		eg:08/8
	*	w 				星期数 0~6 or 日~六
	*	W/WW			ISO8601自然周
	*	DD/dd			日期 	eg:01
	*	D/d   			日期  	eg:1
	*   a/A             am pm   --未实现
	*	q/Q   			季度  	eg:1
	*   o/O/oo/OO		一年中的第几天
	*	HH/hh			小时(24小时制)		eg:09
	*	H/h				小时(24小时制)		eg:9
	*	mm/m			分钟		eg:04/4
	*	SS/ss			秒		eg:01
	*	S/s				秒		eg:1
	*/
	format : function( date,fmt,w ){
		var me = this;
		var date = date || this.now();
		var str = fmt || 'YYYY-MM-DD';  
		var Week = w || ['日','一','二','三','四','五','六']; 
	 
		str=str.replace(/yyyy|YYYY/,function(){
			return date.getFullYear();
		});  
		str=str.replace(/yy|YY/,function(){
			var y = date.getYear() % 100;
			return me.pad(y);
		});  
	 
		str=str.replace(/MM/,function(){
			var m = date.getMonth()+1;
			return me.pad(m);	
		});  
		str=str.replace(/M/g,function(){
			return date.getMonth()+1;	
		});  
	 
		str=str.replace(/w/g,function(){
			return Week[date.getDay()];
		}); 
		
		str=str.replace(/W/g,function(){
			return me.weekOfYear( date );		
		});  
		str=str.replace(/WW/g,function(){
			return me.pad(me.weekOfYear( date ));	
		}); 
	 
		str=str.replace(/dd|DD/,function(){
			return me.pad( date.getDate() );	
		});  
		str=str.replace(/d|D/g,function(){
			return date.getDate();	
		});  
		
		str=str.replace(/q|Q/g,function(){
			return me.getQuarter(date.getMonth()+1);	
		});  
		
		str=str.replace(/o|O/g,function(){
			return me.dayOfYear(date);	
		});  
		str=str.replace(/oo|OO/g,function(){
			me.pad(me.dayOfYear(date),3);	
		});  
	 
		str=str.replace(/hh|HH/,function(){
			return 	me.pad( date.getHours() );
		});  
		str=str.replace(/h|H/g,function(){
			return date.getHours();
		});  
		str=str.replace(/mm/,function(){
			return me.pad( date.getMinutes() );	
		});  
		str=str.replace(/m/g,function(){
			return date.getMinutes();
		});  
	 
		str=str.replace(/ss|SS/,function(){
			return me.pad( date.getSeconds() );	
		});  
		str=str.replace(/s|S/g,function(){
			return date.getSeconds();		
		});  
	 
		return str;  
	},
	/**
	* 字符串转换为日期对象
	* @param {String} 格式为yyyy-MM-dd HH:mm:ss，必须按年月日时分秒的顺序，中间分隔符不限制
	* @parma {String} fmt 可选 如果传入后会调用parseDate来解析 一般解析复杂日期的时候处理eg strToDate('20150809','YYYYMMDD') === parseDate('20150809','YYYYMMDD');
	* @return {Date}
	*/
	strToDate : function(dateStr,fmt){
		var undef;
		if( this.isDate( dateStr ) ) {
			return dateStr;	
		}
		if( dateStr === undef ) {
			return this.now();	
		}
		if( fmt ) {
			return this.parseDate( dateStr,fmt );	
		}
		var data = dateStr;  
		var reCat = /(\d{1,4})/gm;   
		var t = data.match(reCat);
		t[1] = t[1] - 1;//月份减一
		eval('var d = new Date('+t.join(',')+');');
		return d;
	},
	clone : function(date){
		var date = this.strToDate( date );
		return new Date( date.getTime() );	
	},
	/** 
     * 根据给定的格式对给定的字符串日期时间进行解析
	 * @param string eg : 12/09/2014 
	 * @param format 可以是数组或者自定义函数 eg : DD/MM/YYYY   [] func
     */
	parseDate: function(strDate, strFormat){   
		var undef,self = this;
		if( this.isDate( strDate ) ) {
			return strDate;	
		}
		var regs = /YYYY|yyyy|YY|yy|MM|M|w|WW|W|DD|dd|D|d|A|a|q|Q|OO|oo|O|o|HH|hh|H|h|mm|m|SS|ss|S|s/g;
		//默认格式
		var fmts = [
			'YYYY-MM-DD',
			'YYYY-M-D',
			'YYYY/MM/DD',
			'YYYY/M/D',
			'DD/MM/YYYY',
			'D/M/YYYY',
			'YYYYMMDD',
			'YYYY.MM.DD',
			'YYYY.M.D'
		];
		var strFormat = strFormat ? self.isArray( strFormat ) ? strFormat : [ strFormat ] : [];
		fmts = strFormat.concat(fmts);
		var _parseFmt = function( date,fmt ){
			var _matchs = {};
			fmt = fmt.replace(/\.|\\|\/|\+|\?|\$|\*|\^|\(|\)|\||\<|\>|\{|\}/g,function(e){
				return '\\'+e;	
			});	
			var i=0;
			var _regrep = fmt.replace( regs,function(r){
				var s = '';
				_matchs[i++] = r;
				switch( r ) {
					case 'yyyy':
					case 'YYYY':
						s = '(\\d{4})';
						break;
					case 'yy':	
					case 'YY':	
					case 'MM':
					case 'dd':
					case 'DD':
					case 'WW':	
					case 'HH':	
					case 'hh':
					case 'mm':
					case 'ss':
						s = '(\\d{2})';	
						break;
					case 'q':	
					case 'Q':	
						s = '(\\d{1})';	
						break;
					case 'oo':	
					case 'OO':	
						s = '(\\d{3})';	
						break;	
					case 'o':	
					case 'O':	
						s = '(\\d{1,3})';	
						break;	
					case 'a':	
					case 'A':	
						s = '((?:pm|PM|am|AM))';	
						break;			
					case 'w' : 
						s = '(\\S)';
						break;		
					default:
						s = "(\\d\\d?)";
						break;			
				}
				return s;	
			} );
			var es = new RegExp( _regrep,'g' ).exec(date);
			if( !es ) {
				return null;	
			}
			es.splice(0,1);
			var part = {};
			for( k in _matchs ) {
				part[ _matchs[k] ] = es[k];	
			}
			var currentDate = new Date();
			var d = self.dateObject( currentDate );
			d['M+'] = '1';
			d['d+'] = '1';
			d['h+'] = '00';
			d['m+'] = '00';
			d['s+'] = '00';
			
			if( ('yyyy' in part) || ('YYYY' in part) ) {
				d['y+'] = part['YYYY'] || part['yyyy'];	
			} else if( ('yy' in part) || ('YY' in part) ) {
				var _y = (d['y+']+'').substring(0,2);
				d['y+'] = part['YY'] || part['yy'];	
				d['y+'] = _y + d['y+'];
			}
			if( ('MM' in part) || ('M' in part) ) {
				d['M+'] = part['MM'] || part['M'];	
			}
			if( ('DD' in part) || ('dd' in part) ) {
				d['d+'] = part['DD'] || part['dd'];	
			}
			if( ('D' in part) || ('d' in part) ) {
				d['d+'] = part['D'] || part['d'];	
			}
			if( ('HH' in part) || ('hh' in part) || ('H' in part) || ('h' in part) ) {
				d['h+'] = part['HH'] || part['hh'] || part['H'] || part['h'];	
			}
			if( ('mm' in part) || ('m' in part) ) {
				d['m+'] = part['mm'] || part['m'];	
			}
			if( ('SS' in part) || ('ss' in part) || ('S' in part) || ('s' in part) ) {
				d['s+'] = part['SS'] || part['ss'] || part['S'] || part['s'];	
			}
			return new Date( d['y+'],parseInt(d['M+'],10)-1,d['d+'],d['h+'],d['m+'],d['s+'] );
		};
		var es = null;
		for( var n=0;n<fmts.length;n++ ) {
			if( self.isFunction( fmts[n] ) ) {
				es = fmts[n].call( this,strDate );	
			} else {
				if( fmts[n] ) {
					es = _parseFmt.call( this, strDate, fmts[n] );	
				}
			}
			if( es ) {
				break;	
			}
		}
		if( !es ) {
			return new Date();	
		}
		return es;
    },
	/**
	* 获取本月季度
	* @param Int m 月份
	*/
	getQuarter : function(m){
		var q = 0;
		if(m<4){ 
			q = 1; 
		} 
		if( m>3 && m<7){ 
			q = 2; 
		} 
		if( m>6 && m<10){ 
			q = 3; 
		} 
		if( m>9){ 
			q = 4; 
		} 
		return q; 
	},
	/**
	* 日期添加 日期格式必须是 yyyy-MM-dd hh:mm:ss类型 顺序不可更改
	* @param {Date}
	* @param {String} interval 添加间隔类型 年y 月m 日d 季度q 周w 小时h 分n 秒s 毫秒l
	* @param {Int}	number 添加时间间隔值,可以是正负值
	*/
	add : function(idate, interval, number) {
		number = parseInt(number,10);
		var date;
		date = this.strToDate( idate );
		switch (interval) {
			case "y": date.setFullYear(date.getFullYear() + number); break;
			case "m": 
				//bug处理 eg:3.30日 ，如果减去一个月 就是 2.30日 但2月只有28天 所以会溢出又会到3.2日
				var _date = date.getDate();
				date.setDate(1);
				date.setMonth(date.getMonth() + number); 
				var days = this.maxDay( date );
				date.setDate( Math.min( _date,days ) );
				break;
			case "d": date.setDate(date.getDate() + number); break;
			case "q": 
				date.setMonth(date.getMonth() + 3 * number); 
				break;
			case "w": date.setDate(date.getDate() + 7 * number); break;
			case "h": date.setHours(date.getHours() + number); break;
			case "n": date.setMinutes(date.getMinutes() + number); break;
			case "s": date.setSeconds(date.getSeconds() + number); break;
			case "l": date.setMilliseconds(date.getMilliseconds() + number); break;
		}
		return date;
	},
	addDate : function(){
		return this.add.apply( this,arguments );	
	},
	/*
	* 日期减少 使用方法同add
	*/
	reduce : function(a,b,c){
		return this.add(a,b,parseInt(c,10)*-1);	
	},
	reduceDate : function(a,b,c){
		return this.add(a,b,parseInt(c,10)*-1);	
	},
	/**
	* 日期对比
	* @param {String} interval 对比日期类型 年y 月m 日d 季度q 周w 小时h 分n 秒s 毫秒l
	*/
	diff : function(d1, d2, interval){
		d1 = this.strToDate(d1);
		d2 = this.strToDate(d2);
		switch (interval) {
                case "d": //date
                case "w":
                    d1 = new Date(d1.getFullYear(), d1.getMonth(), d1.getDate());
                    d2 = new Date(d2.getFullYear(), d2.getMonth(), d2.getDate());
                    break;  //w
                case "h":
                    d1 = new Date(d1.getFullYear(), d1.getMonth(), d1.getDate(), d1.getHours());
                    d2 = new Date(d2.getFullYear(), d2.getMonth(), d2.getDate(), d2.getHours());
                    break; //h
                case "n":
                    d1 = new Date(d1.getFullYear(), d1.getMonth(), d1.getDate(), d1.getHours(), d1.getMinutes());
                    d2 = new Date(d2.getFullYear(), d2.getMonth(), d2.getDate(), d2.getHours(), d2.getMinutes());
                    break;
                case "s":
                    d1 = new Date(d1.getFullYear(), d1.getMonth(), d1.getDate(), d1.getHours(), d1.getMinutes(), d1.getSeconds());
                    d2 = new Date(d2.getFullYear(), d2.getMonth(), d2.getDate(), d2.getHours(), d2.getMinutes(), d2.getSeconds());
                    break;
            }
            var t1 = d1.getTime(), t2 = d2.getTime();
            var diff = NaN;
            switch (interval) {
                case "y": diff = d2.getFullYear() - d1.getFullYear(); break; //y
                case "m": diff = (d2.getFullYear() - d1.getFullYear()) * 12 + d2.getMonth() - d1.getMonth(); break;    //m
				case "q": diff = (d2.getFullYear() - d1.getFullYear()) * 4 + this.getQuarter(d2.getMonth()+1) - this.getQuarter(d1.getMonth()+1); break;    //q
                case "d": diff = Math.floor(t2 / 86400000) - Math.floor(t1 / 86400000); break;
                case "w": diff = Math.floor((t2 + 345600000) / (604800000)) - Math.floor((t1 + 345600000) / (604800000)); break; //w
                case "h": diff = Math.floor(t2 / 3600000) - Math.floor(t1 / 3600000); break; //h
                case "n": diff = Math.floor(t2 / 60000) - Math.floor(t1 / 60000); break; //
                case "s": diff = Math.floor(t2 / 1000) - Math.floor(t1 / 1000); break; //s
                case "l": diff = t2 - t1; break;
            }
            return diff;	
	},
	diffDate : function(){
		return this.diff.apply( this,arguments );	
	},
	/*
	* 把日期分割才数组 [y,m,d,h,i,s]
	*/
	toArray : function( date ){
		var d = []; 
		date = this.strToDate( date );
		d[0] = date.getFullYear(); 
		d[1] = date.getMonth()+1; 
		d[2] = date.getDate(); 
		d[3] = date.getHours(); 
		d[4] = date.getMinutes(); 
		d[5] = date.getSeconds(); 
		return d; 	
	},
	/**
	* 检查日期是否合法 日期格式必须要类似 yyyy-MM-dd hh:mm:ss 分隔符不限
	* 例如 2015-02-31 二月是没有31号的
	* @param date 日期字符串
	*/
	isVaild : function(date){
		var undef;
		var reCat = /(\d{1,4})/gm;   
		var r = date.match(reCat);
		if( !r.length ) return false;
		var d = this.toArray(date);
		if(r[0] !== undef && d[0]!=r[0])return false;  
   	 	if(r[1] !== undef && d[1]!=r[1])return false;  
   	 	if(r[2] !== undef && d[2]!=r[2])return false;  
    	if(r[3] !== undef && d[3]!=r[3])return false;  
    	if(r[4] !== undef && d[4]!=r[4])return false;  
    	if(r[5] !== undef && d[5]!=r[5])return false;  
		return true;
	},
	/** 
     * 根据给定的日期得到日期的年，月，日，时，分和秒的对象 
     * @params date 给定的日期 date为非Date类型， 则获取当前日期 
     * @return 有给定日期的月、日、时、分和秒组成的对象 
     */   
    dateObject: function(date){   
        date = this.strToDate( date ); 
        return {  
			'y+' : date.getFullYear(),
            'M+' : date.getMonth() + 1,    
            'd+' : date.getDate(),      
            'h+' : date.getHours(),      
            'm+' : date.getMinutes(),    
            's+' : date.getSeconds()   
         };   
    },
	//+--------------------------------------------------- 
	//| 取得日期数据信息 
	//| 参数 interval 表示数据类型 
	//| y 年 m月 d日 w星期 ww周(年) h时 n分 s秒 
	//+--------------------------------------------------- 
	part : function( date,interval,w ){
		date = this.strToDate( date );
		var d=''; 
		var Week = w||['日','一','二','三','四','五','六']; 
		switch (interval) 
		{  
			case 'y' : d = date.getFullYear();break; 
			case 'm' : d = date.getMonth()+1;break; 
			case 'd' : d = date.getDate();break; 
			case 'w' : d = Week[date.getDay()];break; 
			case 'ww': d = this.weekOfYear(date);break; 
			case 'h' : d = date.getHours();break; 
			case 'n' : d = date.getMinutes();break; 
			case 's' : d = date.getSeconds();break; 
		} 
		return d; 
	},
	/**
	* 取得指定日期所在月分的最大天数，一个月的最后一天日期(还有个更简单的方法是 日期设置上个月的日期为0，那么就可以得到这个月的最后一天日期)
	* @param date
	*/
	maxDay : function( date ){
		var date1 = this.strToDate( date );
		date1 = this.clone( date1 );
		date1.setDate(1);
		date1.setMonth( date1.getMonth()+1 );
		date1.setDate(0);
		return date1.getDate(); 		
	},
	/**
	* 返回当前月份的所有天数
	* @param date 日期
	* return Array eg:[1,2,3...,31]
	*/
	getDays : function(date){
		var days = [];
		var md = this.maxDay( date );
		for( var i=1;i<=md;i++ ) {
			days.push( i );	
		}	
		return days;
	},
	/*获取本月第一天*/
	firstDay : function(date){
		var date = this.clone(date);
		return date.setDate(1);	
	},
	/*获取本月最后一天*/
	lastDay : function( date ){
		var date = this.clone( date );
		date.setDate(this.maxDay( date ))
		return date;		
	},
	/*
	*获取月份
	*/
	getMonths : function(){
		return [1,2,3,4,5,6,7,8,9,10,11,12];	
	},
	/*
	*获取从1900到2099数组
	*/
	getYears : function(){
		var y = [];
		for( var i=1900;i<=2099;i++ ) {
			y.push( i );	
		}	
		return y;
	},
	/**
	* The default calculation follows the ISO 8601 definition: the week starts on Monday, the first week of the year contains the first Thursday of the year. This means that some days from one year may be placed into weeks 'belonging' to another year.
	*/
	iso8601Week : function(date) {
		var time,
			checkDate = new Date(date.getTime());

		// Find Thursday of this week starting on Monday
		checkDate.setDate(checkDate.getDate() + 4 - (checkDate.getDay() || 7));

		time = checkDate.getTime();
		checkDate.setMonth(0); // Compare with Jan 1
		checkDate.setDate(1);
		return Math.floor(Math.round((time - checkDate) / 86400000) / 7) + 1;
	},
	dayOfYear : function(date,m){
		var e = this.strToDate( date,m );
		var s = this.clone( e );
		s.setMonth(0);
		s.setDate(1);
		return this.diff( s,e,'d' )+1;
	},
	weekOfYear : function(date){
		return this.iso8601Week( this.strToDate( date ) )
	},
	/**
	* 获取当前日期是该月的周数
	*/
	weekOfMonth : function(date){},
	/** 
     *在控制台输出日志 
     *@params message 要输出的日志信息 
     */   
    error: function(message){   
    }
});
/*
*字符串处理处理工具
*Nex.util.String
*/
Nex.addUtil('String',{
	isFunction : function(obj){
		var toString = Object.prototype.toString;
		return toString.call(obj) == '[object Function]';	
	},
	isArray : function( iarr ){
		var nativeIsArray = Array.isArray;	
		var toString = Object.prototype.toString;
		return nativeIsArray ? nativeIsArray.call( Array,iarr ) : (toString.call(obj) == '[object Array]');
	},
	/*
	*字符串格式化
	*eg : Nex.util.String.format('{0} is {1}','apple','fruit')
	*/
	format : function(str){
		if (arguments.length === 0)
			return null;
		var str = arguments[0];
		for ( var i = 1; i < arguments.length; i++) {
			var re = new RegExp('\\{' + (i - 1) + '\\}', 'gm');
			str = str.replace(re, arguments[i]);
		}
		return str;	
	},
	/*
	*字符转整型
	*/
	toInt : function(str, defaultValue) {
		var result = parseInt(str, 10);
		return (isNaN(result)) ? defaultValue : result;
	},
	/*
	*字符转浮点
	*/
	toFloat : function(str, defaultValue) {
		var result = parseFloat(str);
		return (isNaN(result)) ? defaultValue : result;
	},
	HTMLEncode : function(text) {
		var converter = document.createElement("DIV");
		converter.innerText = text;
		converter.textContent = text;
		var output = converter.innerHTML;
		converter = null;
		output = output.replace(/"/g, "&quot;");
		output = output.replace(/'/g, "&apos;");
		return output;
	},
	HTMLDecode : function(html) {
		var converter = document.createElement("DIV");
		converter.innerHTML = html;
		var output = converter.innerText || converter.textContent;
		converter = null;
		return output;
	},
	"escape" : function( str ){
			
	},
	"unescape" : function( str ){
			
	},
	/*
	*自动填充 默认填充0
	*/
	pad : function(value, length, right, str_pad) {
		var undef;
		str_pad = str_pad === undef ? '0' : str_pad+'';
		var res = "" + value;
		for (; res.length < length; res = right ? res + str_pad : str_pad + res) {
		}
		return res;
	}
});
/*
*UploadFile处理工具
*Nex.util.UploadFile
*/
Nex.addUtil('UploadFile',{
	frame : function(c) {
		var n = 'f' + Math.floor(Math.random() * 99999);
		var d = document.createElement('DIV');
		d.innerHTML = '<iframe style="display:none" src="about:blank" id="'+n+'" name="'+n+'" onload="Nex.getUtil(\'UploadFile\').loaded(\''+n+'\')"></iframe>';
		console.log(d);
		document.body.appendChild(d);

		var i = document.getElementById(n);
		if (c && typeof c == 'function') {
			i.onComplete = c;
		}
		return n;
	},
	form : function(f, name) {
		f.setAttribute('target', name);
	},
	'submit' : function(f, func) {
		if( typeof f !== 'object' ) {
			f = document.getElementById(f);	
		}
		this.form(f, this.frame(func));
		f.submit();
		return true;
	},
	loaded : function(id) {
		function getDoc(frame) {
			var doc = frame.contentWindow ? frame.contentWindow.document : frame.contentDocument ? frame.contentDocument : frame.document;
			return doc;
		}
		var i = document.getElementById(id);
		var s = '';
		var doc = getDoc( i );
		if (doc.location.href == "about:blank") {
			return;
		}

		var docRoot = doc.body ? doc.body : doc.documentElement;

		//var pre = doc.getElementsByTagName('pre')[0];
		var pre = doc.getElementsByTagName('body')[0];
		//console.log(pre);
		if (pre) {
			s = pre.textContent ? pre.textContent : pre.innerText;
		}
		/*else if (b) {
		 s = b.textContent ? b.textContent : b.innerText;
		 }*/
		if (typeof(i.onComplete) == 'function') {
			i.onComplete(s);
		}
	}
});
/*
*Validate工具
*Nex.util.Validate
*验证时数据不能为空 ，eg 验证一个邮件 if( Validate.required( value ) && Validate.email( value ) ) {...}
*/
Nex.addUtil('Validate',{
	required: function( value, param ) {
		return $.trim(value).length > 0;
	},
	email: function( value, param ) {
		return $.trim(value).length==0 || /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(value);
	},
	url: function( value, param ) {
		return $.trim(value).length==0 || /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);//'
	},
	ip : function( value, param ){
		return $.trim(value).length==0 || /^[\d\.]{7,15}$/.test(value);		
	},
	qq : function( value, param ){
		return $.trim(value).length==0 || /^[1-9]\d{4,12}$/.test(value);		
	},
	currency : function( value, param ){
		return $.trim(value).length==0 || /^\d+(\.\d+)?$/.test(value);		
	},
	mobile : function( value, param ){
		return $.trim(value).length==0 || /^((\(\d{3}\))|(\d{3}\-))?13[0-9]\d{8}?$|15[89]\d{8}?$/.test(value);	
	},
	phone : function( value, param ){
		return $.trim(value).length==0 || /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/.test(value);	
	},
	number: function( value, param ) {
		return $.trim(value).length==0 || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(value);
	},
	digits: function( value, param ) {
		return $.trim(value).length==0 || /^\d+$/.test(value);
	},
	creditcard: function( value, param ) {
		
		if( $.trim(value).length==0 ) {
			return true;	
		}
		
		if ( /[^0-9 \-]+/.test(value) ) {
			return false;
		}
		var nCheck = 0,
			nDigit = 0,
			bEven = false;
	
		value = value.replace(/\D/g, "");
	
		for (var n = value.length - 1; n >= 0; n--) {
			var cDigit = value.charAt(n);
			nDigit = parseInt(cDigit, 10);
			if ( bEven ) {
				if ( (nDigit *= 2) > 9 ) {
					nDigit -= 9;
				}
			}
			nCheck += nDigit;
			bEven = !bEven;
		}
	
		return (nCheck % 10) === 0;
	},
	//checkLength 检验radio checkbox的选择数
	rangelength: function( value, param ) {
		if( $.trim(value).length==0 ) {
			return true;	
		}
		
		var length = value.split(",").length;
		//var length = $.isArray( value ) ? value.length : this.getLength($.trim(value), element);
		return ( length >= param[0] && length <= param[1] );
	},
	min: function( value, param ) {
		if( $.trim(value).length==0 ) {
			return true;	
		}
		return value >= param;
	},
	max: function( value, param ) {
		if( $.trim(value).length==0 ) {
			return true;	
		}
		return value <= param;
	},
	range: function( value, param ) {
		if( $.trim(value).length==0 ) {
			return true;	
		}
		return ( value >= param[0] && value <= param[1] );
	},
	equalTo: function( value, param ) {
		var target = $(param);
		return value === target.val();
	}
});

/*
button组件继承 html
http://www.extgrid.com/button
author:nobo
zere.nobo@gmail.com
qq : 505931977
*/

;$define(['Nex.Html'],function(){
	"use strict";
	var button = Nex.define('Nex.button.Button','Nex.Html',{
		alias : 'Nex.Button',
		xtype : 'button'
	});
	//$.nexButton = $.extButton = button;
	button.extend({
		version : '1.0',
		_Tpl : {				
		}
	});
	button.setOptions( function( opt ){
		return {
			prefix : 'nexbutton-',
			tag : 'span',
			renderTo : document.body,
			autoDestroy : true,
			autoResize : false,
			_hasBodyView : false,
			_checkScrollBar : false,
			selectionable : false,
			denyEvents : true,
			tabIndex : Nex.tabIndex++,
			width : 'auto',
			height : 'auto',
			borderCls : [opt.borderCls,'nex-button-border'].join(' '),
			containerCls : [opt.containerCls,'nex-button'].join(' '),
			autoScroll : false,
			autoScrollCls : '',
			autoFocus : false,
			splitBtn : false,
			toggleBtn : false,
			pressed : false,
			plain : false,
			skin : 'default',//按钮主题
			cls : '',
			bodyCls : '',
			bodyStyle : {},
			toggleCls : '',
			pressedCls : '',
			activeCls : '',
			overCls : '',
			focusCls : '',
			plainCls : '',
			disabledCls : '',
			cssText : '',
			align : 'center',
			//removeTextSize 如果你对button设置了比较大的值建议 设置removeTextSize = true
			removeTextSize : false,//如果设置了width 默认text也会设置宽度， 可以通关这个参数取消设置
			iconAlign : 'left', // left top bottom right
			icon : '',
			iconCls : '',
			arrowAlign : 'right',//按钮 箭头位置 right bottom
			showArrow : false,//默认不显示 如果items 有值会自动显示
			arrow : '',//图标地址
			arrowCls : '',//arrow 样式 
			disabled : false,
			callBack : null,//callBack callback 实际作用是一样的
			callback : null,
			toggleHandler : $.noop,
			text : '',
			views : {},
			menuConf : {},
			menu : [],
			events : {
				onStart : $.noop,
				onCreate : $.noop,
				onSizeChange : $.noop,
				onDestroy : $.noop
			}
		};						
	} );
	
	button.fn.extend({
		_init : function(opt) {
			var self = this;
			
			opt.cls += ' nex-button-skin-'+opt.skin; 
			
			self.setContainer();
			self.setBody();
			self.initComponent();
			//self.createButton();
			//self.fireEvent('onCreate');
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return opt.views['body'];
		},
		setBody : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var bd = $( '<span class="nex-button-left '+opt.bodyCls+'" id="'+opt.id+'_left" ></span>' );
			var bd2 = $( '<span class="nex-button-right" id="'+opt.id+'_right"></span>' );
			
			opt.views['body'] = bd;
			opt.views['body2'] = bd2;
			container.append(bd);
			container.append(bd2);
			//bd.css('padding',opt.padding);
			bd.css(opt.bodyStyle);
			//self.bindBodyEvents();	 
			self.fireEvent("onBodyCreate",[bd,bd2,opt]);
			return self;
		},
		_setViewSize : function(w,h){
			var self = this,
				opt = self.configs,
				container = self.getContainer(),
				vbody = self.getBody();
			
			if( opt.realWidth !== 'auto' ) {
				var w = container._width();
				vbody._outerWidth( w );
				if( !opt.removeTextSize ) {
					var iconWidth = 0;
					if( opt.iconAlign === 'top' || opt.iconAlign === 'bottom' ) {
						iconWidth = 0;	
					} else {
						iconWidth = $('#'+opt.id+'_icon')._width();	
					}
					var arrowWidth = 0;
					if( opt.arrowAlign === 'top' || opt.arrowAlign === 'bottom' ) {
						arrowWidth = 0;	
					} else {
						arrowWidth = $('#'+opt.id+'_arrow')._width();	
					}
					var ww = iconWidth + arrowWidth;
					$('#'+opt.id+'_text')._outerWidth( $('#'+opt.id+'_left')._width()-ww );
				}
			}
			if( opt.realHeight !== 'auto' ) {
				var bd2 = opt.views['body2'];
				var h = container._height();
				vbody._outerHeight( h );
				bd2.height( h );
			}
			
			self.fireEvent("onSetViewSize",[opt]);	
			
		},
		initComponent : function(){
			var self = this;
			var opt = self.configs;	
			self.fireEvent('onInitComponent',[opt]);
			
			self.createButton();
			
			//初始是不应该触发onSizeChange事件
			self.lockEvent('onSizeChange');
			self.resetHtmlSize();
			self.unLockEvent('onSizeChange');
			
			self.fireEvent('onCreate',[opt]);
			opt._isInit = false;
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.bind("onCreate.over",self._setFocus,self);
			self.bind("onCreate.over",self.toggleBtnCls,self);
			self.bind("onCreate.over",self._onCreate,self);
			self.bind("onContainerCreate.over",self._setPlain,self);
			self.bind("onFocus.focus",self._setFoucsCls,self);
			self.bind("onBlur.focus",self._unsetFoucsCls,self);//pressedCls
			self.bind("onMouseDown.focus",self._setPressedCls,self);
			self.bind("onMouseUp.focus",self._unsetPressedCls,self);
			self.bind("onMouseOver.over",self.onMouseOver,self);
			self.bind("onMouseOut.over",self.onMouseOut,self);
			self.bind("onClick.click",self._click,self);
			self.bind("onKeyDown.click",self._click2,self);
			self.bind("onClick.menu",self._showMenu,self);
			return self;
		},
		createButton : function(){
			var self = this;
			var opt = self.configs;
			
			self.setInnerButton();
			self.bindButtonEvent();
			
			return true;
		},
		setInnerButton : function(){
			var self = this,
				opt = self.configs,
				vbody = self.getBody();
			
			var wraper = ['<table class="nex-button-layout-table" cellpadding="0" cellspacing="0" border="0"><tr><td align="'+opt.align+'" valign="middle"><div class="nex-button-wraper" id="'+opt.id+'_wraper">'];
	
			var _bg = '';
			if( opt.icon ) {
				_bg = "background-image:url("+opt.icon+")";
			}
	
			if( opt.icon || opt.iconCls ) {
				wraper.push('<span id="'+opt.id+'_icon" class="nex-button-inner nex-button-icon ',opt.iconCls,'" style="',_bg,'"></span>');
			}
			
			wraper.push('<span id="'+opt.id+'_text" class="nex-button-inner nex-button-text" style="">',opt.text,'</span>');
			
			if( opt.showArrow || opt.menu.length || opt.items.length ) {
				var _bg2 = '';
				if( opt.arrow ) {
					_bg2 = 'background-image:url('+opt.arrow+');';	
				}
				wraper.push('<span id="'+opt.id+'_arrow" class="nex-button-inner nex-button-arrow '+ opt.arrowCls +'" style="'+_bg2+'"></span>');
			}
			
			wraper.push('</div></td></tr></table>');
			
			var btnInner = $(wraper.join(""));
			
			vbody.append( btnInner );
			
			self.setIconAlign();
			self.setArrowAlign();
			
			self.fireEvent('onButtonInnerCreate',[btnInner]);
		},
		bindButtonEvent : function(){
			var self = this;
			var opt = self.C();
			var container = self.getContainer();
			
			var callBack = function(type,e){
				var r = self.fireEvent(type,[ this,e,opt ]);
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				}
			};
			var events = {
				'focusin' : function(e) {
					callBack.call(this,'onFocus',e);
				},
				'focusout' : function(e) {
					callBack.call(this,'onBlur',e);
				},
				'click' : function(e) {
					callBack.call(this,'onClick',e);
				},
				'dblclick' : function(e) {
					callBack.call(this,'onDblClick',e);
				},
				'keydown' : function(e) {
					callBack.call(this,'onKeyDown',e);
				},
				'keyup' : function(e) {
					callBack.call(this,'onKeyUp',e);
				},
				'keypress' : function(e){
					callBack.call(this,'onKeyPress',e);
				},
				'mouseenter' : function(e){
					callBack.call(this,'onMouseEnter',e);
				},
				'mouseleave' : function(e){
					callBack.call(this,'onMouseLeave',e);
				},
				'mouseover' : function(e){
					callBack.call(this,'onMouseOver',e);
				},
				'mouseout' : function(e){
					callBack.call(this,'onMouseOut',e);
				},
				'mousedown' : function(e) {
					callBack.call(this,'onMouseDown',e);
				},
				'mouseup' : function(e) {
					callBack.call(this,'onMouseUp',e);
				},
				'contextmenu' : function(e){	
					callBack.call(this,'onContextMenu',e);
				}
			};
			container.bind(events);
			self.fireEvent("onSetButtonEvent",[container,opt]);
			return true;
		},
		focus : function(){
			var self = this,
				opt = self.configs;
			var btn = self.el;
			btn.focus();
		},
		blur : function(){
			var self = this,
				opt = self.configs;
			var btn = self.el;//getContainer
			btn.blur();
		},
		_setFocus : function(){
			var self = this,
				opt = self.configs;
			if( opt.autoFocus ) {
				clearTimeout( opt._ft );
				opt._ft = setTimeout(function(){
					self.focus();	
				},0);
			}
		},
		_setPlain : function(){
			var self = this,
				opt = self.configs,
				btn = self.el;
			if( !opt.plain ) return;	
			btn.addClass("nex-button-plain");
			if( opt.plainCls ) {
				btn.addClass( opt.plainCls );	
			}	
		},
		_setFoucsCls : function(btn){
			var self = this,
				opt = self.configs,
				btn = self.el;
			btn.addClass("nex-button-focus");
			if( opt.focusCls ) {
				btn.addClass( opt.focusCls );	
			}
		},
		_unsetFoucsCls : function(btn){
			var self = this,
				opt = self.configs,
				btn = self.el;
			btn.removeClass("nex-button-focus");
			if( opt.focusCls ) {
				btn.removeClass( opt.focusCls );	
			}
		},
		_setPressedCls : function(btn){
			var self = this,
				opt = self.configs,
				btn = self.el;
			btn.addClass("nex-button-pressed");
			if( opt.pressedCls ) {
				btn.addClass( opt.pressedCls );	
			}
			$(document).one('mouseup',function(){
				self._unsetPressedCls();								   
			});
		},
		_unsetPressedCls : function(btn){
			var self = this,
				opt = self.configs,
				btn = self.el;
			btn.removeClass("nex-button-pressed");
			if( opt.pressedCls ) {
				btn.removeClass( opt.pressedCls );	
			}
		},
		_showMenu : function(btn,e){
			var self = this;
			var opt = self.configs;
			var btn = $(btn);
			
			if( opt.disabled ) {
				return;	
			}
			
			if( opt.menu.length && !opt.splitBtn ) {
				
				if( btn.hasClass('nex-button-active') ) {
					btn.removeClass('nex-button-active');
					if( opt.activeCls ) {
						btn.removeClass(opt.activeCls);	
					}
					if( self._menu ) {
						self._menu.hideRoot();	
					}	
				} else {
					btn.addClass('nex-button-active');
					if( opt.activeCls ) {
						btn.addClass(opt.activeCls);	
					}
					self._menu = new Nex.menu($.extend(opt.menuConf,{data:opt.menu},{
						onClick : function(obj,tid,data,e){
							btn.removeClass('nex-button-active');		
							self.fireEvent('onItemClick',[ obj,tid,data,e ]);	
						}								   
					}));	
					var _menu = self._menu.createMenu();
					self._menu._showAt(_menu,btn,{ xAlign:'left',yAlign:'bottom',zAlign : 'y' });
					setTimeout(function(){
						$(document).one("mousedown",function(){
							btn.removeClass('nex-button-active');								 
							self._menu.hideRoot();								 
						});					
					},0);
				}
			}
		},
		_showSplitMenu : function(btn,e){
			var self = this;
			var opt = self.configs;
			var _btn = self.el;//$("#"+opt.id);
			
			if( !opt.splitBtn ) return;
			
			var splitBtn = $('.nex-button-arrow',_btn);
			if( splitBtn.hasClass('nex-button-arrow-active') ) {
				splitBtn.removeClass('nex-button-arrow-active');
				_btn.removeClass('nex-button-active');
				if( opt.activeCls ) {
					_btn.removeClass(opt.activeCls);	
				}
				if( self._menu ) {
					self._menu.hideRoot();	
				}
			} else {
				splitBtn.addClass('nex-button-arrow-active');
				_btn.addClass('nex-button-active');
				if( opt.activeCls ) {
					_btn.addClass(opt.activeCls);	
				}
				self._menu = new Nex.menu($.extend(opt.menuConf,{data:opt.menu},{
					onClick : function(obj,tid,data,e){
						splitBtn.removeClass('nex-button-arrow-active');
						_btn.removeClass('nex-button-active');
						if( opt.activeCls ) {
							_btn.removeClass(opt.activeCls);	
						}	
						self.fireEvent('onItemClick',[ obj,tid,data,e ]);	
					}								   
				}));
				var _menu = self._menu.createMenu();	
				$(_menu).showAt({ el:_btn,xAlign:'left',yAlign:'bottom' });	
				setTimeout(function(){
					$(document).one("mousedown",function(){
						splitBtn.removeClass('nex-button-arrow-active');
						_btn.removeClass('nex-button-active');
						if( opt.activeCls ) {
							_btn.removeClass(opt.activeCls);	
						}								 
						self._menu.hideRoot();								 
					});					
				},0);
			}
		},
		_onCreate : function(){
			this.disabled( this.C('disabled') );	
		},
		onMouseOver : function(btn,e){
			var self = this,
				opt=this.configs;
			var btn = self.el;
			btn.addClass("nex-button-hover");
			if( opt.overCls ) {
				btn.addClass( opt.overCls );	
			}
		},
		onMouseOut : function(btn,e){
			var self = this,
				opt=this.configs;
			var btn = self.el;
			btn.removeClass("nex-button-hover");
			if( opt.overCls ) {
				btn.removeClass( opt.overCls );	
			}
			if( opt.plain ) {
				self._unsetFoucsCls();	
			}	
		},
		toggleBtnCls : function(){
			var self = this,
				opt=this.configs;	
			var btn = self.el;//$("#"+opt.id);
			if( opt.pressed ) {
				btn.addClass("nex-button-toggle");
				if( opt.toggleCls ) {
					btn.addClass( opt.toggleCls );	
				}
			} else {
				btn.removeClass("nex-button-toggle");
				if( opt.toggleCls ) {
					btn.removeClass( opt.toggleCls );	
				}
			}	
		},
		_click : function(btn,e){
			var self = this,
				opt=this.configs;
			if( opt.disabled ) {
				return;	
			}
			if( $.isFunction(opt.callBack) ) {
				opt.callBack.call(opt.context || self,btn,e);
			}
			if( $.isFunction(opt.callback) ) {
				opt.callback.call(opt.context || self,btn,e);
			}
			
			if( opt.toggleBtn ) {
				opt.pressed = !opt.pressed;
				self.toggleBtnCls();
				opt.toggleHandler.call(opt.context || self,opt.pressed,opt);	
			}
		},
		_click2 : function(btn,e){
			var self = this,
				opt=this.configs;
			if( opt.disabled ) {
				return;	
			}	
			if( e.keyCode === 13 ) {
				self._click();
			}
		},
		disabled : function(m){
			var self = this,
				opt=this.configs,
				undef;
			var m = m === undef ? true : m;
			var btn = self.el;//$("#"+opt.id);
			opt.disabled = !!m;
			if( m ) {
				btn.addClass('nex-button-disabled');
				if( opt.disabledCls ) {
					btn.addClass(opt.disabledCls);	
				}
				btn.removeAttr('tabindex');
			} else {
				btn.removeClass('nex-button-disabled');	
				if( opt.disabledCls ) {
					btn.removeClass(opt.disabledCls);	
				}
				btn.attr('tabindex',opt.tabIndex);
			}
			return true;
		},
		enabled : function(){
			return this.disabled( false );	
		},
		setText : function( text ){
			var self = this,
				opt = self.configs;	
			text = $.isFunction( text ) ? text.call(this,opt) : text;
			opt.text = self._undef(text,opt.text);
			var t = $('#'+opt.id+'_text');
			t.html( opt.text );
		},
		setArrowAlign : function( align ){
			var self = this,
				opt = self.configs,
				align = self._undef( align,opt.arrowAlign );
			opt.arrowAlign = align;	
			var wraper = $('#'+opt.id+'_wraper');
			//var icon = $('#'+opt.id+'_icon');
			//var text = $('#'+opt.id+'_text');	
			var arrow = $('#'+opt.id+'_arrow');	
			if( !arrow.length ) {
				return self;	
			}
			arrow.removeClass( 'nex-button-inner-block' );
			switch( align ) {
				case 'left' : 
					wraper.prepend( arrow );
					break;
				case 'top' : 
					wraper.before( arrow );
					arrow.addClass( 'nex-button-inner-block' );
					break;
				case 'right' : 
					wraper.append( arrow );
					break;
				case 'bottom' : 
					wraper.append( arrow );
					arrow.addClass( 'nex-button-inner-block' );
					break;
			}
			return self;
		},
		setIconAlign : function( align ){
			var self = this,
				opt = self.configs,
				align = self._undef( align,opt.iconAlign );
			opt.iconAlign = align;	
			var wraper = $('#'+opt.id+'_wraper');
			var icon = $('#'+opt.id+'_icon');
			var text = $('#'+opt.id+'_text');	
			if( !icon.length ) {
				return self;	
			}
			icon.removeClass( 'nex-button-inner-block' );
			switch( align ) {
				case 'left' : 
					text.before( icon );
					break;
				case 'top' : 
					text.before( icon );
					icon.addClass( 'nex-button-inner-block' );
					break;
				case 'right' : 
					text.after( icon );
					break;
				case 'bottom' : 
					wraper.append( icon );
					icon.addClass( 'nex-button-inner-block' );
					break;
			}
			return self;
		},
		setIcon : function( icon,align ){
			var self = this,
				opt = self.configs,
				align = self._undef( align,opt.iconAlign ),
				vbody = self.getBody();	
			opt.icon = self._undef(icon,opt.icon);	
			
			var icon = $('#'+opt.id+'_icon');
			var text = $('#'+opt.id+'_text');
			
			if( !opt.icon && !opt.iconCls ) {
				icon.remove();	
			} else {
				var _bg = '';
				if( opt.icon ) {
					_bg = "background-image:url("+opt.icon+")";
				}
				icon.remove();
				icon = $(['<span id="',opt.id,'_icon" class="nex-button-inner nex-button-icon ',opt.iconCls,'" style="',_bg,'"></span>'].join(''));
				text.before(icon);	
				//设置icon位置
				self.setIconAlign( align );
			}
			
			self._setViewSize();
			return self;
		},
		setIconCls : function(iconCls,align){
			var self = this,
				opt = self.configs,
				align = self._undef( align,opt.iconAlign ),
				vbody = self.getBody();	
			opt.iconCls = self._undef(iconCls,opt.iconCls);	
			
			var icon = $('#'+opt.id+'_icon');
			var text = $('#'+opt.id+'_text');
			
			if( !opt.icon && !opt.iconCls ) {
				icon.remove();	
			} else {
				var _bg = '';
				if( opt.icon ) {
					_bg = "background-image:url("+opt.icon+")";
				}
				icon.remove();
				icon = $(['<span id="',opt.id,'_icon" class="nex-button-inner nex-button-icon ',opt.iconCls,'" style="',_bg,'"></span>'].join(''));
				text.before(icon);	
				//设置icon位置
				self.setIconAlign( align );
			}
			
			self._setViewSize();
			return self;
		}
	});
});
/*
*
*Nex.mixins.DropDown
*下拉列表框 或者 自定义下拉框 
*/
Nex.addMixins('DropDown',{
	dropdownzIndex : 999999+Nex.zIndex,
	configs : {
		multiSplit : ',',
		textKey : 'text',
		valueKey : 'value',
		splitChr : ['-',',',';','|'],
		dropdownHideToRemove : false,//dropdown 关闭后销毁下拉框  --未实现
		dropdownItems : [],
		dropdownItemDefault : {},
		dropdownLoadMsg : '数据加载中...',
		//默认和Input一样长
		dropdownLoadWidth : 0,
		//加载提示显示参数设置
		dropdownLoadShowAt : {},
		//dropdown 结构 wrap(可能只有做动画效果才能用到)->body(内容)
		//dropdownMode = 1|2 如果是2 则items的内容都会当作组件来创建 如果是1 则会自动判断：如果是数组则创建下拉列表，其他（如xtype function..） 则当作组件创建
		dropdownAnimate : false,
		dropdownDuration : 200,
		dropdownEasing : 'easeOutQuad',//easeOutCirc linear easeOutSine
		dropdownMode : 1, // 1:列表下拉框 2:组件下拉框 
		dropdownBorder : true,//dropdown 是否有边框 
		dropdownPadding : 0,
		dropdownAutoScroll : false,//如果创建的是 组件下拉框（mode=2） 则该参数生效
		//'<div style="text-align:center;">暂无数据</div>'
		dropdownEmptyMsg : '',//&&dropdownMode=1 下拉列表为空时的提示内容
		dropdownCls : '',
		dropdownShowAt : {},
		//dropdown的宽高可以设置func 动态返回一个数字
		dropdownHeight : 'auto',//
		dropdownWidth : 'auto',//auto 表示自适应 组件下拉框中 0=inputWidth或者container.width
		dropdownMaxHeight : 0,//(不适应mode=2)0 代表auto 最大不能超过屏幕高度
		dropdownMinHeight : 0,//(不适应mode=2)0 代表auto
		dropdownMaxWidth : 0, // (不适应mode=2)0 标识最大不能超过屏幕宽
		dropdownMinWidth : 0,//(不适应mode=2)如果dropdownMinWidth=0 且是下拉列表(dropdownMode=1)时，dropdownMinWidth实际是和组件的大小宽度一致的，所以如果想控制下拉列表的宽度，应该控制dropdownMinWidth
		dropdownSelectionable : true,
		dropdownEdge : 5,//下拉框right bottom距离边缘的宽度 默认是5[px]
		dropdownItemsFilter : null,//下拉数据过滤器
		dropdownItemFilter : null,//下拉列表的数据过滤器
		dropdownItemFormat : null,//下拉列表参数
		dropdownItemNoWrap : true,//下拉列表不换行
		dropdownItemTips : false,//下拉列表是否这种tips字段
		dropdownItemTipsTag : 'title',
		dropdownItemTipsFilter : null,//function
		dropdownOtherHeight : 0,
		dropdownOtherWidth : 0,
		//下拉列表单选模式
		dropdownSingleSelect : true,
		//单击item或者其他区域后会关闭dropdown 默认true 如果为false则需要手动调用hideDropDown
		dropdownHideOnClick : true,
		//鼠标点击其他区域后隐藏dropdown
		dropdownHideOnBlur : true,
		dropdownShadowShow : true,
		dropdownResetPosDuration : 200,
		dropdownItemTpl : '<div id="<%=id%>" <%=tips%> value="<%=value%>" class="nex-form-dropdown-item <%=selected?"nex-form-dropdown-item-selected":""%> <%=disabled?"nex-form-dropdown-item-disabled":""%> <%=nowrap?"nex-form-dropdown-item-nowrap":""%> <%=cls%>"><%=text%></div>',
		dropdownItemSplitLineTpl : '<div class="nex-form-item-separator"><div class="nex-form-line-h"></div></div>',
		//绑定事件
		'@onDestroy._sysdp' : function(){
			this.destroyDropDown();	
		}
	},
	_getElOffset : function(el){
		var self = this;
		var opt = self.configs;	
		var offset = $(el).offset();
		var sLeft = $(window).scrollLeft();
		var sTop = $(window).scrollTop();
		return !offset ? {left:sLeft,top:sTop} : offset;
	},
	//获取周围可显示空间
	_getShowAtSpace : function(el){
		var self = this;
		var opt = self.configs;
		var el = self._undef(el,self.getDropDownShowAt());
		//需要获取的对象
		var obj = $(el);
		
		//获取窗口显示区域大小
		var cw = $(window).width();
		var ch = $(window).height();
		
		var offset = $._isPlainObject(el) ? el : self._getElOffset(obj);
		
		//获取滚位置
		var sLeft = $(window).scrollLeft();
		var sTop = $(window).scrollTop();
		
		var space = {
			top : offset.top - sTop,
			left : offset.left - sLeft
		};
		space.bottom = ch - space.top - ( $._isPlainObject(el) ? 0 : obj._outerHeight() );
		space.right = cw - space.left - ( $._isPlainObject(el) ? 0 : obj._outerWidth() );
		return space;
	},
	getDropDownItems : function(){
		var opt = this.configs;
		return opt.dropdownItems || [];	
	},
	getDropDownItemDefault : function(){
		var opt = this.configs;
		return opt.dropdownItemDefault;	
	},
	/*
	*检测当前itemData是否包含__id text value 
	*/
	__itemId : 1,
	_parseItemData : function( data ){
		var self = this,
			undef,
			opt = self.configs;
		var value = opt.valueKey,
			text = opt.textKey;
		//如果data.__id已经存在说明已经处理过了，不需要重复处理
		if( $.isPlainObject( data ) && data.__id ) {
			return data;	
		}		
		var d = {};	
		if( $.isArray( data ) && data.length ) {
			d[ value ] = data[0];
			d[ text ] = self._undef(data[1],data[0]);	
		} else if( $.isPlainObject( data ) ) {
			d[value] = self._undef(data[value],data[text]);
			d[text] = self._undef(data[text],d[value]);
			d[value] = self._undef(d[value],'');
			d[text] = self._undef(d[text],'');
			//d = data;
		} else {//string
			d[ value ] = data+'';
			d[ text ] = d[ value ];	
			if( $.inArray( d[ value ],opt.splitChr ) !== -1 ) {
				d[ '__splitLine' ] = true;	
			}
		}
		if( !('__id' in d) ) {
			d.__id = opt.id+'_item_'+self.__itemId++;	
		}
		//getDropDownItemDefault
		$.extend( d,self.getDropDownItemDefault(),d );//opt.itemDefault
		return d;
	},
	isSplitLine : function( data ){
		var data = data || {};
		if( data.__splitLine ) {
			return true;	
		}
		return false;
	},
	setDropDownItems : function( items ){
		var opt = this.configs;
		if( items ) {//dropdownItems
			opt.dropdownItems = $.isArray(items) ? items.concat([]) : items;
		}
		if( opt.dropdownMode == 1 && $.isArray(opt.dropdownItems) ) {
			$.each( opt.dropdownItems,function( i,d ){
				opt.dropdownItems[i] = self._parseItemData( d );	
			} );
		}
		//判断dropdown是否已经创建 如果创建则刷新内容
		var dropdown = self.getDropDown();
		if( dropdown.length && items ) {
			this.resetDropDownList( opt.dropdownItems );
		}
		
		return opt.dropdownItems;	
	},
	/*
	*获取DropDownItems数据
	*@param {String,Array}单个字符是返回当前对象，如果是数组或者以','分割的字符串时返回的是数组
	*@param {Boolean} true 默认 返回数据  false返回索引
	*return {Array,Object}
	*/
	getDropDownItemData : function( value,m ){
		var self = this,
			undef,
			opt = self.configs,
			m = m === undef ? true : m,
			items = self.getDropDownItems();	
		var _v = value;	
		if( value === undef ) return null;
		if( $.type( value ) === 'string' ) {
			value = value.split( opt.multiSplit );	
			if( value.length>1 ) {
				_v = value;	
			}
		} else if( $.type( value ) !== 'array' ) {
			value = [ value ];	
		}
		var d = {};
		$.each( value,function(i,v){
			d[v] = true;					   
		} );
		var list = [];
		$.each( items , function(i,v){
			if( !$.isPlainObject( v ) ) return;
			var value = v['value'];
			if( value in d ) {
				list.push( m?v:i );	
			}
		} );
		
		if( list.length === 1 && $.type( _v ) !== 'array' ) {
			return list[0];	
		} else {
			return list;	
		}
	},
	getDropDownItemIndex : function( value ){
		return this.getDropDownItemData( value,false );
	},
	getDropDownItemDataById : function(id){
		var self = this,
			undef,
			opt = self.configs;
		var d = {};
		var items = self.getDropDownItems();	
		if( id === undef ) {
			return d;	
		}
		$.each( items , function(i,v){
			if( !$.isPlainObject( v ) ) return;
			var value = v['__id'];
			if( value === id ) {
				d = v;
				return false;
			}
		} );	
		return d;
	},
	getDropDownShowAt : function(){
		return this.getContainer();	
	},
	showDropDownLoading : function( msg,callback ){
		var self = this,
			undef,
			opt = self.configs;
		var msg = msg || opt.dropdownLoadMsg;
		var at = self.getDropDownShowAt();
		var loader = $('#'+opt.id+'_dropdown_loading');	
		if( self.__ddt ) {
			clearTimeout( self.__ddt );	
		}
		if( loader.length ) {
			loader.html( opt.dropdownLoadMsg );
		} else {
			//创建dropdown
			loader = $('<div id="'+opt.id+'_dropdown_loading" class="nex-form-dropdown-loading">'+msg+'</div>');	
			$(document.body).append( loader );
			var w = at._outerWidth();
			var w1 = loader._outerWidth();
			var ldpw = $.isFunction(opt.dropdownLoadWidth) ? opt.dropdownLoadWidth.call( self,opt ) : opt.dropdownLoadWidth;
			if( ldpw>0 ) {
				loader._outerWidth( ldpw );		
			} else {
				if( w1<w ) {
					loader._outerWidth( w );	
				}
			}
		}
		loader.showAt(
			$.extend(
				{
					el:at
					,xAlign:'left'
					,yAlign:'bottom'
					,offsetY:-1 
				}
			,opt.dropdownLoadShowAt
			) 
		);
		
		if( $.isFunction( callback ) ) {
			callback.call( self,loader );
		}
		
		return loader;
	},
	__ddt : 0,
	hideDropDownLoading : function( callback ){
		var self = this,
			undef,
			opt = self.configs;	
		var loader = $('#'+opt.id+'_dropdown_loading');	
		if( loader.length ) {
			self.__ddt = setTimeout( function(){
				loader.hide(callback);
				self.__ddt = 0;
			},0 );
		}	
		return self;
	},
	getDropDown : function(){
		var self = this,
			opt = self.configs;	
		return $('#'+opt.id+'_dropdown');
	},
	getDropDownBody : function(){
		var self = this,
			opt = self.configs;	
		return $('#'+opt.id+'_dropdown_body');
	},
	getDropDownListItems : function(){
		var dpb = this.getDropDownBody();
		return $('>.nex-form-dropdown-item',dpb);	
	},
	getDropDownListSelectedItems : function(){
		var dpb = this.getDropDownBody();
		return $('>.nex-form-dropdown-item-selected',dpb);	
	},
	getDropDownListDisabledItems : function(){
		var dpb = this.getDropDownBody();
		return $('>.nex-form-dropdown-item-disabled',dpb);	
	},
	/*
	*创建下拉框 默认一个输入框只能同时存在一个下拉框
	*/
	createDropDown : function(){
		var self = this,
			undef,
			opt = self.configs;
		
		var r = self.fireEvent('onBeforeCreateDropDwon',[ opt ]);	
		if( r === false ) {
			return self;	
		}
		
		var dropdown = $('#'+opt.id+'_dropdown');
		if( dropdown.length ) {
			return dropdown;	
		}
		
		var html = [];	
		//创建dropdown
		html.push('<div id="'+opt.id+'_dropdown" class="nex-form-dropdown '+( opt.dropdownBorder ? "nex-form-dropdown-border" : "" )+' '+opt.dropdownCls+'" tabindex="-1">');
			html.push('<div id="'+opt.id+'_dropdown_body" class="nex-form-dropdown-body " tabindex="-1" >');
			html.push('</div>');
		html.push('</div>');
		
		dropdown = $( html.join('') ).appendTo( document.body );
		
		if( !opt.dropdownSelectionable ) {
			dropdown.disableSelection();		
		}
		
		if( opt.dropdownPadding>0 ) {
			$('#'+opt.id+'_dropdown_body').css('padding',opt.dropdownPadding);	
		}
		
		self._setDropDownEvent();
		
		self.fireEvent('onCreateDropDwon',[ dropdown,opt ]);
		
		return dropdown;
	},
	getDropDownSelectedValue : function(){
		return null;	
	},
	/*
	*创建dropdown内容
	*param {Array} 指定创建下拉框的显示内容 可选 不指定默认获取opt.items
	*/
	// __dropdownMode=1|2  1:列表下拉框 2:组件下拉框 
	__dropdownMode : 1,
	createDropDownList : function( list ){
		var self = this,
			undef,
			value = this.getDropDownSelectedValue(),
			opt = self.configs;
		var html = [];
		var valueKey = opt.valueKey,
			textKey = opt.textKey;
		var list = self._undef( list,self.getDropDownItems() );//opt.items
		/*if( !$.isArray( list ) ) {
			return self;
		}*/
		
		var dlist = {
			items : list	
		};
		var r = self.fireEvent('onBeforeCreateDropDwonList',[ dlist,opt ]);
		if( r === false ) {
			return self;
		}
		list = dlist.items;
		
		var dropdown = $('#'+opt.id+'_dropdown');
		if( !dropdown.length ) {
			dropdown = self.createDropDown();	
		}
		
		//如果items 不是数组 则使用addCompanet 创建自定义组件
		var dp = dropdown;
		var dpb = $('#'+opt.id+'_dropdown_body');
		
		dpb.removeClass('nex-form-dropdown-m1 nex-form-dropdown-m2 nex-form-dropdown-auto-scroll');
		
		if( $.isArray( list ) && opt.dropdownMode == 1 ) {
			self.__dropdownMode = 1;
			dpb.addClass('nex-form-dropdown-m1');
			var v_maps = {};
			if( value !== null ) {
				$.each( String(value).split( opt.multiSplit ),function(i,v){
					v_maps[v] = true;	
				} );
			}
			var len = list.length;
			for( var i=0;i<len;i++ ) {
				var _d = self._parseItemData( list[i] );
				if( v_maps[ _d[valueKey] ] ) {
					_d.selected = true;	
				} else {
					_d.selected = false;		
				}
				list[i] = _d;
				var d = $.extend( {
					id : list[i]['__id'],
					cls : '',
					selected : false,
					disabled : false,
					nowrap : opt.dropdownItemNoWrap,
					tips 	 : ''	
				},_d );
				//设置title
				//dropdownItemTips : false,//下拉列表是否这种tips字段
				//dropdownItemTipsTag : 'title',
				//dropdownItemTipsFilter : null,//function
				if( opt.dropdownItemTips ) {
					var attr_tips = [opt.dropdownItemTipsTag,'="',];
					var tips = self._undef(d['tips'],d[textKey]);
					if( $.isFunction( opt.dropdownItemTipsFilter ) ) {
						tips = 	opt.dropdownItemTipsFilter.call( self,tips,d );
					}
					if( tips ) {
						tips = Nex.htmlEncode( tips );	
					}
					d.tipsMsg = tips;
					d.tipsTag = opt.dropdownItemTipsTag;
					attr_tips.push(tips);
					attr_tips.push('"');
					
					d.tips = attr_tips.join('');
				}
				
				d.text = d[ textKey ];
				d.value = Nex.htmlEncode( d[ valueKey ] );
				
				if( opt.dropdownItemFilter && $.isFunction( opt.dropdownItemFilter ) ) {
					var r = opt.dropdownItemFilter.call( self,d );
					if( r === false ) continue;
					if( r !== undef ) {
						d = r;//$.extend(d,r);	
					}
				}
				
				if( opt.dropdownItemFormat && $.isFunction( opt.dropdownItemFormat ) ) {
					d.text = opt.dropdownItemFormat.call( self,d.text,d ) || d.text;
				}
				
				var r = self.fireEvent("onBeforeDropDownItemCreate",[d,opt]);
				if( r === false ) continue;
				
				var _itemTpl = '';
				if( self.isSplitLine( d ) ) {
					_itemTpl = self.tpl(opt.dropdownItemSplitLineTpl,d);	
				} else {
					_itemTpl = self.tpl(opt.dropdownItemTpl,d);
				}
				var et = {
					itemTpl : _itemTpl,
					itemData : d
				};
				self.fireEvent("onDropDownItemCreate",[et,opt]);
				html.push( et.itemTpl );	
			}	
			if( !len && opt.dropdownEmptyMsg != '' ) {
				html.push( opt.dropdownEmptyMsg );	
			}
			dpb.html( html.join('') );
		} else {
			self.__dropdownMode = 2;
			dpb.addClass('nex-form-dropdown-m2');
			if( opt.dropdownAutoScroll ) {
				dpb.addClass('nex-form-dropdown-auto-scroll');	
			}
			dpb.html( '' );
			Nex.gc();
			self.addComponent( dpb,list );
		}
		
		self.fireEvent('onCreateDropDwonList',[ dropdown,self.__dropdownMode,opt ]);
		
		return dropdown;
	},
	resetDropDownList : function(list){
		var self = this;
		var opt = this.configs;
		var list = this._undef( list,this.getDropDownItems() );
		
		if( $.isFunction( opt.dropdownItemsFilter ) ) {
			var _l = opt.dropdownItemsFilter.call( self,list );	
			if( _l === false ) return self;
			if( _l !== undef ) {
				list = _l;	
			}
		}
		
		var d = {
			items : list	
		};
		
		var r = self.fireEvent('onResetDropDownList',[ d,opt ]);
		if( r === false ) {
			return self;	
		}
		
		list = d.items;
		
		if( $.isArray( list ) ){
			self.__CItems = list;		
		} else {
			self.__CItems.length = 0;	
		}
		
		var dropdown = self.createDropDownList( list );
		
		self.setDropDownSize();
		
		//滚动到默认选中的列表
		//var dsel = $('#'+opt.id+'_dropdown_body').find('>.nex-form-dropdown-item-selected:last');
		//if( dsel.length ) {
		//	self.scrollToItemById( dsel.attr('id') );
		//}
		//刷新位置
		if( self.__DP_isShow ) {
			self.resetDropDownPos();
		}
		return self;	
	},
	__CItems : [],
	_bindCloseDropDownEvents : function(){
		var self = this,
			items = this.getDropDownItems(),//this.configs.items,
			opt = self.configs;		
		self.__unbindDropDown();
		if( opt.dropdownHideOnBlur ) {
			//移除下拉框事件
			$(document).bind('mousewheel.dropdown_'+opt.id+' contextmenu.dropdown_'+opt.id+' mousedown.dropdown_'+opt.id,function(e){
				var target = e.target || e.srcElement;
				//closest parents
				if( $(target).is( '#'+opt.id ) 
					|| $(target).is( '#'+opt.id+'_dropdown' ) 
					|| $(target).parents('#'+opt.id+'_dropdown,#'+opt.id).length
				) {
					//
				} else {
					self.hideDropDown();		
				} 
			});
			$(window).bind('resize.dropdown_'+opt.id,function(){
				self.hideDropDown();			
			});
		}
			//支持上下键选择
		$(document).bind("keydown.dropdown_"+opt.id,function(e){
			var sbody = $("#"+opt.id+"_dropdown_body");
			var cur = sbody.find(">.nex-form-dropdown-item-over:last");
			var isFirst = false;
			if( !cur.length ) {
				cur = sbody.find(">.nex-form-dropdown-item-selected:last");
				if( !cur.length ) {
					cur = sbody.find(">.nex-form-dropdown-item:first");	
					isFirst = true;
				}
			}
			
			if( !cur.length ) return;
			var it = cur;
			var _cur = cur;
			switch( e.keyCode ) {
				case 38 : //up
					sbody.find(">.nex-form-dropdown-item").removeClass("nex-form-dropdown-item-over");
					do {
						var prev = isFirst ? cur : cur.prev();
						if( prev.length ) {
							if( !prev.hasClass('nex-form-dropdown-item') ) {
								cur = prev;
								continue;	
							}
							if( prev.hasClass('nex-form-dropdown-item-disabled') ) {
								cur = prev;
								if( isFirst ) break;
								isFirst = false;
								continue;	
							} else {
								cur = prev;
								_cur = prev;	
							}
						} else {
							prev = _cur;
							if( !prev.hasClass('nex-form-dropdown-item') ) {
								cur = prev;
								isFirst = false;
								break;	
							}	
						}
						isFirst = false;
						
						var oitem = prev.length ? prev : _cur;
						var id = oitem.attr('id');
						var data = self.__getItemData(id);
						
						var r = self.fireEvent("onDropDownItemForward",[data,oitem[0],e,opt]);	
						if( r !== false ) {
							oitem.addClass('nex-form-dropdown-item-over');
						}
						//oitem.addClass("nex-form-dropdown-item-over");		
						if( data ) {
							self.scrollToItem( data );
						}
						break;
					} while(1);
					
					break;
				case 40 : //down
					sbody.find(">.nex-form-dropdown-item").removeClass("nex-form-dropdown-item-over");
					do {
						var next = isFirst ? cur : cur.next();
						isFirst = false;
						if( next.length ) {
							if( !next.hasClass('nex-form-dropdown-item') ) {
								cur = next;
								continue;	
							}
							if( next.hasClass('nex-form-dropdown-item-disabled') ) {
								cur = next;
								//如果需要滚动到disabled的话 需要在这里添加scrollToItem
								continue;	
							} else {
								cur = next;
								_cur = next;	
							}
						} else {
							next = _cur;
							if( !next.hasClass('nex-form-dropdown-item') ) {
								cur = next;
								isFirst = false;
								break;	
							}		
						}
						
						var oitem = next.length ? next : _cur;
						var id = oitem.attr('id');
						var data = self.__getItemData(id);
						
						var r = self.fireEvent("onDropDownItemForward",[data,oitem[0],e,opt]);	
						if( r !== false ) {
							oitem.addClass("nex-form-dropdown-item-over");	
						}
						if( data ) {
							self.scrollToItem( data );
						}
						break;
					} while(1);
					
					break;
				case 13:
					//sbody.find(">.nex-form-dropdown-item-over").trigger('click',[e]);//因为使用的是委托 模拟触发会出现问题
					self.__dp_click(sbody.find(">.nex-form-dropdown-item-over"),e);
					//键盘触发 并不会触发是输入框失去焦点
					//self.blur();
					break;
			}
			
		});	
	},
	setDropDownList : function( list ){
		this.__DP_isShow ? this.resetDropDownList( list ) : 0;	
		return this;	
	},
	resetDropDownSizeAndPos : function(){
		if( this.__DP_isShow ) {
			this.resetDropDownSize();		
			this.resetDropDownPos();
		}
	},
	/*
	*显示下拉框
	*/
	__DP_isShow : false,
	//重复调用showDropDown 并且传参 则会调用resetDropDownList
	showDropDown : function( list,callback ){//list = Nex xtype array func , callback 显示后的回调 
		var self = this,
			undef,
			_func,
			opt = self.configs;
		var _setList = list ? true : false;
		var list = this._undef( list,this.getDropDownItems() );
		
		//如果dropdown 已经是显示状态 则调用reset
		if( self.__DP_isShow && _setList ) {
			self.resetDropDownList( list );	
			return self;
		}
		//开始处理list数据
		
		if( $.isFunction( opt.dropdownItemsFilter ) ) {
			var _l = opt.dropdownItemsFilter.call( self,list );	
			if( _l === false ) return self;
			if( _l !== undef ) {
				list = _l;	
			}
		}
		
		var d = {
			items : list	
		};
		
		var r = self.fireEvent('onBeforeDropDownShow',[ d,opt ]);
		if( r === false ) {
			return self;	
		}
		
		if( !opt.dropdownHideToRemove ) {
			var dropdown = self.getDropDown();
			if( dropdown.length ) {
				//显示之前设置选择状态
				if( self.__dropdownMode == 1 ) {
					var ds = self.getDropDownSelectedValue();
					if( ds !== null ) {
						self.dropdownSelectItems( ds );
					}
				}
				self.setDropDownSize();	
				self._showDropDown(null,dropdown);
				return self;
			}	
		}
		
		list = d.items;
		
		self.__CItems = [];
		
		if( $.isArray( list ) ){//&& opt.dropdownMode == 1
			self.__CItems = list;		
		} else {
			self.__CItems.length = 0;	
		}
		//创建dropdown 容器
		var dropdown = $('#'+opt.id+'_dropdown');
		if( !dropdown.length ) {
			dropdown = self.createDropDown();	
		}
		
		//预判__dropdownMode
		if( $.isArray( list ) && opt.dropdownMode == 1 ) {
			self.__dropdownMode = 1;
		} else {
			self.__dropdownMode = 2;	
			//创建下拉组建时 先设置好宽高
			self._setDropDownSize2();
		}
		//创建下拉框内容
		var dropdown = self.createDropDownList( list );
		//设置下拉框大小
		if( self.__dropdownMode == 1 ) {
			self._setDropDownSize1();
		}
		
		self._showDropDown( callback,dropdown );
		
		return self;
	},
	_showDropDown : function(func,dp){
		var self = this,
			opt = self.configs;		
		var fn = function(){
			self.fireEvent("onDropDownShow",[opt]);
			if( $.isFunction( func ) ) {
				func.call( self );
			}
			if( opt.dropdownShadowShow ) {
				self.dropdownShadowShow();	
			}
			self.__DP_isShow = true;
			self._bindCloseDropDownEvents();
		}	
		//显示之前。。。
		if( self.__dropdownMode == 1 ) {
			//滚动到选中的列表
			var dsel = $('#'+opt.id+'_dropdown_body').find('>.nex-form-dropdown-item-selected:last');
			if( dsel.length ) {
				self.scrollToItemById( dsel.attr('id') );
			}
		}
		
		var dropdown = dp || self.getDropDown();
		self.__DP_isShow = true;
		//显示下拉框 
		var zIndex = Nex.mixins.DropDown.dropdownzIndex+2;
		self.dropdownzIndex = zIndex;
		dropdown.css('zIndex',zIndex);
		if( opt.dropdownAnimate ) {
			self._animateDropDownShow(fn);	
		} else {
			self._defaultDropDownShow(fn);		
		}
		return self;
	},
	/*移除下拉框*/
	removeDropDown : function(){
		return this.hideDropDown.apply(this,arguments);	
	},
	hideDropDown : function( callback ){
		var self = this,
			undef,
			func,
			opt = self.configs;	
			
		var func = function(){
			if( opt.dropdownShadowShow ) {
				self.hideDropDownShadow();	
			}
			self.fireEvent("onDropDownHide",[opt]);
			if( $.isFunction( callback ) ) {
				callback.call( self );
			}
			self.__DP_isShow = false;
		}
		var r = self.fireEvent('onBeforeDropDownHide',[ opt ]);
		if( r === false ) {
			return self;	
		}
		self.__DP_isShow = false;
		self.unsetDropDownEvent();
		
		if( opt.dropdownAnimate ) {
			self._animateDropDownHide(func);	
		} else {
			self._defaultDropDownHide(func);		
		}
		return self;
	},
	__unbindDropDown : function(){
		var opt = this.configs;
		$(document).unbind('.dropdown_'+opt.id);	
		$(window).unbind('.dropdown_'+opt.id);	
	},
	isDropDownCreate : function(){
		var opt = this.configs;
		var dp = $('#'+opt.id+'_dropdown');	
		return dp.length ? true : false;
	},
	//判断dropdown是显示中
	isDropDownShow : function(){
		return this.__DP_isShow;	
	},
	toggleDropDown : function( func ){
		var self = this,
			opt = self.configs;		
		if( self.__DP_isShow ) {
			self.hideDropDown( func );	
		} else {
			self.showDropDown( func );	
		}
		return self;
	},
	_getDropDownOtherHeight : function(){
		return this.configs.dropdownOtherHeight;	
	},
	_getDropDownOtherWidth : function(){
		return this.configs.dropdownOtherWidth;	
	},
	/*计算组件下拉框的大小*/
	__DP_autoWidth : false,
	__DP_autoHeight : false,
	_setDropDownSize1 : function(){
		var self = this,
			opt = self.configs;	
			
		var input = self.getDropDownShowAt();
		var space = self._getShowAtSpace( input );
		space.bottom -= opt.dropdownEdge;
		space.top 	 -= opt.dropdownEdge;
		space.left	 -= opt.dropdownEdge;
		space.right  -= opt.dropdownEdge;
		
		var dp = $('#'+opt.id+'_dropdown');
		var bd = $('#'+opt.id+'_dropdown_body');
		
		//移除之前 我们先获取dropdown的border padding占用空间
		var dph_s = (parseInt(dp.css('paddingTop')) || 0)
					+ (parseInt(dp.css('paddingBottomWidth')) || 0)
					+ (parseInt(dp.css('borderTop')) || 0 )
					+ (parseInt(dp.css('borderBottomWidth')) || 0);
		var dpw_s = (parseInt(dp.css('paddingLeft')) || 0)
					+ (parseInt(dp.css('paddingRight')) || 0)
					+ (parseInt(dp.css('borderLeftWidth')) || 0)
					+ (parseInt(dp.css('borderRightWidth')) || 0);
		
		//注意此处不应该移除dp的width height 因为移除后如果数据太多会突然撑大导致闪屏
		//dp._removeStyle('width height');
		bd._removeStyle('width height');
		
		var win_w = $(window).width() - opt.dropdownEdge;
		//var win_h = $(window).height();
		
		var dw = $.isFunction(opt.dropdownWidth) ? opt.dropdownWidth.call( self,opt ) : opt.dropdownWidth;
		var dh = $.isFunction(opt.dropdownHeight) ? opt.dropdownHeight.call( self,opt ) : opt.dropdownHeight;
		
		if( dw == 'auto' ) {
			dp._removeStyle('width');	
		}
		if( dh == 'auto' ) {
			dp._removeStyle('height');	
		}
		
		dw = dw == 'auto' ? 0 : dw;
		dh = dh == 'auto' ? 0 : dh;
		
		var isAutoHeight = false;
		var isAutoWidth = false;
		
		/*
		*setp1:先计算dropdown的高度
		*/
		var sh = bd.outerHeight() + dph_s;//作用等同于 dp.outerHeight 但是我们不能直接用这个 
		var h = dh > 0 ? dh : sh;
		var max_h = $.isFunction(opt.dropdownMaxHeight) ? opt.dropdownMaxHeight.call( self,opt ) : opt.dropdownMaxHeight;
		var min_h = $.isFunction(opt.dropdownMinHeight) ? opt.dropdownMinHeight.call( self,opt ) : opt.dropdownMinHeight;
		//var min_space = Math.min( space.bottom,space.top );
		//if( h > min_space ) {//这个判断可不要
		h = Math.min( h,Math.max(space.bottom,space.top) );
		//}
		if( min_h>0 ) {
			h = Math.max( h,min_h );
		}
		if( max_h>0 ) {
			h = Math.min( h,max_h );
		}
		isAutoHeight = true;
		if( dh != 0 || h != sh ) {
			isAutoHeight = false;
			dp._outerHeight( h );
			bd._outerHeight( dp.height()-self._getDropDownOtherHeight() );	
		} else {
			dp._removeStyle('height');	
		}
		//step2:再计算宽度 注意：必须要先设置高度后在获取宽度
		var sw = bd.outerWidth() + dpw_s;//作用等同于 dp.outerWidth
		var w = dw > 0 ? dw : sw;
		var max_w = $.isFunction(opt.dropdownMaxWidth) ? opt.dropdownMaxWidth.call( self,opt ) : opt.dropdownMaxWidth;
		var min_w = $.isFunction(opt.dropdownMinWidth) ? opt.dropdownMinWidth.call( self,opt ) : opt.dropdownMinWidth;
		min_w = min_w>0?min_w:input._outerWidth();
		w = Math.max( w,min_w );
		w = Math.min( w,win_w );
		if( max_w>0 ) {
			w = Math.min( w,max_w );	
		}
		
		isAutoWidth = true;
		if( dw != 0 || w != sw ) {
			isAutoWidth = false;
			dp._outerWidth( w );
			bd._outerWidth( dp.width()-self._getDropDownOtherWidth() );	
		} else {
			dp._removeStyle('width');	
			//做些微调整 如果出现了滚动条 应该加上滚动条的宽度
			var hasScroll = Nex.hasScroll( bd,'top' );
			if( hasScroll ) {
				isAutoWidth = false;
				var sbar = self.getScrollbarSize();
			 	w += (sbar.y + self._getDropDownOtherWidth());
				w = Math.min( w,win_w );
				dp._outerWidth( w );
				bd._outerWidth( dp.width() );	
			}
		}
		//记录状态
		self.__DP_autoWidth = isAutoWidth;
		self.__DP_autoHeight = isAutoHeight;
		
		self.fireEvent( 'onSetDropDownSize',[dp,1,opt] );
		
		return self;
	},
	_setDropDownSize2 : function(){
		var self = this,
			opt = self.configs;		
	
		var input = self.getDropDownShowAt();	
		
		var dp = $('#'+opt.id+'_dropdown');
		var bd = $('#'+opt.id+'_dropdown_body');
		
		//dropdownAutoScroll
		var win_w = $(window).width() - opt.dropdownEdge;
		var win_h = $(window).height() - opt.dropdownEdge;
		
		var w = $.isFunction(opt.dropdownWidth) ? opt.dropdownWidth.call( self,opt ) : opt.dropdownWidth,
			h = $.isFunction(opt.dropdownHeight) ? opt.dropdownHeight.call( self,opt ) : opt.dropdownHeight
			inputW = input._outerWidth();
		
		if( w == 0 ) {
			w = inputW;
		}
		h = parseInt( h,10 );
		h = isNaN(h) ? 0 : h;
		
		var isAutoHeight = false;
		var isAutoWidth = false;
		
		if( h == 0 || h == 'auto' ) {
			dp._removeStyle( 'height' );	
			bd._removeStyle( 'height' );
			isAutoHeight = true;	
			if( dp.outerHeight() > win_h ) {
				dp._outerHeight( win_h );	
				bd._outerHeight( dp.height() - self._getDropDownOtherHeight() );	
				isAutoHeight = false;		
			}
		} else {
			isAutoHeight = false;		
			dp._outerHeight( h );	
			bd._outerHeight( dp.height() - self._getDropDownOtherHeight() );		
		}
		
		if( w == 'auto' ) {
			isAutoWidth = true;
			dp._removeStyle( 'width' );	
			bd._removeStyle( 'width' );	
			if( dp.outerWidth() > win_w ) {
				isAutoWidth = false;
				dp._outerHeight( win_w );	
				bd._outerHeight( dp.width() - self._getDropDownOtherWidth() );			
			}
		} else {
			isAutoWidth = false;
			w = parseInt( w,10 );
			w = isNaN(w) ? inputW : w;
			dp._outerWidth( w );	
			bd._outerWidth( dp.width() - self._getDropDownOtherWidth() );	
		}
		//记录状态
		self.__DP_autoWidth = isAutoWidth;
		self.__DP_autoHeight = isAutoHeight;
		//应该计算最大最小
		self.fireEvent( 'onSetDropDownSize',[dp,2,opt] );
		
		return self;
	},
	setDropDownSize : function(){
		var self = this,
			opt = self.configs;	
		
		if( self.__dropdownMode == 2 ) {
			return 	self._setDropDownSize2();
		} else {
			return 	self._setDropDownSize1();	
		}
	},
	resetDropDownSize : function(){
		return this.setDropDownSize();
	},
	//@private
	__dp_click : function($this,e){
		var self = this;
		var opt = this.configs;
		var $$this = $($this);
		var id = $$this.attr('id');
		var data = self.__getItemData(id);
		
		if( data.disabled || $$this.hasClass('nex-form-dropdown-item-disabled') ) {
			return;	
		}
		
		var r = self.fireEvent("onDropDownItemClick",[data,$this,e,opt]);	
		if( r !== false ) {
			self._dropdownItemsSelect( data,$this,e );
		}
	},
	//设置选择状态
	dropdownSelectItems : function( value ){
		var self = this;
		var opt = this.configs;	
		var sep = opt.multiSplit;
		var dpb = $('#'+opt.id+'_dropdown_body');
		//self.unselectDropDownAll();
		var selected = String(value).split( sep );
		var _s = {};
		$.each(selected,function(i,v){
			_s[v] = true;	
		});	
		$('>.nex-form-dropdown-item',dpb).each( function(){
			var v = $(this).attr('value');
			if( v in _s ) {
				$(this).addClass('nex-form-dropdown-item-selected');	
			} else {
				$(this).removeClass('nex-form-dropdown-item-selected');	
			}
		} );
		return self;
	},
	_dropdownItemsSelect : function(data,el,e){
		var self = this;
		var opt = this.configs;	
		var $el = $(el);
		var isSelected = $el.hasClass('nex-form-dropdown-item-selected');
		if( opt.dropdownSingleSelect ) {
			if( isSelected ) {
				return;	
			}
			self.unselectDropDownAll();	
			$el.addClass('nex-form-dropdown-item-selected');
			//data.selected = true;
			if( opt.dropdownHideOnClick ) {
				self.hideDropDown();	
			}	
			self.fireEvent("onDropDownItemSelected",[data,el,e,opt]);
			self.fireEvent("onDropDownItemSelectedChange",[data[opt.valueKey],data[opt.textKey],data,el,e,opt]);
		} else {
			var sep = opt.multiSplit;
			var dpb = $('#'+opt.id+'_dropdown_body');
			var value = [];
			var text = [];
			if( isSelected ) {
				$el.removeClass('nex-form-dropdown-item-selected');
				self.fireEvent("onDropDownItemUnSelected",[data,el,e,opt]);
				//data.selected = false;
			} else {
				$el.addClass('nex-form-dropdown-item-selected');	
				self.fireEvent("onDropDownItemSelected",[data,el,e,opt]);
				//data.selected = true;
			}
			$('>.nex-form-dropdown-item-selected',dpb).each( function(){
				value.push( $(this).attr('value') );	
			} );
			$.each( value,function(i,v){
				var d = self.__getItemData( v,false );	
				if( d ) {
					text.push( d[ opt.textKey ] );		
				} else {
					text.push( v );	
				}
			} );
			self.fireEvent("onDropDownItemSelectedChange",[value.join(sep),text.join(sep),data,el,e,opt]);
		}
	},
	//@private
	__getItemData : function( id,isId ){
		var self = this,
			items = this.getDropDownItems(),
			opt = self.configs;	
		var isId = self._undef( isId, true );	
		var d = null;
		$.each( items.concat(self.__CItems) , function(i,v){
			if( !$.isPlainObject( v ) ) return;
			var value = isId ? v['__id'] : v[ opt.valueKey ];
			if( String(value) === String(id) ) {
				d = v;
				return false;
			}
		} );	
		return d;		
	},
	/*下拉框事件*/
	_setDropDownEvent : function(){
		var self = this,
			opt = self.configs;	
			
		var list = $('#'+opt.id+'_dropdown_body');
		
		var getItemData = function( id ){
			return self.__getItemData( id );
		};
		var _click = function(e){
			self.__dp_click(this,e);	
		};
		//下拉框列表事件
		list.undelegate('>.nex-form-dropdown-item')
			.delegate('>.nex-form-dropdown-item',{
			"mouseenter" : function(e){
				var $this = $(this);
				var id = $this.attr('id');
				var data = getItemData(id);
				
				if( data.disabled || $this.hasClass('nex-form-dropdown-item-disabled') ) {
					return;	
				}
				
				var r = self.fireEvent("onDropDownItemOver",[data,this,e,opt]);	
				if( r !== false ) {
					$this.addClass('nex-form-dropdown-item-over');
				}
			},
			"mouseleave" : function(e){
				var $this = $(this);
				var id = $this.attr('id');
				var data = getItemData(id);
				if( data.disabled || $this.hasClass('nex-form-dropdown-item-disabled') ) {
					return;	
				}
				
				var r = self.fireEvent("onDropDownItemOut",[data,this,e,opt]);	
				if( r !== false ) {
					$this.removeClass('nex-form-dropdown-item-over');
				}
			},
			"click" : _click
		});
		
		self.unsetDropDownEvent();
		
		self.fireEvent( 'onSetDropDownEvent',[opt] );
		
		return self;
	},
	/*
	*滚动到指定item
	*param value
	*/
	scrollToItem : function(val){
		var self = this;
		var opt = self.configs;	
		var items = self.getDropDownItems();//opt.items;
		var id = '';
		
		if( typeof val === 'object' ) {
			val = val[opt.valueKey];	
		}
		
		for( var i=0;i<items.length;i++ ) {
			if( items[i]['value']+'' === val+'' ) {
				id = items[i]['__id'];
				break;
			}	
		}
		
		if( !id ) {
			return self;	
		}
		
		var body = $("#"+opt.id+"_dropdown_body");
		
		if( !body.length ) {
			return self;	
		}
		
		var offset = body.offset();
		var h = body._outerHeight();
		
		var f = $("#"+id);
		if( !f.length ) {
			return self;	
		}
		
		var fo = f.offset();
		var fh = f._outerHeight();
		
		var outerHeight = 0;
		if( offset.top > fo.top ) {
			outerHeight = offset.top - fo.top;
		} else if( (offset.top+h) < (fo.top+fh) ) {
			outerHeight = (offset.top+h) - (fo.top+fh);
		}
		
		var sTop = 0;
		
		sTop = body.scrollTop() - outerHeight;
		
		body.scrollTop( sTop );
		
		return self;
	},
	scrollToItemById : function( id ){
		var self = this,
			opt = self.configs;	
		
		var d = self.__getItemData(id);
		if( d ) {
			self.scrollToItem( d );
		}
		return self;
	},
	unsetDropDownEvent : function(){
		var self = this,
			opt = self.configs;
		self.fireEvent('onUnsetDropDownEvent',[ opt ]);
		self.__unbindDropDown();
		return self;
	},
	//取消所有选中状态
	unselectDropDownAll : function(){
		var self = this,
			undef,
			opt = self.configs;
		var items = self.getDropDownItems();	
		$.each( items.concat(self.__CItems),function(i,d){
			if( typeof d === 'object' ) {
				d.selected = false;	
			}
		} );
		$('#'+opt.id+'_dropdown_body').find('>.nex-form-dropdown-item-selected').removeClass('nex-form-dropdown-item-selected');
		return self;
	},
	__DP_ShowAlign : 'bottom',
	/*默认动画显示下拉框*/
	_defaultDropDownShow : function( callback ){
		var self = this,
			undef,
			func,
			opt = self.configs;	
		var dropdown = $('#'+opt.id+'_dropdown');
		func = $.isFunction( callback ) ? callback : null;	
		
		dropdown._show();
		dropdown._visible(true);
		
		var at = self.getDropDownShowAt();
		dropdown.showAt(
			$.extend(
				{
					el:at
					,visibleEdge : opt.dropdownEdge
					,xAlign:'left'
					,yAlign:'bottom'
					,offsetY:0
					,autoShow : true
					,"onShow.dropdown" : function(pos,conf){
						self.__DP_ShowAlign = conf.yAlign;
						dropdown.removeClass('nex-form-dropdown-'+conf.yAlign);
						dropdown.addClass('nex-form-dropdown-'+conf.yAlign);
					} 
				}
			,opt.dropdownShowAt
			) 
		);
		
		if( $.isFunction( func ) ) {
			func.call( self,dropdown );
		}
		return self;
	},
	resetDropDownPos : function(){
		var self = this,
			undef,
			func,
			opt = self.configs;	
		var dropdown = $('#'+opt.id+'_dropdown');
		var at = self.getDropDownShowAt();
		
		var showat = Nex.Create('showAt',$.extend(
			  {
				  el:at
				  ,visibleEdge : opt.dropdownEdge
				  ,xAlign:'left'
				  ,yAlign:'bottom'
				  ,offsetY:0
			  }
			 ,opt.dropdownShowAt,{
				 source : dropdown
				 ,autoShow : false 
			 }
		  ));
		  
		  var pos = showat.getShowPos();
		  var yAlign = showat.C('yAlign');
		  
		  self.__DP_ShowAlign = yAlign;
		  
		  var shadow = null;
		  if( opt.dropdownShadowShow ) {
				shadow = self.getDropDownShadow();
				shadow.hide();
		  }
		  
		  dropdown.stop(true,true).animate(pos,opt.dropdownResetPosDuration,function(){
			  if( opt.dropdownShadowShow && shadow ) {
					shadow.show();
				}
			  self.resetDropDownShadow(); 
		  });
		
		return self;	
	},
	_defaultDropDownHide : function( callback ){
		var self = this,
			undef,
			opt = self.configs;	
		self.__DP_isShow = false;	
		var dp = $('#'+opt.id+'_dropdown');	
		//_visible(true|false)
		dp.stop(true,true)._visible( false )._hide();
		
		if( opt.dropdownHideToRemove ) {
			dp.remove();	
		}
		
		if( $.isFunction( callback ) ) {
			callback.call( self );
		}
		return self;
	},
	_animateDropDownShow : function( callback ){
		var self = this,
			undef,
			func,
			opt = self.configs;	
		var dropdown = $('#'+opt.id+'_dropdown');
		var db = $('#'+opt.id+'_dropdown_body');
		func = $.isFunction( callback ) ? callback : null;	
		
		//显示dropdown
		dropdown._show();
		dropdown._visible(true);
		
		var at = self.getDropDownShowAt();
		var showat = Nex.Create(
			'showAt',
			$.extend(
				{
					el:at
					,visibleEdge : opt.dropdownEdge
					,xAlign:'left'
					,yAlign:'bottom'
					,offsetY:0,
					"onShow.dropdown" : function(pos,conf){
						self.__DP_ShowAlign = conf.yAlign;
						dropdown.removeClass('nex-form-dropdown-'+conf.yAlign);
						dropdown.addClass('nex-form-dropdown-'+conf.yAlign);
					} 
				}
			,opt.dropdownShowAt
			,{ 
				source : dropdown
				,autoShow : false
			 }
			) 
		);
		
		var pos = showat.getShowPos();
		var yAlign = showat.C('yAlign');
		self.__DP_ShowAlign = yAlign;
		//----
		dropdown.removeClass('nex-form-dropdown-'+yAlign);
		dropdown.addClass('nex-form-dropdown-'+yAlign);
		var sh = dropdown.height();
		var _sh = dropdown.outerHeight();
		//如果dropdown是auto-width情况下设置宽度
		if( self.__DP_autoWidth ) {
			dropdown.width( dropdown.width() );
		}
		dropdown.height(0);
		
		db.addClass('nex-form-dropdown-anim-'+yAlign);
		
		var animBack = function(){
			self.__DP_ShowAlign = yAlign;
			dropdown.removeClass('nex-form-dropdown-'+yAlign);
			dropdown.addClass('nex-form-dropdown-'+yAlign);
			db.removeClass( 'nex-form-dropdown-anim-'+yAlign );
			if( self.__DP_autoWidth ) {
				dropdown._removeStyle( 'width' );
			}
			if( self.__DP_autoHeight ) {
				dropdown._removeStyle( 'height' );
			}
			//回调
			if( $.isFunction( func ) ) {
				func.call( self,dropdown );
			}		
		};
		
		if( yAlign === 'bottom' ) {
			dropdown.css( pos );
			dropdown.stop(true,true).animate({ height : sh },opt.dropdownDuration,opt.dropdownEasing,animBack);
		} else {
			var pos2 = {
					left : pos.left,
					top : pos.top+_sh
				}	
			dropdown.css( pos2 );	
			dropdown.stop(true,true).animate({ height : sh,top : pos.top },opt.dropdownDuration,opt.dropdownEasing,animBack);
		}
		return self;
	},
	_animateDropDownHide : function( callback ){
		return this._defaultDropDownHide.apply( this,arguments );
	},
	dropdownShadowShow : function(){
		var self = this,
			undef,
			opt = self.configs;
		var r = self.fireEvent('onBeforeDropDownShadowShow',[opt]);
		if( r === false ) {
			return self;	
		}	
		var shadow = $('#'+opt.id+'_dropdown_shadow');
		if( !shadow.length ) {
			shadow = $('<div id="'+opt.id+'_dropdown_shadow" class="nex-form-dropdown-shadow">'+(Nex.IEVer<=8?'<iframe style="width:99%;height:99%;"></iframe>':'')+'</div>').appendTo(document.body);
		}
		shadow.show();	
		var dropdown = self.getDropDown();
		shadow._width( dropdown.outerWidth() );
		shadow._height( dropdown.outerHeight() );
		shadow.css( dropdown.offset() )
			  .css( 'zIndex',self.dropdownzIndex-1 );
		self.fireEvent('onDropDownShadowShow',[opt]);
		shadow.removeClass('nex-form-dropdown-shadow-top nex-form-dropdown-shadow-bottom');
		shadow.addClass('nex-form-dropdown-shadow-'+self.__DP_ShowAlign);
		return self;
	},
	resetDropDownShadow : function(){
		var self = this,
			undef,
			opt = self.configs;
		var shadow = $('#'+opt.id+'_dropdown_shadow');
		var dropdown = self.getDropDown();
		shadow._width( dropdown.outerWidth() );
		shadow._height( dropdown.outerHeight() );
		
		shadow.css( dropdown.offset() );
		
		shadow.removeClass('nex-form-dropdown-shadow-top nex-form-dropdown-shadow-bottom');
		shadow.addClass('nex-form-dropdown-shadow-'+self.__DP_ShowAlign);
		return self;	
	},
	hideDropDownShadow : function(){
		var self = this,
			undef,
			opt = self.configs;
		var r = self.fireEvent('onBeforeDropDownShadowHide',[opt]);
		if( r === false ) {
			return self;	
		}		
		var shadow = $('#'+opt.id+'_dropdown_shadow');
		if( opt.dropdownHideToRemove ) {
			shadow.remove();
		} else {
			shadow.hide();	
		}
		self.fireEvent('onDropDownShadowHide',[opt]);
		return self;	
	},
	getDropDownShadow : function(){
		var self = this,
			opt = self.configs;	
		return $('#'+opt.id+'_dropdown_shadow');	
	},
	destroyDropDown : function(){
		if( this.isDropDownShow() ) {
			this.hideDropDown();
		}
		var dp = this.getDropDown();
		var dps = this.getDropDownShadow();
		dp.remove();
		dps.remove();
		this.__DP_isShow = false;
		this.__unbindDropDown();
		return this;
	}	
});
/*
draggable - jQuery Nex
nobo
zere.nobo@gmail.com
qq : 505931977
var drag = new Nex.draggable({helper:$('#drag')});
*/
;(function($){
	"use strict";
	//var drag = Nex.widget('draggable');
	var drag = Nex.extend('Nex.menu.drag',{
		alias : 'Nex.Drag',
		xtype : 'drag draggable'		
	});
	$.dragable = $.nexDragable = drag;
	
	drag.extend({
		version : '1.0', 
		getDefaults : function(opt){
			var _opt = {
				prefix : 'drag-',
				cursor:'move',
				_cursor : '',
				appendTo : null,//document.body
				clone : false,
				helper:null,//用于触发移动的元素 必须
				target: null,//最终需要移动的元素
				disabled: false,
				axis:null,	// v or h
				parent : null,
				afterDrag : null,//停止移动后可自定义函数实现
				delay : 0, //当鼠标点下后，延迟指定时间后才开始激活拖拽动作（单位：毫秒）。
				distance : 0, //当鼠标点下后，只有移动指定像素后才开始激活拖拽动作。
				opacity : false,//当元素开始拖拽时，改变元素的透明度。
				_opacity : 1,
				_revertConf : {},//还原信息
				revert :　false,//当元素拖拽结束后，元素回到原来的位置。   
				revertDuration : 500,//当元素拖拽结束后，元素回到原来的位置的时间。（单位：毫秒）
				revertEasing : 'easeOutCubic',
				moveHelper : null,//移动中的元素
				left : 0,//moveHelper移动后的位置 
				top : 0,
				_sLeft : 0,//moveHelper初始位置
				_sTop : 0,
				_ssLeft : 0,//moveHelper滚动条初始位置
				_ssTop : 0,
				_sX : 0, //初始坐标
				_sY : 0,
				offsetX : 0,
				offsetY : 0,
				_sPosition : '',
				_dragging : false,
				edge : 0,//无效边缘
				events : {
					onStart : $.noop,//初始化事件
					onBeforeDrag : $.noop,
					onStartDrag : $.noop,
					onDrag : $.noop,
					onStopDrag : $.noop,
					onAfterDrag : $.noop
				}
			};
			var _opt = this.extSet(_opt);
			
			return $.extend({},_opt,opt);
		}
	});
	drag.fn.extend({
		_init : function(opt) {
			var self = this;
			
			if( !opt.helper && !opt.target ) return;
			if( !opt.helper ) {
				opt.helper = opt.target;	
			}
			var target = null;
            if (typeof opt.target == 'undefined' || opt.target == null){
                target = opt.helper;
            } else {
                target = (typeof opt.target == 'string' ? $(opt.target) : opt.target);
            }
			
			//opt.parent = $(target).offsetParent();
			opt.target = target;
			
			$(opt.helper).data('nex.draggable', self);
			
			opt.helper.bind('mousedown.draggable', $.proxy( self,'mouseDown' ));
			opt.helper.bind('mousemove.draggable', $.proxy( self,'mouseMove' ));
			opt.helper.bind('mouseleave.draggable', $.proxy( self,'mouseLeave' ));
		},
		
		//系统事件
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			//self.bind("onStart",self.onStart);	
		},
		_doDown : function(e){
			var self = this;
			var opt = self.configs;
			
			$(document).bind("selectstart.draggable",function(){return false;});	
			
			var r = self.fireEvent('onStartDrag',[e,opt]);
			if( r === false) return;
			
			//$('body').css('cursor', opt.cursor);
		},
		_doMove : function(e){
			var self = this;
			var opt = self.configs;
			if( opt.disabled ) return;
			
			var offsetX = e.pageX - opt._sX;
			var offsetY = e.pageY - opt._sY;
			
			opt.offsetX = offsetX;
			opt.offsetY = offsetY;
			
			if( opt.distance && !opt._dragging ) {
				
				var dist = Math.max( Math.abs( offsetX ),Math.abs( offsetY ) );
				if( dist<opt.distance ) {
					return;	
				}
				
			}
			if( !opt._dragging ) {
				var r = self.fireEvent('onBeforeDrag',[e,opt]);
				if( r === false) return;
				
				self._startMove();
				
				opt._dragging = true;
			}
			
			//var parent = $(opt.moveHelper).parent();
			var cLeft = 0;//parent.scrollLeft();
			var cTop = 0;//parent.scrollTop();
			
			var left = opt._sLeft + offsetX + cLeft - opt._ssLeft;
			var top = opt._sTop + offsetY + cTop - opt._ssTop;
			
			if (opt.axis == 'h') {
				opt.left = left;
				opt.top = opt._sTop;
			} else if (opt.axis == 'v') {
				opt.left = opt._sLeft;
				opt.top = top;
			} else {
				opt.left = left;
				opt.top = top;
			}
			
			var r = self.fireEvent('onDrag',[e,opt]);
			if( r === false) return;
			
			self.moveToPosition(opt.left,opt.top,e);	
			
		},
		_doUp : function(e){
			var self = this;
			var opt = self.configs;
			$(document).unbind('.draggable');	
			/*setTimeout(function(){
				$('body').css('cursor','');
			},100);*/
			if( !opt._dragging ) {
				return;	
			}
			opt._dragging = false;
			$('body').css('cursor',opt._cursor);
			/*var endDrag = function(){
				opt._dragging = false;	
			};*/
			var r = self.fireEvent('onStopDrag',[e,opt]);
			if( r === false ) {//easeOutCubic
				self._revertEl();
			} else {
				//self.moveToPosition(opt.left,opt.top,e);	
				var afterDrag = function(){
					if( opt.revert === true ) {
						self._revertEl();	
					} else if( opt.revert === false ) {
						self._endMove();
					}	
				};
				if( $.isFunction( opt.afterDrag ) ) {
					afterDrag = opt.afterDrag;	
				}
				afterDrag.call(self);
			}
			//因为onStopDrag后会继续设置target的坐标实际上onStopDrag并不是最终触发的事件，onAfterDrag才是最终触发的事件
			self.fireEvent('onAfterDrag',[e,opt]);
		},
		_revertEl : function(){
			var self = this;
			var opt = self.configs;
			var call = function(){
				$(opt.moveHelper).css( 'opacity',opt._opacity );
				if( opt.clone ) {
					$(opt.moveHelper).remove();	
				}	
				if( opt.appendTo ) {
					opt._revertConf.revert();
					opt._revertConf.target[0].style.cssText = opt._revertConf.cssText;
					opt._revertConf.parent.scrollTop( opt._revertConf.sTop );
					opt._revertConf.parent.scrollLeft( opt._revertConf.sLeft );
				}
			};
			if( opt.revertDuration>0 ) {
				$(opt.moveHelper).animate({
					left:opt._sLeft,
					top:opt._sTop
				}, opt.revertDuration, opt.revertEasing ,function(){
					call();
				});	
			} else {
				$(opt.moveHelper).css({
					left:opt._sLeft,
					top:opt._sTop
				});	
				call();
			}
		},
		_getFixPositionSize : function( op ){
			
			var _c = parseFloat(op.css('borderLeftWidth')),
			_e = parseFloat(op.css('paddingLeft')),
			_c1 = parseFloat(op.css('borderTopWidth')),
			_e1 = parseFloat(op.css('paddingTop'));
			_c = isNaN( _c ) ? 0 : _c;
			_e = isNaN( _e ) ? 0 : _e;
			_c1 = isNaN( _c1 ) ? 0 : _c1;
			_e1 = isNaN( _e1 ) ? 0 : _e1;
			return {
				left : _c + _e,
				top : _c1 + _e1
			};		
		},
		_startMove : function(){
			var self = this;
			var opt = self.configs;
			
			opt._cursor = $('body').css('cursor');
			$('body').css('cursor',opt.cursor);
			
			opt.moveHelper = $(opt.target);	
			var _rv = opt.moveHelper;
			var _rvp = opt.moveHelper.parent();
			if( opt.appendTo ) {
				//记录初始位置和信息
				opt._revertConf = {
					target : opt.moveHelper,
					parent : _rvp,
					sLeft : _rvp.scrollLeft(),
					sTop : _rvp.scrollTop()
				};
				var prev = _rv.prev();
				var next = _rv.next();
				if( prev.size() ) {
					opt._revertConf.revert = function(){
						prev.after( _rv );
					}	
				} else if( next.size() ) {
					opt._revertConf.revert = function(){
						prev.before( _rv );
					}	
				} else {
					opt._revertConf.revert = function(){
						_rvp.prepend( _rv );
					}	
				}
				opt._revertConf.cssText = _rv[0].style.cssText;
			}
			
			if( opt.clone ) {
				opt.moveHelper = $(opt.target).clone();
			}
			
			if( opt.appendTo ) {
				var offset1 = $(opt.target).offset();
				var offset2 = $(opt.appendTo).offsetParent().offset();
				$(opt.appendTo).append( opt.moveHelper );
				if( opt.clone ) {
					$(opt.appendTo).append( opt.target );	
				}
				var offset2 = $(opt.target).offsetParent().offset(),
					_s = self._getFixPositionSize( $(opt.appendTo).offsetParent() );
				$(opt.target).css({
					position : 'absolute',
					left : offset1.left - offset2.left - _s.left,
					top : offset1.top - offset2.top - _s.top
				});
			} else {
				if( opt.clone ) {
					$(opt.target).parent().append( opt.moveHelper );	
				}
			}
			
			//var parent = $(opt.target).parent();
			opt._ssLeft = 0;//parent.scrollLeft();
			opt._ssTop = 0;//parent.scrollTop();
			var position = $(opt.target)._position();
			opt.left = position.left;
			opt.top = position.top;
			
			var target = opt.moveHelper;
			opt._sLeft = opt.left + opt._ssLeft;
			opt._sTop = opt.top + opt._ssTop;
			
			target.css('position','absolute');
			if( opt.clone ) {
				target.css({		   
					left : 	opt._sLeft,
					top : opt._sTop
				});
			}
			opt._opacity = target.css('opacity');
			if( opt.opacity ) {
				target.css( 'opacity',opt.opacity );
			}
			
			return self;
		},
		_endMove : function(){
			var self = this;
			var opt = self.configs;
			
			//self.moveToPosition( opt.left,opt.top );
			$(opt.target).css( {
				position : 'absolute',
				left : opt.left,
				top : opt.top
			} );
			
			$(opt.moveHelper).css( 'opacity',opt._opacity );
			if( opt.clone ) {
				$(opt.moveHelper).remove();
			}
		},
		moveToPosition : function(left,top,e){
			var self = this;
			var opt = self.configs;
			
			var target = $(opt.moveHelper);
			//var parent = target.parent();
			
			target.css({
				left : left,
				top : top
				//position : 'absolute'
			});
		},
		mouseDown : function(e){
			var self = this;
			var opt = self.configs;
			
			if( self.checkDisabledEdge(e) ) {
				//opt.helper.css('cursor', '');
				return;
			}
			
			opt._sX = e.pageX;
			opt._sY = e.pageY;
			
			var st = 0;
			if( opt.delay>0 ) {
				st = setTimeout( function(){
					st = 0;
					$(document).bind('mousedown.draggable', $.proxy( self,'_doDown' ));
					$(document).bind('mousemove.draggable', $.proxy( self,'_doMove' ));	
					$(document).bind('mouseup.draggable', $.proxy( self,'_doUp' ));		
				},opt.delay );	
				$(document).one('mouseup.draggable', function(){
					if( st ) {
						clearTimeout( st );	
					}											   
				});
			} else {
				$(document).bind('mousedown.draggable', $.proxy( self,'_doDown' ));
				$(document).bind('mousemove.draggable', $.proxy( self,'_doMove' ));	
				$(document).bind('mouseup.draggable', $.proxy( self,'_doUp' ));	
			}
			
		},
		mouseMove : function(e){
			var self = this;
			var opt = self.configs;
			
			if( opt._dragging ) return;
			
			if( self.checkDisabledEdge(e) ) {
				//opt.helper.css('cursor', '');
				return;
			}
			
			//opt.helper.css('cursor', opt.cursor);
		},
		mouseLeave : function(e){
			var self = this;
			var opt = self.configs;
			
			if( opt._dragging ) return;
			
			if( self.checkDisabledEdge(e) ) {
				//opt.helper.css('cursor', '');
				return;
			}
			
			//opt.helper.css('cursor', '');	
		},
		//移除可拖拽
		removeDragable : function(){
			var self = this;
			var opt = self.configs;
			
			$(opt.helper).data('nex.draggable', null);
			
			opt.helper.unbind('mousedown.draggable');
			opt.helper.unbind('mousemove.draggable');
			opt.helper.unbind('mouseleave.draggable');
			return true;
		},
		checkDisabledEdge : function(e){
			var self = this;
			var opt = self.configs;
			var offset = $(opt.helper).offset();
			var width = $(opt.helper).outerWidth();
			var height = $(opt.helper).outerHeight();
			var t = e.pageY - offset.top;
			var r = offset.left + width - e.pageX;
			var b = offset.top + height - e.pageY;
			var l = e.pageX - offset.left;
			return Math.min(t,r,b,l) < opt.edge;
		}
	});
	$.fn.draggable = function(options, param){
		var options = options || {};
		if (typeof options == 'string'){
			switch(options) {
				case 'options':
					return $(this[0]).data('nex.draggable').C();
				case 'disabled':
					return this.each(function(){
								$(this).data('nex.draggable').C('disabled',true);
							});
				case 'enable':
					return this.each(function(){
								$(this).data('nex.draggable').C('disabled',false);
							});
				default : 
					return this.each(function(){
						if( param ) {
							$(this).data('nex.draggable').C(options,param);
						}
					}); 
			}
		}
		
		return this.each(function(){
			var opt;
			var self = $(this).data('nex.draggable');
			if (self) {
				opt = self.configs;
				$.extend(opt, options);
				return;
			}
			options.helper = $(this);
			new Nex.Drag(options);
		});
	};
})(jQuery);
/*
resizable - jQuery Nex
nobo
zere.nobo@gmail.com
qq : 505931977
var drag = new Nex.resizable({target:$('#drag')});
*/
;(function($){
	"use strict";
	//var resize = Nex.widget('resizable');
	var resize = Nex.extend('Nex.resize.Resize',{
		alias : 'Nex.Resize',
		xtype : 'resize resizable'		
	});
	
	resize.extend({
		version : '1.0', 
		getDefaults : function(opt){
			var _opt = {
				target: null,
				disabled: false,
				handles:'n, e, s, w, ne, se, sw, nw, all',
				minWidth: 10,
				minHeight: 10,
				maxWidth: 10000,//$(document).width(),
				maxHeight: 10000,//$(document).height(),
				edge : 5,//移动边缘宽度
				left : 0,
				top : 0,
				_sLeft : 0,
				_sTop : 0,
				_sX : 0,
				_sY : 0,
				_sWidth : 0,
				_sHeight : 0,
				width : 0,
				height : 0,
				dir : '',
				events : {
					onStart : $.noop,//初始化事件
					onBeforeResize : $.noop,
					onStartResize : $.noop,
					onResize : $.noop,
					onStopResize : $.noop
				}
			};
			var _opt = this.extSet(_opt);
			
			return $.extend({},_opt,opt);
		}
	});
	resize.fn.extend({
		_init : function(opt) {
			var self = this;
			
			if( !opt.target ) return;
			
			$(opt.target).data('nex.resizable', self);
			
			opt.target.bind('mousedown.resizable', $.proxy( self,'mouseDown' ));
			opt.target.bind('mousemove.resizable', $.proxy( self,'mouseMove' ));
			opt.target.bind('mouseleave.resizable', $.proxy( self,'mouseLeave' ));
		},
		//系统事件
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			//self.bind("onStart",self.onStart);	
		},
		getDirection : function(e) {
			var self = this;
			var opt = self.configs;
			var tt = $(opt.target);
			var dir = '';
			var offset = tt.offset();
			var width = tt.outerWidth();
			var height = tt.outerHeight();
			var edge = opt.edge;
			if (e.pageY > offset.top && e.pageY < offset.top + edge) {
				dir += 'n';
			} else if (e.pageY < offset.top + height && e.pageY > offset.top + height - edge) {
				dir += 's';
			}
			if (e.pageX > offset.left && e.pageX < offset.left + edge) {
				dir += 'w';
			} else if (e.pageX < offset.left + width && e.pageX > offset.left + width - edge) {
				dir += 'e';
			}
			
			var handles = opt.handles.split(',');
			for(var i=0; i<handles.length; i++) {
				var handle = handles[i].replace(/(^\s*)|(\s*$)/g, '');
				if (handle == 'all' || handle == dir) {
					return dir;
				}
			}
			return '';
		},
		resize : function(e){
			var self = this;
			var opt = self.configs;
			
			if (opt.dir.indexOf('e') != -1) {
				var width = opt._sWidth + e.pageX - opt._sX;
				width = Math.min(
							Math.max(width, opt.minWidth),
							opt.maxWidth
						);
				opt.width = width;
			}
			if (opt.dir.indexOf('s') != -1) {
				var height = opt._sHeight + e.pageY - opt._sY;
				height = Math.min(
						Math.max(height, opt.minHeight),
						opt.maxHeight
				);
				opt.height = height;
			}
			if (opt.dir.indexOf('w') != -1) {
				opt.width = opt._sWidth - e.pageX + opt._sX;
				if (opt.width >= opt.minWidth && opt.width <= opt.maxWidth) {
					opt.left = opt._sLeft + e.pageX - opt._sX;
				}
			}
			if (opt.dir.indexOf('n') != -1) {
				opt.height = opt._sHeight - e.pageY + opt._sY;
				if (opt.height >= opt.minHeight && opt.height <= opt.maxHeight) {
					opt.top = opt._sTop + e.pageY - opt._sY;
				}
			}
			
		},
		setWH : function(){
			var self = this;
			var opt = self.configs;	
			var v = $(opt.target).outerWidth() - $(opt.target).width();
			var h = $(opt.target).outerHeight() - $(opt.target).height();
			
			$(opt.target).width( opt.width-v );
			$(opt.target).height( opt.height-h );
		},
		_doDown : function(e){
			var self = this;
			var opt = self.configs;
			
			$(document).bind("selectstart.resizable",function(){return false;});	
			
			var r = self.fireEvent('onStartResize',[e,opt]);
			if( r === false) return;
		},
		_doMove : function(e){
			var self = this;
			var opt = self.configs;
			if( opt.disabled ) return;
			
			self.resize(e);
			
			var r = self.fireEvent('onResize',[opt.width,opt.height,e,opt]);
			if( r === false) return ;
			
			self.setWH();
		},
		_doUp : function(e){
			var self = this;
			var opt = self.configs;
			
			//self.resize(e);
			
			var r = self.fireEvent('onStopResize',[opt.width,opt.height,e,opt]);
			if( r !== false) {
				self.setWH();	
			}
			
			$(document).unbind('.resizable');
			$('body').css('cursor','');
		},
		mouseDown : function(e){
			var self = this;
			var opt = self.configs;
			
			var dir = self.getDirection(e);
			if (dir == '') return;
			
			function getCssValue(css) {
				var val = parseInt($(opt.target).css(css));
				if (isNaN(val)) {
					return 0;
				} else {
					return val;
				}
			}
			
			opt.dir = dir;
			opt._sLeft = getCssValue('left');
			opt._sTop = getCssValue('top');
			opt.left = getCssValue('left');
			opt.top = getCssValue('top');
			opt._sX = e.pageX;
			opt._sY = e.pageY;
			opt._sWidth = $(opt.target).outerWidth();
			opt._sHeight = $(opt.target).outerHeight();
			opt.width = $(opt.target).outerWidth();
			opt.height = $(opt.target).outerHeight();
			
			var r = self.fireEvent('onBeforeResize',[e,opt]);
			if( r === false) return;
		
			$(document).bind('mousedown.resizable', $.proxy( self,'_doDown' ));
			$(document).bind('mousemove.resizable', $.proxy( self,'_doMove' ));
			$(document).bind('mouseup.resizable', $.proxy( self,'_doUp' ));	
			$('body').css('cursor', dir+'-resize');	
		},
		mouseMove : function(e){
			var self = this;
			var opt = self.configs;
			
			var dir = self.getDirection(e);
			if (dir == '') {
				$(opt.target).css('cursor', '');
			} else {
				$(opt.target).css('cursor', dir + '-resize');
			}
		},
		mouseLeave : function(e){
			var self = this;
			var opt = self.configs;
			
			$(opt.target).css('cursor', '');
		}
	});
	$.fn.resizable = function(options, param){
		var options = options || {};
		if (typeof options == 'string'){
			switch(options) {
				case 'options':
					return $(this[0]).data('nex.resizable').C();
				case 'disabled':
					return this.each(function(){
								$(this).data('nex.resizable').C('disabled',true);
							});
				case 'enable':
					return this.each(function(){
								$(this).data('nex.resizable').C('disabled',false);
							});
				default : 
					return this.each(function(){
						if( param ) {
							$(this).data('nex.resizable').C(options,param);
						}
					}); 
			}
		}
		
		return this.each(function(){
			var opt;
			var self = $(this).data('nex.resizable');
			if (self) {
				opt = self.configs;
				$.extend(opt, options);
				return;
			}
			options.target = $(this);
			new Nex.Resize(options);
		});
	};
})(jQuery);
/*
jquery.nexShowAt.js
http://www.extgrid.com/nexShowAt
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
eg1:
var at = new Nex.showAt({source:'#t1',el:'#t2'});
eg2:
$("#t1").showAt("#t2"[,{xAlign:'right'}]);
*/

;(function($){
	"use strict";
	//var showAt = Nex.define('Nex.showat.ShowAt').setXType('showAt').setXType('showat');
	var showAt = Nex.extend('Nex.showat.ShowAt',{
		alias : 'Nex.ShowAt Nex.showAt',
		xtype : 'showat showAt'		
	});
	showAt.extend({
		version : '1.0',
		getDefaults : function(opt){
			var _opt = {
				prefix : 'showAt-',
				denyManager : true,
				autoDestroy : true,
				source : null,
				autoShow : false,//是否自动显示
				openAtOpt : true,//开启后 可使用参数 at 代替el来设置，只是助于理解
				at : null,
				el : null,// 相当于at 或者 一个 坐标eg {left:0,top:2}
				parent : document.body,//source 的父元素 会自动获取offsetParent
				autoRegion : true,//自动调整显示方位
				visibleable : true,//必定可见 相对于source的父元素
				visibleEdge : 0,//距离right bottom的最小宽度
				visibleEdgeLT : 0,//距离 left top的最小宽度
				offsetX : 0,//正 负 分别代表外离 内缩
				offsetY : 0,//同上
				zAlign : 'y',// x:横 y:竖
				xAlign : 'center',// left right center
				yAlign : 'center',//top cenger bottom
				animate : null,//动画显示函数 默认直接show
				events : {
					onStart : $.noop,
					onShow : $.noop,
					onGetPosition : $.noop,
					onBeforeAdaptRegion : $.noop,
					onAdaptRegion : $.noop,
					onAdaptPosition : $.noop,
					onBeforeShow : $.noop
				}
			};
			
			var _opt = this.extSet(_opt);
			
			return $.extend({},_opt,opt);
		}
	});
	showAt.fn.extend({
		_init : function(opt) {
			var self = this,undef;
			
			self.parseSource()
				.parseEl();
			
			self.fireEvent("onCreate",[opt]);	
			
		},
		parseSource : function(){
			var self = this;
			var opt = self.configs;	
			
			if( opt.openAtOpt && opt.at !== null ) {
				opt.el = opt.at;	
			}
			var s = $(opt.source);
			if( s.is(':hidden') ) {
				s.show();
				opt.parent = s.offsetParent();//如果source的display 设置为 none 则会是返回body
				s.hide();
			} else {
				opt.parent = s.offsetParent();	
			}
			//曾经在chrome下获取得到的是一个html
			opt.parent = opt.parent.is('html') ? $(document.body) : opt.parent;
			return self;
		},
		parseEl : function(){
			var self = this;
			var opt = self.configs;	
			if( opt.el === null ) {
				opt.el = opt.parent;
				if( opt.el.is('body') ) {
					opt.el = window;	
				}
			} else {
				if( $(opt.el).is('body') ) {
					opt.el = window;	
				}
			}
			opt.el = (opt.el === document) ? window : opt.el;
			return self;
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.bind("onCreate",self._checkToShow,self);
			return self;
		},
		_checkToShow : function(){
			var self = this;
			var opt = self.configs;
			if( opt.autoShow ) {
				self.show();	
			}		
		},
		//获取 source元素的 offsetParent
		getRender : function(p){
			var self = this,undef;
			var opt = self.configs;
			var parent = p === undef ? opt.parent : $(p);
			if( parent.is('body') || parent.is('html') ) {//opt.el === window || 
				return window;	
			} else {
				return  parent[0];	
			}
		},
		//返回相对于parent(renderTo)的绝对位置
		getOffset : function(el){
			var self = this,undef;
			var opt = self.configs;	
			var renderTo = self.getRender();
			
			if( $._isPlainObject( el ) ) {
				el.left = el.left === undef ? 0 : el.left ;
				el.top = el.top === undef ? 0 : el.top ;
				var offset = $.extend({},el);
				
				var sLeft = $(renderTo).scrollLeft();
				var sTop = $(renderTo).scrollTop();
				offset.left += sLeft;
				offset.top += sTop;
				return offset;
			}
			
			if( $.isWindow(renderTo) ) {// === window
				var offset = $(el).offset();//el是个纯对象时 会返回null
				var sLeft = $(window).scrollLeft();
				var sTop = $(window).scrollTop();
				//return !offset ? {left:sLeft,top:sTop} : offset;	
				return !offset ? {left:sLeft,top:sTop} : offset;	
			} else {
				var renderTo = $(renderTo);
				var sLeft = renderTo.scrollLeft();
				var sLeftBorder = parseFloat(renderTo.css('borderLeftWidth'));
				sLeftBorder = isNaN( sLeftBorder ) ? 0 : sLeftBorder;
				var sLeftPadding = parseFloat(renderTo.css('paddingLeft'));
				sLeftPadding = isNaN( sLeftPadding ) ? 0 : sLeftPadding;
				
				var sTop = renderTo.scrollTop();
				var sTopBorder = parseFloat(renderTo.css('borderTopWidth'));
				sTopBorder = isNaN( sTopBorder ) ? 0 : sTopBorder;
				var sTopPadding = parseFloat(renderTo.css('paddingTop'));
				sTopPadding = isNaN( sTopPadding ) ? 0 : sTopPadding;
				var offset = {
					left : 0,
					top : 0
				};
				try {
					var rOffset = renderTo.offset();
					var eOffset = $(el).offset();	
					//offset = $(el).position();	
					offset = {
						left : eOffset.left - rOffset.left - sLeftBorder - sLeftPadding,
						top : eOffset.top - rOffset.top - sTopBorder - sTopPadding
					};	
				} catch(e){
					//..el 不是dom	
					sLeft = 0;
					sTop = 0;
				}
				return {
					left : 	sLeft + offset.left,
					top : sTop + offset.top
				};
			}
		},
		//获取el[at]周围可显示空间
		getShowSpace : function(el,parent){
			var self = this,undef;
			var opt = self.configs;
			if( opt.el === undef && parent ) {
				el = parent;	
			}
			var el = self._undef(el,opt.el);
			var parent = self._undef(parent,opt.parent);
			//需要获取的对象
			var obj = $(el);
			
			var renderTo = self.getRender(parent);//getOffsetParent
			
			//获取窗口显示区域大小
			var cw = $(renderTo).width();
			var ch = $(renderTo).height();
			
			var offset = self.getOffset(el);
			
			//获取滚位置
			var sLeft = $(renderTo).scrollLeft();
			var sTop = $(renderTo).scrollTop();
			
			var space = {
				top : offset.top - sTop,
				left : offset.left - sLeft
			};
			space.bottom = ch - space.top - ( $._isPlainObject(el) ? 0 : obj._outerHeight() );
			space.right = cw - space.left - ( $._isPlainObject(el) ? 0 : obj._outerWidth() );
			
			return space;
		},
		/*
		*检测是否有足够的空间显示
		*@param a bottom top right left
		*@param el 
		*/
		checkSpace : function(a,s,e,r){
			var self = this;
			var opt = self.configs;	
			var space = self.getShowSpace();// opt.el,opt.parent
			if( space[a]<=0 ) return false;
			var _r = true;
			switch(a){
				case 'bottom':
					_r = s.height>space.bottom?false:true;
					break;
				case 'top' : 
					_r =  s.height>space.top?false:true;
					break;
				case 'right' :
					_r = s.width>space.right?false:true;
					break;
				case 'left' :
					_r = s.width>space.left?false:true;
					break;
			};
			return _r;
		},
		/*
		*根据当前的设置自动适配对应显示位置
		*/
		adaptRegion : function(s,e,r){
			var self = this;
			var opt = self.configs;	
			var zAlign = opt.zAlign.toLowerCase();
			var xAlign = opt.xAlign.toLowerCase();
			var yAlign = opt.yAlign.toLowerCase();
			var space = self.getShowSpace();
			
			var _r = self.fireEvent('onBeforeAdaptRegion',[/*xAlign,yAlign,zAlign,*/opt]);
			if( _r === false ) return false;
			if( zAlign==='y' ) {
				if( yAlign==='center' ) return;
				var sp = self.checkSpace(yAlign,s,e,r);
				if( sp === false ) {
					var _yAlign = yAlign==='bottom' ? 'top' : 'bottom';
					var sp = self.checkSpace(_yAlign,s,e,r);	
					if( sp ) {
						opt.yAlign = _yAlign;
					} else {
						if( space.bottom > space.top ) {
							opt.yAlign = 'bottom';	
						} else if( space.bottom < space.top ) {
							opt.yAlign = 'top';		
						} //===情况
						//opt.yAlign = space.bottom>=space.top?'bottom':'top';	
					}
				}
			} else {
				if( xAlign==='center' ) return;
				var sp = self.checkSpace(xAlign,s,e,r);
				if( sp === false ) {
					var _xAlign = xAlign==='right' ? 'left' : 'right';
					var sp = self.checkSpace(_xAlign,s,e,r);	
					if( sp ) {
						opt.xAlign = _xAlign;
					} else {
						if( space.left > space.right ) {
							opt.yAlign = 'left';	
						} else if( space.left < space.right ) {
							opt.yAlign = 'right';		
						} //===情况
						//opt.xAlign = space.left>=space.right?'left':'right';	
					}
				}	
			}	
			self.fireEvent('onAdaptRegion',[/*opt.xAlign,opt.yAlign,opt.zAlign,*/opt]);
		},
		/*是否出现水平滚动条*/ 
		//scrollHeight scrollWidth
		hasScrollBarX : function(el){
			return Nex.hasScroll(el,'left');
		},
		/*是否出现垂直滚动条*/
		hasScrollBarY : function(el){
			return Nex.hasScroll(el);
		},
		adaptPosition : function(pos){
			var self = this;
			var opt = self.configs;
			var renderTo = self.getRender();
			
			//if( !$.isWindow(renderTo) ) return pos;
			
			var winWidth = $(renderTo).width();
			var winHeight = $(renderTo).height();
			if( !$.isWindow(renderTo) ) {
				var scrollbarSize = self.getScrollbarSize();
				if( self.hasScrollBarX(renderTo) ) {
					winHeight -= scrollbarSize.width;	
				}
				if( self.hasScrollBarY(renderTo) ) {
					winWidth -= scrollbarSize.height;	
				}
			}
			/*
			*有个小bug @已修正
			*如果renderTo 不是window时，应该判断renderTo 是否出现滚动条 然后winWidth - scrollBarWidth,winHeight - scrollBarWidth
			*/
			
			//获取滚位置
			var sLeft = $(renderTo).scrollLeft();
			var sTop = $(renderTo).scrollTop();
			var width = self.getWidth(opt.source);
			var height = self.getHeight(opt.source);
			var edge = opt.visibleEdge;//Number>0
			var edge_lt = opt.visibleEdgeLT;//top left 的edge
			//计算出 bottom right 的超出edge部分 eg 如果edge=5 计算出x=4那么可以得到4-5 = -1 超出-1px
			var x = winWidth + sLeft - pos.left - width;
			var y = winHeight + sTop - pos.top - height;
			//计算bottom right 的edge
			//x = x<0?x:0;
			//y = y<0?y:0;
			x = x<edge?x-edge:0;
			y = y<edge?y-edge:0;
			//计算 top left 的edge 此处的 edge_lt 可以换成 edge 
			pos.left = (pos.left + x - sLeft)<edge_lt?sLeft+edge_lt:(pos.left + x);
			pos.top = (pos.top + y - sTop)<edge_lt?sTop+edge_lt:(pos.top + y);
			
			self.fireEvent('onAdaptPosition',[pos,opt]);
			return pos;
		},
		getWidth : function(el){
			var self = this;
			var opt = self.configs;
			return $._isPlainObject(el) ? 0 : $(el)._outerWidth();
		},
		getHeight : function(el){
			var self = this;
			var opt = self.configs;
			return $._isPlainObject(el) ? 0 : $(el)._outerHeight();
		},
		/*
		*x_inner_top x_inner_bottom y_inner_left y_inner_right
		*/
		x_innerleft : function(s,e,r){
			var self = this;
			var opt = self.configs;
			return e.left + opt.offsetX;
		},
		x_innerright : function(s,e,r){
			var self = this;
			var opt = self.configs;
			return e.left + ( e.width-s.width ) - opt.offsetX;
		},
		y_innertop : function(s,e,r){
			var self = this;
			var opt = self.configs;
			return e.top + opt.offsetY;
		},
		y_innerbottom : function(s,e,r){
			var self = this;
			var opt = self.configs;
			return e.top + ( e.height-s.height ) - opt.offsetY;
		},
		x_left : function(s,e,r){
			var self = this;
			var opt = self.configs;
			var zAlign = opt.zAlign.toLowerCase();
			return zAlign==='y' ? e.left + opt.offsetX : e.left-s.width - opt.offsetX ;
		},
		x_center : function(s,e,r){
			var self = this;
			var opt = self.configs;
			return e.left+(e.width-s.width)/2;
			//return (e.width-s.width)/2;
		},
		x_right : function(s,e,r){
			var self = this;
			var opt = self.configs;
			var zAlign = opt.zAlign.toLowerCase();
			return zAlign==='y' ? e.left + ( e.width-s.width ) - opt.offsetX : e.left+e.width + opt.offsetX ;
		},
		y_top : function(s,e,r){
			var self = this;
			var opt = self.configs;
			var zAlign = opt.zAlign.toLowerCase();
			return zAlign==='y' ? e.top-s.height - opt.offsetY : e.top-( s.height-e.height ) - opt.offsetY;
		},
		y_center : function(s,e,r){
			var self = this;
			var opt = self.configs;
			var zAlign = opt.zAlign.toLowerCase();
			return e.top+(e.height-s.height)/2;
			//return (e.height-s.height)/2;
		},
		y_bottom : function(s,e,r){
			var self = this;
			var opt = self.configs;
			var zAlign = opt.zAlign.toLowerCase();
			return zAlign==='y' ? e.top+e.height + opt.offsetY : e.top + opt.offsetY;
		},
		
		fixPosition : function(pos,opt){
			var self = this;
			
			/*if( opt.parent[0] !== document.body ) {
				if( $.support.boxModel == true ) {
					var _pos = $(opt.parent).offset();
					pos.left = pos.left- _pos.left;
					pos.top = pos.top- _pos.top;
				}
			}*/
			return pos;
		},
		unFixPosition : function(pos,opt){
			var self = this;
			/*if( opt.parent[0] !== document.body ) {
				if( $.support.boxModel == true ) {
					var _pos = $(opt.parent).offset();
					pos.left = pos.left + _pos.left;
					pos.top = pos.top + _pos.top;
				}
			}*/
			return pos;
		},
		getShowPos : function(){
			var self = this;
			var opt = self.configs;
			//滚动位置
			var renderTo = self.getRender();
			var sLeft = $(renderTo).scrollLeft();
			var sTop = $(renderTo).scrollTop();
			var scrollPos = {
				left : sLeft,
				top : sTop
			};
			//源数据
			var source = self.getOffset(opt.source);
			source.width = self.getWidth( opt.source );
			source.height = self.getHeight( opt.source );
			//目标数据
			var target = self.getOffset(opt.el);
			target.width = self.getWidth( opt.el );
			target.height = self.getHeight( opt.el );
			//自动设置或获取显示方位
			if( opt.autoRegion ) {
				self.adaptRegion(source,target,scrollPos);
			}
			
			//获取显示位置
			var _func = function(func){
				var getPos = null;
				if( func in opt ) {
					getPos = opt[func];	
				} else if( func in self ) {
					getPos = self[func];		
				} else if( func in window ) {
					getPos = window[func];	
				} else {
					getPos = function(){return {left:0,top:0};};	
				}
				return getPos;
			}
			var x_func = 'x_'+opt.xAlign.toLowerCase();
			var y_func = 'y_'+opt.yAlign.toLowerCase();
			var pos = {
				left : _func(x_func).call(self,source,target,scrollPos),
				top : _func(y_func).call(self,source,target,scrollPos) 
			};
			var _pos = false;
			
			if( opt.visibleable ) {
				_pos = self.adaptPosition(pos);	
			}
			var p = _pos ? _pos : pos;
			//对显示坐标做最终检测
			p = self.fixPosition(p,opt);
			
			self.fireEvent("onGetPosition",[p,opt]);
			//位置的最后修改
			return p;
		},
		/*
		*显示到指定位置
		*@param left 可选,
		*@param top 可选
		*/
		showAtPos : function(left, top){},
		/*
		*@param el 可选 如果为可选 则默认使用opt.source
		*@param options 可选 显示参数
		*/
		showAtEl : function(el, options){},
		show : function(){
			var self = this,
				opt=this.configs;	
			//不建议在这里获取坐标
			//因为如果改变at的position为absolute时 source的位置会改变，使得showAt会出现错乱	
			//var pos = self.getShowPos();
			var r = self.fireEvent("onBeforeShow",[pos,opt]);
			if( r === false ) return false;
			var callBack = function(){
				self.fireEvent("onShow",[pos,opt]);	
			}
			if( $.isFunction(opt.animate) ) {
				var pos = self.getShowPos();//单独获取
				opt.animate.call(self,opt.source,pos,callBack);	
			} else {
				var src = $(opt.source);
				var position = $(opt.source).css('position');
				if( position === 'static' || position === 'relative' ) {
					//pos.position = 'absolute';
					src.css('position','absolute');
				}
				var pos = self.getShowPos();//单独获取
				src.css(pos).show();
				callBack();
			}
		}
	});
	$.fn.showAt = function(options,conf){
		var undef,opt;
		var conf = conf === undef ? {} : conf;
		if( options === undef ) {
			opt = {}	
		}else if( !$._isPlainObject(options) ) {
			opt = { el:options };	
			$.extend(opt,conf);
		} else {
			opt = 	options;
		}
		var list = [];
		this.each(function(){
			opt.source = $(this);
			opt.autoShow = true;
			var o = Nex.Create('showAt',opt);
			//o.show();
			list.push(o);
			//$(this).data('nex.showAt',o);
		});
		return list.length === 1 ? list[0] : list;
	};
})(jQuery);
/*
Nex.Form  继承 Nex.Html
xtype form|textfield
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
*/
;$define([
	'Nex.util.Validate',
	'Nex.Html',
	'Nex.mixins.DropDown',
	'Nex.showat.ShowAt'
],function(){
	"use strict";
	var form = Nex.define('Nex.form.Form','Nex.Html',{
		alias : 'Nex.Form',
		xtype : 'form',
		mixins : [ 'DropDown' ]	
	});
	
	Nex.form = form;//兼容以前版本
	Nex.form.Form = form;
	
	form.extend({
		version : '1.0',
		dropdownzIndex : 999999+Nex.zIndex,
		//list : {},
		fieldList : {},
		isExists : function(id){
			if( !$( "#"+id ).length ) {
				return false;
			}	
			return true;
		},
		/*
		*根据name , group 获取输入框对象
		*@param {string} 输入框name
		*@param {string} 输入框分组
		*@return {array}
		*/
		get : function(name,group){
			var self = this,
				undef;
			if( name === undef ) return [];
			
			var group = self._undef( group , 'default' );
			
			var ls = [];
			
			var list = self.fieldList;
			for( var id in list ) {
				var cmp = Nex.getCmp(id);
				//var fields = list[ group ];
				if( !cmp ) {
					delete list[id];
					continue;	
				}
				var _opt = cmp.configs;
				var _name = _opt.name;
				var _group = String( _opt.group ).split(/\s+|,/);
				if( String( _name ) === String( name ) && $.inArray( String( group ), _group ) !== -1 ) {
					ls.push(cmp);		
				}
			}
			return ls;//ls.length == 1 ? ls[0] : ls
		},
		/*
		*用法同get只是find只会取第一个并返回
		*/
		"find" : function(){
			var re = [];
			re = this.get.apply( this,arguments );	
			return ls.length ? ls[0] : null;
		},
		/*
		*@m 如果为true则多个数据不转换字符串
		*/
		getVal : function(name,group,m){
			var self = this;
			if( $.type( group ) !== 'string' || group === '' ) {
				group = 'default';	
			}
			var obj = self.get.apply(self,[ name,group ]);
			var val = [];
			var m = self._undef( m,false );
			if( $.isArray(obj) ) {
				$.each(obj,function(){
					var _val = this.val();
					if( _val !== '' ) {
						val.push( _val );	
					}
				});
				var _v = {};
				var _s = false;
				$.each( val,function(i,value){
					if( $._isPlainObject( value ) ) {
						_s = true;
						$.each( value,function(k,v){
							_v[k] = _v[k] || [];
							_v[k].push( v );					   
						} );	
					} else {
						_v[name] = _v[name] || [];
						_v[name].push( value );
					}			 
				} );
				if( !_s ) {
					_v[name] = _v[name] || [];
					val = !m ? _v[name].join(',') : _v[name];		
				} else {
					val = _v;	
					if( $._isPlainObject( val ) ) {
						$.each( val,function(x,d){
							d = d || [];
							d[x] = !m ? d.join(',') : d;	
						} );
					}
				}
				return val;	
			}
			return {};
		},
		getValue : function(){
			return this.getVal.apply( this,arguments );	
		},
		setVal : function(value,name,group){
			var self = this;
			var obj = self.get.apply(self,[arguments[1],arguments[2]]);
			var val = [];
			if( $.isArray(obj) ) {
				$.each(obj,function(i,f){
					if( $.isArray( value ) ) {
						this.val(self._undef(value[i],''));	
					} else {
						this.val(value);
					}
				});
				return true;
			}
			return null;
		},
		setValue : function(){
			return this.setValue.apply( this,arguments );		
		},
		/*
		*@param {string} 分组 默认default
		*@param {boolean} 默认 false 不获取disabled的输入框 如果为true则获取
		*@param {boolean} 默认 false 返回组件 否则返回name
		*/
		getGroup : function(group,m,t){
			var self = this;
			var group = self._undef( group , 'default' );	
			var m = self._undef( m , false );	
			var t = self._undef( t , false );	
			var list = self.fieldList;
			var inputs = [];
			var names = {};
			var _fields = [];
			for( var id in list ) {
				var cmp = Nex.getCmp(id);
				if( !cmp ) {
					delete list[id];
					continue;	
				}
				var _opt = cmp.configs;
				var _name = _opt.name;
				var isDisabled = _opt.disabled;
				if( !m && isDisabled ) {
					continue;	
				}
				var _group = String( _opt.group ).split(/\s+|,/);
				if( $.inArray( String( group ), _group ) === -1 ) {
					continue;
				}
				_fields.push( cmp );
				if( !t ) {
					inputs.push( cmp );	
				} else {
					if( !names[ _name ] ) {
						inputs.push( _name );
					}
				}
				names[ _name ] = true;
			}
			
			inputs.call =function(){
				var argvs = [].slice.apply(arguments);
				if( !argvs.length ) return self;
				var method = argvs[0];
				argvs.splice(0,1);
				$.each( _fields,function(i,o){
					if( o[method] && $.isFunction( o[method] ) ) {
						o[method].apply( o,argvs );	
					}
				} );
				return self;	
			};
			return 	inputs;
		},
		getGroupName : function(group,m){
			return this.getGroup.apply( this,[ group,m,true ] );	
		},
		//获取某分组下的所有值
		/*
		*@m 是否获取disabled 字段 默认不获取 false
		*@t 如果为true如果多个数据不转换字符串
		*/
		getGroupVal : function(group,m,t){
			var self = this;
			var group = self._undef( group , 'default' );	
			var m = self._undef( m , false );	
			var groupNames = self.getGroupName(group,m);
			var data = {};
			$.each(groupNames,function(i,name){
				var value = self.getVal( name,group,t );
				if( $._isPlainObject( value ) ) {
					$.extend( data,value );	
				} else {
					data[ name ] = value;	
				}
			});
			return data;
		},
		getGroupValue : function(){
			return this.getGroupVal.apply( this,arguments );	
		},
		setGroupVal : function(data,group){
			var self = this;
			var data = data || {};
			if( $.isPlainObject( data ) && !$.isEmptyObject(data) ) {
				$.each( data,function(name,value){
					self.setVal( value,name,group );	
				} );	
			}
			return self;
		},
		setGroupValue : function(){
			return this.setGroupVal.apply( this,arguments );		
		},
		//验证是否通过，并返回错误的字段name
		/*
		*m 是否验证disabled 字段 默认不验证 false
		*/
		checkGroup : function(group,m) {
			var self = this;
			var group = self._undef( group , 'default' );	
			var m = self._undef( m , false );	
			var list = self.getGroup( group,m );
			var errorList = [];
			var r;
			for( var i=0;i<list.length;i++ ) {
				var field = list[i];
				r = field.checkVal();
				if( r === false ) {
					errorList.push(field.C('name'));	
				}
			}
			return errorList.length ? errorList : true;
		},
		//验证某分组是否通过
		/*
		*m 是否验证disabled 字段 默认不验证 false
		*/
		valid : function(group,m){
			var self = this;
			var r = self.checkGroup(group,m);
			return r === true ? true : false;
		},
		//验证某一元素
		checkField : function( name,group ){
			var self = this;
			var obj = self.get.apply( self,arguments );
			obj = $.isArray( obj ) ? obj : [obj];
			var re = true;
			$.each(obj,function(i,input){
				if( !input.checkVal() ) {
					re = false;
				}
			});
			return re;
		},
		resetGroup : function( group,m ){
			var self = this;
			var group = self._undef( group , 'default' );	
			var m = self._undef( m , false );	
			var list = self.getGroup( group,m );
			for( var i=0;i<list.length;i++ ) {
				var field = list[i];
				field.reset();
			}
			return self;	
		},
		"reset" : function(){
			return this.resetGroup.apply(this,arguments);	
		}
	});
	form.setOptions( function( opt ){
		return {
			prefix : 'nexform-',
			renderTo : document.body,
			//当DOM不存在是允许回收当前对象
			autoDestroy : true,
			//表单默认设置的是固定宽度，关闭了大小只适应
			autoResize : false,
			//From没有BodyView，虽然有但是大小不会改变
			_hasBodyView : false,
			_checkScrollBar : false,
			//不需要多余事件绑定
			denyEvents : true,
			autoWidthCls : [opt.autoWidthCls,'nex-form-auto-width'].join(' '),
			autoHeightCls : [opt.autoHeightCls,'nex-form-auto-height'].join(' '),
			borderCls : [opt.borderCls,'nex-form-border'].join(' '),
			containerCls : [opt.containerCls,'nex-form'].join(' '),
			//不是容器，不需要开启
			autoScroll : false,
			autoScrollCls : '',
			//是否创建后获得焦点
			autoFocus : false,
			//表单自带tabIndex,关闭系统自带的
			tabIndex : false,
			//多选控件时数据的分隔符
			multiSplit : ',',
			/*private*/
			__inputType : 'text',
			//是否显示Label
			showLabel : 'auto',//是否开启Label显示 atuo:如果存在labelText==''则不显示 否则显示， true:显示 false：不显示  
			labelCls : '',
			labelStyle : {},
			labelvAlign : 'top', // top middle bottom
			labelPosition : 'left',//left top bottom right
			labelAlign : 'left',
			labelText : '',
			labelWidth : 80,
			showPlaceholder : true,
			placeholder : '',
			autocomplete : 'off',
			//显示规则：inline block
			display : 'inline',
			//设置分组
			group : 'default',//分组
			//表单name
			name : '',
			//表单默认值
			value : '',
			_value : '',
			//默认情况下 如果inputText的文字改变是应该触发onChange
			//但是combobox 可选下拉框 就不需要触发onChange  
			//因为这些选择框的值都必须在items中选择
			inputTextChangeEvent : 'onChange',
			//inner或者outer
			triggerBtnsPosition : 'inner',
			triggerBtns : [],
			triggerBtnSelection : false,
			//点击triggerBtn输入框也会获得焦点 默认关闭
			triggerToFocus : false,
			//清空按钮
			cleanBtn : false,
			cleanDefault : '',//清除后的默认值
			inputAttrs : {},
			//数据设置时改变数据的值
			formater : null,
			//数据获取是可改变数据的值
			getFormater : null,
			//数据设置最终控制
			setFormater : null,
			//数据映射，单纯的数据显示时用 并不会实际改变输入框的值 eg : {1:'01'} 显示的时候是01 获取到的值是 1
			renderer : {},
			_renderer : {},//反renderer
			rendererDef : '_default_',
			validator : Nex.formValid || {},
			rules : [],
			showVaildMsg : true, //验证成功或者失败时 提示验证信息
			vaildMsgPosition : 'right', // top bottom left right
			validMsg : '',//验证提示信息，会一直存在
			validMsgOnFocus : '',//获得焦点时的提示信息
			validErrorMsg : '请填写正确信息！',
			validSuccessMsg : '通过信息验证！',
			//验证成功或者错误时提示信息
			//{ required : '当前数据不能为空！',email : '邮箱地址填写不正确',... } 不存在这使用validErrorMsg
			messages : {},
			validErrorCls : 'nex-form-valid-error',
			validSuccessCls : 'nex-form-valid-success',
			textKey : 'text',
			valueKey : 'value',
			items : [],//{cls:'',text:'年龄',value:'45',readOnly:false,disabled:false,selected:true,attrs:''} or '|' ',' ';'
			//_multiItems : [],//multi缓存数据
			splitChr : ['-',',',';','|'],
			_item :　{
				cls:'',
				text:'',
				value:'',
				readOnly:false,
				disabled:false,
				selected:false,
				title : '',//multiSelect
				display : 'inline-block'
			},
			itemDefault : {},
			//加载items时是否显示loading提示
			showItemsLoading : false,//暂时无效
			//加载items的ajax参数设置
			_ajaxOptions : {
				dataType : 'json',	
				type : 'GET'
			},//ajax自定义默认参数
			ajaxOptions : {},//ajax自定义参数
			width : 150,
			height : 'auto',//textarea multselect
			autoValidDelay : 50,
			autoValidEvents : ['onChange','onBlur','onPaste'],//什么时候进行数据验证
			disabled : false,
			readOnly : false,
			cls : '',
			overCls : '',
			focusCls : '',
			disabledCls : '',
			readonlyCls : '',
			dropdownMinWidth : 0,//设置下拉列表的最小宽度和input宽度一样
			tpl : {
				formTpl : '<table id="<%=id%>-inner" class="nex-field nex-form-inner" cellspacing="0" cellpadding="0" ><tbody>'
								+'<tr id="<%=id%>-inputRow">'
									+'<td class="nex-form-inner-body" id="<%=id%>-body-td">'
										+'<div id="<%=id%>-body" class="nex-form-body">'
											+'<div <%=attrs%> id="<%=id%>-input" type="<%=type%>" name="<%=name%>" autocomplete="<%=autocomplete%>" tabindex=<%=tabIndex%> value="" style="/*width:0px;*/" class="nex-form-field nex-form-field-<%=type%>"></div>'
											+'<label id="<%=id%>-placeholder" class="nex-form-placeholder"><%=placeholder%></label>'//for="<%=id%>-input"
											+'<div id="<%=id%>-trigger-body" class="nex-form-trigger-body"></div>'
										 +'</div>'
									+'</td>'
								+'</tr>'
							+'</tbody></table>'
			},
			events : {
				onStart : $.noop,
				onCreate : $.noop,
				onSizeChange : $.noop,
				onClick : $.noop,
				onFocus : $.noop,
				onBlur : $.noop,
				onKeyDown : $.noop,
				onKeyUp : $.noop,
				onKeyPress : $.noop,
				onMouseOver : $.noop,
				onMouseOut : $.noop,
				onPaste : $.noop,
				onSpinnerUp : $.noop,
				onSpinnerDown : $.noop,
				onMouseDown : $.noop,
				onMouseUp : $.noop,
				onBeforeGet : $.noop,
				onAfterGet : $.noop,
				onChange : $.noop,
				onValidError : $.noop,
				onValidSuccess : $.noop,
				onDestroy : $.noop
			}
		};	
	} );
	form.fn.extend({
		_triggerID : 1,
		_init : function(opt) {
			var self = this;
			//检查参数
			self._checkOptions( opt ).
				 setContainer().
				 _setFormView().
				 initComponent();
		},
		_checkOptions : function( opt ){
			opt.cls += ' nex-form-group-'+opt.group;
			opt.cls += ' nex-form-display-'+opt.display;
			if( $.isArray( opt.items ) ) {
				opt.items = opt.items.concat([]);	
			}
			return this;
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			
			Nex.Html.fn._sysEvents.apply( self,arguments );
			
			self.bind("onMouseOver._sys",self._setOverCls,self);
			self.bind("onMouseOut._sys",self._unsetOverCls,self);
			
			self.bind("onFocus._sys",self._setFocusCls,self);
			self.bind("onBlur._sys",self._unsetFocusCls,self);
			
			self.bind("onChange._sys",self._triggerPlaceholder,self);
			self.bind("onBlur._sys",self.refreshFormater,self);//refreshFormater
			self.bind("onBlur._sys",self.refreshRenderer,self);
			
			self.bind("onValidError._sys",self.setValidError,self);
			self.bind("onValidSuccess._sys",self.setValidSuccess,self);
			for(var i=0;i<opt.autoValidEvents.length;i++ ) {
				var s = self.bind(opt.autoValidEvents[i],self._autoValid,self);	
			}
			
			self.bind('onDropDownItemSelectedChange._sys',self._setDropDownValue,self);
			
			return self;
		},
		/*
		*作为备份用，如果用户没有定义tpl.formTpl 那么会使用当前函数
		*/
		formTpl : function(d){
			var text = [];
			/*
			text.push('<table id="'+d.id+'-inner" class="nex-field nex-form-inner" cellspacing="0" cellpadding="0" ><tbody>');//style="table-layout:fixed;" 不建议设置 IE 67 下会有问题
			text.push('<tr id="'+d.id+'-inputRow">');
				text.push('<td class="nex-form-inner-body" id="'+d.id+'-body-td">');	
				text.push('<div id="'+d.id+'-body" class="nex-form-body">');	
					text.push('<div '+d.attrs+' id="'+d.id+'-input" name="'+d.name+'" tabindex='+d.tabIndex+' value="" style="width:0px;" class="nex-form-field"></div>');
				text.push('</div></td>');
			text.push('</tr>');
			text.push('</tbody></table>');
			*/
			return text.join("");	
		},
		/*
		*获取表单模版
		*/
		_getFormTpl : function(){
			var self = this,
				opt = self.configs;
			var d = $.extend({},opt);
			var attrs = [];	
			if( $.isPlainObject( d.inputAttrs ) ) {
				$.each( d.inputAttrs,function(k,v){
					attrs.push(k+'='+v);
				} );
			}
			attrs.join(' ');
			d.attrs = attrs;
			d.tabIndex = ++Nex.tabIndex;
			d.placeholder = opt.placeholder;
			d.type = opt.__inputType;
			return self.tpl( 'formTpl',d );
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return $('#'+opt.id+'-body');
		},
		/*
		*设置组件HTML
		*/
		_setFormView : function(){
			var self = this,
				opt = self.configs,
				container = opt.views['container'];
			container.html( self._getFormTpl() );
			opt.views['body'] = $('#'+opt.id+'_body');
			
			self._setSysTriggerBtns();
			self._setTriggerBtns();
			self._bindEvent();
			
			self.fireEvent("onSetFormView",[opt]);	
			
			return self;
		},
		/*重载设置系统的trigger btn*/
		_setSysTriggerBtns : function(){
			var self = this,
				opt = self.configs;
			if( opt.cleanBtn ) {
				var cdf = opt.cleanDefault;
				self.addInnerTriggerBtn({
					cls : 'nex-form-clear-trigger',
					iconCls : 'nex-form-clear-icon',
					callBack : function(){
						self.val(cdf);	
						self.fireEvent('onTextChange',[ cdf ]);
						self.fireEvent('onClean',[ cdf ]);
						//triggerToFocus 如果这个关闭状态下 我们需要手动设置focus , 如果是开启状态下则会自动设置focus
						if( !opt.triggerToFocus ) {
							self.focus();
						}
					}	
				});
			}
			//cleanBtn	
			return self;
		},
		/*设置触发按钮*/
		_setTriggerBtns : function(){
			var self = this,
				opt = self.configs;
			var html = [];	
			var method = opt.triggerBtnsPosition === 'inner' ? 'addInnerTriggerBtn' : 'addOuterTriggerBtn';
			$.each( opt.triggerBtns,function(i,d){
				if( $.isArray( d ) && d.length>1 ) {
					self[method].call(self,d[0],d[1]);		
				} else {
					self[method].call(self,d);		
				}
			} );	
		},
		_setViewSize : function(){
			var self = this,
				opt = self.configs,
				container = opt.views['container'],
				vbody = opt.views['body'],
				input = self.getInput();
			if( !self.isAutoWidth() ) {	
				input.width(0);
				var inputRow = $("#"+opt.id+"-inputRow");
				var w = 0;
				$('>td',inputRow).not('.nex-form-inner-body').each( function(){
					w += $(this)._outerWidth();	
				} );
				input._outerWidth( container.width()-w );
			}
			if( !self.isAutoHeight() ) {
				vbody._outerHeight( container.height() );	
			}
			
			Nex.Html.fn._setViewSize.apply(self,arguments);//_setViewSize
			
			//self.fireEvent("onSetViewSize",[opt]);	
		},
		_addToList : function(){
			var self = this;
			var opt = self.configs;
			var list = Nex.Form.fieldList;
			
			list[opt.id] = true;
		},
		/*
		*设置Lable
		*/
		_setLabel : function(){
			var self = this,
				td = [],
				opt = self.configs;
			var ltd = $('#'+opt.id+'-label-td');
			if( ltd.size() ) {
				ltd.remove();	
			}
			td.push('<td valign="'+opt.labelvAlign+'" align="'+opt.labelAlign+'" id="'+opt.id+'-label-td" class="nex-form-inner-label nex-form-inner-label-'+opt.labelvAlign+'">');	
				td.push('<label id="'+opt.id+'-label" class="nex-form-label '+opt.labelCls+'"></label>');//for="'+opt.id+'-input" 
			td.push('</td>');
			
			var $td = $(td.join(''));
			
			$("#"+opt.id+"-body-td").before($td);
			
			$('#'+opt.id+'-label').css( opt.labelStyle );
			
			return self;	
		},
		setLabel : function(){
			return this._setLabel();	
		},
		/*
		*设置Label位置
		*/
		_setLabelPosition : function( pos ){
			var self = this,
				undef,
				opt = self.configs,
				pos = pos === undef ? 'left' : pos;	
			var _pos = {
				left : true,
				top : true,
				bottom : true,
				right : true	
			};	
			pos = _pos[pos] ? pos : 'left';
			
			opt.labelPosition = pos;
			
			//td-label
			var td = $("#"+opt.id+"-label-td");
			var inputRow = $("#"+opt.id+"-inputRow");
			$('#'+opt.id+'-label-tb').remove();
			var tr = null;
			if( $.inArray( pos,['top','bottom'] ) !== -1 ) {
				tr = $('<tr id="'+opt.id+'-label-tb"></tr>');	
			}
			
			if( pos === 'left' ) {
				$("#"+opt.id+"-body-td").before(td);
			} else if( pos === 'right' ) {
				$(">td:last",inputRow).after(td);
			} else if( pos === 'top' ) {
				if( tr ) {
					inputRow.before(tr);
					tr.append( td );
				}
			} else {
				if( tr ) {
					inputRow.after(tr);	
					tr.append( td );
				}
			}
			
			$('#'+opt.id+'-label').removeClass('nex-form-label-left nex-form-label-right nex-form-label-top nex-form-label-bottom')
								  .addClass('nex-form-label-'+pos);
			
			return self;
		},
		setLabelPosition : function(pos){
			this._setLabelPosition(pos);
			this._setLabelWidth( this.configs.labelWidth );
			this.resetViewSize();
			return this;		
		},
		/*
		*设置Label内容
		*/
		_setLabelText : function( text ){
			var opt = this.configs;
			var label = $('#'+opt.id+'-label');
			label.empty();
			this.renderComponent( text || opt.labelText,label );
			return this;	
		},
		setLabelText : function( text ){
			this._setLabelText(text);
			return this;	
		},
		/*
		*设置Lable宽度
		*/
		_setLabelWidth : function( w ){
			var opt = this.configs;
			//opt.labelPosition
			var label = $('#'+opt.id+'-label');
			if( opt.labelPosition == 'left' || opt.labelPosition == 'right' ) {
				label._outerWidth( w || opt.labelWidth );
			} else {
				label._removeStyle('width');	
			}
			return this;	
		},
		setLabelWidth : function( w ){
			this._setLabelWidth(w);
			this.resetViewSize();
			return this;	
		},
		checkLabelSet : function(){
			var self = this,
				opt = this.configs;	
			var showLabel = opt.showLabel;
			if( showLabel === 'auto' ) {
				showLabel = opt.labelText === '' ? false : true;
			}	
			
			if( !showLabel ) return self;	
			self._setLabel()
				._setLabelPosition( opt.labelPosition )
				._setLabelWidth( opt.labelWidth )
				._setLabelText( opt.labelText );
			return self;		
		},
		initComponent : function(){
			var self = this,
				opt = this.configs;
				
			self.checkLabelSet();	
			
			Nex.Html.fn.initComponent.apply( self,arguments );
			
			self._addToList();
			
			self._afterCreate();
			
		},
		_afterCreate : function(){
			var self = this,
				opt = self.configs;
			if( opt.disabled ) {
				self._disabled();
			}
			if( opt.readOnly ) {
				self._readOnly( true );
			}
			if( opt.autoFocus ) {
				self.focus();	
			}
			
			opt._value = opt.value;
			if( opt.value !== '' ) {
				self.lockEvent('onChange');
				//初始值设置
				self.setValue( opt.value );	
				self.unLockEvent('onChange');
				//初始化设置值时会触发onInitChange
				self.fireEvent('onInitChange',[opt.value,'']);
				if( opt.showPlaceholder ) {
					self.hidePlaceholder();
				}
			} else {
				if( opt.showPlaceholder ) {
					self.showPlaceholder();
				}
			}
		},
		_appendContent : function(){},
		__placeholderShow : false,
		_triggerPlaceholder : function( value ){
			if( !this.configs.showPlaceholder ) {
				return;	
			}
			if( value === '' ) {
				this.showPlaceholder();	
			} else {
				this.hidePlaceholder();		
			}
		},
		/*
		*获取placeholder
		*/
		getPlaceholder : function(){
			var opt = this.configs;
			var ph = $("#"+opt.id+"-placeholder");
			return ph;	
		},
		getPlaceholderText : function(){
			return this.configs.placeholder;	
		},
		setPlaceholder : function( text ){
			var text = this._undef( text,'' );
			if( text !== '' ) {
				this.configs.placeholder = text;
				this.getPlaceholder().html( text );
			}
			return this;
		},
		showPlaceholder : function(){
			if( !this.__placeholderShow ) {
				this.getPlaceholder().addClass('nex-form-placeholder-show');
			}
			this.__placeholderShow = true;	
			this.el.addClass('nex-form-empty');
			return this;
		},
		hidePlaceholder : function(){
			if( this.__placeholderShow ) {
				this.getPlaceholder().removeClass('nex-form-placeholder-show');
			}
			this.__placeholderShow = false;
			this.el.removeClass('nex-form-empty');
			return this;
		},
		/*
		*获取显示的input
		*/
		__input : null,
		getInput : function(){
			var self = this;
			var opt = self.configs;
			self.__input = self.__input ? self.__input : $("#"+opt.id+"-input");
			return self.__input;
		},
		/*
		*获取实际中的input 一般和input相同
		*/
		__inputreal : null,
		getInputReal : function(){
			var self = this;
			var opt = self.configs;
			self.__inputreal = self.__inputreal ? self.__inputreal : $("#"+opt.id+"-input");
			return self.__inputreal;
		},
		//判断元素是否属于input, textarea, select 和 button 元素
		_isInput : function( el ){
			return $(el).is(':input');	
		},
		/*
		*获取输入框的值
		*/
		getInputValue : function(){
			var self = this;
			var opt = self.configs;
			var input = self.getInputReal();
			
			var value = self._isInput( input ) ? input.val() : input.html();
			
			return value;	
		},
		setInputValue : function( value ){
			var self = this;
			var opt = self.configs;
			var input = self.getInputReal();
			self._isInput( input ) ? input.val( value ) : input.html( value );
			
			self.currentValue = value;
			
			return self;
		},
		/*
		*private
		*/
		getInputWidth : function(){
			return this.getInput()._outerWidth();		
		},
		/*
		*获取输入框的显示值 一般和getInputValue相同
		*/
		getInputText : function(){
			var self = this;
			var opt = self.configs;
			var input = self.getInput();
			
			var value = self._isInput( input ) ? input.val() : input.html();
			
			return $.trim( value );	
		},
		setInputText : function( value ){
			var self = this;
			var opt = self.configs;
			var input = self.getInput();
			self._isInput( input ) ? input.val( value ) : input.html( value );
			return self;
		},
		//过渡用 目前已经没用
		currentValue : '',
		/*
		*获取当前组件值
		*/
		getValue : function(){
			var self = this,undef;
			var opt = self.configs;
			
			var value = $.trim( self.rendererDecode( self.getInputValue() ) );
			
			if( $.isFunction( opt.getFormater ) ) {
				var val = opt.getFormater.call( self,value );
				value = val === undef ? value : val;
			}
			
			var _d = {
				value : value	
			};
			
			self.fireEvent('onGetValue',[ _d ]);
			self.currentValue = _d.value;
			
			return _d.value;
		},
		_oldValue : null,
		setValue : function(){
			var self = this,
				opt = this.configs,
				undef;
			var argvs = [].slice.apply(arguments);
			//记录表单改变之前的值
			var oldValue = self._oldValue === null ? self.getValue() : self._oldValue;
			self._oldValue = oldValue;
			
			self.fireEvent('onSetValue',[argvs]);
			
			if( $.isFunction( opt.setFormater ) ) {
				var val = opt.setFormater.apply( self,argvs );
				if( val !== undef ) {
					if( !$.isArray( val ) ) {
						argvs = [ val ];	
					}
				}
			}
			//formater 一般不建议使用 只对设置时有效
			if( $.isFunction( opt.formater ) ) {
				var val = opt.formater.apply( self,argvs );
				if( val !== undef ) {
					if( !$.isArray( val ) ) {
						argvs = [ val ];	
					}
				}
			}
			
			if( !argvs.length ) {
				return self;	
			}
			
			var v = argvs[0]+'';
			//显示映射
			argvs[0] = self.rendererEncode(argvs[0]);
			
			self.setInputValue.apply(self, argvs );
			
			var newValue = v;
			
			if( oldValue !== newValue && self._oldValue!==null ) {
				self._oldValue = null;
				opt.value = newValue;
				self.fireEvent('onChange',[newValue,oldValue]);	
			}
			
			return self;
		},
		val : function(){
			var self = this,undef;
			var opt = self.configs;
			//设置当前值
			if( arguments.length ) {
				return self.setValue.apply( self,arguments );	
			} else {
				return self.getValue();	
			};
		},
		__isFocus : false,//focus 状态
		_focusValue : null,
		_bindInputEvent : function(){
			var self = this;
			var opt = self.configs;	
			var input = $("#"+opt.id+"-input");
			
			var i19t = opt.inputTextChangeEvent;
			
			var events = {
				'click' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var r = self.fireEvent('onClick',[ this,e ]);	
					if( r === false ) return false;
				},
				'focus' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					
					self._focusValue = self.getInputText();//
					
					//var input = $('#'+opt.id+"-input");
					input.addClass('nex-form-field-focus');
					$('#'+opt.id).addClass('nex-form-focus');
					if( !self.__isFocus ) {
						var r = self.fireEvent('onFocus',[ this,e ]);	
						self.__isFocus = true;
						if( r === false ) return false;
					}
					
				},
				'blur' : function(e) {
					self.__isFocus = false;
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					
					var oldValue = self._focusValue;
					var newValue = self.getInputText();
					
					//var input = $('#'+opt.id+"-input");
					input.removeClass('nex-form-field-focus');
					
					$('#'+opt.id).removeClass('nex-form-focus');
					
					if( oldValue !== newValue ) {
						opt.value = newValue;
						if( i19t ) {
							self.fireEvent(i19t,[ newValue,oldValue ]);
						}
						self.fireEvent('onTextChange',[ self.getInputText() ]);
					}
					
					var r = self.fireEvent('onBlur',[ this,e ]);	
					if( r === false ) return false;
				},
				'keydown' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					self._oldValue = self._oldValue === null ? self.getInputText() : self._oldValue;
					var r = self.fireEvent('onKeyDown',[ this,e ]);	
					if( r === false ) return false;
					
				},
				'keyup' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var oldValue = self._oldValue;
					var newValue = self.getInputText();
					if( oldValue !== newValue && self._oldValue!==null ) {
						opt.value = newValue;
						self._focusValue = newValue;
						if( i19t ) {
							self.fireEvent(i19t,[ newValue,oldValue ]);	
						}
						self.fireEvent('onTextChange',[ newValue ]);
						self._oldValue =null;
					}
					var r = self.fireEvent('onKeyUp',[ this,e ]);	
					if( r === false ) return false;
				},
				'keypress' : function(e){
					if( opt.disabled || opt.readOnly ) {
						return;		
					}
					var r = self.fireEvent('onKeyPress',[ this,e ]);	
					if( r === false ) return false;
				},
				'mouseenter' : function(e){
					if( opt.disabled || opt.readOnly ) {
						return;		
					}
					var r = self.fireEvent('onMouseOver',[ this,e ]);	
					if( r === false ) return false;
				},
				'mouseleave' : function(e){
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var r = self.fireEvent('onMouseOut',[ this,e ]);	
					if( r === false ) return false;
				},
				'paste' : function(e){
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var r = self.fireEvent('onPaste',[ this,e ]);	
					if( r === false ) return false;
				},
				'mousedown' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var r = self.fireEvent('onMouseDown',[ this,e ]);	
					if( r === false ) return false;
				},
				'mouseup' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var r = self.fireEvent('onMouseUp',[ this,e ]);	
					if( r === false ) return false;
				}
			};
			
			input.bind(events);
		},
		_bindEvent : function(){
			var self = this;
			var opt = self.configs;
			
			var dom = self.el;
			var inputRow = $("#"+opt.id+"-inputRow");
			var input = $("#"+opt.id+"-input");
			var bd = $("#"+opt.id+"-body");
			var trigger = $("#"+opt.id+"-trigger-body");
			
			var __t = 0;
			var triggerEvns = {
				'click' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var $this = $(this);
					var tid = parseInt($this.attr('tid'))-1;
					var data = self.__TriBtns[tid];
					var r = self.fireEvent('onTriggerBtnClick',[ data,this,e ]);	
					if( r === false ) return false;
					
					//input.trigger('click',[e]);
				},
				'dblclick' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var $this = $(this);
					var tid = parseInt($this.attr('tid'))-1;
					var data = self.__TriBtns[tid];
					var r = self.fireEvent('onTriggerBtnDblClick',[ data,this,e ]);	
					if( r === false ) return false;
					
					//input.trigger('dblclick',[e]);
				},
				'mouseenter' : function(e){
					if( opt.disabled || opt.readOnly ) {
						return;		
					}
					var $this = $(this);
					var tid = parseInt($this.attr('tid'))-1;
					var data = self.__TriBtns[tid];
					var r = self.fireEvent('onTriggerBtnOver',[ data,this,e ]);	
					if( r === false ) return false;
					
					$this.addClass('nex-form-trigger-btn-over');
					//input.trigger('mouseenter',[e]);
				},
				'mouseleave' : function(e){
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var $this = $(this);
					var tid = parseInt($this.attr('tid'))-1;
					var data = self.__TriBtns[tid];
					var r = self.fireEvent('onTriggerBtnOut',[ data,this,e ]);	
					if( r === false ) return false;
					
					$this.removeClass('nex-form-trigger-btn-over');
					//input.trigger('mouseleave',[e]);
				}, 
				'mousedown' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var $this = $(this);
					var tid = parseInt($this.attr('tid'))-1;
					var data = self.__TriBtns[tid];
					var r = self.fireEvent('onTriggerBtnDown',[ data,this,e ]);	
					if( r === false ) return false;
					
					$this.addClass('nex-form-trigger-btn-down');
					__t = setTimeout(function(){
						__t = 0;
						$(document).one('mouseup',function(){
							$this.removeClass('nex-form-trigger-btn-down');	
						});	
					},0);
					
					//input.trigger('mousedown',[e]);
				},
				'mouseup' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					var $this = $(this);
					var tid = parseInt($this.attr('tid'))-1;
					var data = self.__TriBtns[tid];
					var r = self.fireEvent('onTriggerBtnUp',[ data,this,e ]);	
					if( r === false ) return false;
					
					$this.removeClass('nex-form-trigger-btn-down');
					if( __t ) {
						clearTimeout( __t );	
						__t = 0;
					}
					//input.trigger('mouseup',[e]);
				}
			};
			var placeholderEvns = {
				'click' : function(e) {
					e.stopPropagation();
					e.preventDefault();
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					input.trigger('click',[e]);
				},
				'mouseenter' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					input.trigger('mouseenter',[e]);
				},
				'mouseleave' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					input.trigger('mouseleave',[e]);
				},
				'mousedown' : function(e) {
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					
					input.trigger('mousedown',[e]);
					
					if( $(this).hasClass('nex-form-placeholder') || $(this).hasClass('nex-form-inner-label') ) {
						input.trigger('focus',[e]);	
						
					} else {
						if( opt.triggerToFocus ) {
							input.trigger('focus',[e]);
						}
					}
					e.stopPropagation();
					e.preventDefault();
				},
				'mouseup' : function(e) {
					e.stopPropagation();
					e.preventDefault();
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					input.trigger('mouseup',[e]);
				}
			};
			
			self._bindInputEvent();
			
			bd.undelegate('>.nex-form-placeholder')
			  .delegate('>.nex-form-placeholder',placeholderEvns);
					   
			trigger.undelegate('>.nex-form-trigger-btn')
				   .delegate('>.nex-form-trigger-btn',triggerEvns);
				   
			trigger.bind( placeholderEvns );	
			
			dom.undelegate('[id="'+opt.id+'-label-td"]')
			   .delegate('[id="'+opt.id+'-label-td"]',placeholderEvns);
			//nex-form-label nexform-10-label-td   
				   
			inputRow.undelegate('>.nex-form-outer-trigger-td >.nex-form-outer-trigger-body >.nex-form-trigger-btn')
					.delegate('>.nex-form-outer-trigger-td >.nex-form-outer-trigger-body >.nex-form-trigger-btn',triggerEvns);
			
		},
		__TriBtns : [],
		/*
		*添加触发按钮
		*@param 任意文字,对象或者Nex组件
		*@param 触发按钮按下后调用的回调 可选
		*@param private
		*/
		addInnerTriggerBtn : function( d,callback,_tb ){
			var self = this,
				opt = self.configs;
			var trigger = _tb ? $(_tb) : $("#"+opt.id+"-trigger-body");
			var tid = self.__TriBtns.push( d );
			var _d = {
				text : '',
				icon : '',
				cls : '',
				iconCls : '',
				callBack : null,//兼容以前的用法
				callback : null,
				handler : null	
			};
			
			if( $.type( d ) === 'string' || $.type( d ) === 'number' ) {
				var text = d+'';	
				d = $.extend( {},_d,{
					text : text	
				} );
			} else {
				for( var k in _d ) {
					if( k in d ) {
						continue;
					}	
					d[k] = _d[k];
				}
			}
			
			var tpl = ['<div id="'+opt.id+'-inner-trigger-'+tid+'" tid="'+tid+'" class="nex-form-trigger-btn '+( d.icon || d.iconCls ? 'nex-form-trigger-has-icon':'' )+' '+d.cls+'">'];
			if( d.icon || d.iconCls ) {
				tpl.push('<span class="nex-form-trigger-icon '+d.iconCls+'" style="'+(d.icon?('background-image:url('+d.icon+')'):'')+'"></span>');	
			}
			
			//tpl.push( d.text );
			
			tpl.push( '</div>' );
			var $tpl = $(tpl.join(''));
			$tpl.prependTo( trigger )
			    .bind('click',function(e){
					if( opt.disabled || opt.readOnly ) {
						return;	
					}
					if( $.isFunction( callback ) ) {
						return callback.call( self,d,e );	
					}	
					if( $.isFunction( d.callBack ) ) {
						return d.callBack.call( self,d,e );	
					}
					if( $.isFunction( d.callback ) ) {
						return d.callback.call( self,d,e );	
					}
					if( $.isFunction( d.handler ) ) {
						return d.handler.call( self,d,e );	
					}	   
			    });
			
			if( !opt.triggerBtnSelection ) {	
				$tpl.disableSelection();
			}
			
			if( Nex.isXtype( d ) || Nex.isNexConstructor( d ) ) {
				self.renderComponent( d.text,$tpl );	
			} else if( Nex.isNex( d ) ) {
				$tpl.append( d.getDom() );	
			} else {
				self.renderComponent( d.text,$tpl );
			}
			return tid;
		},
		removeInnerTriggerBtn : function( tid ){
			var self = this,
				opt = self.configs;
			if( typeof tid === 'undefined' ) {
				return self;	
			}
			tid = parseInt(tid) - 1;
			self.__TriBtns[tid] = null;
			$('#'+opt.id+'-inner-trigger-'+tid).remove();
			
			Nex.gc();
			
			return self;
		},
		/*
		*添加触发按钮
		*@param 任意文字或者Nex组件
		*@param 触发按钮按下后调用的回调 可选
		*/
		addOuterTriggerBtn : function( msg,callback ){
			var self = this,
				opt = self.configs;	
			
			var bid = opt.id+'-outer-trigger-body';
			var $td = $('#'+bid+'-td');
			if( !$td.length ) {
				var td = [];
				td.push('<td valign="'+opt.labelvAlign+'" id="'+bid+'-td" align="'+opt.labelAlign+'" class="nex-form-outer-trigger-td">');	
						td.push('<div id="'+bid+'" class="nex-form-outer-trigger-body"></div>');
				td.push('</td>');	
				var td = $(td.join(""));
				
				var triggerBtnTd = $("#"+opt.id+"-inputRow td:last");
				triggerBtnTd.after(td);
			} else {
				var td = $td;	
			}
			/*var itemBtn = td.find(">div");
			if( $.isFunction(callback) ) {
				itemBtn.bind('click',function(e){
					callback.call( self,itemBtn,e );	
				});
			}
			
			self.renderComponent( msg,itemBtn );*/
			
			var tid = self.addInnerTriggerBtn( msg,callback,$('#'+opt.id+'-outer-trigger-body') );
			
			td.attr(opt.id+'-outer-trigger-td-'+tid);
				
			self.resetViewSize();
			
			return tid;
		},
		removeOuterTriggerBtn : function( tid ){
			var self = this,
				opt = self.configs;	
				
			self.removeInnerTriggerBtn( tid );
			$('#'+opt.id+'-outer-trigger-td-'+tid).remove();
				
			self.resetViewSize();
					
			return self;
		},
		_disabled : function(){
			var self = this,
				opt = self.configs,
				input = self.getInput(),
				field = self.getDom();
			
			opt.disabled = true;
			input.attr('disabled',true);	 
			
			field.addClass('nex-form-disabled');
			if( opt.disabledCls ) {
				field.addClass(opt.disabledCls);	
			}
			
			return self;	
		},
		disabled : function(){
			var self = this;
			var opt = self.configs;
			
			self._disabled();
			
			self.fireEvent("onDisabled",[opt]);	
			return self;
		},
		_enable : function(){
			var self = this,
				opt = self.configs,
				input = self.getInput(),
				field = self.getDom();
				
			opt.disabled = false;	
			
			input.attr('disabled',false);	
			
			field.removeClass('nex-form-disabled');
			if( opt.disabledCls ) {
				field.removeClass(opt.disabledCls);	
			}
			
			return self;	
		},
		enable : function(){
			var self = this,
				opt = self.configs;
			
			self._enable();	
				
			self.fireEvent("onEnable",[opt]);	
			return self;
		},
		_readOnly : function( flag ){
			var self = this,
				undef,
				input = self.getInput(),
				field = self.getDom(),
				opt = self.configs;
			var flag = flag === undef ? true : flag;
			opt.readOnly = flag;
			input.attr('readonly',flag);	
			
			if( flag ) {
				self.fireEvent("onReadOnly",[opt]);	
				field.addClass('nex-form-readonly');
				if( opt.readonlyCls ) {
					field.addClass(opt.readonlyCls);	
				}
			} else {
				self.fireEvent("onUnReadOnly",[opt]);		
				field.removeClass('nex-form-readonly');
				if( opt.readonlyCls ) {
					field.removeClass(opt.readonlyCls);	
				}
			}
			return self;	
		},
		readOnly : function( flag ){
			var self = this,
				undef,
				opt = self.configs;
			
			var flag = flag === undef ? true : flag;
			
			self._readOnly( flag );
			
			if( flag ) {
				self.fireEvent("onReadOnly",[opt]);			
			} else {
				self.fireEvent("onUnReadOnly",[opt]);		
			}
			return self;
		},
		setValidError : function(){
			var self = this;
			var opt = self.configs;
			var el = $("#"+opt.id);
			self.resetVaildCss();
			el.addClass(opt.validErrorCls);
		},
		setValidSuccess : function(){
			var self = this;
			var opt = self.configs;
			var el = $("#"+opt.id);
			self.resetVaildCss();
			el.addClass(opt.validSuccessCls);
		},
		resetVaildCss : function(){
			var self = this;
			var opt = self.configs;
			var el = $("#"+opt.id);
			el.removeClass(opt.validErrorCls);	
			el.removeClass(opt.validSuccessCls);	
		},
		_setFocusCls : function(t,e){
			var self = this;
			var opt = self.configs;
			if( opt.disabled || opt.readOnly ) {
				return;	
			}
			var field = self.el;
			field.addClass('nex-form-focus');
			if( opt.focusCls ) {
				field.addClass(opt.focusCls);	
			}	
		},
		_unsetFocusCls : function(t,e){
			var self = this;
			var opt = self.configs;
			if( opt.disabled || opt.readOnly ) {
				return;	
			}
			var field = self.el;
			field.removeClass('nex-form-focus');
			if( opt.focusCls ) {
				field.removeClass(opt.focusCls);	
			}	
		},
		_setOverCls : function(t,e){
			var self = this;
			var opt = self.configs;
			if( opt.disabled || opt.readOnly ) {
				return;	
			}
			var field = self.el;
			field.addClass('nex-form-over');
			$('>.nex-form-inner',field).addClass('nex-form-inner-over');
			if( opt.overCls ) {
				field.addClass(opt.overCls);	
			}
		},
		_unsetOverCls : function(t,e){
			var self = this;
			var opt = self.configs;
			if( opt.disabled || opt.readOnly ) {
				return;	
			}
			var field = self.el;
			field.removeClass('nex-form-over');
			$('>.nex-form-inner',field).removeClass('nex-form-inner-over');
			if( opt.overCls ) {
				field.removeClass(opt.overCls);	
			}
		},
		_autoValid :　function(){
			var self = this;
			var opt = self.configs;
			if( opt._ct ) {
				clearTimeout( opt._ct )
			}
			opt._ct = setTimeout(function(){
				self.checkVal();
				opt._ct = 0;	
			},opt.autoValidDelay);
		},
		hidden : function(){
			return this.hide();
		},
		"focus" : function(){
			var self = this;
			try{
				self.getInput().focus();
			}catch(e){};
		},
		"select" : function(){
			var self = this;
			try{
				self.getInput().select();
			}catch(e){};
		},
		selectText : function(start, end){
			var self = this,
				opt = self.configs,
				v = self.val(),
				undef,
				el = self.getInput().get(0),
				range;
	
			if (v.length > 0) {
				start = start === undef ? 0 : start;
				end = end === undef ? v.length : end;
				if (el.setSelectionRange) {
					el.setSelectionRange(start, end);
				}
				else if(el.createTextRange) {
					range = el.createTextRange();
					range.moveStart('character', start);
					range.moveEnd('character', end - v.length);
					range.select();
				}
				
			}
			self.focus();
		},
		"blur" : function(){
			var self = this;
			try{
				self.getInput().blur();
			} catch(e){}
		},
		checkVal : function(){
			var self = this;
			var opt = self.configs;
			var r = true;
			var rules = $.isArray(opt.rules) ? opt.rules : [ opt.rules ];
			//var validator = opt.validator;
			//Validate
			var validator = Nex.getUtil('Validate');
			var rule;
			var value = self.val();
			//var value = $.nexForm.getVal( opt.name,opt.group );
			var checkList = [];//验证函数
		
			for( var x=0;x<rules.length;x++ ) {
				rule = rules[x];
				if( $.isFunction(rule) ) {
					checkList.push( { method : rule, rule : null, params : null } );
				} else if( $.isPlainObject(rule) ){
					for(var i in rule ) {
						if( $.isFunction(rule[i]) ) {
							checkList.push( { method : rule[i] , rule : i, params : null } );
						} else if( (i in validator) && $.isFunction( validator[i] ) ){
							checkList.push( { method : validator[i], rule : i, params : rule[i] } );
						}
					}
				} else if( typeof rule === 'string' 
							&& ( rule in validator ) 
							&& $.isFunction( validator[rule] ) 
				) {
					checkList.push( { method : validator[rule], rule : rule, params : null } );
				}
			}
			
			var error_r = null;
			for( var t=0,len=checkList.length;t<len;t++ ) {
				var d = checkList[t];
				var args = [ value ];
				if( d.params !== null ) {
					args.push( d.params );	
				}
				r = d.method.apply( validator, args );
				if( r === false ) {
					error_r = d.rule === null ? null : d.rule;
					break;	
				}	
			}
			
			if( r === false ) {
				
				var errorMsg = opt.messages[error_r] || opt.validErrorMsg;
				
				self.fireEvent("onValidError",[errorMsg,error_r]);	
			} else {
				self.fireEvent("onValidSuccess",[opt.validSuccessMsg]);		
			}
			
			return r;
		},
		isValid : function(){
			return this.checkVal();	
		},
		valid : function(){
			return this.checkVal();		
		},
		"reset" : function(){
			var self = this;
			var opt = self.configs;
			opt.value = opt._value;
			
			//初始值设置
			self.setValue( opt.value );	
			
			self.blur();
			clearTimeout( opt._ct );//取消验证
			self.resetVaildCss();	
		},
		//获取数据 ,一般作为内部使用
		
		//一般作为外部使用 又val 区别在于可做最终数据处理
		refreshFormater : function(){
			var self = this,undef;
			var opt = self.C();	
			if( $.isFunction( opt.formater ) ) {
				var value = self.val();
				var _value = opt.formater.call( self,value );
				value = _value === undef ? value : _value;
				self.val( value );
			}	
		},
		/*
		*映射 只有使用api val() 才有效
		*/
		refreshRenderer : function( input,e ){
			var self = this;
			var opt = self.C();	
			if( $.isPlainObject( opt.renderer ) && $.isEmptyObject( opt.renderer ) ) {
				return ;	
			}
			var value = self.val();
			self.val( value );
		},
		/*
		* 映射
		*/
		rendererEncode : function(str){
			var self = this,
				opt = this.configs,
				undef;
			var renderer = opt.renderer;
			var value = '';
			
			if( $.isPlainObject( renderer ) && $.isEmptyObject( renderer ) ) {
				return str;	
			}
			
			if( $.isFunction( renderer ) ) {
				value = self.tpl( renderer , str );	
				if( value === undef ) {
					value = str;	
				}
			} else if( $._isPlainObject( renderer ) ) {
				if( str in renderer ) {
					value = self.tpl( renderer[str] , str );		
				} else if( opt.rendererDef in renderer ) {
					value = self.tpl( renderer[opt.rendererDef] , str );			
				} else {
					value = str;	
				}
			} else {
				value = str;	
			}
			opt._renderer[ value ] = str;
			return value;
		},
		/*
		*反映射
		*/
		rendererDecode : function(str){
			var self = this;
			var opt = self.C();	
			
			if( $.isPlainObject( opt.renderer ) && $.isEmptyObject( opt.renderer ) ) {
				return str;	
			}
			
			var value = '';
			if( str in opt._renderer ) {
				value = opt._renderer[str];	
			}else {
				value = str;	
			}
			return value;
		},
		validTipEl : null,
		/*验证提示信息*/
		_showValidTip : function( position ){
			var self = this;
			var opt = this.configs;
			var bd = this.getBody();
			var position = this._undef( position,opt.position );
			if( !self.validTipEl ) {
				self.validTipEl = $('<div id="'+opt.id+'_tooltip" class=""nex-form-tooltip></div>');		
			}	
			switch( position ) {
				case 'right' :
					break
				case 'left' :
					break;
				case 'top' : 
					break;
				case 'bottom' :
					break;	
			}
		},
		/*
		*下拉框处理流程，由于实现单选 多选 autocomplete下拉框
		*/
		getDropDownItems : function(){
			var opt = this.configs;
			return opt.items || [];	
		},
		getDropDownItemDefault : function(){
			var opt = this.configs;
			return $.extend( {},opt.itemDefault,opt.dropdownItemDefault );	
		},
		/*
		*设置表单的Items
		*/
		setItems : function( items ){
			return this.setDropDownItems.apply( this,arguments );
		},
		setDropDownItems : function( items ){
			var self = this;
			var opt = this.configs;
			if( items ) {//dropdownItems
				opt.items = $.isArray(items) ? [].concat(items) : items;
			}
			if( opt.dropdownMode == 1  && $.isArray(opt.items) ) {
				$.each( opt.items,function( i,d ){
					opt.items[i] = self._parseItemData( d );	
				} );
			}
			//判断dropdown是否已经创建 如果创建则刷新内容
			var dropdown = this.getDropDown();
			if( dropdown.length && items ) {
				this.resetDropDownList( opt.items );
			}
			return opt.items;	
		},
		/*
		*获取items数据
		*@param {String,Array}单个字符是返回当前对象，如果是数组或者以','分割的字符串时返回的是数组
		*@param {Boolean} true 默认 返回数据  false返回索引
		*return {Array,Object}
		*/
		getItemData : function(value,m){
			return this.getDropDownItemData( value,m );	
		},
		getItemIndex : function(value){
			return this.getDropDownItemData( value,false );
		},
		getItemDataById : function( id ){
			return this.getDropDownItemDataById(id);	
		},
		getDropDownShowAt : function(){
			return this.getInput();	
		},
		getDropDownSelectedValue : function(){
			return this.val();	
		},
		_setDropDownValue : function( value,text,data ){
			var self = this,
				undef,
				opt = self.configs;
				
			data.selected = true;
			
			var d = $.extend({},data);	
			
			//self.fireEvent('onSetDropDownValue',[ d,opt ]);	
			
			self.val( value,text,d );
			
			return self;
		}
	});
});
;$define([
	'Nex.form.Form'
],function(){
	"use strict";
	var displayfield = Nex.define('Nex.form.Display','Nex.form.Form',{
		alias : 'Nex.Form.Display',
		xtype : 'displayfield'
	});	
	//参数重载
	displayfield.setOptions( function(opt){
		return {
			__inputType  : 'display',
			containerCls : [opt.containerCls,'nex-form-display'].join(' '),
			cleanBtn	 : false
		};	
	} );
});
;$define([
	'Nex.form.Form'
],function(){
	"use strict";
	var textfield = Nex.define('Nex.form.Text','Nex.form.Form',{
		alias : 'Nex.Form.Text',
		xtype : 'textfield'
	});	
	//参数重载
	textfield.setOptions( function(opt){
		var tpl = opt.tpl;
		tpl.formTpl = '<table id="<%=id%>-inner" class="nex-field nex-form-inner" cellspacing="0" cellpadding="0" ><tbody>'
							+'<tr id="<%=id%>-inputRow">'
								+'<td class="nex-form-inner-body" id="<%=id%>-body-td">'
									+'<div id="<%=id%>-body" class="nex-form-body">'
										+'<input <%=attrs%> id="<%=id%>-input" type="<%=type%>" name="<%=name%>" autocomplete="<%=autocomplete%>" tabindex=<%=tabIndex%> value="" style="/*width:0px;*/" class="nex-form-field nex-form-field-<%=type%>" />'
										+'<label id="<%=id%>-placeholder" class="nex-form-placeholder"><%=placeholder%></label>'
										+'<div id="<%=id%>-trigger-body" class="nex-form-trigger-body"></div>'
									 +'</div>'
								+'</td>'
							+'</tr>'
						+'</tbody></table>';
		return {
			__inputType  : 'text',
			containerCls : [opt.containerCls,'nex-form-text'].join(' '),
			cleanBtn 	 : true,
			tpl			 : tpl
		};	
	} );
});
;$define([
	'Nex.form.Form'
],function(){
	"use strict";
	var textfield = Nex.define('Nex.form.Textarea','Nex.form.Form',{
		alias : 'Nex.Form.Textarea',
		xtype : 'textareafield',
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			Nex.form.Form.fn._sysEvents.call( self );
			self.bind("onSetViewSize._sys",self._setTextareaHeight,self);	
		},
		_setTextareaHeight : function(){
			var self = this;
			var opt = self.configs;
			var container = opt.views['container'];
			var input = self.getInput();
			input._outerHeight( container.height() );
			return self;
		}
	});	
	//参数重载
	textfield.setOptions( function(opt){
		var tpl = opt.tpl;
		tpl.formTpl = '<table id="<%=id%>-inner" class="nex-field nex-form-inner" cellspacing="0" cellpadding="0" ><tbody>'
							+'<tr id="<%=id%>-inputRow">'
								+'<td class="nex-form-inner-body" id="<%=id%>-body-td">'
									+'<div id="<%=id%>-body" class="nex-form-body">'
										+'<textarea <%=attrs%> id="<%=id%>-input" type="<%=type%>" name="<%=name%>" autocomplete="<%=autocomplete%>" tabindex=<%=tabIndex%> style="/*width:0px;*/" class="nex-form-field nex-form-field-<%=type%>"></textarea>'
										+'<label id="<%=id%>-placeholder" class="nex-form-placeholder"><%=placeholder%></label>'
										+'<div id="<%=id%>-trigger-body" class="nex-form-trigger-body"></div>'
									 +'</div>'
								+'</td>'
							+'</tr>'
						+'</tbody></table>';
		return {
			__inputType  : 'textarea',//当前组件中该参数没有作用
			containerCls : [opt.containerCls,'nex-form-textarea'].join(' '),
			cleanBtn 	 : true,
			height 		 : 60,
			labelvAlign  : 'top',
			tpl			 : tpl
		};	
	} );
});
;$define([
	'Nex.form.Display'
],function(){
	"use strict";
	var textfield = Nex.define('Nex.form.Radio','Nex.form.Display',{
		alias : 'Nex.Form.Radio',
		xtype : 'radiofield',
		initComponent : function(){
			var self = this;
			var opt = this.configs;	
			
			self._setRadios( opt.items );
			
			self._setRadioEvents();
			
			//调用父级构造函数
			Nex.form.Display.fn.initComponent.apply( self,arguments );
			
			if( !opt.radioLabelSelection ) {	
				var input = self.getInput();
				input.disableSelection();
			}
			
		},
		_bindEvent : function(){
			var self = this;
			var opt = this.configs;	
			
			//调用父级函数
			Nex.form.Display.fn._bindEvent.apply( self,arguments );	
			//if( !Nex.isIE ) return self;
			var input = $("#"+opt.id+"-input");
			var _t = 0;
			input.unbind('focus blur')
				 .bind({
					'focus2' : function(e) {
						if( opt.disabled || opt.readOnly ) {
							return;	
						}
						
						if( input.hasClass('nex-form-field-focus') ) {
							return;	
						}
						
						self._focusValue = $(this).val();
						
					//	var input = $('#'+opt.id+"-input");
						
						input.addClass('nex-form-field-focus');
						$('#'+opt.id).addClass('nex-form-focus');
						
						var r = self.fireEvent('onFocus',[ this,e ]);	
						if( r === false ) return false;
					},
					'blur2' : function(e) {
						if( opt.disabled || opt.readOnly ) {
							return;	
						}
						var oldValue = self._focusValue;
						var newValue = $(this).val();
						//var input = $('#'+opt.id+"-input");
						input.removeClass('nex-form-field-focus');
						
						$('#'+opt.id).removeClass('nex-form-focus');
						
						if( oldValue !== newValue ) {
							opt.value = newValue;
							self.fireEvent('onChange',[ newValue,oldValue ]);		
						}
						
						var r = self.fireEvent('onBlur',[ this,e ]);	
						if( r === false ) return false;	
					}
				});
		},
		/*private*/
		_setRadios : function( items ){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();
			var html = [];
			var valueKey = opt.valueKey,
				textKey = opt.textKey;
			var items = self._undef( items,opt.items );
			if( !$.isArray( items ) ) {
				return self;
			}
			var len = items.length;
			for( var i=0;i<len;i++ ) {
				var _d = self._parseItemData( items[i] );
				items[i] = _d;
				var d = $.extend( {
					//id 		 : items[i]['__id'],
					cls 	 : '',
					readOnly : false,
					disabled : false,
					display  : 'inline',
					width 	 : 'auto'
				}, opt.itemDefault ,_d );
				d.id = items[i]['__id'];
				if( !self.isSplitLine( d ) ) {
					html.push('<span id="'+d.id+'" tabindex="'+(++Nex.tabIndex)+'" class="nex-form-radio-item nex-form-radio-item-d-'+d.display+' '+ (d.readOnly?'nex-form-radio-item-readonly':'') +' '+ (d.disabled?'nex-form-radio-item-disabled':'') +' '+d.cls+'" value="'+d[valueKey]+'" value="'+encodeURIComponent(d[valueKey])+'" style="'+( isNaN(parseInt( d.width )) ? '' : 'width:'+parseInt( d.width )+'px' )+'"><span id="'+opt.id+'-radio-icon" class="nex-form-radio-icon"></span><span class="nex-form-radio-text">'+d[textKey]+'</span></span>');				 
				} else {
					html.push( self.tpl(opt.dropdownItemSplitLineTpl,d) );
				}
			}
			
			input.html( html.join('') );
			
			return self;
		},
		resetRadios : function( items ){
			var self = this;
			var opt = this.configs;	
			var value = self.getValue();	
			if( !$.isArray( items ) ) {
				return self;	
			}
			opt.items = items;
			self._setRadios( items );
			
			self.checked( value, false );
			
			return self;
		},
		/*private*/
		_setRadioEvents : function(){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();
			
			var fn = function( evt1,evt2,e,func ){
				if( opt.disabled || opt.readOnly ) {
					return;	
				}
				var $this = $(this);
				var id = $this.attr('id');
				var d = self.getItemDataById( id );
				if( d.disabled || d.readOnly ) {
					return;
				}	
				var r;
				if( $.isFunction( d[evt2] ) ) {
					r = d[evt2].call( self,d );	
					if( r === false ) return false;	
				}	
				
				r = self.fireEvent(evt1,[ d[ opt.valueKey ],d,this,e ]);	
				if( r === false ) return false;	
				
				if( $.isFunction( func ) ) {
					func.call( this,d );	
				}
				
			};
			var __t = 0;
			var __t2 = 0;
			input.undelegate('>.nex-form-radio-item')
				 .delegate('>.nex-form-radio-item',{
					"click" : function(e){
						if( opt.disabled || opt.readOnly ) {
							return;	
						}
						
						var $this = $(this);
						var id = $this.attr('id');
						var d = self.getItemDataById( id );
						var r;
						if( d.disabled || d.readOnly ) {
							return;
						}	
						if( $.isFunction( d.callBack ) ) {
							r = d.callBack.call( self,d,e );	
						}
						if( $.isFunction( d.callback ) && r !== false ) {
							r = d.callback.call( self,d,e );	
						}
						if( $.isFunction( d.handler ) && r !== false ) {
							r = d.handler.call( self,d,e );	
						}
						if( r !== false ) {
							r = fn.call( this,'onRaidoClick','click',e );
						}
						
						if( r === false ) return false;
						if( !$this.hasClass('nex-form-radio-item-checked') ) {
							self.setValue( d[ opt.valueKey ] );
							//$this.addClass('nex-form-radio-item-checked');
						}
						
					},
					"dblclick" : function(e){
						return fn.call( this,'onRaidoDblClick','dblclick',e );
					},
					"mouseenter" : function(e){
						var r = fn.call( this,'onRaidoOver','mouseover',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).addClass('nex-form-radio-item-over');
						} );
						if( r === false ) return false;
					},
					"mouseleave" : function(e){
						var r = fn.call( this,'onRaidoOut','mouseout',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).removeClass('nex-form-radio-item-over');
						} );	
						if( r === false ) return false;
					},
					"mousedown" : function(e){
						if( opt.disabled || opt.readOnly ) {
							return;	
						}
						//input.trigger('focus',[e]);
						
						var r = fn.call( this,'onRaidoMouseDown','mousedown',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).addClass('nex-form-radio-item-down');
							var $this = $(this);
							__t = setTimeout( function(){
								__t = 0;
								$(document).one('mouseup',function(){
									$this.removeClass('nex-form-radio-item-down');							 
								});					 
							},0 );
						} );	
						if( r === false ) return false;
					},
					"mouseup" : function(e){
						var r = fn.call( this,'onRaidoMouseUp','mouseup',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).removeClass('nex-form-radio-item-down');
							if( __t ) {
								clearTimeout( __t );	
								__t = 0;
							}
						} );	
						if( r === false ) return false;
					},
					"focus" : function(e){
						input.trigger('focus2',[e]);
						if( __t2 ) {
							clearTimeout( __t2 );
							__t2 = 0;
						}	
					},
					"blur"  : function(e){
						__t2 = setTimeout(function(){
							__t2 = 0;
							input.trigger('blur2',[e]);		
						},0);	
					}
				 });
		},
		getCheckedSize : function(){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();	
			return $('>.nex-form-radio-item-checked',input).length;		
		},
		_unchecked : function(){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();	
			$('>.nex-form-radio-item',input).removeClass('nex-form-radio-item-checked');
			return self;
		},
		_uncheckedAll : function(){
			var self = this;
			var opt = this.configs;	
			//var input = self.getInput();
			var radios = Nex.Form.get( opt.name,opt.group );
			$.each( radios,function(i,radio){
				radio._unchecked();
				if( radio.configs.id === opt.id ) {
					return;	
				}
				var v = radio.getValue();
				if( radio.getCheckedSize() ) {
					radio.fireEvent( 'onChange',[ '',v ] );	
				}
			} );
			//$('>.nex-form-radio-item',input).removeClass('nex-form-radio-item-checked');
			return self;
		},
		unchecked : function(){
			this.setValue('');
			return this;
		},
		//设置选中
		checked : function( value,m ){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();
			var m = self._undef( m,true );
			var d = self.getItemData( value );
			d = $.isArray( d ) ? d[0] : d;
			if( d ) {
				if( m ) {
					self._uncheckedAll();
				}
				$('#'+d.__id).addClass('nex-form-radio-item-checked');
			}
		},
		/*
		*对单个radio设置disabled
		*@param value
		*param m private 默认true 设置disabled , false unsetDisabled
		*param css private 默认disabled , readonly
		*/
		setRadioDisabled : function( value,m,css ){
			var self = this;
			var opt = this.configs;	
			var m = self._undef( m,true );
			var css = self._undef( css,'disabled' );
			var d = self.getItemData( value );
			d = $.isArray( d ) ? d[0] : d;
			if( d ) {
				if( m ) {
					$('#'+d.__id).addClass('nex-form-radio-item-'+css);
					if( css === 'disabled' ) {
						d.disabled = true;	
					} else if( css === 'readonly' ) {
						d.readOnly = true;		
					} else {
						d[css] = true;	
					}
				} else {
					$('#'+d.__id).removeClass('nex-form-radio-item-'+css);
					if( css === 'disabled' ) {
						d.disabled = false;	
					} else if( css === 'readonly' ) {
						d.readOnly = false;		
					} else {
						d[css] = false;	
					}
				}
			}
			return self;		
		},
		unsetRadioDisabled : function( value ){
			return this.setRadioDisabled.apply( this,[ value,false ] );		
		},
		setRadioReadOnly : function(){
			return this.setRadioDisabled.apply( this,[ value,true,'readonly' ] );			
		},
		unsetRadioReadOnly : function(){
			return this.setRadioDisabled.apply( this,[ value,false,'readonly' ] );			
		},
		//重载
		getInputValue : function(){
			var self = this,undef;
			var opt = this.configs;	
			var input = self.getInput();
			var checked = $('>.nex-form-radio-item-checked',input);
			var value = '';
			if( checked.length  ) {
				value = decodeURIComponent( checked.attr('value') ) || '';
			}
			return value;
		},
		setInputValue : function( value ){
			var self = this;
			var opt = this.configs;
			
			self.checked( value );
			
			return self;
		},
		getInputText : function(){
			var self = this;
			var opt = this.configs;
			var value = self.getInputValue();
			var d = self.getItemData( value );
			d = $.isArray( d ) ? d[0] : d;
			if( d ) {
				return d[opt.textKey];	
			}
			return '';
		},
		setInputText : function( text ){
			var self = this;
			var opt = this.configs;
			var value = '';
			$.each( opt.items,function( i,d ){
				if( d[ opt.textKey ] === text ) {
					value = d[ opt.valueKey ];	
					return false;
				}	
			} );	
			self.setValue( value );
			return self;
		}
	});	
	//参数重载
	textfield.setOptions( function(opt){
		var tpl = opt.tpl;
		return {
			__inputType  		: 'radio',
			containerCls 		: [opt.containerCls,'nex-form-radio'].join(' '),
			showPlaceholder 	: false,
			triggerBtnsPosition : 'outer',
			radioLabelSelection : false,
			labelvAlign 		: 'top',
			width 				: 'auto',
			/*
			item = {
				cls : '',
				text : '',
				value : '',
				readOnly : false,
				disabled : false,
				display : 'inline',
				width : auto
			}
			或
			item = '-'
			*/
			itemDefault			: {},
			items 				: []
		};	
	} );
});
;$define([
	'Nex.form.Radio'
],function(){
	"use strict";
	var Checkbox = Nex.define('Nex.form.Checkbox','Nex.form.Radio',{
		alias : 'Nex.Form.Checkbox',
		xtype : 'checkboxfield',
		initComponent : function(){
			var self = this;
			var opt = this.configs;	
			
			self._setCheckboxs( opt.items );
			
			self._setCheckboxEvents();
			
			//调用父级构造函数
			Nex.form.Display.fn.initComponent.apply( self,arguments );
			
			if( !opt.checkboxLabelSelection ) {	
				var input = self.getInput();
				input.disableSelection();
			}
			
		},
		/*private*/
		_setCheckboxs : function( items ){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();
			var html = [];
			var valueKey = opt.valueKey,
				textKey = opt.textKey;
			var items = self._undef( items,opt.items );
			if( !$.isArray( items ) ) {
				return self;
			}
			var len = items.length;
			for( var i=0;i<len;i++ ) {
				var _d = self._parseItemData( items[i] );
				items[i] = _d;
				var d = $.extend( {
					//id 		 : items[i]['__id'],
					cls 	 : '',
					readOnly : false,
					disabled : false,
					display  : 'inline',
					width 	 : 'auto'
				}, opt.itemDefault ,_d );
				d.id = items[i]['__id'];
				if( !self.isSplitLine( d ) ) {
					html.push('<span id="'+d.id+'" tabindex="'+(++Nex.tabIndex)+'" class="nex-form-checkbox-item nex-form-checkbox-item-d-'+d.display+' '+ (d.readOnly?'nex-form-checkbox-item-readonly':'') +' '+ (d.disabled?'nex-form-checkbox-item-disabled':'') +' '+d.cls+'" value="'+d[valueKey]+'" value="'+encodeURIComponent(d[valueKey])+'" style="'+( isNaN(parseInt( d.width )) ? '' : 'width:'+parseInt( d.width )+'px' )+'"><span id="'+opt.id+'-checkbox-icon" class="nex-form-checkbox-icon"></span><span class="nex-form-checkbox-text">'+d[textKey]+'</span></span>');				 
				} else {
					html.push( self.tpl(opt.dropdownItemSplitLineTpl,d) );
				}
			}
			
			input.html( html.join('') );
			
			return self;
		},
		resetCheckboxs : function( items ){
			var self = this;
			var opt = this.configs;	
			var value = self.getValue();	
			if( !$.isArray( items ) ) {
				return self;	
			}
			opt.items = items;
			self._setCheckboxs( items );
			
			self.setInputValue( value );
			
			return self;
		},
		/*private*/
		_setCheckboxEvents : function(){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();
			
			var fn = function( evt1,evt2,e,func ){
				if( opt.disabled || opt.readOnly ) {
					return;	
				}
				var $this = $(this);
				var id = $this.attr('id');
				var d = self.getItemDataById( id );
				if( d.disabled || d.readOnly ) {
					return;
				}	
				var r;
				if( $.isFunction( d[evt2] ) ) {
					r = d[evt2].call( self,d );	
					if( r === false ) return false;	
				}	
				
				r = self.fireEvent(evt1,[ d[ opt.valueKey ],d,this,e ]);	
				if( r === false ) return false;	
				
				if( $.isFunction( func ) ) {
					func.call( this,d );	
				}
				
			};
			var __t = 0;
			var __t2 = 0;
			input.undelegate('>.nex-form-checkbox-item')
				 .delegate('>.nex-form-checkbox-item',{
					"click" : function(e){
						if( opt.disabled || opt.readOnly ) {
							return;	
						}
						var $this = $(this);
						var id = $this.attr('id');
						var d = self.getItemDataById( id );
						var r;
						if( d.disabled || d.readOnly ) {
							return;
						}	
						if( $.isFunction( d.callBack ) ) {
							r = d.callBack.call( self,d,e );	
						}
						if( $.isFunction( d.callback ) && r !== false ) {
							r = d.callback.call( self,d,e );	
						}
						if( $.isFunction( d.handler ) && r !== false ) {
							r = d.handler.call( self,d,e );	
						}
						if( r !== false ) {
							r = fn.call( this,'onCheckboxClick','click',e );
						}
						
						if( r === false ) return false;
						if( !$this.hasClass('nex-form-checkbox-item-checked') ) {
							self.setChecked( d[ opt.valueKey ] );
							//$this.toggleClass('nex-form-checkbox-item-checked');
						} else {
							self.unsetChecked( d[ opt.valueKey ] );	
						}
						
					},
					"dblclick" : function(e){
						return fn.call( this,'onRaidoDblClick','dblclick',e );
					},
					"mouseenter" : function(e){
						var r = fn.call( this,'onRaidoOver','mouseover',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).addClass('nex-form-checkbox-item-over');
						} );
						if( r === false ) return false;
					},
					"mouseleave" : function(e){
						var r = fn.call( this,'onRaidoOut','mouseout',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).removeClass('nex-form-checkbox-item-over');
						} );	
						if( r === false ) return false;
					},
					"mousedown" : function(e){
						var r = fn.call( this,'onRaidoMouseDown','mousedown',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).addClass('nex-form-checkbox-item-down');
							var $this = $(this);
							__t = setTimeout( function(){
								__t = 0;	
								$(document).one('mouseup',function(){
									$this.removeClass('nex-form-checkbox-item-down');							 
								});					 
							},0 );
						} );	
						if( r === false ) return false;
					},
					"mouseup" : function(e){
						var r = fn.call( this,'onRaidoMouseUp','mouseup',e,function( d ){
							if( d.disabled || d.readOnly ) {
								return;
							}	
							$(this).removeClass('nex-form-checkbox-item-down');
							if( __t ) {
								clearTimeout( __t );
								__t = 0;	
							}
						} );	
						if( r === false ) return false;
					},
					"focus" : function(e){
						input.trigger('focus2',[e]);
						if( __t2 ) {
							clearTimeout( __t2 );
							__t2 = 0;
						}	
					},
					"blur"  : function(e){
						__t2 = setTimeout(function(){
							__t2 = 0;
							input.trigger('blur2',[e]);		
						},0);	
					}
				 });
		},
		getCheckedSize : function(){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();	
			return $('>.nex-form-checkbox-item-checked',input).length;		
		},
		_uncheckedAll : function(){
			var self = this;
			var opt = this.configs;	
			var input = self.getInput();	
			$('>.nex-form-checkbox-item',input).removeClass('nex-form-checkbox-item-checked');
			$.each( opt.items , function(i,d){
				d.checked = false;	
			} );
			return self;
		},
		uncheckedAll : function(){
			this.setValue('');
			return this;
		},
		//选择所有
		checkedAll : function(  ){
			var self = this;
			var opt = this.configs;	
			var value = [];
			$.each( opt.items, function(i,d){
				value.push( d[ opt.valueKey ] );	
			} );
			self.setValue( value.join( opt.multiSplit ) );
			return self;
		},
		//反选
		reverseChecked : function(){
			var self = this;
			var opt = this.configs;	
			var selected = self.getValue();
			selected = selected.split( opt.multiSplit );
			var value = [];
			$.each( opt.items, function(i,d){
				if( $.inArray( d[opt.valueKey],selected ) === -1 ) {
					value.push( d[opt.valueKey] );
				}	
			} );
			self.setValue( value.join( opt.multiSplit ) );
			return self;
		},
		/*
		*对单个checkbox设置disabled
		*@param value
		*param m private 默认true 设置disabled , false unsetDisabled
		*param css private 默认disabled , readonly
		*/
		setCheckboxDisabled : function( value,m,css ){
			var self = this;
			var opt = this.configs;	
			var m = self._undef( m,true );
			var css = self._undef( css,'disabled' );
			var d = self.getItemData( value );
			d = $.isArray( d ) ? d[0] : d;
			if( d ) {
				if( m ) {
					$('#'+d.__id).addClass('nex-form-checkbox-item-'+css);
					if( css === 'disabled' ) {
						d.disabled = true;	
					} else if( css === 'readonly' ) {
						d.readOnly = true;		
					} else {
						d[css] = true;	
					}
				} else {
					$('#'+d.__id).removeClass('nex-form-checkbox-item-'+css);
					if( css === 'disabled' ) {
						d.disabled = false;	
					} else if( css === 'readonly' ) {
						d.readOnly = false;		
					} else {
						d[css] = false;	
					}
				}
			}
			return self;		
		},
		unsetCheckboxDisabled : function( value ){
			return this.setCheckboxDisabled.apply( this,[ value,false ] );		
		},
		setCheckboxReadOnly : function( value ){
			return this.setCheckboxDisabled.apply( this,[ value,true,'readonly' ] );			
		},
		unsetCheckboxReadOnly : function( value ){
			return this.setCheckboxDisabled.apply( this,[ value,false,'readonly' ] );			
		},
		_setChecked : function( value ){
			this.setCheckboxDisabled.apply( this,[ value,true,'checked' ] );	
		},
		setChecked : function( value ){
			var v1 = this.getInputValue();
			this._setChecked( value );	
			var v2 = this.getInputValue();
			if( v1 !== v2 ) {
				this.fireEvent('onChange',[v2,v1]);	
			}
			return this;		
		},
		_unsetChecked : function( value ){
			this.setCheckboxDisabled.apply( this,[ value,false,'checked' ] );
		},
		unsetChecked : function( value ){
			var v1 = this.getInputValue();
			this._unsetChecked( value );	
			var v2 = this.getInputValue();
			if( v1 !== v2 ) {
				this.fireEvent('onChange',[v2,v1]);	
			}
			return this;			
		},
		//重载
		getInputValue : function(){
			var self = this,undef;
			var opt = this.configs;	
			var input = self.getInput();
			var checked = $('>.nex-form-checkbox-item-checked',input);
			var value = [];
			if( checked.length  ) {
				checked.each( function(){
					value.push( decodeURIComponent( $(this).attr('value') ) );	
				} );
			}
			return value.join( opt.multiSplit );
		},
		setInputValue : function( value ){
			var self = this;
			var opt = this.configs;
			self._uncheckedAll();
			$.each( (value+'').split(opt.multiSplit),function(i,d){
				self._setChecked( d );	
			} );
			return self;
		},
		getInputText : function(){
			var self = this;
			var opt = this.configs;
			var value = self.getInputValue();
			var d = self.getItemData( value );
			d = $.isArray( d ) ? d : [d];
			var text = [];
			$.each( d,function(i,d){
				text.push( d[opt.textKey] );	
			} );
			return text.join( opt.multiSplit );
		},
		setInputText : function( text ){
			var self = this;
			var opt = this.configs;
			var value = [];
			var text = text.split( opt.multiSplit );
			$.each( opt.items,function( i,d ){
				if( $.inArray(d[ opt.textKey ],text) !== -1 ) {
					value.push( d[ opt.valueKey ] );
				}	
			} );	
			self.setValue( value.join( opt.multiSplit ) );
			return self;
		}
	});	
	//参数重载
	Checkbox.setOptions( function(opt){
		return {
			__inputType  : 'checkbox',
			containerCls : [opt.containerCls,'nex-form-checkbox'].join(' '),
			checkboxLabelSelection : false
		};	
	} );
});
;$define([
	'Nex.form.Text'
],function(){
	"use strict";
	var textfield = Nex.define('Nex.form.Hidden','Nex.form.Text',{
		alias : 'Nex.Form.Hidden',
		xtype : 'hiddenfield'
	});	
	//参数重载
	textfield.setOptions( function(opt){
		return {
			__inputType  : 'hidden',
			containerCls : [opt.containerCls,'nex-form-hidden'].join(' '),
			width 		 : 'auto',
			height 		 : 'auto',
			showLabel	 : false,
			cleanBtn	 : false
		};	
	} );
});
;$define([
	'Nex.form.Checkbox'
],function(){
	"use strict";
	var textfield = Nex.define('Nex.form.SingleCheckbox','Nex.form.Checkbox',{
		alias : 'Nex.Form.SingleCheckbox',
		xtype : 'singlecheckboxfield',
		_sysEvents2 : function(){
			var self = this,
				opt = self.configs;	
			Nex.form.Checkbox.fn._sysEvents.apply( self,arguments );
			//self.bind( 'onClick._sys',self._showDropDownClick,self );
			//self.bind( 'onCreateDropDwon._sys',self._setDropDownCls,self );
			return self;	
		},
		/*private*/
		_setCheckboxs : function( ){
			var self = this;
			var opt = this.configs;	
			var data = [{
				text : opt.text,
				value : opt.on	
			}];
			opt.items = data;
			Nex.form.Checkbox.fn._setCheckboxs.apply( self,[ data ] );
			return self;
		},
		unchecked : function(){
			var self = this;
			var opt = this.configs;	
			self.setValue( opt.off );
			return this;
		},
		checked : function( value,m ){
			var self = this;
			var opt = this.configs;	
			self.setValue( opt.on );
			return self;
		},
		getInputValue : function(){
			var self = this,undef;
			var opt = this.configs;	
			
			var value = Nex.form.Checkbox.fn.getInputValue.apply( self,arguments );
			
			return value === (opt.on+'') ? opt.on : opt.off;
		}
	});	
	//参数重载
	textfield.setOptions( function(opt){
		return {
			__inputType  : 'singlecheckbox',
			containerCls : [opt.containerCls,'nex-form-singlecheckbox'].join(' '),
			cleanBtn 	 : false,
			on 			 : '1',
			off 		 : '0',
			text  	     : '',
			value 		 : ''
		};	
	} );
});
;$define([
	'Nex.form.Form'
],function(){
	"use strict";
	var selectfield = Nex.define('Nex.form.Select','Nex.form.Form',{
		alias : 'Nex.Form.Select',
		xtype : 'selectfield',
		_sysEvents : function(){
			var self = this,
				opt = self.configs;	
			Nex.form.Form.fn._sysEvents.apply( self,arguments );
			self.bind( 'onClick._sys',self._showDropDownClick,self );
			self.bind( 'onCreateDropDwon._sys',self._setDropDownCls,self );
			return self;	
		},
		/*重载设置系统的trigger btn*/
		_setSysTriggerBtns : function(){
			var self = this,
				opt = self.configs;
			var input = self.getInput();	
			self.addInnerTriggerBtn({
				cls : 'nex-form-select-trigger',
				iconCls : 'nex-form-select-icon',
				callBack : function( d,e ){
					if( !opt.triggerToFocus ) {
						input.trigger('focus',[e]);//self.focus();
					}
				}	
			});
			Nex.form.Form.fn._setSysTriggerBtns.apply( self,arguments );
			//cleanBtn	
			return self;
		},
		_showDropDownClick : function(){
			var self = this,
				opt = self.configs;
			self.toggleDropDown();	
		},
		_setDropDownCls : function( dropdown ){
			var self = this,
				opt = self.configs;
			var el = self.el;
			if( el.hasClass('nex-form-focus') ) {	
				dropdown.addClass('nex-form-select-dropdown-focus');
			} else {
				dropdown.removeClass('nex-form-select-dropdown-focus');		
			}
		},
		_getItemData2 : function( value ){
			var self = this;
			var opt = self.configs;
			var items = opt.items;
			var d = null;
			$.each( items.concat(self.__CItems) , function(i,v){
				if( !$.isPlainObject( v ) ) return;
				var vs = v[opt.valueKey];
				if( String(vs) === String(value) ) {
					d = v;
					return false;
				}
			} );		
			return d;
		},
		/*
		*获取实际中的input 一般和input相同
		*/
		__inputreal : null,
		getInputReal : function(){
			var self = this;
			var opt = self.configs;
			self.__inputreal = self.__inputreal ? self.__inputreal : $("#"+opt.id+"-input-real");
			return self.__inputreal;
		},
		/*
		*设置下拉框的值
		*param value
		*param text 可选 如果没设置会从items里查找
		*/
		setInputValue : function( value,text ){
			var self = this;
			var opt = self.configs;
			var text = self._undef( text,null );
			var sep = opt.multiSplit;
			
			Nex.form.Form.fn.setInputValue.apply( self,arguments );
			
			if( text === null ) {	
				var txt = [];
				value = String(value).split(sep);
				$.each( value,function(i,v){
					var d = self._getItemData2( v );
					txt.push(d ? d[ opt.textKey ] : value);	
				} );
				text = txt.join(sep);
			}
			
			self.setInputText( text );
			
			return self;
		},
		/*
		*设置表单的Items
		*如果初始化后 需要重新设置items 最好使用setItems(list) 而不要直接使用obj.C('items',list);
		*m 默认true 会根据items自动刷新text显示框的文本
		*/
		setDropDownItems : function( items,m ){
			var self = this;
			var opt = this.configs;
			
			Nex.form.Form.fn.setDropDownItems.apply( self,arguments );
			
			if( opt.dropdownMode == 2 ) {
				return opt.items;
			}
			
			var sep = opt.multiSplit;
			var value = this.getInputValue();	
			value = value.split(sep);
			var text = [];
			
			if( $.isArray( opt.items ) ) {
				$.each( value,function(i,v){
					var txt = v;
					$.each( opt.items,function( i,d ){
						var _v = d[opt.valueKey];
						if( String(_v) === String(v) ) {
							txt = d[opt.textKey];
							return false;
						}
					} );
					text.push( txt );	
				} );
			}
			var m = this._undef( m,true );
			if( m ) {
				this.setInputText( text.join( sep ) );	
			}
			
			return opt.items;	
		}
	});	
	//参数重载
	selectfield.setOptions( function(opt){
		var tpl = opt.tpl;
		tpl.formTpl = '<table id="<%=id%>-inner" class="nex-field nex-form-inner" cellspacing="0" cellpadding="0" ><tbody>'
							+'<tr id="<%=id%>-inputRow">'
								+'<td class="nex-form-inner-body" id="<%=id%>-body-td">'
									+'<div id="<%=id%>-body" class="nex-form-body">'
										+'<div <%=attrs%> id="<%=id%>-input" type="<%=type%>" tabindex=<%=tabIndex%> autocomplete="<%=autocomplete%>" value="" style="/*width:0px;*/" class="nex-form-field nex-form-field-<%=type%>"></div>'
										+'<input id="<%=id%>-input-real" type="hidden" value="" name="<%=name%>" />'
										+'<label id="<%=id%>-placeholder" class="nex-form-placeholder"><%=placeholder%></label>'
										+'<div id="<%=id%>-trigger-body" class="nex-form-trigger-body"></div>'
									 +'</div>'
								+'</td>'
							+'</tr>'
						+'</tbody></table>';
		return {
			__inputType  : 'select',
			containerCls : [opt.containerCls,'nex-form-select'].join(' '),
			cleanBtn 	 : false,
			triggerToFocus : true,
			tpl			 : tpl,
			dropdownSingleSelect : true  //单选下拉框
		};	
	} );
});
;$import([
	'Nex.form.Text'
],function(){
	"use strict";
	var trigger = Nex.define('Nex.form.Trigger','Nex.form.Text',{
		alias : 'Nex.Form.Trigger',
		xtype : 'trigger triggerfield',
		_sysEvents : function(){
			var self = this,
				opt = self.configs;	
			self.bind('onSetFormView._sys',self._setInputCls,self);	
			Nex.form.Form.fn._sysEvents.apply( self,arguments );
			return self;	
		},
		/*重载设置系统的trigger btn*/
		_setSysTriggerBtns : function(){
			var self = this,
				opt = self.configs;
			self._setTriggerBtn();
			Nex.form.Form.fn._setSysTriggerBtns.apply( self,arguments );
			//cleanBtn	
			return self;
		},
		_setTriggerBtn : function(){
			var self = this,
				opt = self.configs;
			//var input = self.getInput();	
			self.addInnerTriggerBtn({
				name : 'trigger',
				cls : ['nex-form-triggerfield-trigger',opt.triggerCls].join(' '),
				iconCls : ['nex-form-triggerfield-icon',opt.triggerIconCls].join(' '),
				callBack : function( d,e ){
					var r = self.fireEvent('onTriggerClick',[ opt ]);
					if( r === false ) return;
				}	
			});	
		},
		_setInputCls : function(){
			var self = this,
				opt = self.configs;
			var ccls = $.isArray(opt._inputCls) ? opt._inputCls : [ opt._inputCls ];
			var cls = ['nex-form-field-trigger'].concat( ccls );	
			$('#'+opt.id+'-input').addClass( cls.join(' ') );
		}
	});	
	//参数重载
	trigger.setOptions( function(opt){
		return {
			__inputType  : 'text',
			containerCls : [opt.containerCls,'nex-form-trigger'].join(' '),
			_inputCls    : [],
			cleanBtn 	 : false,
			triggerToFocus : false,
			triggerCls	 : '',
			triggerIconCls	 : ''
		};	
	} );
});
/*
*需要修改 应该继承Trigger
*/
;$import([
	'Nex.form.Text'
],function(){
	"use strict";
	var combobox = Nex.define('Nex.form.ComboBox','Nex.form.Text',{
		alias : 'Nex.Form.ComboBox',
		xtype : 'combobox',
		_sysEvents : function(){
			var self = this,
				opt = self.configs;	
			self.bind('onSetFormView._sys',self._setInputCls,self);	
			Nex.form.Form.fn._sysEvents.apply( self,arguments );
			return self;	
		},
		/*重载设置系统的trigger btn*/
		_setSysTriggerBtns : function(){
			var self = this,
				opt = self.configs;
			var input = self.getInput();	
			self.addInnerTriggerBtn({
				cls : ['nex-form-combobox-trigger',opt.triggerCls].join(' '),
				iconCls : ['nex-form-combobox-icon',opt.triggerIconCls].join(' '),
				callBack : function( d,e ){
					if( !opt.triggerToFocus ) {
						input.trigger('focus',[e]);
					}
				}	
			});
			Nex.form.Form.fn._setSysTriggerBtns.apply( self,arguments );
			//cleanBtn	
			return self;
		},
		_setInputCls : function(){
			var self = this,
				opt = self.configs;
			var ccls = $.isArray(opt._inputCls) ? opt._inputCls : [ opt._inputCls ];
			var cls = ['nex-form-field-combobox'].concat( ccls );	
			$('#'+opt.id+'-input').addClass( cls.join(' ') );
		}
	});	
	//参数重载
	combobox.setOptions( function(opt){
		return {
			__inputType  : 'text',
			containerCls : [opt.containerCls,'nex-form-combobox'].join(' '),
			_inputCls    : [],
			//cleanBtn 	 : true,
			triggerToFocus : true,
			triggerCls	 : '',
			triggerIconCls	 : ''
		};	
	} );
});
/*
jquery.nexMenu.js
http://www.extgrid.com/menu
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
*/

;(function($){
	"use strict";
	//var menu = Nex.widget('menu');
	var menu = Nex.define('Nex.menu.Menu',{
		alias : 'Nex.Menu',
		xtype : 'menu'		
	});
	menu.extend({
		version : '1.0',
		getDefaults : function(opt){
			var _opt = {
				prefix : 'nexmenu-',
				renderTo : document.body,
				denyManager : true,
				width : 0,
				height : 0,
				maxWidth : 0,
				minWidth : 0,
				minHeight : 0,
				maxHeight : 0,
				parent : null,//设置menu绑定的父组件，如果父组件释放，则当前menu也会销毁
				items : [],
				//item可能出现的值
				_item : {
					cls : '',
					icon : '',
					iconCls: '',
					arrow : '',//arrow 图片地址
					arrowCls : '',
					id :　'',
					text : '',
					'open' : '',
					_level : '',
					pid : '',
					items : '',
					disabled : '',
					width : '',
					height : '',
					callBack:null,//return false会阻止事件冒泡
					callback : null,
					hideOnClick:true, //点击后会关闭菜单列表
					subCls : '',//subMenu样式
					isCmp : false// 如果设为 true 则会把items当作组件来创建
				},
				itemDefault : {},
				itemTpl : '<div id="<%=menuId%>_<%=itemId%>_item" <%=tips%> menuid="<%=itemId%>" class="nex-menu-item <%=cls%>">'
						+ '<%'
						+ '    if( showMenuIcon ) {'
						+ '        if( icon ) {'
						+ '            icon = "background-image:url("+icon+")";'
						+ '        }'
						+ '%>'
						+ '    <span class="nex-menu-icon <%=iconCls%>" style="<%=icon%>"></span>'
						+ '<%'
						+ '    }'
						+ '%>'
						+ '    <span class="nex-menu-title"><%=text%></span>'
						+ '<%'
						+ '    if( !isLeaf ) {'
						+ '        if( arrow ) {'
						+ '            arrow = "background-image:url("+arrow+")";'
						+ '        }'
						+ '%>    '
						+ '    <span class="nex-menu-arrow <%=arrowCls%>" style="<%=arrow%>"></span>'
						+ '<%'
						+ '    }'
						+ '%>    '
						+ '</div>',
				splitLineTpl : '<div class="nex-menu-item-separator"><div class="nex-menu-line-h"></div></div>',
				itemTips : false,//下拉列表是否这种tips字段
				itemTipsTag : 'title',
				itemTipsFilter : null,//function	
				itemFilter : null,	
				itemFormat : null,
				splitChr : ['-',',',';','|'],
				cls : '',//所有menu的样式
				style : {},//同上
				padding : null,//同上
				delay : 0,//延迟毫秒数 ms
				//IEVer : Nex.IEVer,
				border :　false,
				borderCls : 'nex-menu-border',
				showShadow : true,
				shadowWidth : 5,
				hideToRemove : true,
				showMenuVLine : true,//显示节点线条
				showMenuIcon : true,//显示节点图标
				showMenuMore : true,//如果列表过多 显示上下 btn
				upBtnCls : '',
				downBtnCls : '',
				_speedTime : 10,
				_speedNum : 5,
				_data : {},
				_childrens : {},
				_levelData : {},//level=>[]
				_firstNodes : {},// 0:node1,1:node2 k=>v k表示第几级
				_lastNodes : {},// 0:node1,1:node2 k=>v k表示第几级
				hideOnClick : true,
				hideOnBlur  : true, //点击其他区域时 关闭menu
				expandOnEvent : 0,//0 mousover 1 click  -1 不显示子菜单
				simpleData : false,
				root : '0',//simpleData下可不用设置且只在初始化时有效，初始化后会用showRowId代替
				showRootId : '0',//请设置对应的顶层ID 非simpleData下可不用设置
				iconField : 'icon',//图标字段 样式
				iconClsField : 'iconCls',//图标字段 样式
				idField : 'id',
				textField : 'text',
				openField : 'open',
				levelField : '_level',
				parentField : 'pid',
				sortField : 'order',
				childField : 'items',
				disabledField : 'disabled',
				groupNode : false,//开启后会对叶子和节点进行分类
				autoShow  : false,
				showAt : {},//根菜单显示配置
				subShowAt : {},//子菜单显示配置
				_showAt : {xAlign:'right',yAlign:'bottom',zAlign:'x'},//通用配置
				events : {}
			};
			
			var _opt = this.extSet(_opt);
			
			return $.extend({},_opt,opt);
		}
	});
	menu.fn.extend({
		_init : function(opt) {
			var self = this;
			var cls = opt.cls.split(/\s+/);
			Nex.array_splice( function(i,v){
				if( v == 'nex-component-item' ) {
					return true;	
				}
			},cls );
			opt.cls = cls.join(' ');
			//_mapTree
			opt.items = $.isArray( opt.items ) ? [].concat(opt.items) : [opt.items];
			
			self._parseMenuData(opt.items);
			
			self._destroyOnParent();
			if( opt.autoShow ) {
				self.show();
			}
			self.fireEvent('onCreate',[opt]);
		},
		_destroyOnParent : function(){
			var self = this;
			var opt = self.configs;
			if( !opt.parent ) return;
			var p = opt.parent;
			if( !Nex.isNex( p ) ) {
				p = Nex.get( p );
			} else {
				opt.parent = p.configs.id;	
			}	
			if( !p ) return;
			p.one('onDestroy._'+opt.id,function(){
				self.destroyMenu();	
				self.destroy();
			});
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			
			return self;
		},
		_clickItem : function(li,tid,node,e){
			var self = this,
				opt=this.configs;
			
			if( node[opt.disabledField] ) {
				return;
			}
			var r;
			if( $.isFunction( node['callBack'] ) ) {
				r = node['callBack'].apply(opt.context || self,[li,tid,node,e,opt]);
				if( r === false ) return false;
			}
			if( $.isFunction( node['callback'] ) ) {
				r = node['callback'].apply(opt.context || self,[li,tid,node,e,opt]);
				if( r === false ) return false;
			}
			var hide = self._undef( node['hideOnClick'], opt.hideOnClick );
			if( !hide ) {
				return;	
			}
			if( self.isLeaf( tid ) && opt.hideOnClick ) {
				self.hideRoot();
			}
		},
		_setOverCls : function(li,tid,node,e){
			var self = this,
				opt=this.configs;
			if( node[opt.disabledField] ) {
				return;	
			}
			$(li).addClass("nex-menu-item-over");
		},
		_unsetOverCls : function(li,tid,node,e){
			var self = this,
				opt=this.configs,
				undef;
			if( node[opt.disabledField] ) {
				return;	
			}
			$(li).removeClass("nex-menu-item-over");	
		},
		_t_delay : 0,
		_displayMenu : function(el,tid,node,e){
			var self = this,
				opt=this.configs,
				undef;
				
			if( self._t_delay ) {
				clearTimeout( self._t_delay );
				self._t_delay = 0;
			}	
			
			if( $(el).hasClass('nex-menu-item-active') ) {
				return;	
			}
			
			if( opt.delay>0 ) {
				self._t_delay = setTimeout(function(){
					self.showSubMenu( tid );
				},opt.delay);	
			} else {
				self.showSubMenu( tid );
			}
		},
		_getNode : function(tid,pro){
			var self = this,
				opt=this.configs,
				undef;	
			//var node = opt._data[ opt._tfix+tid ];
			var node = opt._data[ tid ];
			
			if( node === undef ) {
				return false;	
			}
	
			return pro===undef ? node : node[pro];
		},
		getNode : function(){
			return this._getNode.apply( this,arguments );	
		},
		_getParentID : function(tid){
			var self = this,
				opt=this.configs,
				undef;	
			var pid = 	self._getNode(tid,opt.parentField);
			return pid === opt.root ? opt.root : 	pid;
		},
		_parseSimpleData : function(data,pid){
			var self = this,
				opt=this.configs;	
			var undef;
			var _ids = {};
			for( var i=0;i<data.length;i++ ) {
				var node = data[i];
				
				if( self.inArray( node,opt.splitChr ) !== -1 ) {
					node = {
						splitLine : true
					};	
				}
				
				node = $.extend({},opt.itemDefault,node);
				
				if( node[opt.parentField] === undef ) {
					node[opt.parentField] = pid === undef ? opt.root : pid;
					node[opt.levelField] = pid === undef ? 0 : self._getNode(pid,opt.levelField)+1;
				} else {
					node[opt.levelField] = 	self._getNode(node[opt.parentField],opt.levelField)+1;
				}
				if( !(opt.idField in node) ) {
					node[opt.idField] = 'menu_'+self.unique();	
				} else{
					if(node[opt.idField].toString().length<=0) {
						node[opt.idField] = 'menu_'+self.unique();		
					}
				}
				
				opt._data[ node[opt.idField] ] = node; 
				
				var _pid = node[opt.parentField];
				opt._childrens[ _pid ] = opt._childrens[ _pid ] === undef ? [] : opt._childrens[ _pid ];
				var childs = opt._childrens[ _pid ];
				childs.push(node);
				//levelData
				var _lv = node[opt.levelField];
				opt._levelData[ _lv ] = opt._levelData[ _lv ] === undef ? [] : opt._levelData[ _lv ];
				var levels = opt._levelData[ _lv ];
				levels.push(node);
				
				_ids[_pid] = true;
				
			}	

			for( var nid in _ids ) {
				//self.groupNodes( nid );
				self.updateLastNodes( nid );
			}
		},
		//解析数据 _mapTree
		_parseMenuData : function(data,pid){
			var self = this,
				opt=this.configs;	
			var undef;
			if( opt.simpleData ) {
				self._parseSimpleData(data,pid);
				return self;
			}
			for( var i=0;i<data.length;i++ ) {
				var node = data[i];
				
				if( self.inArray( node,opt.splitChr ) !== -1 ) {
					node = {
						splitLine : true
					};	
				}
				
				node = $.extend({},opt.itemDefault,node);
				
				node[opt.levelField] = pid === undef ? 0 : self._getNode(pid,opt.levelField)+1;
				node[opt.parentField] = pid === undef ? opt.root : pid;
				
				if( !(opt.idField in node) ) {
					node[opt.idField] = 'menu_'+self.unique();	
				}
				
				opt._data[ node[opt.idField] ] = node; 
				
				var _pid = node[opt.parentField];
				opt._childrens[ _pid ] = opt._childrens[ _pid ] === undef ? [] : opt._childrens[ _pid ];
				var childs = opt._childrens[ _pid ];
				childs.push(node);
				//levelData
				var _lv = node[opt.levelField];
				opt._levelData[ _lv ] = opt._levelData[ _lv ] === undef ? [] : opt._levelData[ _lv ];
				var levels = opt._levelData[ _lv ];
				levels.push(node);
				
				if( ( opt.childField in node ) && $.isArray( node[opt.childField] ) && node[opt.childField].length ) {
					self._parseMenuData(node[opt.childField],node[opt.idField]);
				}
				
				if( (i+1) === data.length ) {
					self.updateLastNodes( _pid );
				}
				
			}	
			return self;
		},
		/*
		*更新 第一个节点和最后一个节点的索引
		*/
		updateLastNodes : function(pid){
			var self = this,
				opt=this.configs,
				undef;
			var pid = pid === undef ? opt.root : pid;	
			var chlids = opt._childrens[pid];
			if( chlids.length ) {
				opt._firstNodes[pid] = chlids[0];
				opt._lastNodes[pid] = chlids[chlids.length-1];
			}
		},
		_clearParseCache : function(){
			var self = this,
				opt=this.configs;	
			opt._childrens = {};	
			opt._data = {};
			opt._childrens = {};
			opt._levelData = {};
			opt._firstNodes = {};
			opt._lastNodes = {};
			return this;
		},
		//重新设置items
		setItems : function( items ){
			this.destroyMenu();
			this._clearParseCache();
			this._parseMenuData( items );
			return this;	
		},
		addChildren : function(tid,data){
			var self = this,
				opt=this.configs,
				undef;	
			var d = !$.isArray( data ) ? [data] : data;	
			self._parseMenuData(d,tid);
			return this;
		},
		addItems : function(){
			return this.addChildren.apply(this,arguments)	
		},
		resetMenuList : function( tid ){
			var menu = this.getMenuItem( tid );
			if( menu.length ) {
				menu.remove();	
			}	
			return this;
		},
		isSplitLine : function( node ){
			var self = this
				,opt=this.configs
				,undef;	
			if( node.splitLine ) return true;
			return false;
		},
		isLeaf : function(node){
			var self = this
				,opt=this.configs
				,undef;
			if( node === opt.root ) return false;
			var tnode = $.isPlainObject(node) ? node : self._getNode(node);
			if( tnode === false && !self._isRoot(node) ) return true;
			if( self._isRoot(node) ) return false;
			if( tnode.leaf === undef ) {
				//判断isCmp
				if( tnode['isCmp'] && tnode[opt.childField] ) {
					return false;	
				}
				var tid = tnode[opt.idField];
				var childrens = self.getChildrens(tid);
				if( childrens.length ) {
					return false;	
				}
				if( (opt.childField in tnode) && tnode[opt.childField].length ) {
					return false;	
				}
				return true;	
			} else {
				return !!tnode.leaf;	
			}
		},
		getAllChildrens : function(pid) {
			var self = this
				,opt=this.configs
				,undef;
			var childs = [];
			var pid = self._undef(pid,opt.root);
			var getChilds = function(pid){
				var _childs = self.getChildrens(pid);
				if( _childs.length ) {
					childs = childs.concat(_childs);
					for( var i=0;i<_childs.length;i++ ) {
						getChilds(_childs[i][opt.idField]);
					}
				}
			}
			getChilds(pid);
			return childs;
		},
		/*
		*获取子级
		*/
		getChildrens : function(pid){
			var self = this
				,opt=this.configs
				,undef;
			
			var pid = pid === undef ? opt.root : pid;
			
			return opt._childrens[pid] === undef ? [] : opt._childrens[pid];
		},
		//没有用到
		_getParentsList : function(tid){
			var self = this
				,opt=this.configs
				,root=opt.root
				,pids = [];
			var node = $.isPlainObject(tid) ? tid : self._getNode(tid);	
			if( node===false ) return [];
			var id = node[opt.idField];
			var pid = self._getParentID(id);
			while( 1 ) {
				if( !(pid in opt._data) ) break;
				pids.push( pid );	
				pid = self._getParentID(pid);
				if( pid === opt.root ) break;
			}
			return pids.reverse();
		},
		//没有用到
		_isFirstNode : function(tid){
			var self = this
				,opt=this.configs;
			var _pid = self._getParentID(tid);
			return opt._firstNodes[_pid][opt.idField] === tid ? true : false;
		},
		//没有用到
		_isLastNode : function(tid){
			var self = this
				,opt=this.configs;
			var _pid = self._getParentID(tid);
			return opt._lastNodes[_pid][opt.idField] === tid ? true : false;
		},
		_getMenuItemTpl : function(tnode){
			var self = this
				,opt=this.configs
				,spacers = [];
				
			var node = $.isPlainObject(tnode) ? tnode : self._getNode(tnode);
			if( node===false ) return '';
			/*
			if( self.isSplitLine( node ) ) {
				return '<div class="nex-menu-item-separator"><div class="nex-menu-line-h"></div></div>';	
			}
			*/
			var tid = node[opt.idField];
				
			var menuID = [opt.id,'_',node[opt.idField]].join("");
			
			var _pid = self._getParentID(tid);
			var liCls='';
			if( opt._firstNodes[_pid][opt.idField] === tid ) {
				liCls = 'nex-menu-first';	
				if( opt._firstNodes[opt.root][opt.idField] === tid ) {
					liCls+=' nex-menu-first-all';
				}
			}
			if( opt._lastNodes[_pid][opt.idField] === tid ) {
				liCls = 'nex-menu-last';	
			}
			
			if( node[opt.disabledField] ) {
				liCls += ' nex-menu-item-disabled';		
			}
			
			if( node['cls'] ) {
				liCls += ' '+node['cls'];			
			}
			
			var d = {
				splitLine : node['splitLine'],
				menuId : opt.id,
				itemId : tid,
				showMenuIcon : opt.showMenuIcon,
				cls : liCls,
				iconCls : node[opt.iconClsField],
				icon : node[opt.iconField],
				arrow : node['arrow'],
				arrowCls : node['arrowCls'],
				text : node[opt.textField],
				isLeaf : self.isLeaf(tid),
				showTips : opt.itemTips,
				tips : ''
			};
			
			if( opt.itemTips ) {
				var attr_tips = [opt.itemTipsTag,'="',];
				var tips = self._undef( node['tips'], node[opt.textField] );
				if( $.isFunction( opt.itemTipsFilter ) ) {
					tips = 	opt.itemTipsFilter.call( self,tips,d );
				}
				if( tips ) {
					tips = Nex.htmlEncode( tips );	
				}
				d.tipsMsg = tips;
				d.tipsTag = opt.itemTipsTag;
				attr_tips.push(tips);
				attr_tips.push('"');
				d.tips = attr_tips.join('');
			}
			
			if( opt.itemFilter && $.isFunction( opt.itemFilter ) ) {
				var r = opt.itemFilter.call( self,d );
				if( r === false ) return '';
				if( r !== undef ) {
					d = r;//$.extend(d,r);	
				}
			}
			
			if( opt.itemFormat && $.isFunction( opt.itemFormat ) ) {
				d.text = opt.itemFormat.call( self,d.text,d ) || d.text;
			}
			
			var r = self.fireEvent('onBeforeCreateItem',[ tid,d,opt ]);
			if( r === false ) return '';
			
			var _itemTpl = '';
			if( self.isSplitLine( d ) ) {
				_itemTpl = self.tpl(opt.splitLineTpl,d);	
			} else {
				_itemTpl = self.tpl(opt.itemTpl,d);
			}
			
			var et = {
				itemId : tid,
				itemTpl : _itemTpl,
				itemData : d
			};
			
			self.fireEvent('onCreateItem',[ et,opt ]);
			
			return et.itemTpl;
		},
		_isRoot : function(tid){
			var opt=this.configs;	
			return (tid === opt.root) ? true : false;
		},
		_bindUpBtnEvent : function( up,menu ){ 
			var self = this
				,opt=this.configs;	
			var menu = menu || down.parent();	
			var wraper = $('>.nex-menu-items-wraper',menu);
			var down = $('>.nex-menu-down',menu);
			
			up.bind({
				mouseenter : function(){
					var i = parseInt(wraper.css( 'margin-top' )) || 0;
					var tid = $(this).attr('menuid');
					self.hideAllSubSubMenu( tid );
					down.show();
					if( opt._t_down ) {
						clearInterval( opt._t_down );		
					}
					opt._t_down = setInterval(function(){
													   
						i = i+opt._speedNum;
						i = Math.min(i,0);
						wraper.css({
							'margin-top' : i								  
						});		
						
						if( i>=0 ) {
							up.hide();
							clearInterval( opt._t_down );	
						}
						
					},opt._speedTime);	
				},
				mouseleave : function(){
					clearInterval( opt._t_down );	
				}		  
			});
			
			
		},
		_bindDownBtnEvent : function( down,menu ){ 
			var self = this
				,opt=this.configs;	
			var menu = menu || down.parent();	
			var up = $('>.nex-menu-up',menu);
			var wraper = $('>.nex-menu-items-wraper',menu);
			var h1 = $(menu).height(),
				h2 = wraper.outerHeight();
			var diff = h2 - h1;
			down.bind({
				mouseenter : function(){
					var i = -(parseInt(wraper.css( 'margin-top' )) || 0);
					var tid = $(this).attr('menuid');
					self.hideAllSubSubMenu( tid );
					up.show();
					if( opt._t_down ) {
						clearInterval( opt._t_down );		
					}
					opt._t_down = setInterval(function(){
													   
						i = i+opt._speedNum;
						i = Math.min(i,diff);
						wraper.css({
							'margin-top' : -i								  
						});		
						
						if( i>=diff ) {
							down.hide();
							clearInterval( opt._t_down );	
						}
						
					},opt._speedTime);	
				},
				mouseleave : function(){
					clearInterval( opt._t_down );	
				}		  
			});
			
			
		},
		_checkMenuHeight : function( tid,menu ){
			var self = this
				,opt=this.configs;	
			if( !menu ) return false;
			var h1 = $(menu).height(),
				wraper = $('>.nex-menu-items-wraper',menu),
				h2 = wraper.outerHeight();
				
			$('>.nex-menu-up,>.nex-menu-down',menu).remove();
			
			if( h2 <= h1 ) return false;
			var diff = h2 - h1;
			var sTop = parseInt(wraper.css('marginTop')) || 0;
			
			var up = $('<div class="nex-menu-up '+opt.upBtnCls+'" menuid="'+tid+'"></div>'),
				down = $('<div class="nex-menu-down '+opt.downBtnCls+'" menuid="'+tid+'"></div>');
			
			menu.append( up );	
			menu.append( down );
			
			wraper.css('marginTop',0);
			up.hide();
			down.show();
			
			self._bindUpBtnEvent(up,menu);
			self._bindDownBtnEvent(down,menu);
			
			self.fireEvent('onMenuScrollBtnCreate',[tid,up,down,opt]);
			
		},
		/*
		*事件绑定 注：并没有阻止事件冒泡
		*/
		_bindMenuEvent : function(menu){
			var self = this
				,opt=this.configs;	
			var menus = opt._data;
			var callBack = function(type,e,fn,def){
				var tid = $(this).attr('menuid');
				var node = self._getNode(tid);
				var r = true;
				if( (type in node) && $.isFunction(node[type]) ) {
					r = node[type].apply(self,[this,tid,menus[tid],e]);
				}
				if( r!==false ) {
					r = self.fireEvent(type,[ this,tid,menus[tid],e,opt ]);
				}
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				} else {
					if( fn ) {
						$.isFunction( fn ) ? fn.apply( self,[ this,tid,menus[tid],e ] ) : null;
					}
				}
				if( def ) {
					$.isFunction( def ) ? def.apply( self,[ this,tid,menus[tid],e ] ) : null;
				}
				return r;
			};
			var events = {
				'click._meun' : function(e) {
					callBack.call(this,'onClick',e,function(){
						if( opt.expandOnEvent == 1 ) {
							self._displayMenu.apply( self,arguments );	
						}		
					},self._clickItem);
				},
				'dblclick._meun' : function(e) {
					callBack.call(this,'onDblClick',e);
				},
				'keydown._meun' : function(e) {
					callBack.call(this,'onKeyDown',e);
				},
				'keyup._meun' : function(e) {
					callBack.call(this,'onKeyUp',e);
				},
				'keypress._meun' : function(e){
					callBack.call(this,'onKeyPress',e);
				},
				'mouseenter._meun' : function(e){
					callBack.call(this,'onMouseOver',e,function(){
						self._setOverCls.apply( self,arguments );	
						if( opt.expandOnEvent == 0 ) {
							self._displayMenu.apply( self,arguments );	
						}		
					});
				},
				'mouseleave._meun' : function(e){
					callBack.call(this,'onMouseOut',e,function(){
						self._unsetOverCls.apply( self,arguments );		
					});
				},
				'mousedown._meun' : function(e) {
					callBack.call(this,'onMouseDown',e);
				},
				'mouseup._meun' : function(e) {
					callBack.call(this,'onMouseUp',e);
				},
				'contextmenu._meun' : function(e){	
					callBack.call(this,'onContextMenu',e);
				}
			};
			
			menu.undelegate('>.nex-menu-item')
				.delegate('>.nex-menu-item',events);
			
			return self;
		},
		bindMenuEvent : function(menu){
			var opt=this.configs;	
			var returnfalse = function(e){
					return false;
				};
			$(menu).parent().bind({
				//'mousedown' : returnfalse,
				//'mouseover' : returnfalse,
				'contextmenu._menu' : returnfalse
				//click : returnfalse
			});
			//这里可以采用 事件委托的方式...
			this._bindMenuEvent(menu);	
			this.fireEvent('onBindMenuEvents',[ menu,opt ]);
			return this;
		},
		getRootMenu : function(){
			var opt=this.configs;	
			var id = [opt.id,'_',opt.root].join("");
			return $('#'+id);
		},
		getMenu : function( tid ){
			var opt=this.configs;	
			var id = [opt.id,'_',tid].join("");
			return $('#'+id);
		},
		getMenuShadow : function( tid ){
			var opt=this.configs;	
			var id = [opt.id,'_',tid,'_shadow'].join("");
			return $('#'+id);
		},
		getMenuWraper : function( tid ){
			var opt=this.configs;	
			var id = [opt.id,'_',tid,'_items_wraper'].join("");
			return $('#'+id);
		},
		getMenuBody : function( tid ){
			return this.getMenuWraper( tid );	
		},
		getMenuItem : function( tid ){
			var opt=this.configs;	
			var id = [opt.id,'_',tid,'_item'].join("");
			return $('#'+id);
		},
		/*
		*创建Menu
		*/
		_bulidMenu : function(tid){
			var self = this
				,opt=this.configs;	
			var tid = self._undef(tid,opt.root);
	
			var node = self._getNode(tid);
			
			var menuID = [opt.id,'_',tid].join("");
			var menu = $("#"+menuID);
			//var menu_wraper = $('#'+menuID+'_items_wraper');
			
			var _createMenu = function(){
				var childrens = self._undef(opt._childrens[ tid ],[]);;
				var menuCls = ['nex-menu'];
				if( opt.border ) {
					menuCls.push( opt.borderCls );	
				}
				menuCls.push( opt.cls );
				menuCls.push( node['subCls'] );
				
				Nex.topzIndex = Nex.topzIndex + 2;
				
				var menu = ['<div id="',menuID,'" menu-cmpid="'+opt.id+'" style="z-index:',Nex.topzIndex,'" class="',menuCls.join(' '),'">'];
				menu.push('<div class="nex-menu-items-wraper" id="'+menuID+'_items_wraper">')
				if( !node['isCmp'] ) {
					menu.push(opt.showMenuVLine ? '<div class="nex-menu-line-v"></div>' : '');
					for( var i=0;i<childrens.length;i++ ) {
						menu.push( self._getMenuItemTpl(childrens[i]) );
					}
				}
				menu.push('</div></div>');
				menu = $(menu.join(""));
				
				var render = $(opt.renderTo);
				render.append(menu);
				
				if( opt.padding ) {
					menu.css('padding',opt.padding);	
				}
				menu.css(opt.style);
				
				//isCmp
				if( node['isCmp'] && node[opt.childField] ) {
					var wraper = $('#'+menuID+'_items_wraper');	
					//wraper.empty();
					self.parseItems( wraper,node[opt.childField] );
				}
				
				return menu;
			};
			
			var _setMenuSize = function( menu ){
				var render = $(opt.renderTo);
				menu._removeStyle('width height');
				//menu_wraper._removeStyle('width height');
				var w = node['width'] || opt.width;
				var h = node['height'] || opt.height;
				w = $.isFunction( w ) ? w.call( self,tid ) : w;
				h = $.isFunction( h ) ? h.call( self,tid ) : h;
				
				w = w == 'auto' ? 0 : w;
				h = h == 'auto' ? 0 : h;
				
				//var _w = w,_h = h;
				
				var mh = render.is('body') ? $(window) : render;
				var maxWidth = $.isFunction(opt.maxWidth) ? opt.maxWidth.call( self,tid ) : opt.maxWidth,
					maxHeight = $.isFunction(opt.maxHeight) ? opt.maxHeight.call( self,tid ) : opt.maxHeight;
				var minWidth = $.isFunction(opt.minWidth) ? opt.minWidth.call( self,tid ) : opt.minWidth,
					minHeight = $.isFunction(opt.minHeight) ? opt.minHeight.call( self,tid ) : opt.minHeight;	
				//先设置宽度
				var width = w > 0 ? w : menu._outerWidth();
				var _w = width;
				if(!opt.maxWidth) {
					maxWidth = mh.width() - opt.shadowWidth;	
				}
				if( minWidth>0 ) {
					width = Math.max(width,minWidth);
				}
				if( maxWidth>0 ) {
					width = Math.min(width,maxWidth);
				}
				
				if( w>0 || _w != width ) {
					menu._outerWidth(width);
				}
				
				//在设置高度
				var height = h > 0 ? h : menu._outerHeight();
				var _h = height;
				if(!opt.maxHeight) {
					maxHeight = mh.height() - opt.shadowWidth;	
				}
				if( minHeight>0 ) {
					height = Math.max(height,minHeight);
				}
				if( maxHeight>0 ) {
					height = Math.min(height,maxHeight);
				}
			
				if( h>0 || _h != height ) {
					menu._outerHeight(height);
				}
					
			}
			
			if( !menu.length ) {
				menu = _createMenu();
				
				//menu_wraper = $('#'+menuID+'_items_wraper');
				
				menu.disableSelection();
				
				self.bindMenuEvent($('>.nex-menu-items-wraper',menu));
				
				self.fireEvent('onCreateMenu',[ menu,tid,opt ]);
				
			}
			menu.css( {
				left : -99999,
				top : -99999	
			} ).show();
			
			_setMenuSize( menu );
			
			if( !node['isCmp'] ) {
				if( opt.showMenuMore ) {
					self._checkMenuHeight( tid,menu );	
				}
			}
			
			return menu;
		},
		//hideOnBlur
		_createMenu : function(tid){
			var self = this
				,opt=this.configs
				,undef
				,pids = [];	
			if( tid === undef ) return false;
			
			var node = self._getNode(tid);
			if( node === false && !self._isRoot(tid) ) return false ;
			
			var menu = self._bulidMenu(tid);
			
			return menu;
		},
		_showMenu : function( tid ){
			var self = this
				,opt=this.configs
				,undef;	
			var tid = self._undef(tid,opt.root);		
			
			var r = self.fireEvent('onBeforeShowMenu',[tid,opt]);//CreateMenu
			if( r === false ) return false;
			
			//创建SubMenu
			var menu = self._createMenu(tid);
			
			if( menu ) {
				
				$("#"+opt.id+"_"+tid+"_item").addClass("nex-menu-item-active");
			
				self.fireEvent('onShowMenu',[tid,menu,opt]);
				
			}
			return menu;
		},
		_showRootMenu : function( pos, opts ){
			var self = this;
			var opt = this.configs;
			var menu = this._showMenu();	
			
			if( !menu ) return false;
			
			var pos = self._undef( pos,null );
			var showAtConf = self._undef( opts,{} );
			
			if( $.isArray( pos ) ) {
				pos = {
					left : pos[0],
					top  : pos[1]	
				}
			}
			
			var dpos = pos ? { at : pos } :　{};
			
			showAtConf = $.extend( {},$._isPlainObject(opt.showAt) ? opt.showAt : { at : opt.showAt }, dpos ,showAtConf );
			
			this._showAt( menu,null,showAtConf,0 );
			//setTimeout(function(){
			self.bindCloseEvents();	
			//},0);
			return true;	
		},
		showRootMenu : function( pos,opts ){
			var self = this,
				opt=this.configs;
				
			var r = self.fireEvent('onBeforeShowRootMenu',[ pos,opts,opt]);
			
			if( r === false ) return self;
			
			self._showRootMenu.apply( this,arguments );
			
			self.fireEvent('onShowRootMenu',[opt]);
			
			return self;
		},
		showRoot : function(){
			return this.showRootMenu.apply( this,arguments );
		},
		_showSubMenu : function( tid,opts ){//div,tid,node,e
			var self = this,
				opt=this.configs,
				undef;
			var isRoot = self._isRoot( tid );	
			var mitem = $('#'+opt.id+'_'+tid+'_item');	
			if( !isRoot && !mitem.length ) {
				return false;	
			}
			
			var showAtConf = self._undef( opts,{} );
			
			var menu = self._showMenu(tid);
			
			var pos = isRoot ? null : mitem;
			var _showAt = isRoot ? 
							$._isPlainObject(opt.showAt) ? opt.showAt : { at : opt.showAt }
							: $._isPlainObject(opt.subShowAt) ? opt.subShowAt : { at : opt.subShowAt };
			
			var dpos = pos ? { at : pos } : {};				
							
			showAtConf = $.extend( {},_showAt, dpos ,showAtConf );
			
			if( menu ) {
				self._showAt( menu,null,showAtConf,isRoot ? 0 : 1 );	
			} else {
				return false;	
			}
			return true;
		},
		showSubMenu : function( tid ){
			var self = this,
				opt=this.configs,
				node = this._getNode( tid );
			
			self.hideAllSubMenu(tid);	
			
			if( node ) {
				if( node[opt.disabledField] ) {
				  return self;	
			  	}
			}
				
			var r = self.fireEvent('onBeforeShowSubMenu',[tid,opt]);
			
			if( r === false ) return self;
			
			if( self.isLeaf(tid) ) {
				return self;	
			}
			
			self._showSubMenu( tid );
			
			self.fireEvent('onShowSubMenu',[tid,opt]);
			
			return self;
		},
		_hide : function(menu,fn){
			var self = this;
			menu.css( {
				left : -99999,
				top : -99999	
			} ).hide();	
			if( fn && $.isFunction( fn ) ) {
				fn();	
			}
		},
		hideMenu : function(menuid){
			var self = this,
				opt=this.configs,	
				undef;		
			if( menuid === undef ) return self;
			var treeID = [opt.id,'_',menuid].join("");
			
			var menu = $("#"+treeID);
			if( !menu.length ) {
				return self;	
			}
			var menuShadow = $("#"+treeID+'_shadow');
			
			var r = self.fireEvent('onBeforeHideMenu',[menuid,opt]);
			if( r === false ) return self;
			
			var cb = function(){
				self.fireEvent('onHideMenu',[menuid,opt]);	
			};
			
			if( opt.hideToRemove ) {
				var node = self._getNode( menuid );
				self._hide( menu,function(){
					menu.remove();
					if( node['isCmp'] ) {
						Nex.gc();	
					}
					if( menuShadow.length ) {
						menuShadow.remove();
					}	
				} );
			} else {
				self._hide( menu,function(){
					if( menuShadow.length ) {
						menuShadow.hide();
					}	
				} );
			}
			
			$("#"+opt.id+"_"+menuid+"_item").removeClass("nex-menu-item-active");	
			
			return self;
		},
		hideAllSubSubMenu : function(pid){
			var self = this,
				opt=this.configs;	
			var pid = self._undef(pid,opt.root);

			var allChilds = self.getAllChildrens(pid);
			
			for( var i=0;i<allChilds.length;i++ ) {
				var tid = allChilds[i][opt.idField];
				var isLeaf = self.isLeaf(tid);
				if( !isLeaf ) {
					self.hideMenu(tid);
				}	
			}
		},
		/*
		* 隐藏当前同级item列表下所有的
		*/
		hideAllMenu : function(){
			this.hideAllSubMenu( this.configs.root , 1 );
			return this;
		},
		hideAllSubMenu : function( pid,m ){
			var self = this,
				opt=this.configs;	
			var pid = self._undef(pid,opt.root);
			pid = self._isRoot( pid ) ? pid : self._getParentID(pid);
			var allChilds = self.getAllChildrens(pid);
			if( m ) {
				self.hideMenu(pid);
			}
			for( var i=0;i<allChilds.length;i++ ) {
				var tid = allChilds[i][opt.idField];
				var isLeaf = self.isLeaf(tid);
				if( !isLeaf ) {
					self.hideMenu(tid);
				}	
			}
			return self;
		},
		hideRoot : function(){
			this.hideAllMenu();
			this.unbindCloseEvents();
			return this;
		},
		hideRootMenu : function(){
			return this.hideRoot.apply( this,arguments );	
		},
		//销毁所有的菜单
		destroyMenu : function(){
			var opt = this.configs;
			var _status = opt.hideToRemove;
			opt.hideToRemove = true;
			this.hideAllMenu();	
			opt.hideToRemove = _status;
			return this;
		},
		hideLeveMenu : function(level){
			var self = this,
				opt=this.configs,
				undef;	
			if( level === undef ) return true;
			var menus = opt._levelData[ level ];
			for( var i=0;i<menus.length;i++ ) {
				self.hideMenu( menus[i][opt.idField] );	
			}
			return true;
		},
		/*
		*IE9以下版本不支持shadow 属性 所以用其他方法实现
		*/
		_setShadow : function(source){
			var self = this,
				opt=this.configs,
				undef;	
			
			var shadowid = $(source).attr('id') + '_shadow';
			var shadow = $("#"+shadowid);
			if( shadow.length ) {
				shadow.show();
				shadow.width( $(source).outerWidth() );
				shadow.height( $(source).outerHeight() );
				shadow.css( {
					left : $(source).css('left'),	
					top : $(source).css('top')
				} );
				shadow.css( "zIndex",$(source).css('z-index') - 1 );	
				return true;	
			}
			var shadow = $('<div class="nex-menu-shadow" id="'+shadowid+'">'+(Nex.IEVer<=8?'<iframe frameborder="0" class="nex-menu-shadow-iframe" style="width:99%;height:99%;"></iframe>':'')+'</div>');
			shadow.appendTo(opt.renderTo);
			shadow.width( $(source).outerWidth() );
			shadow.height( $(source).outerHeight() );
			shadow.css( {
				left : $(source).css('left'),	
				top : $(source).css('top')
			} );
			shadow.css( "zIndex",$(source).css('z-index') - 1 );	
			return true;
		},
		//animate 不要去设置
		_showAt : function(source,target,conf){//el,at,conf
			var self = this,
				opt=this.configs,
				undef;	
			var confs = {};
			var conf = self._undef( conf,{} );
		
			var dc = {visibleEdge : opt.shadowWidth};
			if( target ) {
				dc.at = target;	
			}
			$.extend( confs,opt._showAt,conf,dc );
			if( !confs.at ) {
				confs.at = {
					left : 0,
					top  : 0	
				}	
			}
			if( !source ) {
				return false;
			}
			
			var r = self.fireEvent('onBeforeShowAt',[ menu,confs,opt ]);
			if( r === false ) {
				return;	
			}
			
			var fn = function(){
				if( opt.showShadow ) {
					self._setShadow( source );
				}		
				self.fireEvent('onShowAt',[ menu,confs,opt ]);
			};
			
			self._show( source,confs,fn );
			
			return true;
		},
		_show : function( menu,confs,fn ){
			var self = this;
			
			var sc = $.extend( {},confs || {} );
			
			if( fn && $.isFunction( fn ) ) {
				var evt = 'onShow.'+self.C('id');
				sc[evt] = function(){
					fn();
				};	
			}
			
			$(menu).showAt(sc);
		},
		unbindCloseEvents : function(){
			var opt = this.configs;
			$(document).unbind('.menu_'+opt.id);	
			$(window).unbind('.menu_'+opt.id);	
			return this;
		},
		bindCloseEvents : function(){
			var self = this;
			var opt = this.configs;
			if( !opt.hideOnBlur ) return self;
			self.unbindCloseEvents();	
			$(document).one('contextmenu.menu_'+opt.id+' mousedown.menu_'+opt.id,function(e){//mousewheel.menu_'+opt.id+' 
				var target = e.target || e.srcElement;
				//closest parents
				if( 
					$(target).closest('[menu-cmpid="'+opt.id+'"]').length
				) {
					self.bindCloseEvents();
				} else {
					self.hideRoot();
					self.unbindCloseEvents();		
				} 
			});
			$(window).one('resize.menu_'+opt.id,function(){
				self.hideRoot();	
				self.unbindCloseEvents();		
			});	
			return self;
		},
		//显示根节点的时候 调用 -- 不建议使用了
		showAt : function(){
			return this.show.apply(this,arguments);	
		},
		//显示menu
		show : function( pos,opts ){
			this.showRootMenu.apply( this,arguments );
			return this;
		},
		hide : function(){
			this.hideRootMenu();	
			return this;
		}
	});
})(jQuery);
//contextMenu
/*
$.fn.contextMenu( [ delegate ],opts );
1.$(div).contentMenu( opts );
2.$(document).contentMenu( 'tr',opts );
*/
;$define([
	'Nex.menu.Menu'
],function(){
	$.fn.contextMenu = function( delegate,opts ){
		var args = [];
		if( !this.length ) return this;
		var selector = this.selector;
		if ( typeof delegate === "object" || typeof delegate === "function" ) {
			
			opts = delegate;
			
			if( this.data(selector) ) {
				if( $.isFunction( opts ) ) {
					var c = opts.call( this.data(selector) );	
					if( c ) {
						this.data( selector ).C( c, true );		
					}
				} else {
					this.data( selector ).C( opts );
				}
				return this;	
			}
			
			if( $.isFunction( opts ) ) {
				opts = opts.call() || {};	
			}
			
			opts.autoShow = false;
			
			args.push( opts.which == 1 ? 'click._cmenu' : 'contextmenu._cmenu',function(e){
				menuOpts.context = this;
				menu.show( [ e.pageX,e.pageY ] );
				e.preventDefault();	
			} );
		} else if( delegate && (typeof opts === "object" || typeof opts === "function") ) {
			delegate = String( delegate );
			
			selector += '.'+delegate;
		
			if( this.data(selector) ) {
				if( $.isFunction( opts ) ) {
					var c = opts.call( this.data(selector) );	
					if( c ) {
						this.data( selector ).C( c, true );		
					}
				} else {
					this.data( selector ).C( opts );
				}
				return this;	
			}
			
			opts.autoShow = false;
			args.push( opts.which == 1 ? 'click._cmenu' : 'contextmenu._cmenu',delegate,function(e){
				menuOpts.context = this;
				menu.show( [ e.pageX,e.pageY ] );	
				e.preventDefault();
			});
		}
		if( args.length ) {
			var menu = Nex.Create('menu',opts);
			var menuOpts = menu.configs;
			
			this.data( selector,menu );
			
			this.on.apply( this,args );	
			
			if( opts.which == 1 ) {
				menu.bind('@onBindMenuEvents._contextmenu', function( el ){
					$(el).click( function(e){
						e.preventDefault();
						e.stopPropagation();	
					} );	
				});		
			}
		} else {
			if( 'remove' == delegate ) {
				var cmenu = this.data( selector );
				cmenu.destroyMenu();	
				this.off('._cmenu');
				return this;
			}
			if( 'remove' == opts ) {
				var cmenu = this.data( selector+'.'+delegate );
				cmenu.destroyMenu();	
				this.off('._cmenu',delegate);
				return this;
			}
			if( !arguments.length )	{
				return this.data( selector );	
			} else {
				return this.data( selector+'.'+delegate );		
			}
		}
		
		return this;	
	};
});	
/*
jquery.nexWindow.js
http://www.extgrid.com/window
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

*/

;(function($){
	"use strict";
	//var win = Nex.define('Nex.Window','Nex.Html').setXType('window');
	var win = Nex.extend('Nex.window.Window','Nex.Html',{
		alias : 'Nex.Window',
		xtype : 'window'		
	});
	win.extend({
		version : '1.0',
		_Tpl : {				
		}
	});
	win.setOptions(function(opt,t){
		return {
			prefix : 'nexwindow-',
			autoDestroy : true,
			autoResize : true,
			_hasBodyView : true,
			_checkScrollBar : false,
			position : 'absolute',
			border : true,
			borderCls : [opt.borderCls,'nex-window-border'].join(' '),
			containerCls : [opt.containerCls,'nex-window'].join(' '),
			autoScrollCls : [opt.autoScrollCls,'nex-window-auto-scroll'].join(' '),
			autoScroll : false,
			autoShow : true,
			closeToRemove : true,//关闭窗口后 销毁对象
			draggable : true,
			resizeable : false,
			modal : false,
			focusToTop : true,//点击窗口后最顶层显示
			zIndex : (function(){
				var zIndex = Nex['zIndex']+2;
				Nex['zIndex'] = zIndex;
				return zIndex;
			})(),
			refreshPosOnResize : true,//通过调用resize时会重置窗口显示位置
			point : null,//point : {left:0,top:0},
			showAt : {},
			title : '',
			toolsItems : [],//更自由的自定义组件显示
			toolsIcons : [],//自定义图标显示 {icon:'abc',text:'',callBack:func}
			collapseable : false,
			collapsed :　false,
			minable : false,
			maxable : false,
			hideHeader : false,
			headerSelectionable : true,
			closeable : false,
			headerItemsCls : '',
			footerItemsCls : '',
			headerItems : null,//string xobject [ xobject ] jquery...
			footerItems : null,
			html : '',
			items : [],
			padding : 0,
			style : '',
			renderTo : window,
			url : '',//支持远程创建 返回数据格式  json
			cache : true,
			dataType : 'json',
			queryParams : {},
			method : 'get',
			parames : {},
			views : {},
			cls : '',
			headerCls : '',
			modalCls : '',
			bodyCls : '',
			bodyStyle : {},
			icon : '',
			iconCls : '',
			iconTitle : '',
			iconTag : 'span',
			autoSize : false,
			width : 'auto',
			height : 'auto',
			animShow : false,//是否动画显示
			animShowType : 'showInAt',
			animHideType : 'showOutAt',
			denyEvents : [ 'scroll' ],
			animateShow : {
				xtype : 'showInAt'	
			},//动画显示函数
			animateHide : {
				xtype : 'showOutAt'		
			},//动画关闭函数
			maxWidth : function(){
				var self = this;
				var opt = self.configs;
				var renderTo = this.C('renderTo');	
				if( $.isWindow(opt.renderTo) ) {
					return $(renderTo).width();
				} else {
					return 0;		
				}
			},
			maxHeight : function(){
				var self = this;
				var opt = self.configs;
				var renderTo = this.C('renderTo');
				if( $.isWindow(opt.renderTo) ) {
					return $(renderTo).height();
				} else {
					return 0;	
				}
			},
			minHeight : 100,
			minWidth : 200,
			events : {
				onStart : $.noop,
				onCreate : $.noop,
				onDestroy : $.noop
			}
		};	
	});
	win.fn.extend({
		_init : function(opt) {
			var self = this;
			self.setContainer();//setContainer必须
			if( !opt.hideHeader ) {	
				self.setHeader();
			}
			self.setHeaderItems()
				.setBody()
				.setFooter()
				.createModal()
				.initWindow();		
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			
			Nex.Html.fn._sysEvents.apply(self,arguments);
			
			self.bind("onHeaderCreate",self._drag,self);
			self.bind("onCreate",self._resizeable,self);
			self.bind("onCreate",self._setTopzindex,self);
			//self.bind("onHeaderCreate",self.displayHeader,self);
			return self;
		},
		displayHeader : function(m){
			var self = this;
			var opt = self.configs;
			var header = opt.views['header'];
			if( !header ) { 
				return false;
			}
			if( m ) {
				header.show();	
			} else {
				header.hide();	
			}
		},
		showHeader : function(){
			return this.displayHeader( true );	
		},
		hideHeader : function(){
			return this.displayHeader( false );	
		},
		setzIndex : function(){
			var self = this;
			var opt = self.configs;		
			var container = opt.views['container'];
			var zIndex = Nex['zIndex']+2;
			Nex['zIndex'] = zIndex;
			opt.zIndex = zIndex; 
			
			container.css('z-index',opt.zIndex);
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
				modal.css('z-index',opt.zIndex-1);
			}		
		},
		_setTopzindex : function(){
			var self = this;
			var opt = self.configs;	
			
			if( !opt.focusToTop ) return;
			
			var container = opt.views['container'];
			
			container.bind('mousedown.zindex',function(e){
				self.setzIndex();
			});
		},
		_drag : function(){
			var self = this;
			var opt = self.configs;
			if( !opt.draggable || !Nex.draggable ) return;
			var header = opt.views['header'];
			Nex.Create('draggable',{
				helper : header,
				target:opt.views['container'],
				onBeforeDrag : function(e,_opt){
					
					if( !opt.draggable ) return false;
					
					var r = self.fireEvent("onWindowBeforeDrag",[e,_opt]);	
					if( r === false) return r;
				},
				onStartDrag : function(e,_opt){
					var r = self.fireEvent("onWindowStartDrag",[e,_opt]);	
					if( r === false) return r;
				},
				onDrag : function(e,_opt){
					var r = self.fireEvent("onWindowDrag",[e,_opt]);	
					if( r === false) return r;
				},
				onStopDrag : function(e,_opt){
					var r = self.fireEvent("onWindowStopDrag",[e,_opt]);	
					if( r === false) return r;
				}
			});
			//header.draggable({target:opt.views['container']});
		},
		_resizeable : function(){
			var self = this;
			var opt = self.configs;
			if( !opt.resizeable || !Nex.resizable ) return;
			var container = opt.views['container'];
			
			Nex.Create('resizable',{
				target : container,
				minWidth: opt.minWidth,	
				minHeight: opt.minHeight,
				//maxWidth: opt.maxWidth,	
				//maxHeight: opt.maxHeight,
				onBeforeResize : function(e,_opt){
					
					if( opt.autoSize || !opt.resizeable || opt.collapsed ) return false;
					
					var r = self.fireEvent("onWindowBeforeResize",[e,_opt]);	
					if( r === false) return r;	
				},
				onStartResize : function(e,_opt){
					var r = self.fireEvent("onWindowStartResize",[e,_opt]);	
					if( r === false) return r;	
				},
				onResize : function(w,h,e,_opt){
					var r = self.fireEvent("onWindowResize",[w,h,e,_opt]);	
					if( r === false) return r;	
					self.setWH( _opt.width,_opt.height );	
				},
				onStopResize : function(w,h,e,_opt){
					var r = self.fireEvent("onWindowStopResize",[w,h,e,_opt]);	
					if( r === false) return r;	
				}
			});
			/*container.resizable({
				minWidth: opt.minWidth,
				minHeight: opt.minHeight,
				onResize:function(w,h){
				self.setWH( w,h );		
			}});*/
		},
		setContainer : function(){
			var self = this;
			var opt = self.C();
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			if( render.css('position') === 'static' ) {
				render.css('position','relative');	
			}
			//防止重复创建相同ID的窗口
			$("#"+opt.id).remove();
			$("#"+opt.id+'_modal').remove();
			
			self.lockEvent('onContainerCreate');
			
			opt.containerCls += ' nex-window-'+opt.position;
			
			Nex.Html.fn.setContainer.call(self);
			
			self.unLockEvent('onContainerCreate');
			/*var container = $('<div class="nex-window '+( opt.autoScroll ? 'nex-window-auto-scroll' : '' )+' nex-window-'+opt.position+' '+opt.cls+'" id="'+opt.id+'"></div>');
			opt.views['container'] = container;*/
			var container = opt.views['container'];
			
			container._removeStyle('padding');
			
			container.css('z-index',opt.zIndex);
			render.append(container);
			self.fireEvent("onContainerCreate",[container,opt]);
			return self;
		},
		_hide : function( func ){
			var self = this,undef;
			var opt = self.configs;	
			var container = opt.views['container'];
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}	
			opt._isShow = false;
			if( modal ) {
				modal.hide();
			}
			if( opt.animShowType && opt.animShow ) {
				var d = $.extend( {},opt.showAt,{ 
					xtype : opt.animHideType || 'showAt',
					source:container,
					onShow : function(){
						if( $.isFunction(func) ) {
							func.call( self );	
						}	
					}
				 } );
				 
				Nex.Create(d).show();
			} else {
				container.hide();
				func.call( self );		
			}
		},
		_show : function(func){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}
			
			if( opt._isShow ) {
				return;	
			}
			opt._isShow = true;
			//animateShow
			self.setzIndex();//设置z-index 重要...
			
			if( opt.showAt.at ) {
				opt.showAt.el = opt.showAt.at;
			}
			
			opt.showAt.el = opt.showAt.el === undef ? (opt.point === null ? opt.renderTo : opt.point) : opt.showAt.el;
			
			//container.show()
			//		 .showAt(opt.showAt);
			
			if( modal ) {
				modal.show();
			}
			var animShowType = 'showAt';
			if( opt.animShow && opt.animShowType ) {
				animShowType = opt.animShowType
			}
			//animShowType
			var d = $.extend( {},opt.showAt,{ 
				xtype : animShowType,
				source:container,
				onShow : function(){
					if( $.isFunction(func) ) {
						func.call( self );	
					}	
				}
			 } );
			Nex.Create(d).show();	
			
		},
		resetPosition : function(){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			if( opt.showAt.at ) {
				opt.showAt.el = opt.showAt.at;
			}
			
			opt.showAt.el = opt.showAt.el === undef ? (opt.point === null ? opt.renderTo : opt.point) : opt.showAt.el;
			var d = $.extend( {},opt.showAt,opt.animateShow,{ 
				source:container
			 } );
			
			if( !opt.animShow ) {
				d.xtype = 'showAt';	
			}
			
			var anim = Nex.Create(d),
				pos = {};
			if( anim ) {
				pos = anim.getShowPos();		
			}
			container.stop(true,true).animate( pos,200,function(){
				self.fireEvent("onResetPosition",[container,opt]);													
			} );
		},
		maxWindow : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeMaxWindow",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-window-max-icon',header) : btn;
			
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			render.addClass('nex-window-noscroll');
			
			btn.addClass('nex-window-max-icon-reset');
			
			opt.__mOffset = self.getPosition();
			container.css({
							left : 0,
							top : 0
						});
			opt.__mWidth = opt.width;
			opt.__mHeight = opt.height;
			opt.__mdraggable = opt.draggable;
			opt.__mresizeable = opt.resizeable;
			opt.__mautosize = opt.autoSize;
			opt.autoSize = opt.resizeable = opt.draggable = false;
			
			self.initWH('100%','100%');	
			
			if( opt.collapsed ) {
				container.height( header._height() );	
				if( opt._mAutoResize ) {	
					Nex.Manager._resize(opt.id,true);
				}
			}
			
			self.fireEvent("onMaxWindow",[container,opt]);
			
		},
		maxResetWindow : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeMaxResetWindow",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-window-max-icon',header) : btn;
			
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			render.removeClass('nex-window-noscroll');
			
			btn.removeClass('nex-window-max-icon-reset');
			
			opt.width = opt.__mWidth || opt.width;
			opt.height = opt.__mHeight || opt.height;
			
			opt.draggable = self._undef(opt.__mdraggable,opt.draggable);
			opt.resizeable = self._undef(opt.__mresizeable,opt.resizeable);
			opt.autoSize = self._undef(opt.__mautosize,opt.autoSize);
			
			self.initWH(opt.__mWidth,opt.__mHeight);	
			
			if( opt.__mOffset ) {
				container.css(opt.__mOffset);
			}
			
			if( opt.collapsed ) {
				container.height( header._height() );		
				if( opt._mAutoResize ) {	
					Nex.Manager._resize(opt.id,true);
				}
			}
			
			self.fireEvent("onMaxResetWindow",[container,opt]);
			
		},
		minWindow : function(e1,e2){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var e1 = e1 === undef ? 'onBeforeMinWindow' : e1;
			var e2 = e2 === undef ? 'onMinWindow' : e2;
			
			var r = self.fireEvent(e1,[container,opt]);
			if( r === false ) return r;
			
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}	
			container.addClass('nex-window-hidden');
			if( modal ) {
				modal.addClass('nex-window-hidden');
			}
			
			opt._mAutoResize = opt.autoResize;
			self.disabledAutoResize();
			
			self._hide(function(){
				self.fireEvent(e2,[container,opt]);					
			});
		},
		minResetWindow : function(e1,e2){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			opt._mAutoResize = opt._mAutoResize === undef ? opt.autoResize : opt._mAutoResize;
			
			var e1 = e1 === undef ? 'onBeforeMinResetWindow' : e1;
			var e2 = e2 === undef ? 'onMinResetWindow' : e2;
			
			var r = self.fireEvent(e1,[container,opt]);
			if( r === false ) return r;
			
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}	
			container.removeClass('nex-window-hidden');
			if( modal ) {
				modal.removeClass('nex-window-hidden');
			}
			//恢复	
			var func = opt._mAutoResize ? 'enableAutoResize' : 'disabledAutoResize';
			self[func]();
			
			self._show(function(){
				self.resize();
				self.fireEvent(e2,[container,opt]);		
				self.fireEvent('onWindowShow',[opt]);					
			});
			
		},
		closeWindow : function(){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			if( !opt.closeToRemove ) {
				self.minWindow('onBeforeCloseWindow','onCloseWindow');	
			} else {
				var r = self.fireEvent('onBeforeCloseWindow',[container,opt]);
				if( r === false ) return r;
				opt._closed = true;
				self._hide(function(){
					opt.views['container'] = container.detach();
					var modal = false;	
					if( opt.modal && ('modal' in opt.views) ) {
						opt.views['modal'] = opt.views['modal'].detach();
					}	
					self.fireEvent('onCloseWindow',[container,opt]);
					self.fireEvent('onWindowHide',[opt]);
				});
			}
		},
		openWindow : function(){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			if( !opt.closeToRemove ) {
				self.minResetWindow('onBeforeOpenWindow','onOpenWindow');	
			} else {
				opt._closed = opt._closed === undef ? false : opt._closed;
				if( opt._closed ) {
					var r = self.fireEvent('onBeforeOpenWindow',[container,opt]);
					if( r === false ) return r;
					var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
					container.appendTo( render );
					var modal = false;	
					if( opt.modal && ('modal' in opt.views) ) {
						modal = opt.views['modal'];
						modal.appendTo( render );
					}	
				}
				self._show(function(){
					self.resize();	
					self.fireEvent('onOpenWindow',[container,opt]);
				});
			}
		},
		collapseWindow : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeCollapseWindow",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-window-collapse-icon',header) : btn;
			btn.addClass('nex-window-collapse-icon-collapsed');	
			
			opt.collapsed = true;
			opt._mAutoResize = opt.autoResize;
			self.disabledAutoResize();
			container.animate({
				height : header._height()  
			},300);	
			self.fireEvent("onCollapseWindow",[container,opt]);
		},
		expandWindow : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeExpandWindow",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-window-collapse-icon',header) : btn;
			btn.removeClass('nex-window-collapse-icon-collapsed');	
			
			opt.collapsed = false;
			var func = opt._mAutoResize ? 'enableAutoResize' : 'disabledAutoResize';
			self[func]();
			container.animate({
				height : opt._height - ( container._outerHeight() - container._height() )
			},300);	
			self.fireEvent("onExpandWindow",[container,opt]);
		},
		bindHeaderEvent : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			if( opt.closeable ) {
				$('a.nex-window-close-icon',header).click(function(e){
					self.closeWindow();
					$(document).trigger('click',[e]);
					return false;
				});
			}
			if( opt.maxable ) {
				$('.nex-window-max-icon',header).click(function(e){
					var btn = $(this);
					if( btn.hasClass('nex-window-max-icon-reset') ) {
						self.maxResetWindow(btn);		
					} else {
						self.maxWindow(btn);		
					}	
					$(document).trigger('click',[e]);
					return false;				   
				});
			}
			if( opt.minable ) {
				$('.nex-window-min-icon',header).click(function(e){													
					/*if( container.hasClass('nex-window-hidden') ) { 
						self.minResetWindow();
					} else {
						self.minWindow();
					}*/
					self.minWindow();
					$(document).trigger('click',[e]);
					return false;
				});	
			}
			if( opt.collapseable ) {
				$('.nex-window-collapse-icon',header).click(function(e){
					var btn = $(this);												  
					if( $(this).hasClass('nex-window-collapse-icon-collapsed') ) {
						self.expandWindow(btn);
					} else {
						self.collapseWindow(btn);
					}	
					$(document).trigger('click',[e]);
					return false;				   
				});
			}
		},
		setHeader : function(){
			var self = this;
			var opt = self.C();	
			var container = opt.views['container'];
			
			if( opt.views['header'] ) return self;
			var icon = '';
			if( opt.icon || opt.iconCls ) {
				var _icon = '';
				if( opt.icon ) {
					_icon = 'background-image:url('+opt.icon+')';	
				}
				var ititle = '';
				if( opt.iconTitle ) {
					ititle = 'title="'+opt.iconTitle+'"';	
				}
				icon = '<'+opt.iconTag+' '+ititle+' class="nex-window-icon '+opt.iconCls+'" style="'+_icon+'"></'+opt.iconTag+'>';	
			}
			//var header = $('<div class="nex-window-header '+opt.headerCls+'" id="'+opt.id+'_header" style=""><table class="nex-window-header-table" cellpadding="0" cellspacing="0" border="0"><tr><td>'+icon+'</td><td><span class="nex-window-title-text"></span></td></tr></table><div class="nex-window-tools"></div></div>');
			var header = $('<div class="nex-window-header '+opt.headerCls+'" id="'+opt.id+'_header" style=""><div class="nex-window-tools"></div><div class="nex-window-header-title">'+icon+'<span class="nex-window-title-text"></span></div></div>');
			
			opt.views['header'] = header;
			container.prepend(header);
			if( !opt.headerSelectionable ) {
				header.disableSelection();
			}
			self.addComponent( $('.nex-window-title-text',header),opt.title );
			var icons = [];
			if( opt.closeable ) {
				icons.push('close');
			}
			if( opt.maxable ) {
				icons.push('max');
			}
			if( opt.minable ) {
				icons.push('min');
			}
			if( opt.collapseable ) {
				icons.push('collapse');
			}
			icons.reverse();
			var tools = $('>.nex-window-tools',header);
			if( opt.toolsItems.length ) {
				self.addComponent( tools,opt.toolsItems );
			}
			for( var i=0;i<opt.toolsIcons.length;i++ ) {
				var __d = {
					icon : '',
					text : ''
				};
				var iconData = 	opt.toolsIcons[i];
				iconData = $.extend( __d,iconData );
				
				if( !$._isPlainObject( iconData ) ) {
					continue;	
				}
				var _icon = $('<a class="nex-window-icon '+iconData.icon+'" hideFocus=true href="javascript:void(0)">'+iconData.text+'</a>');
				tools.append( _icon );
				(function(cdata){
					_icon.click(function(e){
						if( $.isFunction( cdata.callBack ) ) {
							cdata.callBack.call( self,_icon,e );	
						}					 
					});	
				})(iconData);
			}
			for( var i=0;i<icons.length;i++ ) {
				tools.append( $('<a class="nex-window-icon nex-window-'+icons[i]+'-icon" hideFocus=true href="javascript:void(0)"></a>') );	
			}
			
			self.bindHeaderEvent();
			
			self.fireEvent("onHeaderCreate",[header],opt);
			
			if( opt.hideHeader ) {
				self.setWH();
			}
			
			return self;
		},
		setHeaderItems : function(){
			var self = this,undef;
			var opt = self.C();	
			var container = opt.views['container'];	
			
			var headerItems = opt.headerItems;
			if( $.isFunction( headerItems ) ) {
				headerItems = headerItems.apply( self,arguments );
				if( headerItems === undef ) {
					headerItems = null;	
				}	
			}
			
			if( headerItems === null || headerItems === '' ) return self;
			
			var headerItem = $('<div class="nex-window-header-items '+opt.headerItemsCls+'" id="'+opt.id+'_header_items" style=""></div>');
			container.append(headerItem);
			opt.views['headerItem'] = headerItem;
			
			self.addComponent( headerItem,headerItems );
			return self;
		},
		bindBodyEvents : function(){
			var self = this;
			var opt = self.configs;	
			var bd = opt.views['body'];
			var callBack = function(type,e){
				var r = self.fireEvent(type,[ this,e,opt ]);
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				}
			};
			bd.unbind('.window');
			var events = {
				'scroll.window' : function(e){
					callBack.call(this,'onScroll',e);
					var $this = $(this);
					if( $this.scrollTop()<=0 ) {
						self.fireEvent('onScrollTopStart',[ this,e,opt ]);		
					} else if( $this.scrollLeft()<=0 ) {
						self.fireEvent('onScrollLeftStart',[ this,e,opt ])
					}
					if( self.isScrollEnd( this,'top' ) ) {
						self.fireEvent('onScrollTopEnd',[ this,e,opt ]);	
					}
					if( self.isScrollEnd( this,'left' ) ) {
						self.fireEvent('onScrollLeftEnd',[ this,e,opt ]);	
					}
				}
			};
			bd.bind(events);
		},
		setBody : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var bd = $( '<div class="nex-window-body '+opt.bodyCls+'" id="'+opt.id+'_body" class="" style=""></div>' );
			opt.views['body'] = bd;
			container.append(bd);
			bd.css('padding',opt.padding);
			bd.css(opt.bodyStyle);
			self.bindBodyEvents();	 
			self.fireEvent("onBodyCreate",[bd],opt);
			return self;
		},
		setFooter : function(){
			var self = this,undef;
			var opt = self.C();	
			var container = opt.views['container'];
			
			var footerItems = opt.footerItems;
			if( $.isFunction( footerItems ) ) {
				footerItems = footerItems.apply( self,arguments );
				if( footerItems === undef ) {
					footerItems = null;	
				}	
			}
			
			if( footerItems === null || footerItems === '' ) return self;
			
			var footer = $('<div class="nex-window-footer '+opt.footerItemsCls+'" id="'+opt.id+'_footer" style=""></div>');
			opt.views['footer'] = footer;
			
			container.append(footer);	
			
			self.addComponent( footer,footerItems );
			
			self.fireEvent("onFooterCreate",[footer],opt);
			
			return self;
		},
		createModal : function (){
			var self = this;
			var opt = self.C();	
			
			if( !opt.modal ) return self;
			
			var container = opt.views['container'];
			var modal = $('<div class="nex-window-modal '+opt.modalCls+'" id="'+opt.id+'_modal" style=""></div>');	
			opt.views['modal'] = modal;
			
			modal.css( 'zIndex',opt.zIndex-1 );

			modal.bind({
				'click' : function(e){
					self.fireEvent('onModalClick',[modal,e,opt]);
					$(document).trigger('click',[e]);
					return false;
				},
				'dblclick' : function(e){
					self.fireEvent('onModalDblClick',[modal,e,opt]);
					$(document).trigger('dblclick',[e]);
					return false;
				},
				'mousedown' : function(e){
					self.fireEvent('onModalMouseDown',[modal,e,opt]);
					$(document).trigger('mousedown',[e]);
					return false;	
				},
				'mouseup' : function(e){
					self.fireEvent('onModalMouseUp',[modal,e,opt]);
					$(document).trigger('mouseup',[e]);
					return false;	
				},
				'keydown' : function(e){
					self.fireEvent('onModalKeyDown',[modal,e,opt]);
					$(document).trigger('keydown',[e]);
					return false;		
				},
				'keyup' : function(e){
					self.fireEvent('onModalKeyUp',[modal,e,opt]);
					$(document).trigger('keyup',[e]);
					return false;		
				},
				'mousewheel' : function(e){
					self.fireEvent('onModalMouseWheel',[modal,e,opt]);	
				},
				'mouseover' : function(e){
					self.fireEvent('onModalMouseOver',[modal,e,opt]);
					$(document).trigger('mouseover',[e]);
					return false;		
				},
				'mouseout' : function(e){
					self.fireEvent('onModalMouseOut',[modal,e,opt]);
					$(document).trigger('mouseout',[e]);
					return false;		
				}
			});
			
			container.after(modal);	
			self.fireEvent("onModelCreate",[modal],opt);
			return self;
		},
		showModal : function (){
			var self = this;
			var opt = self.C();	
			//如果开启modal 应该是不能出现滚动条的
			//var render = $(opt.renderTo);
			//render.addClass('nex-window-noscroll');
			
			opt.views['modal'].show();
		},
		hideModal : function (){
			var self = this;
			var opt = self.C();	
			
			//var render = $(opt.renderTo);
			//render.removeClass('nex-window-noscroll');
			
			opt.views['modal'].hide();
		},
		getPosition : function(){
			var self = this;
			var opt = self.C();	
			var container = opt.views['container'];
			if( $.isWindow(opt.renderTo) ) {
				return 	container.position();
			} else {
				var sLeft = $(opt.renderTo).scrollLeft();
				var sTop = $(opt.renderTo).scrollTop();	
				var pos = container.position();
				return {
						left　: sLeft + pos.left,
						top　: sTop + pos.top
					}
			}
		},
		getHeader : function(){
			var self = this,
				opt = self.configs;
			return opt.views['header'];	
		},
		getHeaderItem : function(){
			var self = this,
				opt = self.configs;
			return opt.views['headerItem'];	
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return opt.views['body'];
		},
		getFooter : function(){
			var self = this,
				opt = self.configs;
			return opt.views['footer'];	
		},
		/*
		onViewSizeChange : function(func){
			var self = this;
			var opt = self.C();	
			var container = opt.views['container'];	
			self.resetViewSize();
			self.resetModelSize();		
			Nex.html.fn.onViewSizeChange.apply(self,arguments);
		},
		*/
		/*onSizeChange : function(w,h){
			var self = this,
				opt=this.configs,
				undef;
			if( opt.autoSize ){
				self.autoSize();	
			} else {
				self._onSizeChange(w,h);	
			}
		},*/
		resetModelSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			
			if( !opt.modal ) return self;
			if( !( 'modal' in opt.views ) ) return self;

			var render = $(opt.renderTo);
			
			var  isWin = $.isWindow( opt.renderTo );
			
			var modal = opt.views['modal'];
			
			var w = isWin ? 0 : parseInt(render.css('paddingLeft')) + parseInt(render.css('paddingRight'));
			var h = isWin ? 0 : parseInt(render.css('paddingTop')) + parseInt(render.css('paddingBottom'));
			
			var mw = render._width() + w,
				mh = render._height() + h;
			
			if( isWin ) {
				var winWidth = $(window).width();
				var winHeight = $(window).height();
				w = parseInt($(document.body).css('paddingLeft')) + parseInt($(document.body).css('paddingRight'));
				h = parseInt($(document.body).css('paddingTop')) + parseInt($(document.body).css('paddingBottom'));
				mw = Math.max( winWidth,$(document.body).width() + w );
				mh = Math.max( winHeight,$(document.body).height() + h );
			}
			
			modal._outerWidth( mw );
			modal._outerHeight( mh );
			
			self.fireEvent('onModelSizeChange',[ opt ]);
		},
		_setViewSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			var container = opt.views['container'];	
			var bd = self.getBody();
			
			if( opt.realWidth !== 'auto' ) {
				bd._outerWidth( container._width() );
			}
			if( opt.realHeight !== 'auto' ) {
				var h = 0;
				$.each( opt.views,function(key,item){
					if( key === 'body' || key === 'container' || key === 'modal' ) return;
					h += item._outerHeight();
				} );
				bd._outerHeight( container._height()-h );
			}
			self.fireEvent("onSetViewSize",[opt]);
			
			self.resetModelSize();
			//self.fireEvent('onViewSizeChange',[ opt ]);
		},
		initWH : function(w,h){
			var self = this,
				opt = self.C();
			self.setWH(w,h);
		},
		resize : function(m){
			var self = this,
				opt = self.C(),
				undef;
			
			opt._rt = opt._rt || 0;
			
			if( opt._rt ) {
				clearTimeout( opt._rt );	
			}
			
			opt._rt = setTimeout(function(){
				self._setBodyOverflowHidden();	
				self.setWH();	
				if( opt.refreshPosOnResize ) {
					self.resetModelSize();
					self.resetPosition();
				}
				
			},0);
			return self;
		},
		/*
		*清空window内容
		*/
		empytContent : function(){
			return this.empty();
		},
		_addContent : function(items,after){
			return this._insert( items,after );
		},
		/*
		*向window追加内容
		*/
		addContent : function(items,after){
			return this.insert( items,after );
		},
		initWindow : function(){
			var self = this,
				opt=this.configs;
				
			Nex.Html.fn.initComponent.apply(self,arguments);
			
			var container = opt.views['container'];
			container.hide();
			if( opt.autoShow ) {
				self.openWindow();	
			}
			//self.fireEvent('onCreate',[ opt ]);
			
			return self;
		},
		hide :　function(){
			var self = this;
			var opt = self.configs;	
			self.closeWindow();
		},
		//默认显示函数
		show : function(){
			var self = this,
				opt=this.configs;	
			self.openWindow();	
		}
	});
})(jQuery);
/*
jquery.nexPanel.js
http://www.extgrid.com/panel
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

*/

;(function($){
	"use strict";
	//var panel = Nex.define('Nex.Panel','Nex.Html').setXType('panel');
	var panel = Nex.extend('Nex.panel.Panel','Nex.Html',{
		alias : 'Nex.Panel',
		xtype : 'panel'		
	});
	panel.extend({
		version : '1.0',
		_Tpl : {				
		}
	});
	panel.setOptions(function( opt,t ){
		return {
			prefix : 'nexpanel-',
			autoDestroy : true,
			autoResize : true,
			_hasBodyView : true,
			_checkScrollBar : false,
			position : 'relative',
			border : true,
			borderCls : [opt.borderCls,'nex-panel-border'].join(' '),
			containerCls : [opt.containerCls,'nex-panel'].join(' '),
			autoScrollCls : [opt.autoScrollCls,'nex-panel-auto-scroll'].join(' '),
			autoScroll : false,
			autoShow : true,
			closeToRremove : true,//关闭窗口后 销毁对象
			draggable : false,
			resizeable : false,
			modal : false,
			focusToTop : false,//点击窗口后最顶层显示
			zIndex : (function(){
				var zIndex = Nex['zIndex']+2;
				Nex['zIndex'] = zIndex;
				return zIndex;
			})(),
			refreshPosOnResize : false,//通过调用resize时会重置窗口显示位置
			point : null,//point : {left:0,top:0},
			showAt : {},
			title : '',
			toolsItems : [],//更自由的自定义组件显示
			toolsIcons : [],//自定义图标显示 {icon:'abc',text:'',callBack:func}
			collapseable : false,
			collapsed :　false,
			minable : false,
			maxable : false,
			hideHeader : false,
			headerSelectionable : true,
			closeable : false,
			headerItemsCls : '',
			footerItemsCls : '',
			headerItems : null,//string xobject [ xobject ] jquery...
			footerItems : null,
			html : '',
			items : [],
			padding : 0,//body的
			style : '',//body的
			renderTo : window,
			isIE : !!window.ActiveXObject,
			url : '',//支持远程创建 返回数据格式  json
			cache : true,
			dataType : 'json',
			queryParams : {},
			method : 'get',
			parames : {},
			views : {},
			cls : '',
			headerCls : '',
			icon : '',
			iconCls : '',
			iconTitle : '',
			iconTag : 'span',
			modalCls : '',
			bodyCls : '',
			bodyStyle : {},
			autoSize : false,
			width : 'auto',
			height : 'auto',
			maxWidth : function(){
				var self = this;
				var opt = self.configs;
				var renderTo = this.C('renderTo');	
				if( $.isWindow(opt.renderTo) ) {
					return $(renderTo).width();
				} else {
					return 0;		
				}
			},
			maxHeight : function(){
				var self = this;
				var opt = self.configs;
				var renderTo = this.C('renderTo');
				if( $.isWindow(opt.renderTo) ) {
					return $(renderTo).height();
				} else {
					return 0;	
				}
			},
			minHeight : 0,
			minWidth : 0,
			events : {
				onStart : $.noop,
				onCreate : $.noop,
				onDestroy : $.noop
			}
		};	
	});
	panel.fn.extend({
		_init : function(opt) {
			var self = this;
			self.setContainer();//setContainer必须
			if( !opt.hideHeader ) {	
				self.setHeader();
			}
			self.setHeaderItems()
				.setBody()
				.setFooter()
				.createModal()
				.initPanel();		
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			
			Nex.Html.fn._sysEvents.apply(self,arguments);
			
			self.bind("onHeaderCreate",self._drag,self);
			self.bind("onCreate",self._resizeable,self);
			self.bind("onHeaderCreate",self._setTopzindex,self);
			//self.bind("onHeaderCreate",self.displayHeader,self);
			return self;
		},
		displayHeader : function(m){
			var self = this;
			var opt = self.configs;
			var header = opt.views['header'];
			if( !header ) { 
				return false;
			}
			if( m ) {
				header.show();	
			} else {
				header.hide();	
			}
		},
		showHeader : function(){
			return this.displayHeader( true );	
		},
		hideHeader : function(){
			return this.displayHeader( false );	
		},
		_setTopzindex : function(){
			var self = this;
			var opt = self.configs;	
			
			if( !opt.focusToTop ) return;
			
			var container = opt.views['container'];
			
			container.bind('mousedown.zindex',function(e){
				var zIndex = Nex['zIndex']+2;
				Nex['zIndex'] = zIndex;
				opt.zIndex = zIndex; 
				
				container.css('z-index',opt.zIndex);
				var modal = false;	
				if( opt.modal && ('modal' in opt.views) ) {
					modal = opt.views['modal'];
					modal.css('z-index',opt.zIndex-1);
				}										   
			
			});
		},
		_drag : function(){
			var self = this;
			var opt = self.configs;
			if( !opt.draggable || !Nex.draggable ) return;
			var header = opt.views['header'];
			Nex.Create('draggable',{
				helper : header,
				target:opt.views['container'],
				onBeforeDrag : function(e,_opt){
					
					if( !opt.draggable ) return false;
					
					var r = self.fireEvent("onPanelBeforeDrag",[e,_opt]);	
					if( r === false) return r;
				},
				onStartDrag : function(e,_opt){
					var r = self.fireEvent("onPanelStartDrag",[e,_opt]);	
					if( r === false) return r;
				},
				onDrag : function(e,_opt){
					var r = self.fireEvent("onPanelDrag",[e,_opt]);	
					if( r === false) return r;
				},
				onStopDrag : function(e,_opt){
					var r = self.fireEvent("onPanelStopDrag",[e,_opt]);	
					if( r === false) return r;
				}
			});
			//header.draggable({target:opt.views['container']});
		},
		_resizeable : function(){
			var self = this;
			var opt = self.configs;
			if( !opt.resizeable || !Nex.resizable ) return;
			var container = opt.views['container'];
			
			Nex.Create('resizable',{
				target : container,
				minWidth: opt.minWidth,	
				minHeight: opt.minHeight,
				//maxWidth: opt.maxWidth,	
				//maxHeight: opt.maxHeight,
				onBeforeResize : function(e,_opt){
					
					if( opt.autoSize || !opt.resizeable || opt.collapsed ) return false;
					
					var r = self.fireEvent("onPanelBeforeResize",[e,_opt]);	
					if( r === false) return r;	
				},
				onStartResize : function(e,_opt){
					var r = self.fireEvent("onPanelStartResize",[e,_opt]);	
					if( r === false) return r;	
				},
				onResize : function(w,h,e,_opt){
					var r = self.fireEvent("onPanelResize",[w,h,e,_opt]);	
					if( r === false) return r;	
					self.setWH( _opt.width,_opt.height );	
				},
				onStopResize : function(w,h,e,_opt){
					var r = self.fireEvent("onPanelStopResize",[w,h,e,_opt]);	
					if( r === false) return r;	
				}
			});
			/*container.resizable({
				minWidth: opt.minWidth,
				minHeight: opt.minHeight,
				onResize:function(w,h){
				self.setWH( w,h );		
			}});*/
		},
		setContainer : function(){
			var self = this;
			var opt = self.C();
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			/*if( render.css('position') === 'static' ) {
				render.css('position','relative');	
			}*/
			//防止重复创建相同ID的窗口
			$("#"+opt.id).remove();
			$("#"+opt.id+'_modal').remove();
			
			self.lockEvent('onContainerCreate');
			
			opt.containerCls += ' nex-panel-'+opt.position;
			
			Nex.Html.fn.setContainer.call(self);
			
			self.unLockEvent('onContainerCreate');
			/*var container = $('<div class="nex-panel '+( opt.autoScroll ? 'nex-panel-auto-scroll' : '' )+' nex-panel-'+opt.position+' '+opt.cls+'" id="'+opt.id+'"></div>');
			opt.views['container'] = container;*/
			var container = opt.views['container'];
			
			//container._removeStyle('padding');
			
			//container.css('z-index',opt.zIndex);
			render.append(container);
			self.fireEvent("onContainerCreate",[container,opt]);
			return self;
		},
		_hide : function( func ){
			var self = this,undef;
			var opt = self.configs;	
			var container = opt.views['container'];
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}	
			//animateHide
			container.hide();
			
			if( modal ) {
				modal.hide();
			}
			
			if( $.isFunction(func) ) {
				func.call( self );	
			}
			
		},
		_show : function(func){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}
			//animateShow
			if( opt.showAt.at ) {
				opt.showAt.el = opt.showAt.at;
			}
			
			opt.showAt.el = opt.showAt.el === undef ? (opt.point === null ? opt.renderTo : opt.point) : opt.showAt.el;
			
			container.show();
					 //.showAt(opt.showAt);
			
			if( modal ) {
				modal.show();
			}
			
			if( $.isFunction(func) ) {
				func.call( self );	
			}
		},
		maxPanel : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeMaxPanel",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-panel-max-icon',header) : btn;
			
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			render.addClass('nex-panel-noscroll');
			
			btn.addClass('nex-panel-max-icon-reset');
			
			opt.__mOffset = self.getPosition();
			container.css({
							left : 0,
							top : 0
						});
			opt.__mWidth = opt.width;
			opt.__mHeight = opt.height;
			opt.__mdraggable = opt.draggable;
			opt.__mresizeable = opt.resizeable;
			opt.__mautosize = opt.autoSize;
			opt.autoSize = opt.resizeable = opt.draggable = false;
			
			self.initWH('100%','100%');	
			
			if( opt.collapsed ) {
				container.height( header._height() );	
				if( opt._mAutoResize ) {	
					Nex.Manager._resize(opt.id,true);
				}
			}
			
			self.fireEvent("onMaxPanel",[container,opt]);
			
		},
		maxResetPanel : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeMaxResetPanel",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-panel-max-icon',header) : btn;
			
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			render.removeClass('nex-panel-noscroll');
			
			btn.removeClass('nex-panel-max-icon-reset');
			
			opt.width = opt.__mWidth || opt.width;
			opt.height = opt.__mHeight || opt.height;
			
			opt.draggable = self._undef(opt.__mdraggable,opt.draggable);
			opt.resizeable = self._undef(opt.__mresizeable,opt.resizeable);
			opt.autoSize = self._undef(opt.__mautosize,opt.autoSize);
			
			self.initWH(opt.__mWidth,opt.__mHeight);	
			
			if( opt.__mOffset ) {
				container.css(opt.__mOffset);
			}
			
			if( opt.collapsed ) {
				container.height( header._height() );		
				if( opt._mAutoResize ) {	
					Nex.Manager._resize(opt.id,true);
				}
			}
			
			self.fireEvent("onMaxResetPanel",[container,opt]);
			
		},
		minPanel : function(e1,e2){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var e1 = e1 === undef ? 'onBeforeMinPanel' : e1;
			var e2 = e2 === undef ? 'onMinPanel' : e2;
			
			var r = self.fireEvent(e1,[container,opt]);
			if( r === false ) return r;
			
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}	
			container.addClass('nex-panel-hidden');
			if( modal ) {
				modal.addClass('nex-panel-hidden');
			}
			
			opt._mAutoResize = opt.autoResize;
			self.disabledAutoResize();
			
			self._hide(function(){
				self.fireEvent(e2,[container,opt]);					
			});
		},
		minResetPanel : function(e1,e2){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			opt._mAutoResize = opt._mAutoResize === undef ? opt.autoResize : opt._mAutoResize;
			
			var e1 = e1 === undef ? 'onBeforeMinResetPanel' : e1;
			var e2 = e2 === undef ? 'onMinResetPanel' : e2;
			
			var r = self.fireEvent(e1,[container,opt]);
			if( r === false ) return r;
			
			var modal = false;	
			if( opt.modal && ('modal' in opt.views) ) {
				modal = opt.views['modal'];
			}	
			container.removeClass('nex-panel-hidden');
			if( modal ) {
				modal.removeClass('nex-panel-hidden');
			}
			//恢复	
			var func = opt._mAutoResize ? 'enableAutoResize' : 'disabledAutoResize';
			self[func]();
			
			self._show(function(){
				self.resize();
				self.fireEvent(e2,[container,opt]);					
			});
			
		},
		closePanel : function(){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			if( !opt.closeToRremove ) {
				self.minPanel('onBeforeClosePanel','onClosePanel');	
			} else {
				var r = self.fireEvent('onBeforeClosePanel',[container,opt]);
				if( r === false ) return r;
				opt._closed = true;
				self._hide(function(){
					opt.views['container'] = container.detach();
					var modal = false;	
					if( opt.modal && ('modal' in opt.views) ) {
						opt.views['modal'] = opt.views['modal'].detach();
					}	
					self.fireEvent('onClosePanel',[container,opt]);
				});
			}
		},
		openPanel : function(){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			if( !opt.closeToRremove ) {
				self.minResetPanel('onBeforeOpenPanel','onOpenPanel');	
			} else {
				opt._closed = opt._closed === undef ? false : opt._closed;
				if( opt._closed ) {
					var r = self.fireEvent('onBeforeOpenPanel',[container,opt]);
					if( r === false ) return r;
					var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
					container.appendTo( render );
					var modal = false;	
					if( opt.modal && ('modal' in opt.views) ) {
						modal = opt.views['modal'];
						modal.appendTo( render );
					}	
				}
				self._show(function(){
					self.resize();	
					self.fireEvent('onOpenPanel',[container,opt]);
				});
			}
		},
		collapsePanel : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeCollapsePanel",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-panel-collapse-icon',header) : btn;
			btn.addClass('nex-panel-collapse-icon-collapsed');	
			
			opt.collapsed = true;
			opt._mAutoResize = opt.autoResize;
			self.disabledAutoResize();
			container.animate({
				height : header._height()  
			},300);	
			self.fireEvent("onCollapsePanel",[container,opt]);
		},
		expandPanel : function(btn){
			var self = this,undef;
			var opt = self.configs;		
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			var r = self.fireEvent("onBeforeExpandPanel",[container,opt]);
			if( r === false ) return r;
			
			var btn = btn === undef ? $('.nex-panel-collapse-icon',header) : btn;
			btn.removeClass('nex-panel-collapse-icon-collapsed');	
			
			opt.collapsed = false;
			var func = opt._mAutoResize ? 'enableAutoResize' : 'disabledAutoResize';
			self[func]();
			container.animate({
				height : opt._height - ( container._outerHeight() - container._height() )
			},300);	
			self.fireEvent("onExpandPanel",[container,opt]);
		},
		bindHeaderEvent : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var header = opt.views['header'];
			
			if( opt.closeable ) {
				$('a.nex-panel-close-icon',header).click(function(e){
					self.closePanel();
					$(document).trigger('click',[e]);
					return false;
				});
			}
			if( opt.maxable ) {
				$('.nex-panel-max-icon',header).click(function(e){
					var btn = $(this);
					if( btn.hasClass('nex-panel-max-icon-reset') ) {
						self.maxResetPanel(btn);		
					} else {
						self.maxPanel(btn);		
					}
					$(document).trigger('click',[e]);
					return false;					   
				});
			}
			if( opt.minable ) {
				$('.nex-panel-min-icon',header).click(function(e){													
					/*if( container.hasClass('nex-panel-hidden') ) { 
						self.minResetPanel();
					} else {
						self.minPanel();
					}*/
					self.minPanel();
					$(document).trigger('click',[e]);
					return false;
				});	
			}
			if( opt.collapseable ) {
				$('.nex-panel-collapse-icon',header).click(function(e){
					var btn = $(this);												  
					if( $(this).hasClass('nex-panel-collapse-icon-collapsed') ) {
						self.expandPanel(btn);
					} else {
						self.collapsePanel(btn);
					}	
					$(document).trigger('click',[e]);
					return false;				   
				});
			}
		},
		setHeader : function(){
			var self = this;
			var opt = self.C();	
			var container = opt.views['container'];
			
			if( opt.views['header'] ) return self;
			var icon = '';
			if( opt.icon || opt.iconCls ) {
				var _icon = '';
				if( opt.icon ) {
					_icon = 'background-image:url('+opt.icon+')';	
				}
				var ititle = '';
				if( opt.iconTitle ) {
					ititle = 'title="'+opt.iconTitle+'"';	
				}
				icon = '<'+opt.iconTag+' '+ititle+' class="nex-panel-icon '+opt.iconCls+'" style="'+_icon+'"></'+opt.iconTag+'>';	
			}
			
			var header = $('<div class="nex-panel-header '+opt.headerCls+'" id="'+opt.id+'_header" style=""><div class="nex-panel-tools"></div><div class="nex-panel-header-title">'+icon+'<span class="nex-panel-title-text"></span></div></div>');
			opt.views['header'] = header;
			container.prepend(header);
			if( !opt.headerSelectionable ) {
				header.disableSelection();
			}
			self.addComponent( $('.nex-panel-title-text',header),opt.title );
			var icons = [];
			if( opt.closeable ) {
				icons.push('close');
			}
			if( opt.maxable ) {
				icons.push('max');
			}
			if( opt.minable ) {
				icons.push('min');
			}
			if( opt.collapseable ) {
				icons.push('collapse');
			}
			icons.reverse();
			var tools = $('>.nex-panel-tools',header);
			if( opt.toolsItems.length ) {
				self.addComponent( tools,opt.toolsItems );
			}
			for( var i=0;i<opt.toolsIcons.length;i++ ) {
				var __d = {
					icon : '',
					text : '',
					callBack : null
				};
				var iconData = 	opt.toolsIcons[i];
				iconData = $.extend( __d,iconData );
				
				if( !$._isPlainObject( iconData ) ) {
					continue;	
				}
				var _icon = $('<a class="nex-panel-icon '+iconData.icon+'" hideFocus=true href="javascript:void(0)">'+iconData.text+'</a>');
				tools.append( _icon );
				(function(cdata){
					_icon.click(function(e){
						if( $.isFunction( cdata.callBack ) ) {
							var r = cdata.callBack.call( self,_icon,e );
							if( r === false ) return r;	
						}					 
					});	
				})(iconData);
			}
			for( var i=0;i<icons.length;i++ ) {
				tools.append( $('<a class="nex-panel-icon nex-panel-'+icons[i]+'-icon" hideFocus=true href="javascript:void(0)"></a>') );	
			}
			
			self.bindHeaderEvent();
			
			self.fireEvent("onHeaderCreate",[header],opt);
			
			if( opt.hideHeader ) {
				self.setWH();
			}
			
			return self;
		},
		setHeaderItems : function(){
			var self = this,undef;
			var opt = self.C();	
			var container = opt.views['container'];	
			
			var headerItems = opt.headerItems;
			if( $.isFunction( headerItems ) ) {
				headerItems = headerItems.apply( self,arguments );
				if( headerItems === undef ) {
					headerItems = null;	
				}	
			}
			
			if( headerItems === null || headerItems === '' ) return self;
			
			var headerItem = $('<div class="nex-panel-header-items '+opt.headerItemsCls+'" id="'+opt.id+'_header_items" style=""></div>');
			container.append(headerItem);
			opt.views['headerItem'] = headerItem;
			
			self.addComponent( headerItem,headerItems );
			return self;
		},
		bindBodyEvents : function(){
			var self = this;
			var opt = self.configs;	
			var bd = opt.views['body'];
			var callBack = function(type,e){
				var r = self.fireEvent(type,[ this,e,opt ]);
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				}
			};
			bd.unbind('.panel');
			var events = {
				'scroll.panel' : function(e){
					callBack.call(this,'onScroll',e);
					var $this = $(this);
					if( $this.scrollTop()<=0 ) {
						self.fireEvent('onScrollTopStart',[ this,e,opt ]);		
					} else if( $this.scrollLeft()<=0 ) {
						self.fireEvent('onScrollLeftStart',[ this,e,opt ])
					}
					if( self.isScrollEnd( this,'top' ) ) {
						self.fireEvent('onScrollTopEnd',[ this,e,opt ]);	
					}
					if( self.isScrollEnd( this,'left' ) ) {
						self.fireEvent('onScrollLeftEnd',[ this,e,opt ]);	
					}
				}
			};
			bd.bind(events);
		},
		setBody : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var bd = $( '<div class="nex-panel-body '+opt.bodyCls+'" id="'+opt.id+'_body" style=""></div>' );
			opt.views['body'] = bd;
			container.append(bd);
			//bd.css('padding',opt.padding);
			bd.css(opt.bodyStyle);
			self.bindBodyEvents();	 
			self.fireEvent("onBodyCreate",[bd],opt);
			return self;
		},
		setFooter : function(){
			var self = this,undef;
			var opt = self.C();	
			var container = opt.views['container'];
			
			var footerItems = opt.footerItems;
			if( $.isFunction( footerItems ) ) {
				footerItems = footerItems.apply( self,arguments );
				if( footerItems === undef ) {
					footerItems = null;	
				}	
			}
			
			if( footerItems === null || footerItems === '' ) return self;
			
			var footer = $('<div class="nex-panel-footer '+opt.footerItemsCls+'" id="'+opt.id+'_footer" style=""></div>');
			opt.views['footer'] = footer;
			
			container.append(footer);	
			
			self.addComponent( footer,footerItems );
			
			self.fireEvent("onFooterCreate",[footer],opt);
			
			return self;
		},
		createModal : function (){
			var self = this;
			var opt = self.C();	
			
			if( !opt.modal ) return self;
			
			var container = opt.views['container'];
			var modal = $('<div class="nex-panel-modal '+opt.modalCls+'" id="'+opt.id+'_modal" style=""></div>');	
			opt.views['modal'] = modal;
			
			modal.css( 'zIndex',opt.zIndex-1 );

			modal.bind({
				'click' : function(e){
					self.fireEvent('onModalClick',[modal,e,opt]);
					$(document).trigger('click',[e]);
					return false;
				},
				'dblclick' : function(e){
					self.fireEvent('onModalDblClick',[modal,e,opt]);
					$(document).trigger('dblclick',[e]);
					return false;
				},
				'mousedown' : function(e){
					self.fireEvent('onModalMouseDown',[modal,e,opt]);
					$(document).trigger('mousedown',[e]);
					return false;	
				},
				'mouseup' : function(e){
					self.fireEvent('onModalMouseUp',[modal,e,opt]);
					$(document).trigger('mouseup',[e]);
					return false;	
				},
				'keydown' : function(e){
					self.fireEvent('onModalKeyDown',[modal,e,opt]);
					$(document).trigger('keydown',[e]);
					return false;		
				},
				'keyup' : function(e){
					self.fireEvent('onModalKeyUp',[modal,e,opt]);
					$(document).trigger('keyup',[e]);
					return false;		
				},
				'mousewheel' : function(e){
					self.fireEvent('onModalMouseWheel',[modal,e,opt]);	
				},
				'mouseover' : function(e){
					self.fireEvent('onModalMouseOver',[modal,e,opt]);
					$(document).trigger('mouseover',[e]);
					return false;		
				},
				'mouseout' : function(e){
					self.fireEvent('onModalMouseOut',[modal,e,opt]);
					$(document).trigger('mouseout',[e]);
					return false;		
				}
			});
			
			container.after(modal);	
			self.fireEvent("onModelCreate",[modal],opt);
			return self;
		},
		showModal : function (){
			var self = this;
			var opt = self.C();	
			//如果开启modal 应该是不能出现滚动条的
			//var render = $(opt.renderTo);
			//render.addClass('nex-panel-noscroll');
			
			opt.views['modal'].show();
		},
		hideModal : function (){
			var self = this;
			var opt = self.C();	
			
			//var render = $(opt.renderTo);
			//render.removeClass('nex-panel-noscroll');
			
			opt.views['modal'].hide();
		},
		getPosition : function(){
			var self = this;
			var opt = self.C();	
			var container = opt.views['container'];
			if( $.isWindow(opt.renderTo) ) {
				return 	container.position();
			} else {
				var sLeft = $(opt.renderTo).scrollLeft();
				var sTop = $(opt.renderTo).scrollTop();	
				var pos = container.position();
				return {
						left　: sLeft + pos.left,
						top　: sTop + pos.top
					}
			}
		},
		getHeader : function(){
			var self = this,
				opt = self.configs;
			return opt.views['header'];	
		},
		getHeaderItem : function(){
			var self = this,
				opt = self.configs;
			return opt.views['headerItem'];	
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return opt.views['body'];
		},
		getFooter : function(){
			var self = this,
				opt = self.configs;
			return opt.views['footer'];	
		},
		/*
		onViewSizeChange : function(func){
			var self = this;
			var opt = self.C();	
			var container = opt.views['container'];	
			self.resetViewSize();
			self.resetModelSize();		
			Nex.html.fn.onViewSizeChange.apply(self,arguments);
		},
		*/
		/*onSizeChange : function(w,h){
			var self = this,
				opt=this.configs,
				undef;
			if( opt.autoSize ){
				self.autoSize();	
			} else {
				self._onSizeChange(w,h);	
			}
		},*/
		resetModelSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			
			if( !opt.modal ) return self;
			if( !( 'modal' in opt.views ) ) return self;

			var render = $(opt.renderTo);
			
			var  isWin = $.isWindow( opt.renderTo );
			
			var modal = opt.views['modal'];
			
			var w = isWin ? 0 : parseInt(render.css('paddingLeft')) + parseInt(render.css('paddingRight'));
			var h = isWin ? 0 : parseInt(render.css('paddingTop')) + parseInt(render.css('paddingBottom'));
			
			var mw = render._width() + w,
				mh = render._height() + h;
			
			if( isWin ) {
				var winWidth = $(window).width();
				var winHeight = $(window).height();
				w = parseInt($(document.body).css('paddingLeft')) + parseInt($(document.body).css('paddingRight'));
				h = parseInt($(document.body).css('paddingTop')) + parseInt($(document.body).css('paddingBottom'));
				mw = Math.max( winWidth,$(document.body).width() + w );
				mh = Math.max( winHeight,$(document.body).height() + h );
			}
			
			modal._outerWidth( mw );
			modal._outerHeight( mh );
			
			self.fireEvent('onModelSizeChange',[ opt ]);
		},
		_setViewSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			var container = self.getContainer();	
			var bd = self.getBody();
			
			if( opt.realWidth !== 'auto' ) {
				bd._outerWidth( container._width() );
			}
			if( opt.realHeight !== 'auto' ) {
				var h = 0;
				$.each( opt.views,function(key,item){
					if( key === 'body' || key === 'container' || key === 'modal' ) return;
					h += item._outerHeight();
				} );
				bd._outerHeight( container._height()-h );
			}
			self.fireEvent("onSetViewSize",[opt]);
			
			self.resetModelSize();
			//self.fireEvent('onViewSizeChange',[ opt ]);
		},
		initWH : function(w,h){
			var self = this,
				opt = self.C();
			self.setWH(w,h);
		},
		resize : function(m){
			var self = this,
				opt = self.C(),
				undef;
			
			opt._rt = opt._rt || 0;
			
			if( opt._rt ) {
				clearTimeout( opt._rt );	
			}
			
			opt._rt = setTimeout(function(){
				self._setBodyOverflowHidden();	
				self.setWH();	
				if( opt.refreshPosOnResize ) {
					self.resetModelSize();
				}
				if( opt.refreshPosOnResize ) {
					self._show();
				}	
				
			},0);
			return self;
		},
		/*
		*清空panel内容
		*/
		empytContent : function(){
			return this.empty();
		},
		_addContent : function(items,after){
			return this._insert( items,after );
		},
		/*
		*向panel追加内容
		*/
		addContent : function(items,after){
			return this.insert( items,after );
		},
		initPanel : function(){
			var self = this,
				opt=this.configs;
				
			Nex.Html.fn.initComponent.apply(self,arguments);

			var container = opt.views['container'];
			container.hide();
			if( opt.autoShow ) {
				self._show();	
			}
			//self.fireEvent('onCreate',[ opt ]);
			
			return self;
		},
		hide :　function(){
			var self = this;
			var opt = self.configs;	
			self.closePanel();
		},
		//默认显示函数
		show : function(){
			var self = this,
				opt=this.configs;	
			self.openPanel();	
		}
	});
})(jQuery);
/*
jquery.extGrid.js
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
+-----------+
v1.0        |
			|
+-----------+
+-------------------------------------------+
v1.0.1        								|
修正 不同jquery版本出现的返回字符问题			|
+-------------------------------------------+
+--------------------------------------------------------+
v 1.2+       								   			 |
修正核心函数 提升数据展示速度，修正部分函数性能                 |
	1.新增 denyRowEvents : false,//禁止或使用自定义事件      |
	2.新增 onOverCell onOutCell                           |
+--------------------------------------------------------+
+--------------------------------------------------------+
v 1.2.1       								   			 |
1.新增 column中index 数据索引参数                    |
2.修正某些函数重复调用getColumns问题                         |
3.修正IE下刷新空白问题                                      |
4.修正v1.2版本_lSize没清0导致的BUG                          |
+--------------------------------------------------------+
+--------------------------------------------------------+
v 1.2.2      								   			 |
1.修正列锁情况下 Loading 出现的header问题            |
2.修正resize line 边框样式写死                        |
3.修正对数据排序后 出现的大小改变问题               |
+--------------------------------------------------------+
+-----------------------------------------------------------------------------------+
v 1.2.3	 									   			 							|
1.修正大数据下 导致深复制出现的问题												|
2.分页工具栏按钮优化																|
3.提高核心函数模板生成的性能													|
4.新增showHeader 开关 可控制是否显示header 对应的api: showHeader hideHeader		|
5.新增数据为空时 滚动条不出现问题（可选择性开启）								|
6.新增API updateGrid(data);  用户可自己设置显示数据 方便二次开发				|
7.新增参数emptyGridMsg 当grid数据为空是 显示在grid里的数据					|
8.showEmptyGridMsg:true 当设置为true emptyGridMsg则开启,否则关闭					|
	注:开启后 显示内容的宽度和gridHeader一样,也就是说超出宽度时会显示滚动条	|
9.修正showLoading时事件传递问题													|
10.提升分页栏性能																	|
+-----------------------------------------------------------------------------------+
+-----------------------------------------------------------------------------------+
v 1.2.4 									   			 							|
1.修改事件处理函数 																|
2.分页工具栏优化																	|
3.修正单元格事件返回false不阻止事件传递										|
4.新增事件 和修改部分事件名													|
5.新增 $.extGrid.puglins:[]插件队列，系统会调用里面的自定义插件函数			|
6.修正ajax 获取数据后调用不同的数据解析函数 eg jsonFilter						|
7.修正v1.2.3下分页工具栏出现js报错问题											|
8.修正列锁后被锁列事件缺失问题													|
9.新增触发单元格事件时检测当前对象是否单元格													|
10.新增API scrollToField,scrollToRow和配置参数 autoScrollToField/Row  |
+-----------------------------------------------------------------------------------+
+---------------------------------------------------------------------------------------------------------------------------+
v 1.2.5									   			 							
1.修正searchData存在的BUG																
2.修正严格模式下部分函数出现的语法错误													
3.修正rowNumbersWidth的默认参数原本为false改为'0px'										
4.新增rowNumbersExpand的参数 : false|auto|string|function								
5.添加分页输入框数据验证															
6.新增参数url 可接受一个回调函数,grid会传入查询条件（data）和success,error 2个回调函数 
	json_data格式 {total:"255",rows:[{},{},..] [,pageSize:50,pageNumber:1,columns:[{}]]} pageSize,pageNumber,columns是可选
	注 :
		success,error 这2个回调函数，一定有一个需要调用，不然grid会一直处于loading状态
		success 接受 josn_data格式数据 数据格式参考上面.
		error 可接受xmlHttp对象 或 一个字符串
	eg:
	function getGridData(data,success,error){
		data.status = 1;
		$.ajax({
			url : 'list.php',
			data : data,
			success : function( json_data ){
				success(json_data);    
			},
			error : function(xmlHttp){
				error(xmlHttp)
			}
		});
	}
	...extgrid( {url:getGridData} )..
7.一次性实例多个gird时data丢失问题修正(v1.2.3修改后留下的BUG)
8.当grid首次创建在隐藏元素里时,grid高度问题获取不正确问题修正
9.新增metaData方法，可直接调用该方法传递json_data格式的数据
10.修正 scrollToField/Row 出现的误差值
11.新增setFieldWidth 设置列宽 支持百分比
12.把原本直接对元素设置宽度的方法改成用CSS样式控制,方便操作.
注：
1).当定义了行模板时 不要去拖动列交换位置，否则列表的列并不会交换
2).rowTpl 建议不用，用rowCallBack or 单元格回调
13.新增addRow() @return rid,updateRow,deleteRow函数
14.修改默认主键名为'_pk'
15.新增minWidth:20配置参数
+----------------------------------------------------------------------------------------------------------------------------+
*/
/*
+----------------------------------------------------------------------------------------------------------------------------+
v 1.2.6		
1.新增事件onHideExpandRow,onBeforeCellEdit
2.新增maxWidth:null 默认
3.事件可通过参数直接绑定 
	eg:
		{
			title : 'extGrid',
			onClickRow : func,
			...
		}
4.tpl(参数1,参数2) 参数1可以是回调函数：eg：_columnMetaData._expand可是是函数
5.修正多表头在低版本jquery中出现使用field无效问题
6.修正手动调用列锁，隐藏列的时候 再新增行数据时列锁和隐藏列都无效问题
7.取消leftBorder,rightBorder,topBorder,bottomBorder参数边框大小都由CSS控制
8.修正expandRow 宽度设置
9.新增事件 onShowColumn,onHideColumn
10.修正headerTpl使用data-options时部分参数无效问题 
11.新增公用配置$.extGrid.defaults = {}
12.修正initFieldWidth 时 minWidth,maxWidth 无效
13.新增column.reader 映射参数 column._expand 定义后 column.reader会无效
14.新增事件onFieldWidthChange
15.新增API:moveColumn 
16.新增参数:forceFit: true false(默认) 设置 列宽自动调整
17.新增API:forceFitColumn  作用是实现forceFit
18.新增事件 onShowGroup,onHideGroup 
19.新增参数autoHeight 以及API: autoHeight
20.优化forceFitColumn
21.新增API:unAutoHeight ,如果想取消autoHeight 应该调用unAutoHeight()
22.新增API:unForceFitColumn ,如果想取消forceFit 应该调用unForceFitColumn()
23.fireEvent中添加事件锁,防止事件循环
24.新增footer行,对应的控制参数和事件:
	footerTpl : '',
	footerData : [],//footer数据 参数可以是 模版或者 函数
	footerRowStyler 
	footerRowCallBack
	footerRowNumbersExpand : '',
	onOverFooterRow : $.noop,
	onOutFooterRow : $.noop,
	onDblClickFooterRow : $.noop,
	onFooterRowContextMenu : $.noop,
	onClickFooterRowNumber : $.noop,
	onClickFooterCell : $.noop,
	onDblClickFooterCell : $.noop,
	onOverFooterCell : $.noop,
	onOutFooterCell : $.noop,
	onFooterCellContextMenu : $.noop
25.优化事件处理，以及事件依赖
26.新增API:updateFooterData
27.优化部分细节问题
28.新增API:denyEventInvoke 
29.支持大数据加载,参数lazyLoadRow
30.优化scrollToField/Row不合理的触发onScroll 
31.优化获取行数据时考虑当前行是否创建而考虑直接获取data[rid]
32.优化footerRow显示方式，已经修正原先的显示方式而出现滚动问题
33.修正onMoveColumn触发方式
34.重写selectRow部分
35.新增API updateFooterRow,updateHeaderRow, 分别会触发onUpdateFooterRow,onUpdateHeaderRow
36.取消setFieldWidth 触发onScroll事件
37.优化核心函数 事件绑定解绑支持扩展辨别 eg onClickRow.ab
38.取消_autoHeight 事件的同时触发
39.开启大数据支持请不要开启 autoHeight,和groupBy参数
40.新增API width,height
41.新增API resetExpandRowHeight
42.新增API onScrollEnd
43.修正参数名
44.修正_loadRows不删除通过addRrow(_insert) 方式添加的行
45.新增API getRowId
46.修正fireEvent 返回false BUG
47.新增事件绑定API one() 
48.修正ajax获取数据时不检查主键问题
49.新增grid宽高 最小限制参数 minWidth,minHeight
50.onSizeChange 优化，如果大小没有更改会返回false,第三个参数可设为true 来强制更改大小
51.修正setFieldWidth在刷新grid后不重新设置列宽大小问题
52.优化togrid
53.新增事件映射(别名)
54.新增扩展参数,扩展事件
55.修正rowNumbersWidth设为false 还会多出1px宽度问题
56.优化resetViewSize 的调用次数
57.新增事件onBeforeSortColumn
58.优化resetViewSize,onScroll,setGridBody,优化展示速度
59.新增API addFooterItems
60.修正forceFitColumn 传的是对象而不是字符问题
61.新增模板引擎,可选引入artTemplate 也可选择不引入。
62.新增API page()
63.修正大数据开启下 moveColumn时行锁出现的问题
64.优化selectRow 性能
65.selectRows 可设置默认选择的行,如果singleSelect 开启只会选择当前数组中的第一个rid
+----------------------------------------------------------------------------------------------------------------------------+
*/
/*
+----------------------------------------------------------------------------------------------------------------------------+
v 1.2.7
1.修正setFieldValue 和 column.callBack(...这里调用setFieldValue会出问题...) 的循环调用问题，
并且callBack修改为初始创建单元格时才会调用
2.新增API setFieldText 和 setFieldValue 区别在于只会设置单元格的显示文本，而不会设置单元格的实际值,且不触发任何事件
3.autoHeight 开启后如果容器不设置宽度会出现首次渲染时只适应高度不正确
4.判断isEmptyGrid事件位置调整
5.新增API setRowHeight(rid,height)
6.修正IE 下autoHeight overflow hidden 时scrollWidth 获取不正确
7.修正z-index的大小 1 0 1
8.新增cutHeight cutWidth
9.新增onBeforeAjaxCreate事件
10.新增ajaxSend作为扩展
11.修正grid大小改变时抖动问题
12.render优化 可支持函数
13.优化metaData
14.新增参数 ajaxSend 可替换api ajaxSend
15.新增参数 stripeRows 可开启隔行变色
16.css文件新增隔行变色样式
17.添加行事件 onMouseEnter onMouseLeave
18.重新开启 callBack,callBack里一定不要调用setFieldValue
19.getRealField 当列没设置时返回null BUG
20.新增editColumnSetter 扩展函数可自定义编辑列内容
21.#2306 修正columns不设置field是 field为空而导致不能修改列宽的bug
22.多表头功能实现 新增参数multiColumns 可控制
23.优化moveColumn 体验
24.#2740 多表头实现中发现 getTD 里中间行使用的是field作为名称显示 已经修改成title OK
25.关于多表头多个不同行出现的不对其问题，应该使用onHeaderCreate 后 对header里的table都设置一个相同的高度就OK  待解决 OK
26.当field出现@#￥*（）等字符是 或出现很多问题 比如jquery选择器不能呢个带有( ) 会报错 待解决 OK 
27.forceFit的另外一种实现方法.
28.修正行列锁时刷新grid 导致callBack的t其实是一个已经旧的td 
var t = $("#"+opt.id+'_'+field["field"]+'_row_'+rowId+'_cell',tr);
field['callBack'].call(self,t,rowId,field,rowData);
29.新增独立api _setEmptyMsg 并取消!showHeader 不执行问题
30.修正一个久远的BUG 缺少opt定义 eg:showColumn
31. beforeSend 触发位置改变
32.getRowData 获得的是副本数据
33.新增onCreate事件
34.新增绑定autoHeight事件并重新设置列宽
35.优化部分函数的书写方式
36.新增nowrap参数 控制是否换行
37.优化hasScroll 在IE下的BUG
38.forceFit在width等于百分比时调用性能优化
39.优化改变列大小时不会触发headerColumn的click事件
40.新增事件onSetColumns。 getColumns时 触发
41.新增参数customColumnData 可针对单独列设置默认信息
42.新增参数multiFromStr multiSplitStr multiFromStrData 可通过filed来开启多列
43.优化setFieldWidth的效率，做了缓存机制
44.修正了一个BUG header 单元格id不唯一问题
45.修正onViewSizeChange添加缓存后导致初始加载时onViewSizeChange事件未触发 需要持续优化
46.修正由于getRowData 返回不是引用而引起的一些bug
47.修正autoHeight调用onViewSizeChange是不触发onViewSizeChange事件
48.onShowGrid时调用autoHeight
49.由于onViewSizeChange有缓存机制 只有改变的情况下才会触发，所以onShowGrid中绑定了isEmeptyMsg事件
50.由于开启了多列功能所以在多列处理中新增判断是否有设置field
51.新增全局变量 Nex.grid._colid
52.onFinish 不触发问题 ?
53.hideHeader 在加载数据时没有隐藏 ?
54.修正了一个可能出现的bug
	如果用户不设置columns 直接设置数据 而且数据的key是带多表头实现的 eg [{a_b_c:1}]这样的方式 会导致数据获取不正确或则说是需要用户手动配置 cutsomColumnsData:{'c':{index:'a_b_c'}}
55.现在的多表头实现已经没问题，但是不是通过rowSpan colSpan来实现的，也考虑使用这个方法
56.添加一种新的多列算法，目前可提供自由选择 参数 mulitEngine
+----------------------------------------------------------------------------------------------------------------------------+
*/
;(function($){
	"use strict";
	var dataGrid = Nex.define('Nex.grid.Grid',{
		xtype : 'grid',
		alias : 'Nex.Grid'	
	});
	//Nex.grid = dataGrid;
	$.extGrid = $.nexGrid = dataGrid;
	
	dataGrid.extend({
		version : '1.2.7', 
		__resizing : false,
		__moving : false,
		_colid : 1,
		getDefaults : function(opt){
			var _opt = {
				prefix : 'datagrid_',
				autoResize : true,
				renderTo : document.body,
				title : '',//为空不显示标题
				cls : '',//自定义CSS
				iconCls : '',//datagrid 标题的icon样式
				toolBars : false,// [{'text':'添加',cls:'样式',callBack,disabled:false}]
				_toolItem : {text : '',cls : '',callBack : $.noop,disabled:false},//tool 属性
				ltText : '',//leftTopText
				rowNumbersWidth : false,//左侧数字列表 一般设为24px 
				rowNumbersExpand: false,// false : 索引 ,auto : 当前显示数据的索引 , 字符串时 自定义模版
				rowNumbers2Row : true,//开启当rowNumbers2Row click的时候 选择当前行
				nowrap : true,//是否换行
				rowTpl : '',//grid 自定义行模板
				showHeader : true,//显示header
				showFooter : false,
				headerTpl : '',//自定义 header 列模板
				containerCss : 'datagrid-container-border',
				clsOverRow : 'datagrid-row-over',
				clsSelectRow : 'datagrid-row-selected',
				stripeRows : false,//开启隔行变色
				clsSingleRow : 'datagrid-row-single',
				clsDoubleRow : 'datagrid-row-double',
				border : true,//开启后会 给grid添加 containerCss 的样式
				lazyLoadRow : false,//开启后 不要使用groupBy
				pageTotal : 0,//pageTotal可用来控制lazyLoadRow显示行数,是一个虚拟值,与total 不同的是 total是用来控制分页工具栏和当前页的实际显示数,某些情况下这2个值应该相等
				lazyMaxRow : 0,
				lazyRows : [],
				lazyTopRows : 5,
				lazyBottomRows : 5,
				showLazyLoading : true,
				_trHeight : -1,
				_lazyEdge : 80,//距离边缘多少时 开始加载
				_csTop : 0,
				_loadRowing : false,
				_tq : 0,
				_initLazy : true,
				cellpPadding : 8,//因为padding 有别的用途 这里的padding 改成cellpPadding
				multiColumns : true,
				mulitEngine : 1,//第一种方法 可设置 1 2
				multiColumnsAlign : 'center',
				multiFromStr : true,//开启支持以字符串形式的方式实现 。multiColumns必须开启
				multiSplitStr : '_',//分割字符
				multiFromStrData : {},//multiFromStr 字符串开启后 可以为不同层数的单元格设置配置信息
				autoHeight : false,//如果为 true height参数无效，并且grid高度会自动调整高度
				minAutoHeight : 50,//开启autoHeight时 视图部分最小高度
				maxAutoHeight : 0,//开启autoHeight时 视图部分最大高度 0表示不限制
				width : 0,
				height : 0,
				minWidth : 0,
				minHeight : 0,
				maxWidth : 0,
				maxHeight : 0,
				checkBox : false,//是否显示checkbox列 开启后 ck 将是系统列
				checkBoxWidth : '28px',
				checkBoxForceFit : false,
				checkBoxTitle : '<input type="checkbox">',
				checkBoxFit : false,
				editColumn : false,//是否显示edit列 [{'text':'添加',cls:'样式',callBack,disabled:false}]  开启后 ed 将是系统列
				editColumnTitle : '操作',
				editColumnFit : true,
				editColumnForceFit : false,
				editCellW : 63,//每个操作按钮的大小
				editColumnSetter : null,//自定义 列内容内置，默认使用getTools
				columns : [],//
				_columnsHash : {},//field=>column 这里包含所有的 会通过getColumns填充
				_colid : 1,//col 自增 参数
				moveColumnTm : 500,//按下多少秒后开始移动列
				moveColumns : true,
				forceFit:false,//自动设置列宽
				forceFitVisible : true,//列是否始终保持可见
				_columnMetaData : {//默认列信息
					field : '',
					index : '',//数据索引，默认==field
					title : '',
					width : '120px',//默认的列宽,
					_fieldWidth : 0,//如果width是百分比 那么这个就是计算百分比后的宽度
					minWidth : 20,//默认最小宽度
					maxWidth : null,
					align : 'left',
					valign : 'middle',//body里的垂直居中
					_expand : false,//自定义列内容
					callBack : $.noop,
					hcls : '',//header cell自定义css
					bcls : '',//body cell自定义css
					fcls : '',//footer cell自定义css
					_icon : '',
					iconCls : '',
					icon : '',
					sortable : false, 
					textLimit : false,//当处理大数据的时候 性能消耗比较厉害， 不建议开启了
					fitColumn : true,//改变列大小
					casePerChange : true,//如果当前列设置的是百分比大小，手动修改列大小后 设置为true:grid刷新会失去百分比作用,false:grid刷新时不会失去百分比作用，而是失去手动修改后的宽度
					reader : {},//映射 可直接使用Function 效果同formatter
					forceFit : true,//接受forceFit开启时自动设置列大小 checkbox edit 列会设置为false
					disabled : false//当前列不可用
				},
				//用户可针对某一列设置默认信息
				customColumnData : {},
				readerDef : '_default_',
				textLimit : false,//文字溢出总开关 已经改用CSS控制，请不要设置
				textLimitDef : '...',
				autoScrollToField : true,
				autoScrollToRow : true,
				scrollbarSize : false,//获取滚动条大小
				sTop : 0,//初始滚动位置
				sLeft : 0,
				_lTime : 0,//v1.0旧 数据显示后 相隔这个时间继续显示下一个 废弃
				_lStart : 0,//采用预先加载的数据时 开始显示位置 eg offset _lStart limit _lSize
				_lSize : 0,//关闭分页显示 用于一页显示大数据时 采用一次性预先加载的数据
				fitColumns : true,//移动列总开关
				data : [],//列表数据 含有_expand的将作为扩展列 如果有 _openExpand=true 则会自动展开
				emptyGridMsg : '',//grid数据为空是的显示数据 可以是模板 opt 作为参数
				showEmptyGridMsg : true,
				pk : '_pk',//主键名称
				hideColumns : [],//已经隐藏的列
				selectRows : [],//设置默认选中的行
				_selectRows : {},//选择的行
				isCreate : false,//废弃
				isShow : false,
				views : {},
				method : 'post',
				url : '',
				loadMsg : '加载中,请稍后...',
				loadErrorMsg : '数据加载错误！',
				showErrorTime : 2000,
				_lmt : 0,//loadMsg 计时器id
				_colWidthExt : 0,//列宽精确位数
				cache : true,//缓存,
				pageNumber : 1,
				pageSize : 10,
				ajaxSend : null,//自定义ajax发送函数
				dataType : 'json',
				queryParams : {},
				singleSelect : false,//是否可以多选
				rowStyler : "",//行style 字符串作为 class function(rowid,rowdata)
				rowCallBack : $.noop,
				methodCall : {},//内部函数的回调函数
				denyRowEvents : false,//禁止触发的事件
				eventMaps : {},
				events : {
					onStart : $.noop,//创建开始 1
					onCreate : $.noop,//创建开始 1
					onViewCreate : $.noop,
					onShowContainer : $.noop,
					onFinish : $.noop,//创建结束 1
					onBeforeLoad : $.noop,//调用远程数据开始 ，如果返回false讲取消本次请1求
					onLoadSuccess : $.noop,//调用远程数据成功1
					onLoadError : $.noop,//调用远程数据失败1
					onClickRow : $.noop,//当用户点击一行时触发1
					onColumnOver : $.noop,//当用户mouseover row
					onColumnOut : $.noop,//当用户mouseout row
					onOverCell : $.noop,//当用户mouseover cell
					onOutCell : $.noop,//当用户mouseout cell
					onOverRow : $.noop,//当用户mouseover row
					onOutRow : $.noop,//当用户mouseout row
					onDblClickRow : $.noop,//当用户双击一行时触发1
					onClickCell : $.noop,//当用户单击一个单元格时触发1
					onDblClickCell : $.noop,//当用户双击一个单元格时触发1
					onResizeColumnStart : $.noop,//当用户调整列的尺寸时触发1
					onResizeColumn : $.noop,//当用户调整列的尺寸时触发1
					onResizeColumnStop : $.noop,//当用户调整列的尺寸时触发1
					onAfterResize : $.noop,//当用户调整列大小后触发,如果onResizeColumnStop 返回false 那么不会执行
					onSelect : $.noop,//用户选中一行时触发1
					onUnselect : $.noop,//当用户取消选择一行时触发1
					onSelectAll : $.noop,//当用户选中全部行时触发1
					onUnselectAll : $.noop,//当用户取消选中全部行时触发1
					onHeaderContextMenu : $.noop,//当 datagrid 的头部被右键单击时触发1
					onHeaderCreate : $.noop,//当 grid-header 创建完成时调用
					onToolBarCreate: $.noop,//排序触发1
					onRowContextMenu : $.noop,//当右键点击行时触发1
					onCellContextMenu : $.noop,
					onBeforeRefresh : $.noop,//1
					onRefresh : $.noop,//1
					onShowGriding : $.noop,// grid数据显示中的时候调用
					onShowGrid : $.noop,// grid 每次刷新都会调用
					onBeforeShowGrid : $.noop, 
					onGetData : $.noop,//1 grid 数据变动都会调用
					onClickRowNumber : $.noop,//1
					onShowColumn : $.noop,//隐藏/显示列触发
					onHideColumn : $.noop,
					onBeforeHideColumn : $.noop,
					onBeforeShowColumn : $.noop,
					onViewSizeChange : $.noop,
					onSizeChange : $.noop,
					onFieldWidthChange : $.noop,
					onScroll : $.noop,
					onScrollBar : $.noop,//手动拖动滚动条时触发
					onScrollEnd : $.noop,
					onDataChange : $.noop,//数据有变更
					onBeforeCellEdit : $.noop,//单元格数据有变更调用
					onCellEdit : $.noop,//单元格数据有变更调用
					onBeforeAddRow : $.noop,//添加行
					onAfterAddRow : $.noop,//添加行
					onBeforeUpdateRow : $.noop,//修改行
					onAfterUpdateRow : $.noop,//修改行
					onBeforeDeleteRow : $.noop,//删除改行
					onAfterDeleteRow : $.noop,//删除改行
					onAdd : $.noop,//添加数据
					onUpdate : $.noop,//更新数据
					onDelete : $.noop,//删除数据
					onAjaxAdd : $.noop,//远程添加数据 需要自定义
					onAjaxUpdate : $.noop,//远程更新数据 需要自定义
					onAjaxDelete : $.noop,//远程删除数据 需要自定义
					onColumnMove : $.noop,
					onColumnMoving : $.noop,
					onBeforeColumnMove : $.noop,
					onAutoColumnResize : $.noop,//开启forceFit 如果列自适应会触发此事件
					onShowLazyRows : $.noop,
					onLazyRowHide : $.noop,
					onUpdateHeaderRow : $.noop,
					onUpdateFooterRow : $.noop,
					onLazyRowShow : $.noop,
					onColumnValueChange : $.noop//列信息改变是触发
				}//事件组合 
				
			};
			
			var _opt = this.extSet(_opt);
			
			return $.extend({},_opt,opt);
		},
		//table转换成gird时的设置参数
		getToGridOptions : function(cfg){
			var opt = {
				options_from : 'data-options',
				columns_from : 'thead th',
				data_from : 'tbody tr',
				footdata_from : 'tfoot tr'
			}
			return $.extend(true,opt,cfg);
		},
		_Tpl : {
			'container' : '<div class="datagrid-container <%=cls%> <%=border?containerCss:""%>" id="<%=id%>" style=" position:relative; overflow:hidden; width:<%=width%>px; height:<%=height%>px;"></div>',
			'title' : '<div class="datagrid-title <%=iconCls%>" id="title_<%=id%>"><%=title%></div>',
			'toolbar' : '<div class="datagrid-toolbar" id="toolbar_<%=id%>"></div>',
			'grid' : '<div class="datagrid-view" id="view_<%=id%>" style="width:1px; height:1px;"></div>',
			'group_row' : '<tr id="<%=id%>-group-row-<%=gid%>"  datagrid-group-row-id="<%=gid%>" class="datagrid-group-row"><td style="width:<%=w%>px" colspan="<%=colspan%>"><div  class="datagrid-group-cell"><%=html%>(<%=num%>)</div></td></tr>',
			'view1' : '<div class="datagrid-view1" id="view1_<%=id%>" style="width:<%=parseFloat(rowNumbersWidth)%>px;height:100%;">'
							+'<div  class="datagrid-header" id="view1-datagrid-header-<%=id%>" style="width: 100%; z-index:1; position:relative;">'
								+'<div class="datagrid-header-inner" id="view1-datagrid-header-inner-<%=id%>">'
									+'<div class="datagrid-header-inner-wraper" id="datagrid-view1-header-inner-wraper-<%=id%>">'
										+'<table class="datagrid-htable" id="view1-datagrid-header-inner-htable-<%=id%>" border="0" cellspacing="0" cellpadding="0">'
											+'<tbody id="view1-datagrid-header-inner-htable-tbody-<%=id%>">'
											+'</tbody>'
										+'</table>'
									+'</div>'
								+'</div>'
								+'<div class="datagrid-header-outer" id="view1-datagrid-header-outer-<%=id%>">'
									+'<div class="datagrid-header-outer-wraper" id="datagrid-view1-header-outer-wraper-<%=id%>">'
										+'<table class="datagrid-locktable" id="view1-datagrid-header-outer-locktable-<%=id%>" border="0" cellspacing="0" cellpadding="0">'
											+'<tbody id="view1-datagrid-header-outer-locktable-tbody-<%=id%>">'
											+'</tbody>'
										+'</table>'
									+'</div>'
								+'</div>'
							+'</div>'
							+'<div class="datagrid-body-wrap" id="view1-datagrid-body-wrap-<%=id%>" style="width: 100%; height:0px; overflow:hidden;zoom:1; ">'
								+'<div class="datagrid-body datagrid-view1-body" id="view1-datagrid-body-<%=id%>" style="width: 100%;float:left;z-index:0;position:relative;">'
									+'<table class="datagrid-btable" id="view1-datagrid-body-btable-<%=id%>" cellspacing="0" cellpadding="0" border="0">'
										+'<tbody id="view1-datagrid-body-btable-tbody-<%=id%>">'
										+'</tbody>'
									+'</table>'
								+'</div>'
							+'</div>'
							+'<div class="datagrid-footer" id="view1-datagrid-footer-<%=id%>" style="width: 100%; height:0px; overflow:hidden;position:relative;z-index:1;"><div id="view1-datagrid-footer-inner-<%=id%>"  class="datagrid-footer-inner"></div></div>'
						+'</div>',
			'view2' : '<div class="datagrid-view2" id="view2_<%=id%>" style="width:1px;height:100%;">'
							+'<div  class="datagrid-header" id="view2-datagrid-header-<%=id%>" style="width: 100%;">'
								+'<div class="datagrid-header-inner" id="view2-datagrid-header-inner-<%=id%>">'
									+'<div class="datagrid-header-inner-wraper" id="datagrid-view2-header-inner-wraper-<%=id%>">'
										+'<table class="datagrid-htable" id="view2-datagrid-header-inner-htable-<%=id%>" border="0" cellspacing="0" cellpadding="0">'
											+'<tbody id="view2-datagrid-header-inner-htable-tbody-<%=id%>">'
											+'</tbody>'
										+'</table>'
									+'</div>'
								+'</div>'
								+'<div class="datagrid-header-outer" id="view2-datagrid-header-outer-<%=id%>">'
									+'<div class="datagrid-header-outer-wraper" id="datagrid-view2-header-outer-wraper-<%=id%>">'
										+'<table class="datagrid-locktable" id="view2-datagrid-header-outer-locktable-<%=id%>" border="0" cellspacing="0" cellpadding="0">'
											+'<tbody id="view2-datagrid-header-outer-locktable-tbody-<%=id%>">'
											+'</tbody>'
										+'</table>'
									+'</div>'	
								+'</div>'
							+'</div>'
							+'<div class="datagrid-body datagrid-view2-body" id="view2-datagrid-body-<%=id%>" style="width: 100%;height:0px;">'
								+'<table class="datagrid-btable" id="view2-datagrid-body-btable-<%=id%>" cellspacing="0" cellpadding="0" border="0">'
									+'<tbody id="view2-datagrid-body-btable-tbody-<%=id%>">'
									+'</tbody>'
								+'</table>'
							+'</div>'
							+'<div class="datagrid-footer" id="view2-datagrid-footer-<%=id%>" style="width: 100%; height:0px; "><div id="view2-datagrid-footer-inner-<%=id%>"  class="datagrid-footer-inner"></div></div>'
					+'</div>',
			'pager' : '',
			'view1_header_inner_row' : '<tr class="datagrid-header-row">'
											+'<% if( rowNumbersWidth !== false ) {%>'
											+'<td align="center" class="datagrid-td-rownumber" style=""><div class="datagrid-header-rownumber" style="width:<%=parseFloat(rowNumbersWidth)%>px;"><%=ltText%></div></td>'
											+'<% } %>'
									   +'</tr>',	
			'view1_header_outer_row' : '',	
			'view2_header_inner_row' : '',//改用模版函数代替
			'view2_header_inner_row_bak' : '<tr class="datagrid-header-row">'
											+'<% var i=0;len = fields.length;  for(;i<len;i++) {%>'
											+'<td id="<%=opt.id%>_cols_<%=fields[i]["_colid"]%>" class="datagrid_<%=fields[i]["_colid"]%>" field="<%=fields[i]["field"]%>" align="<%=fields[i]["align"]%>">'
												+'<div class="datagrid-header-wrap" field="<%=fields[i]["field"]%>" >'
													+'<div id="<%=opt.id%>_cell_header_<%=fields[i]["_colid"]%>" class="datagrid-cell datagrid-header-cell <%=opt.nowrap ? "datagrid-header-cell-nowrap":""%> datagrid-cell-<%=fields[i]["_colid"]%> datagrid-cell-header-<%=fields[i]["_colid"]%> <%=fields[i]["hcls"]%>" >'
														+'<span><%=fields[i]["title"]%></span>'
													+'</div>'
												+'</div>'
											+'</td>'
											+'<% } %>'
										+'</tr>',							
			'view2_header_outer_row' : '',
			'view1_row' : '',//改用模版函数代替
			'view2_row' : ''//改用模版函数代替
		}
		
	});
	dataGrid.fn.extend({
		_init : function( opt ) {
			var self = this;
			//模版引擎设置
			opt.template.isEscape = opt.isEscape;
			opt.template.helper('parseInt', parseInt);
			opt.template.helper('parseFloat', parseFloat);

			opt.gid = opt.gid || "#view_"+opt.id;
			
			opt.renderTo = $(opt.renderTo);

			//保存初始设置值
			opt.__width = opt.width;
			opt.__height = opt.height;
			
			self.setContainer() //setContainer必须
				.setTitle()
				.setToolBar()
				.setGrid()
				.show();
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			//绑定checkBox
			self.bind("onUnselectAll",function(){this.checkCk(false,0)});
			self.bind("onSelectAll",function(){this.checkCk(true,0)});
			self.bind("onUnselect",function(){this.checkCk(false,1)});
			
			self.bind("onBeforeShowGrid",function(){this.checkCk(false,2)});
			//core
			self.bind("onShowContainer",self.onInitFieldWidth);// onViewCreate
			
			self.bind("onSetPk",self.setPk);
			
			self.bind("onSizeChange",self.refreshColumnsWidth);
			self.bind("onShowGrid",self.resetHeader);
			
			self.bind("onScrollBar",self.onScrollBar);
			self.bind("onScroll",self.loadRows);
			
			self.bind("onDataChange",self.onDataChange);
			self.bind("onMouseEnter",self.onOverRow);
			self.bind("onMouseLeave",self.onOutRow);
			self.bind("onShowGrid",self.onDisplayField);
			
			self.bind("onHeaderCreate",self.onHeaderCreate);
			
			self.bind("onColumnValueChange",self.onColumnValueChange);
			
			self.bind("onAfterAddRow",self.onDisplayField);//隐藏列
			
			//emptyGrid
			self.bind("onAfterAddRow",self.removeEmptyDiv);
			
			self.bind("onFieldWidthChange",self.setForceFitColumn);
			
			self.bind("onAutoHeight",function(){
				var self = this,
					opt = this.configs;
				if( !opt.forceFit ) {	
					var columns = opt.columns;
					self.lockMethod( 'resetViewSize' );
					$.each(columns,function(i,column){
						if( column.width.toString().indexOf("%") != -1 ) {
							self.setFieldWidth( column.field,column.width );
						}
					});
					self.unLockMethod( 'resetViewSize' );
				}
			});//autoHeight后滚动条会消失 最好就是重设宽度
			self.bind("onViewSizeChange",self._autoHeight);
			self.bind("onViewSizeChange",self.onFitColumn);
			self.bind("onViewSizeChange",self.isEmptyGrid);//改变大小
			self.bind("onShowLazyRows",self.onDisplayField);//隐藏列
			
			self.bind("onUpdateHeaderRow",self.onDisplayField);//隐藏列
			
			//self.bind("onUpdateFooterRow",self.onDisplayField);//隐藏列
			//_loadRows
			self.bind("onSizeChange",function(){
				this.loadRows(true);							  
			});
			self.bind("onLazyRowShow",self._selectLazyRows);
			//selectRows = []
			self.bind("onShowGrid",self._selectDefRows);
			
			self.bind("onShowGrid",self._autoHeight);
			self.bind("onShowGrid",self.isEmptyGrid);//创建
			//self.bind("onShowGrid",self.refreshColumnsWidth);
			self.bind("onViewSizeChange",self.refreshColumnsWidth);
		},
		
		showLoading : function(msg,render){
			var self = this;	
			var opt = self.configs;
			var msg = typeof msg === 'undefined' ? opt.loadMsg : msg;
			if( opt._lmt ) {
				clearTimeout(opt._lmt);	
			}
			
			var render = "#"+opt.id;
			//self.hideLoading(render);
			var isExists = $("#"+opt.id+"_datagrid-mask-wraper");
			if( isExists.length ) {
				var maskMsg = $("#"+opt.id+"_datagrid-mask-msg");
				maskMsg.html( msg );
				
				isExists.show();	
				
				var w = maskMsg.outerWidth(true);
				maskMsg.css("marginLeft",-w/2+"px");
				
				return self;
			}
			
			var maskWraper = $('<div id="'+opt.id+'_datagrid-mask-wraper" class="datagrid-mask-wraper"><div id="'+opt.id+'_datagrid-mask" class="datagrid-mask"></div><div id="'+opt.id+'_datagrid-mask-spacer" class="datagrid-mask-spacer"></div><div id="'+opt.id+'_datagrid-mask-msg" class="datagrid-mask-msg" style=" left: 50%;">'+msg+'</div><div>');
			$(render).append(maskWraper);
			var maskMsg = $("#"+opt.id+"_datagrid-mask-msg");
			var w = maskMsg.outerWidth(true);
			maskMsg.css("marginLeft",-w/2+"px");
			maskWraper.click(function(e){
					e.stopPropagation();
					e.preventDefault();											 
				});
			return self;
		},
		hideLoading : function(render){
			var self = this;
			var opt = self.configs;
			//$("#"+opt.id+"_datagrid-mask-wraper").hide();
			opt._lmt = setTimeout(function(){
				$("#"+opt.id+"_datagrid-mask-wraper").hide();					
			},0);
			
			return self;
		},
		methodCall : function(method){
			var method = method || "";
			var self = this;
			var opt = self.configs;
			if( method!="" && method in opt.methodCall && $.isFunction(opt.methodCall[method]) ) {
				opt.methodCall[method].call(self);	
			}
			
			return self;
		},
		/*
		* 获取当前grid列信息,数组方式返回
		*/
		getColumnMap : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var fields = opt.columns;
			return fields;
		},
		/*
		* 获取当前grid的列名,数组方式返回
		*/
		getColumnList : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var fields = self.getColumnMap();
			var list = [];
			var i = 0,
				len = fields.length;
			for(;i<len;i++) {
				list.push(fields[i]['field']);	
			}
			return list;
		},
		/*
		* 获取/设置列信息(部分参数设置后会刷新grid表格)
		* 可触发事件onColumnValueChange
		*  @columnName {String} 列名
		*  @proto      {String} 参数(可选)
		*  @value      {String} 参数值(可选)
		*/
		getColumnData : function(columnName,proto,value){
			var self = this;
			var opt = self.configs;
			
			var columnName = self._undef(columnName,false);	
			var proto = self._undef(proto,false);	
			
			if(columnName === false ) return null;
			
			//var fields = self.getColumns(true);//获取columns元数据 ？？ 想不起为啥以前要获取元数据了
			//var fields = opt.columns;
			//统一使用getColumnMap 接口获取列
			var fields = opt._columnsHash;///self.getColumnMap();//这里不建议直接使用getColumnMap 因为多表头情况下 表头不存在opt.columns
			
			var col = 'nsort'+columnName;
			
			if( !(col in fields) ) return  null;
			
			var field = fields[col];
			
			if(proto === false) {
				return field;
			} else {
				if(typeof value === 'undefined') {
					return self._undef(field[proto],null);
				} else {
					field[proto] = value;
					
					//址引用 不必重新设置
					//opt.columns = fields;//设置后必须调用getColumns 。setGridHeader会调用getColumns

					self.fireEvent("onColumnValueChange",[fields[i],proto,value,opt]);
		
					//self.setGridHeader();//重新生成
					//self.refreshDataCache();
					return value;
				}
			}
			return null;
		},
		/*
		*同getColumnData
		*/
		setColumnData : function(columnName,proto,value){
			var self = this;
			return self.getColumnData(columnName,proto,value);
		},
		/*
		*系统事件
		*/
		onColumnValueChange : function(column,proto,value){
			var self = this;
			var opt = self.configs;
			switch(proto) {
				case 'width' : 
					self.setFieldWidth(column.field,value);
					break;
				case 'title' : 
					$(".datagrid-cell-header-"+column._colid+" >span:first",$("#"+opt.id)).html(value);
					break;
				case 'field' :
					self.setFieldWidth(value,column[value].width);
					self.setGridHeader();//重新生成
					self.refreshDataCache();	
					break;
				default : 
					self.setGridHeader();//重新生成
					self.refreshDataCache();	
			}
		},
		/*
		* 获取当前grid数据集
		*  @return {Object} 数据集
		*/
		getData : function(){
			var self = this;
			var opt = self.configs;
			var async = self.getAsync();
			if( async ) {
				opt.cacheData['source'] = opt.cacheData['source'] || opt.data;
				return opt.cacheData['source'];
			} else {
				return opt.data;
			}
		},
		textLimit : function(text,width,fontSize) {},
		getTpl : function(tpl) { //兼容函数
			return tpl;
		},
		/*如果width height 设置的是百分比那么将返回百分比值，只对resize和初始创建时有效*/
		getResizeWH : function(){
			var self = this;
			var opt = self.C();	
			var width =  $(opt.renderTo)._width();
			var height =  $(opt.renderTo)._height();	
			opt.__pWidth = width;
			opt.__pHeight = height;

			var w = opt.__width === 0 ? width : opt.__width
				,h = opt.__height === 0 ? height : opt.__height;
			if( opt.__width.toString().indexOf("%") != -1 ) {
				w = parseFloat(opt.__width)*width/100;
			}
			if( opt.__height.toString().indexOf("%") != -1 ) {
				h = parseFloat(opt.__height)*height/100;
			}

			return {width:w,height:h};
		},
		/*
		*返回组件的最终宽高
		*/
		checkSize : function(width,height){
			var self = this;
			var opt = self.configs;	
			
			height -= isNaN(parseFloat(opt.cutHeight)) ? 0 : opt.cutHeight;
			width -= isNaN(parseFloat(opt.cutWidth)) ? 0 : opt.cutWidth;
			
			if( opt.minWidth>0 ) {
				width = Math.max(width,opt.minWidth);
			}
			if( opt.minHeight>0 ) {
				height = Math.max(height,opt.minHeight);
			}
			if( opt.maxWidth>0 ) {
				width = Math.min(width,opt.maxWidth);
			}
			if( opt.maxHeight>0 ) {
				height = Math.min(height,opt.maxHeight);
			}
			
			return {
					width : width,
					height : height
				};
		},
		/*
		* 设置grid容器宽高
		*  @width  {int} 宽
		*  @height {int} 高
		*/
		resizeContainer : function(width,height){
			var self = this;
			var opt = self.configs;
			
			var container = $("#"+opt.id);
			
			var size = self.getResizeWH();
			
			opt.width = self._undef(width,size.width);
			opt.height = self._undef(height,size.height);
			
			//检查自定义setWH 是否使用百分比做为单位
			if( opt.width.toString().indexOf("%") != -1 ) {
				opt.width = parseFloat(opt.width)*opt.__pWidth/100;
			}
			if( opt.height.toString().indexOf("%") != -1 ) {
				opt.height = parseFloat(opt.height)*opt.__pHeight/100;
			}
			
			/*opt.height -= isNaN(parseFloat(opt.cutHeight)) ? 0 : opt.cutHeight;
			opt.width -= isNaN(parseFloat(opt.cutWidth)) ? 0 : opt.cutWidth;
			
			if( opt.minWidth>0 ) {
				opt.width = Math.max(opt.width,opt.minWidth);
			}
			if( opt.minHeight>0 ) {
				opt.height = Math.max(opt.height,opt.minHeight);
			}
			if( opt.maxWidth>0 ) {
				opt.width = Math.min(opt.width,opt.maxWidth);
			}
			if( opt.maxHeight>0 ) {
				opt.height = Math.min(opt.height,opt.maxHeight);
			}*/
			var wh = self.checkSize( opt.width,opt.height );
			opt.width = wh.width;
			opt.height = wh.height;
			
			var width=opt.width,height=opt.height;
			//2014-03-13  取消
			width -= (container._outerWidth() - container._width());
			height -= (container._outerHeight() - container._height());
			//直接使用width height
			//width = container._width();
			//height = container._height();
			container.css({
				width : width,
				height : height
			});
			return {
				width : width,
				height : height
			};
		},
		setContainer : function(opt) {
			var opt = opt || {};
			var self = this;
			//var opt = $.extend({},self.configs,opt);
			var opt = self.configs;
			var tpl = self.tpl("container",opt);
			
			opt.renderTo.append($(tpl));
			//__SIZE__ 用于 _setGridWH
			opt.__SIZE__ = self.resizeContainer();
			
			return self;
		},
		setTitle : function(title) {
			var self = this;
			var opt = self.configs;
			opt.title = typeof title === 'undefined' ?  opt.title : title;
			if(opt.title==="") return self;
			var tpl = self.tpl("title",opt);
			self.configs.views['title'] = $(tpl);
			return self;
		},
		/*
		* 获取工具列表
		*  @items  {Array} 工具按钮
		*  @return  {Object} 创建好的工具对象dom
		*/
		getTools : function(items){
			var self = this;
			var opt = self.configs;
			
			
			if( $.isPlainObject(items) ) {
				var items = [ items ];	
			}
			if( !$.isArray(items) && !$.isPlainObject(items) ) {
				return $(items);	
			}
			var _item = opt._toolItem;
			var container = '<table cellspacing="0" cellpadding="0" border="0"><tbody><tr>{$tools}</tr></tbody></table>';
			var h = '';
			var i=0,
				len = items.length;
			for(;i<len;i++) {
				if( $.isPlainObject(items[i]) ) {
					items[i] = $.extend({},_item,items[i]);
					if(items[i]['cls'] != '') {
						items[i]['cls'] += " l-btn-icon-left";		
					}
					var isDisabled = items[i]['disabled'] ? "l-btn-disabled" : "";
					h += '<td><a href="javascript:void(0)" class="l-btn l-btn-plain '+isDisabled+'" indexid="'+i+'"><span class="l-btn-left"><span class="l-btn-text '+items[i]['cls']+'">'+items[i]['text']+'</span></span></a></td>';
				} else if( items[i]==='|' || items[i]==='-' || items[i]===';' || items[i]===',' ) {
					h += '<td><div class="datagrid-btn-separator"></div></td>';	
				} else {
					h += '<td>'+items[i]+'</td>';		
				}
			}
			container = container.replace('{$tools}',h);
			var container = $(container);
			container.find(".l-btn").each(function(i){
				$(this).click(function(e){
					var indexid = $(this).attr("indexid");
					items[indexid]['callBack'].call(self,this,items[indexid]);
					e.stopPropagation();
					e.preventDefault();
				});									   
			});
			return container;
		},
		setToolBar : function() {
			var self = this;
			var opt = self.configs;
			if(opt.toolBars===false) return self;
			var tpl = self.tpl("toolbar",opt);
			self.configs.views['toolbar'] = $(tpl);
			var tool = self.getTools(opt.toolBars);
			if( tool !== false ) {
				self.configs.views['toolbar'].append(tool);	
			}
			self.fireEvent('onToolBarCreate',[self.configs.views['toolbar'],opt.toolBars,opt]);
			self.methodCall('setToolBar');
			
			return self;
		},
		//初步设置gridView高度和宽度
		_setGridWH : function(){
			var self = this;
			var opt = self.configs;
			var views = opt.views;
			var grid = views['grid'];
			
			var h = 0;
			for(var i in views) {
				if(i === 'grid') continue;
				h += views[i]._outerHeight(true);
			}
			//var g = $("#"+opt.id);
			var size = opt.__SIZE__;
			
			grid._outerHeight( size.height - h );
			grid._outerWidth( size.width );
			
			//解决IE下 $().width() 耗时问题
			//grid.data('_width',grid.width());
			//grid.data('_height',grid.height());
		},
		_setGridViewWH : function(){
			var self = this;
			var opt = self.configs;
			
			var size = opt.__SIZE__;
			
			var w = size.width;
			
			//初始化是设置 gridViewSize 提示等待时的友好
			var view1 = $("#view1_"+opt.id);
			var view2 = $("#view2_"+opt.id);
			//设置宽度	
			var view1_w = $("#view1-datagrid-header-inner-htable-"+opt.id)._outerWidth();
			view1.width(view1_w);
			var v1_w = view1._outerWidth();
			//设置绝对显示位置
			view2.css('left',v1_w);
			var _v2 = w - v1_w;
			view2._outerWidth( _v2 );
		},
		setGrid : function () {
			//setView
			var self = this;
			var opt = self.configs;
			var views = opt.views;
			if(!views['grid']) {
				var tpl = self.tpl("grid",opt);
				self.configs.views['grid'] = $(tpl);
			}
			self.methodCall('setGrid');
			return self;
		},
		//autoExpand : function(){},
		checkCk : function(type,t){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var render = gid;
			var type = self._undef(type,false);
			var t = self._undef(t,0);
			if( t == 1 ) {
				if( opt.lazyLoadRow ) {
					return;
				}	
			}
			//view2-datagrid-header-inner-htable-tbody-datagrid_57036
			$("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find(">.datagrid-header-row td[field='ck']").find("input:checkbox").each(function(i){
				this.checked = type ? true : false;																					   
			});
		},
		//setExpandEvent : function(t,rowId,rowData){},
		/*
		* 滚动到指定列
		*  @field {String} 列名
		*/
		scrollToField : function(field){
			var self = this;
			var opt = self.configs;
			var header = $("#view2-datagrid-header-"+opt.id);
			
			if( !header.length ) {
				return self;	
			}
			
			var columns = self.getColumnList();
			
			if( self.inArray( field,columns ) == -1 ) {
				return self;		
			}
			
			//检测当前列是否已经隐藏
			if( self.inArray( field,opt.hideColumns ) != -1 ) {
				return self;		
			}
			
			var r = self.fireEvent("onBeforeScrollToField",[field,opt]);
			if( r === false ) {
				return r;	
			}
			
			var scrollbarSize = self.getScrollbarSize();
			
			var offset = header.offset();
			var w = header._outerWidth();
			//判断是否出现了垂直滚动条
			//这里在某些情况下有可能存在BUG, 可参见autoHeight 对判断是否出现滚动条问题的解决
			var body = $("#view2-datagrid-body-"+opt.id);
			var sh = body.get(0).scrollHeight;
			if( sh > body._outerHeight() ) {
				w -= scrollbarSize.width;//-滚动条大小
			}
			
			var f = $(">.datagrid-header-row td[field='"+field+"']","#view2-datagrid-header-inner-htable-tbody-"+opt.id);
			
			if( !f.length ) return self;
			
			var fo = f.offset();
			var fw = f._outerWidth();
			
			var outerWidth = 0;
			if( offset.left > fo.left ) {
				outerWidth = offset.left - fo.left;
			} else if( (offset.left+w) < (fo.left+fw) ) {
				outerWidth = (offset.left+w) - (fo.left+fw);
			}
			var sLeft = 0;
			
			sLeft = opt.sLeft - outerWidth;
			
			opt.sLeft = sLeft;

			//self.fireEvent("onScroll",[true]);
			
			self.onScroll(true);
			
			self.fireEvent("onAfterScrollToField",[field,opt]);

			return self;
		},
		/*
		* 滚动到指定行
		*  @rid {int} 行id
		*/
		scrollToRow : function(rid){
			var self = this;
			var opt = self.configs;
	
			var r = self.fireEvent("onBeforeScrollToRow",[rid,opt]);
			if( r === false ) {
				return r;	
			}
			
			if( opt.lazyLoadRow && self.inArray( rid,opt.lazyRows ) == -1 ) {
				opt.sTop = opt._trHeight*rid;
				self.fireEvent("onScroll",[]);
				return self;
			}
			
			var body = $("#view2-datagrid-body-"+opt.id);
			
			if( !body.length ) {
				return self;	
			}
			
			var scrollbarSize = self.getScrollbarSize();
			
			var offset = body.offset();
			var h = body._outerHeight();
			//判断是否出现了水平滚动条
			//这里在某些情况下有可能存在BUG, 可参见autoHeight 对判断是否出现滚动条问题的解决
			var sw = body.get(0).scrollWidth;
			if( sw > body._outerWidth() ) {
				h -= scrollbarSize.height;//-滚动条大小
			}
			
			var f = $("#"+opt.id+"-row-"+rid);
			if( !f.length ) {
				return self;	
			}
			
			var fo = f.offset();
			var fh = f._outerHeight();
			
			var outerHeight = 0;
			if( offset.top > fo.top ) {
				outerHeight = offset.top - fo.top;
			} else if( (offset.top+h) < (fo.top+fh) ) {
				outerHeight = (offset.top+h) - (fo.top+fh);
			}
			
			var sTop = 0;
			
			sTop = opt.sTop - outerHeight;
			
			opt.sTop = sTop;

			//self.fireEvent("onScroll",[true]);
			self.onScroll(true);
			
			self.fireEvent("onAfterScrollToRow",[rid,opt]);
			
			return self;
		},
		//refreshPager : function(){},
		//addPagerEvent : function(){},
		//setPager : function(init) {},
		_autoHeight : function(){
			var self = this;
			var opt = self.configs;
			/*
			if( opt.autoHeight ) {
				self.autoHeight();		
			}	
			*/
			if( opt._atuoHTime ) {
				clearTimeout( opt._atuoHTime )	
			}
			opt._atuoHTime = setTimeout(function(){
				if( opt.autoHeight ) {
					self.autoHeight();		
				}	
			},0);
			
		},
		/*
		* 只适应高度
		*  大数据开启下不建议使用这个
		*/
		autoHeight : function(){
			var self = this;
			var opt = self.configs;
			var grid = $("#"+opt.id);
			var view = $("#view_"+opt.id);

			var scrollbarSize = self.getScrollbarSize();
			
			$("#view2-datagrid-body-"+opt.id).css("overflow-y","hidden");	
			
			//var h = grid.outerHeight() - view.outerHeight();//2014-03-03 取消 
			var rv = $("#view2-datagrid-header-"+opt.id)._outerHeight();
			var rh = $("#view2-datagrid-body-btable-"+opt.id)._outerHeight();
			var rf = $("#view2-datagrid-footer-"+opt.id)._outerHeight();
			var _min = opt.minAutoHeight;
			var _max = opt.maxAutoHeight;
			rh = Math.max( rh,_min );
			if( _max>0 ) {
				
				if( rh > _max ) {
					$("#view2-datagrid-body-"+opt.id).css("overflow-y","auto");	
				}
				
				rh = Math.min( rh,_max );	
			}
			var _f = 0;
			if( !opt.forceFit ) {
				//判断是否出现了水平滚动条
				var header = $("#view2-datagrid-header-"+opt.id);
				var headerInner = $("#view2-datagrid-header-inner-htable-"+opt.id);
				if( headerInner._outerWidth()>header._outerWidth() ) {
					_f = scrollbarSize.height;
				}
			}
			var height = rv + rh + rf + _f;//取消 +h 
			
			//bug : grid.outerHeight()-grid.height()
			//如果容器高度为0时 则 grid.outerHeight()会是一个0或者2 grid.outerHeight()-grid.height() 的值就是错误的
			//fix 2014-3-3
			//以上问题出现在于grid不在$.ready里创建 ,$.boxModel还没设置
			var views = opt.views;
			var h = grid._outerHeight()-grid._height();
			for(var i in views) {
				if(i == 'grid') continue;
				h += views[i]._outerHeight(true);
			}
			
			self.onSizeChange( opt.width,height+h );
			var r = self.onViewSizeChange();
			if( r ) {
				self.fireEvent("onViewSizeChange",[opt]);	
			}
			/*self.methodInvoke('resetViewSize',function(){
				self.fireEvent("onAutoHeight",[opt]);					   
			});*/
			
			//如果是opt.autoHeight = true 应该把高度设置给grid
			if( opt.autoHeight ) {
				opt.height = height+h;	
			}
			
			self.fireEvent("onAutoHeight",[opt]);
		},
		unAutoHeight : function(){
			var self = this;
			var opt = self.configs;	
			opt.autoHeight = false;
			$("#view2-datagrid-body-"+opt.id).css("overflow-y","auto");
		},
		/*
		* 设置grid宽,高
		*  触发onSizeChange事件
		*  @width  {int} 宽
		*  @height {int} 高
		*  @m      {boolean} true:强制更新,false:大小都没变化时不更新大小返回false 默认(可选)
		*/
		resetGridSize : function(width,height,m){
			var self = this;
			var opt = self.configs;	
			var m = self._undef(m,false);
			var width = self._undef(width,opt.width);
			var height = self._undef(height,opt.height);
			//如果不需要设置会返回false
			var r = self.onSizeChange(width,height,m);
			if( r === false ) return r;
			
			//self.resetViewSize();
			self.methodInvoke('resetViewSize',function(){
				self.fireEvent("onSizeChange",[opt]);								   
			});
			//因为resetViewSize有延迟，所以必须要把事件触发放到resetViewSize里
			//self.fireEvent("onSizeChange",[opt]);	
		},
		setGridSize : function(w,h,m){
			this.resetGridSize(w,h,m);
		},
		onSizeChange : function(width,height,m){
			var self = this;
			var opt = self.configs;
			
			var m = self._undef(m,false);
			//m:true 强制更新宽高
			if( !m ) {
				var w = self._undef(width,opt.width);
				var h = self._undef(height,opt.height);
				var  wh = self.checkSize( w,h );
				if( wh.width == opt.width && wh.height == opt.height ) return false;
			}
			
			opt.width = self._undef(width,opt.width);
			opt.height = self._undef(height,opt.height);

			var container = $("#"+opt.id);
			
			var size = self.resizeContainer(opt.width,opt.height);
			//计算grid高度
			var views = opt.views;
			var grid = views['grid'];
			var h = 0;
			for(var i in views) {
				if(i == 'grid') continue;
				h += views[i]._outerHeight(true);
			}
			grid._outerWidth( size.width );
			grid._outerHeight(size.height - h);
			
			self.fireEvent("onSetGridSize",[opt]);
			//解决IE下耗时问题 方案1
			//grid.data('_width',grid.width());
			//grid.data('_height',grid.height());
			return true;
		},
		/*
		* 更新grid视图部分宽高
		*  触发onViewSizeChange事件
		*/
		resetViewSize : function (func){
			var self = this;
			var opt = self.configs;
			if( opt.__svt ) {
				clearTimeout(opt.__svt);	
			}
			opt.__svt = setTimeout(function(){
				var r = self.onViewSizeChange();
				if( r ) {
					self.fireEvent("onViewSizeChange",[opt]);
				}
				opt.__svt = 0;
				if( func && $.isFunction(func) ) {
					func();
				}
			},0);
			
		}, 
		setViewSize : function(func){
			var self = this;
			self.methodInvoke('resetViewSize',func);
			//this.resetViewSize();
		},
		_setViewSize : function(){
			//var s = $.now();
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var grid = $(gid);
			
			var w = grid.width();//列太多，会导致获取时间成正比
			var	h = grid.height();
			
			var view1 = $("#view1_"+opt.id);
			var view2 = $("#view2_"+opt.id);
			
			//设置宽度	
			var view1_w = $("#view1-datagrid-header-inner-htable-"+opt.id)._outerWidth();
			view1.width(view1_w);
			var v1_w = view1._outerWidth();
			//设置绝对显示位置
			view2.css('left',v1_w);
			var _v2 = w - v1_w;
			view2._outerWidth( _v2 );
			//设置高度
			var view2_header_h = $("#view2-datagrid-header-inner-htable-"+opt.id)._height();//datagrid-view2-header-inner-wraper-datagrid_1
			//左右高度一样
			$("#view1-datagrid-header-inner-htable-"+opt.id).height( view2_header_h );

			//隐藏header
			if( !opt.showHeader ) {
				view2_header_h = 0;	
			}
			
			$("#view1-datagrid-header-inner-"+opt.id)._outerHeight( view2_header_h );
			$("#view2-datagrid-header-inner-"+opt.id)._outerHeight( view2_header_h );
			//设置datagrid-header-outer
			var view2_header_outer_h = $("#datagrid-view2-header-outer-wraper-"+opt.id)._height();
			$("#view1-datagrid-header-outer-"+opt.id).height( view2_header_outer_h );
			$("#view2-datagrid-header-outer-"+opt.id).height( view2_header_outer_h );
			//设置datagrid-header
			var header_h =  $("#view2-datagrid-header-inner-"+opt.id)._outerHeight() + $("#view2-datagrid-header-outer-"+opt.id)._outerHeight();
			
			$("#view1-datagrid-header-"+opt.id).height( header_h );
			$("#view2-datagrid-header-"+opt.id).height( header_h );
			//隐藏footer
			if( !opt.showFooter ) {
				opt.gfooter.height( 0 );
				$("#view1-datagrid-footer-"+opt.id).height( 0 );
			} else {
				var fh = 0;
				var nodes = $("#view2-datagrid-footer-inner-"+opt.id).children();
				nodes.each(function(){
					fh += $(this)._outerHeight();				
				});
				opt.gfooter.height( fh );	
				$("#view1-datagrid-footer-"+opt.id).height( fh );
			}
			
			var bodyH = view2._height() - opt.gheader._outerHeight() - opt.gfooter._outerHeight();
			opt.gbody._outerHeight( bodyH );
			$("#view1-datagrid-body-wrap-"+opt.id)._outerHeight( bodyH );
			//开启显示footer后,如果数据过少会导致不粘合在一起问题,觉得不需要
			if( opt.showFooter ) {}
			
			self.fireEvent("onSetGridViewSize",[opt]);
		},
		onViewSizeChange : function( roll ){
			//var s = $.now();
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var roll = self._undef( roll,true );
			
			//self._setViewSize();
			self.methodInvoke('_setViewSize');
			
			if( roll ) {
				self.methodInvoke('onScroll',true);
			}
			
			//缓存机制
			//因为grid特殊 所以应该判断是否出现滚动条
			var hasScrollLeft = self.hasScroll( opt.gbody,'left' );
			var hasScrollTop = self.hasScroll( opt.gbody,'top' );
			var barSize = self.getScrollbarSize();
			
			var _gbodyWidth = opt.gbody._width() - ( hasScrollTop ? barSize.y : 0 );
			var _gbodyHeight = opt.gbody.height() - ( hasScrollLeft ? barSize.x : 0 );
			
			if( opt._gbodyWidth && opt._gbodyHeight ) {
				if( (opt._gbodyWidth == _gbodyWidth) && (opt._gbodyHeight == _gbodyHeight) ) {
					return false;
				}
			} 
			//设置缓存
			opt._gbodyWidth = _gbodyWidth;
			opt._gbodyHeight = _gbodyHeight;
			
			
			return true;
		},
		//数组移动算法
		// pos 要移动的元素
		array_sort : function(iarr,pos,target,t) {//t 代表是前还是后 1 代表前 0 代表后

			if(pos == target) return iarr;
			//支持字符下标
			var _iarr = iarr;
			iarr = [];
			var j=0,
				len = _iarr.length;
			for(;j<len;j++) {
				var _i = iarr.push(j);
				if( j == pos) {
					pos = _i-1;
				} else if( j == target ) {
					target = _i-1;
				}
			}
			//core
			var _p = iarr[pos];//记录元副本
			if( pos>target ) {
				if(!t) {
					target++;
				}
				for(var i=pos;i>=0;i--) {
					if(i == target) {
						iarr[i] = _p;
						break;
					}
					iarr[i] = iarr[i-1];
				}
			} else if( pos<target ) {
				if(t) {
					target--;
				}
				for(var i=pos;i<=target;i++) {
					
					if( i == target ) {
						iarr[i] = _p;
					} else {
						iarr[i] = iarr[i+1];
					}	
				}
			}
			//字符下标
			var new_arr = [];
			var k=0,
				len = iarr.length;
			for( ;k<len;k++ ) {
				new_arr.push( _iarr[ iarr[k] ] );
			}
			iarr = new_arr;
			return iarr;
		},
		/*
		@moveField : field 需要移动的列
		@moveToField : field 需要移动到目的列
		@moveToFieldPos : 1,0(1=>移动到moveToField之前,0=>之后)	
		*/
		moveColumn : function( moveField,moveToField,moveToFieldPos ){
			var self = this,
				opt = self.configs;
			self.onColumnMove( moveField,moveToField,moveToFieldPos );
			return self;
		},
		onColumnMove : function(moveField,moveToField,moveToFieldPos){
			var self = this,
				opt = self.configs;
			//var fields = opt.columns;
			//统一使用getColumnMap 接口获取列
			var fields = self.getColumnMap();
			var pos = 0;
			var target = 0;
			var t = moveToFieldPos || opt.moveToFieldPos;
			opt.moveField = moveField || opt.moveField;
			opt.moveToField = moveToField || opt.moveToField;
			if( opt.moveField == opt.moveToField ) return;
			
			var _r = self.fireEvent("onBeforeSwitchColumn",[opt.moveField,opt.moveToField,opt.moveToFieldPos,opt]);
			if( _r === false ) {
				return _r;	
			}
			
			var i=0,
				len = fields.length;
			for(;i<len;i++) {
				if( fields[i]['field'] == opt.moveField ) {
					pos  = i;	
				}
				if( fields[i]['field'] == opt.moveToField ) {
					target  = i;	
				}
			}
			//移动列
			fields = opt.columns =self.array_sort(fields,pos,target,t);
			//数组去重
			var disArr = self.distArr;
			
			//移动单元格数据
			if( t ) {//移动到目标元素前
				var pos = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find("td[field='"+opt.moveField+"']");
				var target = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find("td[field='"+opt.moveToField+"']");
				target.before( pos );
				if( opt.lazyLoadRow ) {
					var rows = [];
					rows = rows.concat(opt.lazyRows,opt.lockRows);
					rows = disArr(rows);
					var j = 0,
						len = rows.length;
					for(;j<len;j++) {
						var rid = rows[j];
						pos = $("#"+opt.id+"-row-"+rid).find("td[field='"+opt.moveField+"']");
						target = $("#"+opt.id+"-row-"+rid).find("td[field='"+opt.moveToField+"']");	
						target.before( pos );
					}
				} else {
					var j = 0,
						len = opt.data.length;
					for(;j<len;j++) {
						pos = $("#"+opt.id+"-row-"+j).find("td[field='"+opt.moveField+"']");
						target = $("#"+opt.id+"-row-"+j).find("td[field='"+opt.moveToField+"']");	
						target.before( pos );
					}
				}
				
			} else {//移动到目标元素后
				var pos = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find("td[field='"+opt.moveField+"']");
				var target = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find("td[field='"+opt.moveToField+"']");
				target.after( pos );
				if( opt.lazyLoadRow ) {
					var rows = [];
					rows = rows.concat(opt.lazyRows,opt.lockRows);
					rows = disArr(rows);
					var j = 0,
						len = rows.length;
					for(;j<len;j++) {
						var rid = rows[j];
						pos = $("#"+opt.id+"-row-"+rid).find("td[field='"+opt.moveField+"']");
						target = $("#"+opt.id+"-row-"+rid).find("td[field='"+opt.moveToField+"']");	
						target.after( pos );
					}	
				} else {
					var j = 0,
						len = opt.data.length;
					for(;j<len;j++) {
						pos = $("#"+opt.id+"-row-"+j).find("td[field='"+opt.moveField+"']");
						target = $("#"+opt.id+"-row-"+j).find("td[field='"+opt.moveToField+"']");	
						target.after( pos );
					}	
				}
				
			}
			
			self.fireEvent("onColumnMove",[opt.moveField,opt.moveToField,t,opt]);
		},
		setView : function(){
			var self = this,
				opt = self.configs,
				tpl_view1 = self.tpl(self.getTpl("view1"),opt),
				tpl_view2 = self.tpl(self.getTpl("view2"),opt),
				gid = opt.gid;
				$(gid).html('');//防止重复调用
				$(tpl_view1).appendTo(gid);
				$(tpl_view2).appendTo(gid);
				opt.gheader = $("#view2-datagrid-header-"+opt.id);
				opt.gbody = $("#view2-datagrid-body-"+opt.id);
				opt.gfooter = $("#view2-datagrid-footer-"+opt.id);
				// 滚动条事件绑定
				opt.gbody.scroll(function(){
					self.onScroll();
					self.fireEvent('onScroll',[]);
					self.fireEvent("onScrollBar",[]);
					//console.log(3);
				});
		},
		/*
		* 获取指定行数据
		*  获取失败会返回false
		*  @rid {int} 行id或者主键
		*  @isPK {boolean} 默认false,true代表根据主键获取数据(可选)
		*/
		_getRowData : function(rid,isPK){
			var self = this;
			var opt = self.configs;
			
			var isPK = self._undef(isPK,false);
			
			var data = isPK ? self.getData() : opt.data;
			
			var rd = false;
			
			if(!isPK) {
				var tr = $("#"+opt.id+"-row-"+rid);
				if( tr.size() ) {
					rd = tr.data('rowData');	
				} else {
					rd = data[rid];	
				}
				
			} else {
				var pk = opt.pk;
				var i=0,
					len = data.length;
				for(;i<len;i++) {
					if(data[i][pk] == rid) {
						rd = data[i];
						break;
					}	
				}
			}
			
			return self._undef(rd,false);
		},
		/*
		* 获取指定行数据 参考_getRowData
		*  返回的是一个副本数据
		*/
		getRowData : function (rid,isPK){
			var data = this._getRowData( rid,isPK );
			if( data ) {
				data = $.extend( {},data );		
			}
			return data;
		},
		/*
		* 获取指定主键的行id
		*  设置不成功会返回falsee
		*  @pk   {int,String,Object,Array} 
		*  @return {int,Array} 失败返回false,否则如果传入的是数组则返回数组，其他则直接返回id
		*/
		getRowId : function(pk){
			var self = this,
				opt = self.configs;	
			if( typeof pk == 'undefined' ) return false;
			var pks = [];
			if( $.isArray( pk ) ) {
				for( var i=0;i<pk.length;i++ ) {
					if( $.isPlainObject( pk[i] ) && (opt.pk in pk[i]) ) {
						pks.push( pk[i][opt.pk] );	
					} else {
						pks.push( pk[i] );	
					}
				}	
			} else {
				if( $.isPlainObject( pk ) && (opt.pk in pk) ) {
					pks.push( pk[opt.pk] );	
				} else {
					pks.push( pk );	
				}
			}
			
			var rids = [];
			
			$("#view2-datagrid-header-outer-locktable-tbody-"+opt.id+",#view2-datagrid-body-btable-tbody-"+opt.id).find(">tr.datagrid-row").each(function(i){
				var rowData = $(this).data('rowData');
				var rid = $(this).attr("datagrid-rid");
				if( rowData && (opt.pk in rowData) ) {
					if( self.inArray( rowData[opt.pk],pks ) != -1 ) {
						rids.push(rid);	
					}	
				}
				
			});
			return rids.length == 1 ? rids[0] : rids;
		},
		/*
		* 设置指定行下指定列的值
		*  field应该是通过getRealField处理过的,或者改做setFieldValue
		*  设置不成功会返回false,否则返回true
		*  @rid   {int} 行id
		*  @field {String} 列名
		*  @value {String} 值
		*/
		setRowData : function (rid,field,value){
			var self = this,
				opt = self.configs;	
			
			var tr = $("#"+opt.id+"-row-"+rid);
			var data;
			if( tr.size() ) {
				data = tr.data('rowData');
			} else {
				data = opt.data[rid];	
			}
			
			if( !data ) return false;	
			
			data[field] = value;
			//同时修改元数据
			var _d = false;
			//这里应该不用再修改，因为他们是引用同一个对象
			if( typeof data[opt.pk] != "undefined" ) {
				_d = self._getRowData( data[opt.pk],true);
				if( _d ) {
					_d[field] = value;
				}
			}
			
			return true;
		},
		/*
		* 获取当前Field 和 data数据的真实索引
		*  @field {String} 列名
		*  @return {String} 索引名
		*/
		getRealField : function(field){
			var self = this,
				opt = self.configs;	
			if( typeof field == 'undefined' ) {
				return null;	
			}
			var _field = field;
			var field = self.getColumnData(field,'index');
			
			if( field === null ) return _field;
			
			field = field=="" ? _field : field;
			return field;
		},
		/*
		* 获取指定单元格内容
		*  不要直接用 rowData[rid][field] 获取数据 而应该用getFieldValue
		*  @rid {int} 行id
		*  @field {String} 列名
		*  @mod {boolean} false:获取经过映射后的值,true:源数据 默认（可选）
		*/
		getFieldValue : function (rid,field,mod){
			var self = this,
				opt = self.configs;	
			
			var mod = self._undef(mod,true);
				
			field = self.getRealField(field);
			
			var data = this._getRowData(rid);
			
			if( !data ) {
				return "";
			}
			if( typeof data[field] == 'undefined' ) {
				return "";
			}
			
			return mod?data[field]:self._cellReader( data[field], self.getColumnData(field,'reader') ,data ,rid,field);
		},
		/*
		* 设置指定单元格内容
		*  不要直接用 rowData[rid][field],setRowData 来设置 而应该用setFieldValue
		*  成功设置后会返回当前行数据，否则返回false
		*  @rid   {int} 行id
		*  @field {String} 列名
		*  @value {String} 值
		*/
		setFieldValue : function(rid,field,value){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			
			var _field = self.getRealField(field);//
			
			var rowData = self.getRowData(rid);
			if( !rowData ) {
				return false;	
			}
			//判断是否内容是否改动
			rowData[_field] = typeof rowData[_field] == 'undefined' ? "" : rowData[_field];
			if( rowData[_field] === value ) {
				return false;	
			}

			var rc = self.fireEvent('onBeforeCellEdit',[rid,field,value,rowData,opt]);
			if( rc === false ) {
				return false;	
			}

			self.setRowData(rid,_field,value);
			rowData = self.getRowData(rid);//getRowData返回的是非引用数据 所以必须要在数据更新后再次获取
			
			var _colid = self.getColumnData( field,'_colid' );
			_colid = _colid === null ? '' : _colid;
			
			var t = _colid == '' ? $() : $("#"+opt.id+"_"+_colid+"_row_"+rid+"_cell");
			if( !t.size() && _colid!=='' ) {
				var rows = "#"+opt.id+"-row-"+rid+",#"+opt.id+"-view1-row-"+rid;
				var t = $(rows).find("td[field='"+field+"'] .datagrid-cell");
			}
			if( t.size() ) {
				var _expand = self.getColumnData(field,'_expand');
				_expand = _expand === null ? false : _expand;
				
				var value = _expand !== false ? self.tpl(_expand,rowData,rid,field) : self._cellReader( value , self.getColumnData(field,'reader') , rowData , rid,field );//value;
				
				t.html(value)
				 .addClass("datagrid-cell-edit");
				 
				 //取消2014-02-26
				 //重新开启， callBack 请不要调用setFieldValue
				var callBack = self.getColumnData(field,"callBack");
				if( callBack!=null && $.isFunction(callBack) &&  callBack != opt.noop) {
					callBack.call(self,t,rid,field,rowData);	//field['callBack'].call(self,t,rowId,field,rowData)
				}
			}
			
			self.fireEvent('onCellEdit',[t,rid,field,rowData[_field],rowData,opt]);

			return rowData;
		},
		setFieldText : function(rid,field,value){
			var self = this,
				opt = self.configs;	
			var _colid = self.getColumnData( field,'_colid' );	
			var t = $("#"+opt.id+"_"+_colid+"_row_"+rid+"_cell");
			if( !t.size() ) {
				var rows = "#"+opt.id+"-row-"+rid+",#"+opt.id+"-view1-row-"+rid;
				var t = $(rows).find("td[field='"+field+"'] div.datagrid-cell");
			}	
			if( t.size() ) {
				t.html(value);
			} else {
				return false;	
			}
			return true;
		},
		/*
		* 获取选择行id或数据
		*  @d   {boolean} true:返回选择行数据,false:返回行id 默认 (可选)
		*/
		getSlectRows : function( d ){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var $list = opt._selectRows;
			var list = [];
			
			for( var rid in $list ) {
				if( $list[rid] === true ) {
					list.push( rid );	
				}	
			}
			
			var d = self._undef(d,false);
			
			var _list = [];
			if( d ) {
				var j=0,
					len = list.length;
				for(;j<len;j++)	{
					if( !opt.data[ list[j] ] ) continue;
					_list.push( opt.data[ list[j] ] );	
				}
				return _list;
			} 
			return list;
		},
		/*
		*同getSlectRows
		*/
		getSelectRows : function( d ) {
			var self = this;
			return self.getSlectRows(d);
		},
		//行列锁
		//onLockRow : function(){},
		//onAfterLockRow : function(rowId){},
		//onLockColumn : function(){},
		//onAfterLockColumn : function(field){},
		//lockRow : function(rowId){},
		//unLockRow : function(rowId){},
		//unLockColumn : function(field){},
		//lockColumn : function(field){},
		//_lockRow : function(rowId) {},
		//_unLockRow : function(rowId){},
		//_getFooterRowNumber : function(rowId) {},
		_getRowNumber : function(rowId) {
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			var view1_tr = $("#"+opt.id+"-view1-row-"+rowId);
			var isNew = false;
			var _d = {};
			if( !view1_tr.size() ) {//添加行
				isNew = true;
				var view1_row = self.getTpl("view1_row");
				_d = {
					i : rowId,
					id : opt.id,
					rowNumbersExpand : opt.rowNumbersExpand,
					data : data[rowId],
					//groupBy : opt.groupBy,
					rowNumbersWidth : opt.rowNumbersWidth,
					opt : opt
				};
				var ltr = $( self.tpl(view1_row,_d) );
				self.bindRowEvent(false,ltr);
				view1_tr = ltr;

			}
			return {
					isNew : isNew,
					node : view1_tr
				};
		},
		//_lockColumn : function(field) {},
		//_unLockColumn : function(field) {},
		
		getCheckBoxColumn : function(columns) {
			var self = this,
			opt = self.configs;
			var r = $.extend({},opt._columnMetaData);
			r._colid = 'col'+opt._colid++;
			r._hasSetCk = true;
			r.field = 'ck';
			r.title = opt.checkBoxTitle;
			r._expand = '<input type="checkbox">';
			r.hcls = 'datagrid-header-check';
			r.bcls = 'datagrid-cell-check';
			r.width = opt.checkBoxWidth;
			r.forceFit = opt.checkBoxForceFit;
			r.fitColumn = opt.checkBoxFit;
			r.align = 'center';
			r.callBack = function(t,rowId,field,rowData){
				var self = this;
				$(t).find("input:checkbox").click(function(e){
					if( this.checked ) {
						self.selectRow(rowId);	
					} else {
						self.unselectRow(rowId);
					}
					e.stopPropagation();
				});
			};
			return r;
		},
		geteditColumn : function(columns) {
			var self = this,
			opt = self.configs;
			var r = $.extend({},opt._columnMetaData);
			var j = 0;
			var k = 0;
			if( $.isArray(opt.editColumn) ) { 
				$.each(opt.editColumn,function(i,n){
					if( $.isPlainObject(this) ) {
						opt.editColumn[i] = $.extend({},opt._toolItem,opt.editColumn[i]);
						j++;	
					} else {
						k++;	
					}						   
				});
			} else {
				opt.editColumn = [];
			}

			var str = '';
			r._colid = 'col'+opt._colid++;
			r._hasSetEd = true;
			r.field = 'ed';
			r.title = (opt.editColumnTitle === '' || opt.editColumnTitle === false ) ? ' ' : opt.editColumnTitle;
			r._expand = str;
			r.forceFit = opt.editColumnForceFit;
			r.hcls = 'datagrid-header-edit';
			r.bcls = 'datagrid-cell-edit';
			r.width = ( j * opt.editCellW + k * 4 )+'px';
			r.fitColumn = opt.editColumnFit;
			r.align = 'center';
			r.callBack = function(t,rowId,field,rowData){
				var self = this;
				var _item = opt._toolItem;
				var tools = [];
				var tool = {};
				var i = 0,
					len = opt.editColumn.length;
				for(;i<len;i++) {
					
					if( $.isPlainObject(opt.editColumn[i]) ) {
						tool = $.extend(true,{},_item,opt.editColumn[i]);
						tool.callBack = function(t,_item_){
							var indexid = $(t).attr("indexid");
							opt.editColumn[indexid]['callBack'].call(self,t,rowId,field,rowData,_item_);	
						}
						
						tools.push(tool);	
					}  else {
						tools.push(opt.editColumn[i]);	
					}
				};
				if( !$.isFunction( opt.editColumnSetter ) ) {
					var _tool = self.getTools(tools);
					t.append(_tool);
				} else {
					opt.editColumnSetter.call( self,tools,t,rowId,field,rowData );	
				}
			}
			
			return r;
		},
		/*
		*系统事件,设置grid列宽
		*/
		onInitFieldWidth : function(){
			var self = this,
			opt = self.configs;
			self._initFieldWidth();
			return self;
		},
		/*
		*系统事件,设置grid中含有百分比的列宽
		*/
		onFinishFieldWidth : function(){
			var self = this,
			opt = self.configs;
			var columns = opt.columns;
			var nd = false;
			self.lockMethod( 'resetViewSize' );
			//self.lockEvent("onFieldWidthChange");
			$.each(columns,function(i,column){
				if( column.width.toString().indexOf("%") != -1 ) {
					nd = true;
					self.setFieldWidth( column.field,column.width );
				}
			});
			//self.unLockEvent("onFieldWidthChange");
			
			/*if( nd && opt.forceFit ) {
				self.forceFitColumn();	
			}*/
			
			self.unLockMethod( 'resetViewSize' );
			if( nd ) {
				self.lockMethod("onScroll");
				self.lockEvent("onScroll");
				self.methodInvoke('resetViewSize',function(){
					self.unLockMethod("onScroll");	
					self.unLockEvent("onScroll");
				});
			}
			return self;
		},
		refreshColumnsWidth : function(){
			return this.onFinishFieldWidth();	
		},
		//初始化宽度
		_initFieldWidth : function(){
			var self = this,
			opt = self.configs;	
			//console.log('^^1',opt.columns);
			var columns = self.getColumns();
			//opt.columns = columns;
			
			//取得grid 显示区域宽度
			var w = 0;
			var gridWidth = $("#view_"+opt.id).width();//不要用_width 因为grid表格一定会设置宽度
			var view1_w = $("#view1-datagrid-header-inner-htable-"+opt.id)._outerWidth(); 
			w = gridWidth - parseFloat( view1_w );
			
			$("#"+opt.id+"_css").remove();
			var style = [];
			style.push('<style type="text/css" id="'+opt.id+'_css">');
			//datagrid_cols_
			for(var i=0;i<columns.length;i++) {
				var column = columns[i];
				var _colpadding = opt.cellpPadding;
				if( '_colpadding' in column ) {
					_colpadding	= parseFloat(column._colpadding);
				} else {
					var _colpadding = $('#'+opt.id+'_cols_' + column['_colid']);
					var cell_colpadding = $('#'+opt.id+'_cell_header_' + column['_colid']);
					if( _colpadding.size() ) {
						var _w = _colpadding.outerWidth()-cell_colpadding._width();
						_w = _w<0?0:_w;	
						_colpadding = _w;
						column._colpadding = _colpadding;
					} else {
						_colpadding = opt.cellpPadding;	
						column._colpadding = _colpadding;
					}
				}
				var width = column['width'];
				var field = column['field'];
				//初始化宽度
				if( width.toString().indexOf("%") != -1 ) {
					width = parseFloat(width)*w/100;
				} else {
					width = parseFloat(width);
				}
				//maxWidth
				var maxWidth = column['maxWidth'];
				if( maxWidth !== null ) {
					maxWidth = 	parseFloat(maxWidth);
					width = Math.min(maxWidth,width);
				}
				
				var minWidth = column['minWidth'];
				width = width>=minWidth ? width : minWidth;
				
				column._fieldWidth = width;

				width -= column._colpadding;
				
				if( opt._colWidthExt ) {
					width = self.str_number( width,opt._colWidthExt );	
				} else {
					width = Math.floor(width); 	
				}
				
				var css = ['#',opt.id,' .datagrid-cell-',column['_colid'],'{width:',width,'px;}'].join('');	
				style.push(css);
			}
			style.push('</style>');
			style = style.join("\n");
			$("#"+opt.id).before(style);
			
			return self;
		},
		//ie6 7 下动态添加的css对 隐藏元素无效
		_setFieldWidth : function(field,width,real){
			var self = this,
			opt = self.configs;
			var column = self.getColumnData(field);
			if( column === null ) {
				return false;	
			}
			var _colid = column._colid;
			var real = self._undef(real,false);
			var width = self._undef(width,120);

			if( width.toString().indexOf("%") != -1 ) {
				var w = 0;
				var body = $("#view2-datagrid-body-"+opt.id);
				//判断是否出现了垂直滚动条
				if( body.size() && self.hasScroll( body[0],'top' ) ) {
					var scrollbarSize = self.getScrollbarSize();
					w = body.width() - scrollbarSize.width;//减滚动条宽度
					width = parseFloat(width)*w/100;
				} else {
					var body = $("#view2-datagrid-header-inner-"+opt.id);
					width = parseFloat(width)*(body.width())/100;
				}
			} else {
				width = parseFloat(width);
			}
			//maxWidth
			var maxWidth = column.maxWidth;
			if( maxWidth !== null ) {
				maxWidth = 	parseFloat(maxWidth);
				width = Math.min(maxWidth,width);
			}
			
			var minWidth = parseFloat(column.minWidth);
			width = width>=minWidth ? width : minWidth;
			
			var changeWidth = width;
			//如果当前值和上一次的_realWidth值相同，那么列宽并没有改变不需要重设
			if( column._fieldWidth && column._fieldWidth == changeWidth ) {
				return false;//列宽并没有改变 不需要设置
			}
			
			if( !real ) {
				width -= column._colpadding;
			}
			//保留几位小数点 不要开启
			if( opt._colWidthExt ) {
				width = self.str_number( width,opt._colWidthExt );	
			} else {
				width = Math.floor(width); 	
			}
			
			var cellSelector = ["#",opt.id," .datagrid-cell-",_colid].join('');
			
			var style = $("#"+opt.id+'_css').get(0);
			if( !style ) return false;
			var styleSheet = style.styleSheet?style.styleSheet:(style.sheet||document.styleSheets[document.styleSheets.length-1]);
			var rules = styleSheet.cssRules || styleSheet.rules;
			var isRule = false;//判断是否存在当前设置
			//解决IE下 width = NaN的情况
			width = isNaN( width ) ? 0 : width;
			for(var i=0;i<rules.length;i++) {
				if( rules[i].selectorText.toLowerCase() == cellSelector.toLowerCase() ) {
					rules[i]['style']['width'] = width+'px';
					isRule = true;
					break;
				}
			}
			if( !isRule ) {
				var addRule = styleSheet.addRule || styleSheet.insertRule;
				if( styleSheet.addRule ) {
					styleSheet.addRule(cellSelector,"width:"+width+"px");	
				} else {
					styleSheet.insertRule(cellSelector+"{width:"+width+"px}",rules.length);	
				}
				
			}
			//作为缓存用，判断是否改变
			column._fieldWidth = changeWidth;
			return changeWidth;
		},
		/*
		* 设置列宽度(支持百分比)
		*  必须要等到grid创建好才可调用
		*  @field {String} 列名
		*  @width {String,int} 列宽
		*  @real {boolean} true:真实宽度,false:需要对当前设置的宽度处理 默认(可选)
		*/
		setFieldWidth : function(field,width,real){
			var self = this,
			opt = self.configs;

			var _c = self.getColumnData(field);
			if( _c === null ) return width;
			//var _fieldWidth = _c._fieldWidth;
			var changeWidth = self._setFieldWidth(field,width,real);
			if( changeWidth === false ) {
				return false;	
			}
			//self.onScroll(true);
			var w = _c['width'];
			if( width.toString().indexOf("%") != -1 ) {
				self.setColumnValue(field,'width',width);	
			} else {
				if( w.toString().indexOf("%") != -1 ) {	
					if( _c.casePerChange ) {
						self.setColumnValue(field,'width',changeWidth);	
					}
				} else {
					self.setColumnValue(field,'width',changeWidth);	
				}
			}
			
			self.fireEvent("onFieldWidthChange",[field,changeWidth,width,w,opt]);
			//作用是 如果开启了autoHeight emptyMsg 需要通知他们更新宽度或高度
			//方式一
			//var r = self.onViewSizeChange( false );
			//if( r ) {
			//	self.fireEvent("onViewSizeChange",[opt]);
			//}
			//方式二
			self.lockEvent("onScroll");
			self.methodInvoke('resetViewSize');
			self.unLockEvent("onScroll");
			
			return changeWidth;
		},
		setForceFitColumn : function( field,w ){
			var self = this,
			opt = self.configs;	
	
			var column = self.getColumnData(field);
			if( opt.forceFit && column.forceFit ) {
				self.onFitColumn( field,w );
			}
		},
		onFitColumn : function( field,w ){
			var self = this,
			opt = self.configs;
			if( opt.forceFit ) {
				self.forceFitColumn( field,w );
				self.fireEvent("onAutoColumnResize",[opt]);
			}
		},
		/*
		* 列宽度只适应
		* fields {Array} 不需要自适应的列(可选)
		* _w {int} 当前fields改变后的宽度(可选)
		*/
		_forceFitColumn : function( fields,_w ){//平均设置列宽大小，如果传入field则传入的filed 大小不会改变
			var self = this,
			opt = self.configs;	
			var columns = opt.columns;
			
			var fields = typeof fields == 'undefined' ? [] : fields;
			
			fields = $.isArray( fields ) ? fields : [ fields ];
			
			$("#view2-datagrid-body-"+opt.id).css("overflow-x","hidden");
			
			var w = $('#view2_'+opt.id).width();

			var body = $("#view2-datagrid-body-"+opt.id);

			if( self.hasScroll(body,'top') ) {
				var scrollbarSize = self.getScrollbarSize();
				w -= scrollbarSize.width;
			} else {
				w -= 0;	
			}
			
			var _clw = {};
			var _mw = {};//获取最小宽度
			var _wt = 0;//总宽
			var border = 0;
			//获取每个列宽
			$("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find(">.datagrid-header-row td[field]").each(function(){	
				var tw = $(this)._outerWidth();

				var field = $(this).attr('field');

				for( var x=0;x<columns.length;x++ ) {
					if( columns[x]['field'] == field && self.inArray( field,opt.hideColumns )==-1 ) {
						if( columns[x]['forceFit'] && self.inArray( field,fields )==-1 ) {
							_clw[ field ] = tw;
							_mw[ field ] = columns[x]['minWidth'];
							_wt += tw;
						} else {
							w -= tw;	
						}
						break;
					}
				}
			});
		//	console.log(w,_wt);
			var dw = 0;//超出宽度
			for( var f in _clw ) {
				_clw[f] =  (w*Math.floor( _clw[f]*10000/_wt )/10000) - border;	//Number(_clw[f]).toFixed(0);
				
				if( _clw[f] < _mw[f] ) {
					dw += (_mw[f]-_clw[f]);
				}
				self._setFieldWidth(f,_clw[f]);
			}
			//如果forceFit的列都已经是最小了，那么还超出宽度就需要减少当前列的宽度
			if( dw && fields.length==1 && _w && opt.forceFitVisible ) {
				//fields[0]['field']
				self._setFieldWidth(fields[0],_w-dw);	
			}

			//self.fireEvent("onForceFitColumn",[opt]);
			return self;
		},
		forceFitColumn : function(fields,_w){
			var self = this,
			opt = self.configs;	
			if( opt._forceFitWTime ) {
				clearTimeout( opt._forceFitWTime );	
			}
			opt._forceFitWTime = setTimeout( function(){
				self._forceFitColumn(fields,_w);	
				self.fireEvent("onForceFitColumn",[opt]);
			},0 );
			return self;
		},
		unForceFitColumn : function(){
			var self = this,
			opt = self.configs;	
			opt.forceFit = false;
			$("#view2-datagrid-body-"+opt.id).css("overflow-x","auto");
		},
		/*遍历 树形 columns 并返回叶子节点*/
		_columnsMap : function( columns ){
			var self = this
				,undef
				,opt = self.configs
				,columns = columns === undef ? opt.columns : columns
			;
			var fields = columns;
			var list = [];
			
			/*递归遍历*/
			var listMap = function( column,pid ){
				
				if( column.field === undef || column.field=='' ) {
					column.field = ['field',++Nex.aid].join('');	
				}
				
				if( pid === undef || pid === null ) {
					  pid = null;	
				} else {
					pid = $.isPlainObject( pid ) && (pid.field !== undef) ? pid.field : null;
				}
				
				if( opt.multiFromStr && opt.multiSplitStr != '' ) {
					//对列名有"_"的进行处理
					var _sp = opt.multiSplitStr;
					var _md = opt.multiFromStrData;
					var _field = column.field+'';
					column._ofield =  column._ofield===undef ? _field : column._ofield;
					
					var sl = column._hasSet?[]:_field.split(_sp);
					if( sl.length>1 ) {
						 column._hasSet = true;
						 column.field = sl[0];
						 var of = column._ofield.split(_sp);
						 var index = $.inArray( column.field,of );
						 column.field = of.slice(0,index+1).join(_sp); 
						 var tls = column.field.split(_sp);
						 var _realField = tls.pop();
						 column.title = column.title||_realField;
						 if( _realField in _md ) {
							$.extend( column,_md[ _realField ] ); 
						 }
						 if( column.field in _md ) {
							$.extend( column,_md[ column.field ] ); 
						 }
						 sl.splice(0,1);//删除第一个
						 column.columns = column.columns === undef ? [] : column.columns;
						 column.columns.push( { field : sl.join(_sp),_ofield:column._ofield } );
						
					} else {
						if( !column._hasSet && sl.length ) {
							   column._hasSet = true;
							   var of = column._ofield.split(_sp);
							   var index = $.inArray( column.field,of );
							   column.field = of.slice(0,index+1).join(_sp); 
							   var tls = column.field.split(_sp);
							   var _realField = tls.pop();
							   column.title = column.title||_realField;
							   
							   if( _realField in _md ) {
									$.extend( column,_md[ _realField ] ); 
							   }
							   if( column.field in _md ) {
									$.extend( column,_md[ column.field ] ); 
							   }
						}
					}
				}
				
				//设置默认值
				column = $.extend({},opt._columnMetaData,column);
				
				if( column.disabled===true  ) return;
				
				opt._columnsHash['nsort'+column.field] = column;
				column.__pid = column.__pid===undef ?  pid : column.__pid;
				
				if( ('columns' in column) && $.isArray( column.columns ) && column.columns.length ) {
					var ls = column.columns;
					var len = ls.length;
					for( var i=0;i<len;i++ ) {
						listMap( ls[i],column );	
					}
				} else {
					//console.log( column.field );
					list.push( column );	
				}
			}
			var i = 0,
				len = fields.length;
			for(;i<len;i++) {
				listMap( fields[i],null );
			}	
			//修正header和body如果columns设置不一致时顺序问题
			list = self._getLeafColumns();
			return list;
		},
		addColumn : function( column ){
			var self = this,
			opt = self.configs;
			opt.columns.push( column );
			self._initFieldWidth();
			self.setGridHeader();
			self.refreshDataCache();
			return self;
		},
		/*
		* 获取当前grid的列信息
		* s {boolean} true:返回源数据,false:返回经过处理后的数据 默认(可选)
		*/
		getColumns : function(s){
			var self = this,
				undef,
				opt = self.configs;
			var xcolumns = opt.columns;
			//console.log(xcolumns,xcolumns.length);
			var s = self._undef(s,false);
			//初始调用时保存副本
			opt.cacheData['columns'] = self._undef(opt.cacheData['columns'],xcolumns);//cacheData
			//获取副本
			if(s) {
				return 	opt.cacheData['columns'];
			}
			
			//检测是否设置了 列 否则用data的key作为列名
			//var _mIndex = {}; //已经做了处理
			if(xcolumns.length<=0) {
				if(opt.data.length>0) {
					
					if( $.isPlainObject( opt.data[0] ) ) {
					
						for(var i in opt.data[0]) {
							xcolumns.push({'field':i});
						}
					}
					//已经做了处理
					//给每列添加数据映射 因为每列有可能以"_"分割 所以最后一个就是需要的列名
					/*var _hdata = opt.data[0];
					if( $.isPlainObject( _hdata ) ) {
						for(var _index in _hdata) {
							var _cl = _index.split('_');
							if( _cl.length>1 ) {
								_mIndex[ _cl[ _cl.length-1 ] ] = _index;
							} else {
								_mIndex[ _index ] = _index;
							}
						}
					}*/
				}
			}
			
			//对多级列进行处理 初次用时有效
			var columns = self._columnsMap(xcolumns);
			
			//var _columns = [];
			var _hasSetCk = false,
				_hasSetEd = false;
			var i = 0,
				len = columns.length;
			for(;i<len;i++) {
				
				//columns[i] = $.extend({},opt._columnMetaData,columns[i]);
				
				if( columns[i]['disabled'] === true ) continue;
				
				//if(typeof columns[i]['width'] == 'number') columns[i]['width'] += 'px';
				columns[i]['field'] = columns[i]['field'] === "" ?  i : columns[i]['field'];
				//已经做了处理
				//if( !$.isEmptyObject( _mIndex ) ) {
					//columns[i]['index'] = _mIndex[ columns[i]['field'] ] === undefined ?  columns[i]['index'] : _mIndex[ columns[i]['field'] ];
				//}
				
				//customColumnData
				if( columns[i]['field'] in opt.customColumnData ) {
					$.extend( columns[i],opt.customColumnData[columns[i]['field']] );
				}
				
				columns[i]['title'] = columns[i]['title'] === "" ?  columns[i]['field'] : columns[i]['title'];
				columns[i]['index'] = columns[i]['index'] === "" ?  columns[i]['field'] : columns[i]['index'];
				columns[i]['_colid'] = columns[i]['_colid'] === undef ? 'col'+(Nex.grid._colid++ || opt._colid++) : columns[i]['_colid'];
				
				//判断是否开启ck ed字段
				if( opt.checkBox !== false && columns[i]['field']=="ck" && _hasSetCk===false ) {
					if( !columns[i]['_hasSetCk'] ) {
						columns[i] = self.getCheckBoxColumn();
						opt._columnsHash[ 'nsort'+columns[i]['field'] ] = columns[i];
					}
					_hasSetCk = true;
				}
				if( opt.editColumn !== false  && columns[i]['field']=="ed" && _hasSetEd===false ) {
					if( !columns[i]['_hasSetEd'] ) {
						columns[i] = self.geteditColumn();
						opt._columnsHash[ 'nsort'+columns[i]['field'] ] = columns[i];
					}
					_hasSetEd = true;
				}
				
				//opt._columnsHash[ columns[i]['field'] ] = columns[i];
				//_columns.push(columns[i]);
			}
			
			//columns = _columns;
			
			//检测是否使用checkbox
			var ck = [],
				ed = [];
			if( opt.checkBox !== false && _hasSetCk===false ) {
				var copt = self.getCheckBoxColumn();
				if( copt !== false) {
					ck = [ copt ];
					opt._columnsHash[ 'nsort'+copt['field'] ] = copt;
					//$.merge(ck,columns);
					columns.unshift( copt );
					//columns = ck.concat( columns );
					//columns = ck;
				}
			}
			
			if( opt.editColumn !== false && _hasSetEd===false) {
				if(self.geteditColumn() !== false) {
					ed = [ self.geteditColumn() ];
					opt._columnsHash[ 'nsort'+ed[0]['field'] ] = ed[0];
					//$.merge(columns,ed);
					//columns = columns.concat( ed );
					columns.push(ed[0]);
				}
			}
			//opt.columns.length = 0;
			opt.columns = columns;
			
			self.fireEvent( 'onSetColumns',[columns] );
			
			return opt.columns;
		},
		//页面刷新的时候调用
		onDisplayField : function(){
			var self = this,
				opt = self.configs,
				_columns = opt.hideColumns,
				gid = opt.gid;
			if(_columns.length <= 0) return;
			var i = 0,
				len = _columns.length;
			for(;i<len;i++) {
				if( _columns[i] == null ) continue;
				self.hideColumn(_columns[i]);
			}
		},
		displayColumn : function( field , type ) {
			var self = this,
				opt = self.configs,
				_columns = opt.hideColumns,
				gid = opt.gid;
			var fields = self.getColumnList();

			if( self.inArray(field,fields) == -1 ) return false;
			
			var isDisplay = (type == "show") ? true : false;
			if( isDisplay  ) { //&& self.inArray( field,_columns )
				var i = 0,
				len = _columns.length;
				for(;i<len;i++) {
					if(_columns[i] == field) _columns[i] = null;
				}
			} else {
				if( self.inArray( field,_columns ) == -1 )
					_columns.push( field );
			}
			$(gid).find("td[field='"+field+"']")[type]();
			
			var eventType = isDisplay ? 'onShowColumn' : 'onHideColumn';

			self.fireEvent(eventType,[field,opt]);
			//是否应该锁定？ onScrll
			self.lockEvent("onScroll");
			self.methodInvoke('resetViewSize');
			self.unLockEvent("onScroll");
			
			return true;
		},
		/*
		* 显示指定列
		*  field {String} 列名
		*/
		showColumn : function( field ){
			var self = this,
				opt = self.configs;
			var r = self.fireEvent('onBeforeShowColumn',[field,opt]);
			if( r === false ) {
				return r;	
			}
			return self.displayColumn( field ,"show");
		},
		/*
		* 隐藏指定列
		*  field {String} 列名
		*/
		hideColumn : function( field ){
			var self = this,
				opt = self.configs;
			var r = self.fireEvent('onBeforeHideColumn',[field,opt]);
			if( r === false ) {
				return r;	
			}
			return self.displayColumn( field , "hide");
		},
		/*
		* 对指定列排序
		*  field {String} 列名
		*/
		sortColumn : function(field){},
		/*
		* 显示列头
		*/
		showHeader : function(){
			var self = this,
				opt = self.configs;
				opt.showHeader = true;
			//self.resetViewSize();
			self.methodInvoke('resetViewSize');
		},
		/*
		* 隐藏列头
		*/
		hideHeader : function(){
			var self = this,
				opt = self.configs;
				opt.showHeader = false;
			//self.resetViewSize();
			self.methodInvoke('resetViewSize');
		},
		setGridHeaderEvent : function(tr,ltr){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			
			var fields = self.getColumnMap();	
			
			
			var tds = tr.find("td[field]");
			
			//设置列 是否可以改变大小 参数
			if(opt.fitColumns) {
				var o = $.extend({},opt);
				o.self = self;
				o.stop = function(e,cfg){
					var r = self.fireEvent('onResizeColumnStop',[cfg,opt]);
					if(r === false) return r;
					self.cStop(cfg);
				};
				setTimeout(function(){
					var resizes = [];
					tds.each(function(){
						var field = $(this).attr("field");
						//设置列是否可改变大小
						var fitColumn = self.getColumnData(field,'fitColumn');
						
						if( fitColumn ) {
							//$(".datagrid-cell",this)._resize(o);
							resizes.push($(".datagrid-cell",this));
						}	
					});
					$(resizes)._resize(o);
				},10);
			}
			//拖动列
			if( opt.moveColumns ) {
				setTimeout(function(){
					tds.moveColumn(opt);//tr.find("td[field]").moveColumn(opt)					
				},10);
			}
			
			tds.bind({
				click : function(e){  
					if( dataGrid.__resizing || dataGrid.__moving ) {
						return;	
					}
					var field = $(this).attr("field");
					if( opt.autoScrollToField ) {
						self.scrollToField(field);	
					}
					var r = self.fireEvent('onColumnClick',[field,this,e]);
					if( r === false ) return r;
				},	 
				mouseenter : function(e){
					var field = $(this).attr("field");
					$(this).addClass("datagrid-header-over");
					var r = self.fireEvent('onColumnOver',[field,this,e]);	
					if( r === false ) return r;
				},	
				mouseleave : function(e){
					var field = $(this).attr("field");
					$(this).removeClass("datagrid-header-over");
					var r = self.fireEvent('onColumnOut',[field,this,e]);	
					if( r === false ) return r;
				},	
				dblclick : function(e){
					var field = $(this).attr("field");
					var r = self.fireEvent('onColumnDblClick',[field,this,e]);	
					if( r === false ) return r;
				},
				contextmenu : function(e){
					var field = $(this).attr("field");
					var r = self.fireEvent('onColumnContextMenu',[field,this,e]);	
					if( r === false ) return r;
				}
			});
			
			//设置contentmenu
			tr.bind("contextmenu",function(ev){
				//触发单击行事件
				var r = self.fireEvent('onHeaderContextMenu',[this,ev]);
				if(r == false) return false;
			});
			/*检查文字是否超出边界*/
			self.setGridHeaderTextLimit();
			/*checkbox绑定*/
			if(opt.checkBox) {
				var cks = tr.find("td[field='ck']");
				//cks.find(".datagrid-sort-icon").hide();
				cks.find("input:checkbox").click(function(){
						if(opt.singleSelect) {
							this.checked = false;
							return false;
						}
						if(this.checked) {
							self.selectAllRows();
						} else {
							self.unselectAllRows();
						}
					});
			}
			
			self.fireEvent("onSetGridHeaderEvent",[tr,tds,opt]);
			
		},
		/*检查文字是否超出边界*/
		setGridHeaderTextLimit : function(){},
		updateHeaderRow : function(w){
			var self = this,
				opt = self.configs;
			var w = self._undef( w,false );
			self.setGridHeader();
			if( w ) {
				self.onInitFieldWidth();
				self.refreshColumnsWidth();
			}
			self.fireEvent("onUpdateHeaderRow",[opt]);
		},
		_getColumnChildrens : function( name ){
			var self = this
				,undef
				,opt = self.configs;	
			var list = [];
			if( name === undef || name === null ) {
				return self._getRootColumns();	
			}
			var columns = opt._columnsHash;	
			for( var key in columns ) {
				var field = columns[key];	
				if( field.__pid === name ) {
					list.push( field );
				}		
			}		
			return list;	
		},
		_getColumnAllChildrens : function( name ){
			var self = this
				,undef
				,opt = self.configs;	
			var list = [];
			var name = name;
			var _loop = function( n ){
				var childs = self._getColumnChildrens(n);
				for( var i=0,len=childs.length;i<len;i++ ) {
					list.push( childs[i] );	
					_loop( childs[i]['field'] );
				}
			};
			_loop(name);
			return list;	
		},
		/*获取当前单元格下 还有多少层次*/
		_getColumnAllLevel : function( name ){
			var self = this
				,undef
				,opt = self.configs;	
			if( name === undef || name === null || name === '' ) {
				name = null;
			}	
			var columns = opt._columnsHash;	
			var childs = self._getLeafColumns( name );
			var level = 1;
			var getTop = function( n ){
				var n = 'nsort'+n;
				if( n in columns ) {
					var column = columns[n];
					if( column.__pid !== name ) {
						level++;
						return getTop( column.__pid );	
					} else {
						return level++;	
					}	
				}	
			};
			var _max = 0;
			$.each( childs,function(i,field){
				var i = getTop( field['field'] );
				_max = Math.max( _max,i );	
				level = 1;
			} );
			
			return _max;	
		},
		_isRootColumn : function( field ){
			var field = field || {};
			return field.__pid === null || 	field.__pid===undef ? true : false;	
		},
		_isLeafColumn : function(name){
			var list = this._getColumnChildrens( name );
			return list.length ? false : true;
		},
		/**
		*获取指定单元格下的叶子节点	
		*/
		_getLeafColumns : function( name ){
			var self = this
				,undef
				,opt = self.configs;
			var list = [];
			var columns = opt._columnsHash;	
			var childs = self._getColumnAllChildrens( name );
			for( var i=0,len=childs.length;i<len;i++ ) {
				if( self._isLeafColumn( childs[i]['field'] ) ) {
					list.push( childs[i] );	
				}
			}
			return list;	
		},
		//返回指定单元格的最顶层
		_getTopColumn : function(name){
			var self = this
				,undef
				,opt = self.configs;
			var columns = opt._columnsHash;	
			var name = 'nsort'+name;
			if( name in columns ) {
				var column = columns[name];
				if( column.__pid !== null && column.__pid !== undef ) {
					return self._getTopColumn( column.__pid );	
				} else {
					return column;	
				}	
			}	
		},
		//返回最顶层的单元格列表
		_getRootColumns : function(){
			var self = this
				,undef
				,opt = self.configs;
			var list = [];
			var columns = opt._columnsHash;
			for( var key in columns ) {
				var field = columns[key];	
				if( field.__pid === null || field.__pid===undef ) {
					list.push( field );
				}	
			}	
			return list;		
		},
		/*
		*多表头实现 方法一
		*/
		view2_header_inner_row_1 : function(){
			var self = this
				,undef
				,opt = self.configs;
			var hlist = [];
			var hhash = {};
			
			if( !opt.multiColumns ) {
				return self.tpl('view2_header_inner_row_bak',data);	
			}	
			//leafColumn 模版
			var tdTpl = '<td rowspan="<%=rowSpan%>" colspan="<%=colSpan%>" id="<%=gridId%>_cols_<%=_colid%>" class="datagrid-td-leaf datagrid_<%=_colid%>" field="<%=field%>" align="<%=align%>">'
							+'<div class="datagrid-header-wrap" field="<%=field%>" >'
								+'<div id="<%=gridId%>_cell_header_<%=_colid%>" class="datagrid-cell datagrid-header-cell datagrid-cell-<%=_colid%> datagrid-cell-header-<%=_colid%> <%=hcls%>" >'
									+'<span class="datagrid-header-column-inner datagrid-header-column-inner-text"><%=title%></span>'
								+'</div>'
							+'</div>'
						+'</td>';
			//parentColumn模版
			var tdTpl2 = '<td rowspan="<%=rowSpan%>" colspan="<%=colSpan%>" class="datagrid-td-noleaf" align="<%=align%>">'
							+'<div class="datagrid-header-wrap">'
								+'<span class="datagrid-header-column-inner datagrid-header-column-inner-text"><%=title%></span>'
							+'</div>'
						+'</td>';
			
			function getTD( field,level ){
				var level = level || 0;
				var name = field['field'];
				var colSpan = self._getLeafColumns( name );
				var rowSpan = 1;
				colSpan = colSpan.length;
				//rowSpan += 1;
				rowSpan = maxRow-level;
				var fieldText = field.title === undef ? field.field : field.title ;
				field.title = fieldText;
			
				if( self._isLeafColumn(name) ) {
					colSpan = 1;
					var tds = self.tpl( tdTpl,$.extend({},field,{gridId:opt.id,rowSpan:rowSpan,colSpan:colSpan}) );	
					trs[level].push( tds );
					return;
				} else {
					rowSpan = 1;
					var tds = self.tpl( tdTpl2,$.extend({},field,{gridId:opt.id,rowSpan:rowSpan,colSpan:colSpan,align:opt.multiColumnsAlign}) );	
					trs[level].push( tds );
					var childs = self._getColumnChildrens( name );
					$.each( childs,function(i,f){
						var _level = level;
						getTD( f,++_level );
					} );
				}	
			}
			
			//更新_columnsHash
			//self._columnsMap();
			var columns = opt._columnsHash;
			var maxRow = self._getColumnAllLevel();
			var cols = self._getRootColumns();
			var trs = [];//每层td内容
			//初始化内容
			for(var i=0;i<maxRow;i++) {
				trs[i] = [];	
			}
			$.each( cols,function(i,field){
				getTD( field );	
			} );
			
			var html = [];
			$.each(trs,function(i,tr){
				var tds = ['<tr class="datagrid-header-row">'];
				tds.push(tr.join(''));
				tds.push('</tr>');
				html.push( tds.join('') );	
			});
			return html.join('');
		},
		/*
		*多表头实现 方法二
		*/
		view2_header_inner_row : function( data ){ 
			var self = this
				,undef
				,opt = self.configs;
			var hlist = [];
			var hhash = {};
			
			if( !opt.multiColumns ) {
				return self.tpl('view2_header_inner_row_bak',data);	
			}
			if( opt.mulitEngine == 1 ) {
				return self.view2_header_inner_row_1( data );
			}
			//更新_columnsHash
			//self._columnsMap();
			var columns = opt._columnsHash;
			/*
			 *最终单元格模版
			*/
			var tdTpl = '<td id="<%=gridId%>_cols_<%=_colid%>" class="datagrid_<%=_colid%>" field="<%=field%>" align="<%=align%>">'
							+'<div class="datagrid-header-wrap" field="<%=field%>" >'
								+'<div id="<%=gridId%>_cell_header_<%=_colid%>" class="datagrid-cell datagrid-header-cell datagrid-cell-<%=_colid%> datagrid-cell-header-<%=_colid%> <%=hcls%>" >'
									+'<span><%=title%></span>'
								+'</div>'
							+'</div>'
						+'</td>';
			var getTopParent = function(name){
				return self._getTopColumn( name );
			}			
			var sortColumns = function( columns ){
				return columns;	
			}
			var getRoot = function(){
				return self._getRootColumns();
			}
			var getChildrens = function(name){
				return self._getColumnChildrens(name);
			}
			var isRoot = function(field){
				return self._isRootColumn();
			}
			var isLeaf = function( name ){
				return self._isLeafColumn(name);
			}
			
			var getTD = function( field ){
				var name = field.field;
				var fieldText = field.title === undef ? field.field : field.title ;
				field.title = fieldText;
				if( isLeaf( name ) ) {
					return self.tpl( tdTpl,$.extend({},field,{gridId:opt.id}) );
				} else {
					var childs = getChildrens( name );
					var itd = ['<td class="datagrid-noborder" valign="bottom">'];
					itd.push('<table cellpadding="0" cellspacing="0" style="height:100%;">');
						itd.push('<tr class="datagrid-header-middle-row">');
							itd.push('<td colspan="'+childs.length+'" class="datagrid-td-noborder" align="'+opt.multiColumnsAlign+'">'+fieldText+'</td>');
						itd.push('</tr>');
						itd.push('<tr>');
							for( var i=0;i<childs.length;i++ ) {
								itd.push( getTD( childs[i] ) );	
							}
						itd.push('</tr>');
					itd.push('</table>');
					itd.push('</td>');
					return itd.join('');
				}
			}
			
			/*
			* 排列顺序，但是只曾对顶成field有效，
			*/
			var fields = self.getColumnMap();//getColumnMap 是 相当于直接使用opt.columns 只是封装接口而已
			var _flist = {};
			for( var t=0;t<fields.length;t++ ) {
				var tf = getTopParent( fields[t]['field'] );
				if( tf === undef ) continue;
				_flist[ tf.field+'_mf_nsort' ] = tf;
			}
			var mfields = [];
			for( var k in _flist ) {
				mfields.push( _flist[k] )	
			}
			//直接调用getChildrens会有顺序问题
			//var fields = getChildrens(null);

			var tds = ['<tr class="datagrid-header-row">'];
			for( var i=0;i<mfields.length;i++ ) {
				var field = mfields[i];
				var td = getTD( field );
				tds.push(td);
			}
			tds.push('</tr>');
			
			return tds.join('');
		},
		/*
		* 重新设置列头 当前会执行2次 待检查
		*/
		setGridHeader : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			//console.log('^^2',opt.columns);
			//var fields = opt.columns;
			var fields = self.getColumns();
			//self.C('columns',fields);
			//console.log('^^22',fields);
			var view1_header_row = self.getTpl("view1_header_inner_row");
			var view2_header_row = opt.headerTpl ? opt.headerTpl : self.getTpl("view2_header_inner_row");
			
			var $view2_header_inner_wraper = $("#datagrid-view2-header-inner-wraper-"+opt.id);
			var $view1_header_inner_wraper = $("#datagrid-view1-header-inner-wraper-"+opt.id);
			var $view2_header_outer_wraper = $("#datagrid-view2-header-outer-wraper-"+opt.id);
			var $view1_header_outer_wraper = $("#datagrid-view1-header-outer-wraper-"+opt.id);
			
			//datagrid-header-inner-wraper
			var view1_header_inner_wraper = ['<table class="datagrid-htable" id="view1-datagrid-header-inner-htable-'+opt.id+'" border="0" cellspacing="0" cellpadding="0"><tbody id="view1-datagrid-header-inner-htable-tbody-'+opt.id+'">'];
			var view2_header_inner_wraper = ['<table class="datagrid-htable" id="view2-datagrid-header-inner-htable-'+opt.id+'" border="0" cellspacing="0" cellpadding="0"><tbody id="view2-datagrid-header-inner-htable-tbody-'+opt.id+'">'];
			//datagrid-header-outer-wraper
			var view1_header_outer_wraper = ['<table class="datagrid-locktable" id="view1-datagrid-header-outer-locktable-'+opt.id+'" border="0" cellspacing="0" cellpadding="0"><tbody id="view1-datagrid-header-outer-locktable-tbody-'+opt.id+'"></tbody></table>'];
			var view2_header_outer_wraper = ['<table class="datagrid-locktable" id="view2-datagrid-header-outer-locktable-'+opt.id+'" border="0" cellspacing="0" cellpadding="0"><tbody id="view2-datagrid-header-outer-locktable-tbody-'+opt.id+'">'];
			
			var ltr = self.tpl(view1_header_row,opt);
			var tr = self.tpl(view2_header_row,{'fields':fields,opt:opt});

			view1_header_inner_wraper.push(ltr);
			view2_header_inner_wraper.push(tr);
			
			view1_header_inner_wraper.push('</tbody></table>');
			view2_header_inner_wraper.push('</tbody></table>');
			

			view2_header_outer_wraper.push('</tbody></table>');
			
			$view1_header_inner_wraper.html( view1_header_inner_wraper.join("") );
			$view2_header_inner_wraper.html( view2_header_inner_wraper.join("") );
			$view1_header_outer_wraper.html( view1_header_outer_wraper.join("") );
			$view2_header_outer_wraper.html( view2_header_outer_wraper.join("") );
			
			ltr = $(">.datagrid-header-row",'#view1-datagrid-header-inner-htable-tbody-'+opt.id);
			tr = $(">.datagrid-header-row",'#view2-datagrid-header-inner-htable-tbody-'+opt.id);
			
			self.setGridHeaderEvent(tr,ltr);//性能
			
			self.methodCall('setGridHeader');
			if( opt.mulitEngine != 1 ) {
				self.refreshHeaderHeight(tr,ltr,opt);
			}
			self.fireEvent('onHeaderCreate',[tr,ltr,opt]);
			
			return true;
		},
		refreshHeaderHeight : function(tr,ltr,opt){
			var self = this;
			
			var h = tr._height();
		  	var tr = tr.add(ltr);

			tr.find('>td').each(function(){
				var $this = $(this);
				$this._outerHeight( h );
				if( Nex.isIE ) {
					$('table',$this).each(function(){
						var $table = $(this);	
						var ph = $table.parent()._height();
						$table._outerHeight( ph );
					});
				}
			});		

		},
		onHeaderCreate : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			//headerTpl都不在建议使用了	
			if( !opt.headerTpl ) return -1;
			var fields = opt.columns;	
			var headerBody = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id);
			var _columns = [];
			var _thex = dataGrid.getToGridOptions();
			//jquery 1.4.4出现不能寻找tr下多级th td问题
			headerBody.find("td[field],th[field],td["+_thex.options_from+"],th["+_thex.options_from+"]").each(function(i){
				var field = $(this).attr("field");
				var _d = $(this).attr(_thex.options_from);
				if( _d ) {
					_d = eval("({"+_d+"})")	
				} else {
					_d = {};	
				}
				if(!field) {
					field = _d.field ?  _d.field : 'field_'+Nex.aid++;
				}
				
				var _d2 = {};
				_d2.title = $(this).html();
				if( _d2.title === '' ) {
					_d2 = {};	
				}
				
				var _d3 = {};
				var j = 0,
				len = fields.length;
				for(;j<len;j++) {
					if( fields[j]['field'] == field ) {
						_d3 = fields[j];
						break;
					}
				}
				if( $.isEmptyObject( _d3 ) ) {
					_d3.field = field;
				}
				
				var _d4 = $.extend(true,{},_d3,_d,_d2);
				
				_d4.align = _d4.align ? _d4.align : ($(this).attr("align") ? $(this).attr("align") : opt._columnMetaData.align);
				_d4.hcls = _d4.hcls ? _d4.hcls : opt._columnMetaData.hcls;
				_d4.title = _d4.title === '' ? _d4.field : _d4.title;
				_d4.width = _d4.width ? _d4.width : $(this)._width();

				var $this = this;
				
				if( $(this).is("th") ) {
					$this = $('<td field="'+_d4.field+'" align="'+_d4.align+'"></td>');
					$(this).replaceWith($this);
				} else {
					$(this).attr("field",_d4.field);
					$(this).attr("align",_d4.align);
				}
				
				$($this).html('<div class="datagrid-header-wrap" field="'+_d4.field+'"><div class="datagrid-cell datagrid-cell-'+_d4._colid+' datagrid-cell-header-'+_d4._colid+' '+_d4.hcls+'" ><span>'+_d4.title+'</span></div></div>');//style="width:'+parseFloat(_d4.width)+'px"
				
				_columns.push(_d4);
				
			});
			opt.columns = _columns;
			//添加系统必要的参数
			headerBody.find(">tr").addClass('datagrid-header-row');
			
			self.getColumns();
			//因为自定义header可能会不设置列信息，所以需要重新设置列宽，但是这个会给设置htpl的 带来每次刷新的问题,以下是解决判断
			/*
			opt._headerTpl = self._undef( opt._headerTpl,'' );
			if( opt._headerTpl != opt.headerTpl ) {
				self.onInitFieldWidth();
			}
			*/
			
			return headerBody.find(">tr");
		},
		/*
		* 同setColumnData,不同在于不会触发事件和刷新表格
		*/
		setColumnValue : function(field,key,value){
			var self = this,
				opt = this.configs;
			var fields = opt.columns;;//self.getColumns();
			var i = 0,
				len = fields.length;
			for(;i<len;i++) {
				if(fields[i]['field'] == field) {
					fields[i][key] = value;
					continue;
				}	
			}
		},
		cStop : function(cfg){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			
			var column = self.getColumnData(cfg.field);
			
			if( !column ) return;
			
			var w = column._fieldWidth + cfg.offsetX;
			
			var w = self.setFieldWidth( cfg.field,w );

			self.fireEvent("onAfterResize",[cfg.field,w,cfg]);
		},
		//当行的宽度改变时 group row的大小也要随之改变
		//setGroupRowSize : function(){},
		//changeExpandPos : function(){},
		//当行的宽度改变时expand row的大小也要随之改变
		//setExpandRowSize : function(){},
		//resetExpandRowHeight : function(rid){},
		isRowHidden : function(rowId) {
			var self = this,
				opt = self.configs,
				gid = opt.gid;
				if(rowId === undefined) return true;
				return ($("#"+opt.id+"-row-"+rowId).size() && !$("#"+opt.id+"-row-"+rowId).is(":hidden") ) ? false : true;
		},
		_selectDefRows : function(){
			var self = this,
				opt = self.configs;
			var rows = opt.selectRows;
			//因为开启lazyLoadRows时 默认被锁的行是在_selectDefRows调用后才生成，而当前事件绑定没有绑定最后执行事件的功能.
			//只能通过计时器来实现
			setTimeout(function(){
				for( var i=0;i<rows.length;i++ ) {
					self.selectRow(rows[i]);	
					if( opt.singleSelect ) break;
				}						
			},0);
		},
		//destroyExpandRow : function(rowId){},
		//updateExpandRow : function(rowId,html){},
		/*
		* 选择所有行
		*/
		selectAllRows : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			//var e = opt.events;	
			if(opt.singleSelect) return self; //singleSelect 模式下无效
			//var r = e.onSelectAll.call(self);
			var r = self.fireEvent('onSelectAll',[opt]);
			if(r === false) return self;
			if( opt.lazyLoadRow ) {
				self._clearSelectRows();
				var i = 0,
					len = opt.data.length;
				for(;i<len;i++) {
					opt._selectRows[i] = true;	
				}
			}
			$(">.datagrid-row",$("#view2-datagrid-header-outer-locktable-tbody-"+opt.id)).each(function(idx){
				self.selectRow($(this).attr("datagrid-rid"));									
			});
			$(">.datagrid-row",$("#view2-datagrid-body-btable-tbody-"+opt.id)).each(function(idx){
				self.selectRow($(this).attr("datagrid-rid"));									
			});

			return self;
		},
		/*
		* 取消选择所有行
		*/
		unselectAllRows : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var e = opt.events;	
			//var r = e.onUnSelectAll.call(self);
			var r = self.fireEvent('onUnselectAll',[opt]);
			if(r === false) return self;
			
			$(">.datagrid-row",$("#view2-datagrid-header-outer-locktable-tbody-"+opt.id)).each(function(idx){
				self.unselectRow($(this).attr("datagrid-rid"));									
			});
			$(">.datagrid-row",$("#view2-datagrid-body-btable-tbody-"+opt.id)).each(function(idx){
				self.unselectRow($(this).attr("datagrid-rid"));									
			});
			
			self._clearSelectRows();
			return self;
		},
		_clearSelectRows : function(){
			var self = this,
				opt = self.configs;
			opt._selectRows = {};
		},
		/*
		* 选择指定行
		*/
		selectRow : function(rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var e = opt.events;	
			var render = gid;
			var rowId = typeof rowId === 'undefined' ? false : rowId;
			if(rowId === false) return self;

			var rowData = self.getRowData(rowId);

			var obj1 = $("#"+opt.id+"-row-"+rowId);
			var obj2 = $("#"+opt.id+"-view1-row-"+rowId);
			var obj = $(obj1).add(obj2);

			if( !obj.size() ) {
				var r = self.fireEvent('onSelect',[obj,rowId,rowData,opt]);
				if(r === false) return r;	
			} else {
				if( obj1.hasClass(opt.clsSelectRow) ) {
					return self;	
				}	
				var r = self.fireEvent('onSelect',[obj,rowId,rowData,opt]);
				if(r === false) return r;
			}		

			opt._selectRows[rowId] = true;	
			
			if( obj.size() ) {
				obj1.addClass(opt.clsSelectRow);
				obj2.addClass(opt.clsSelectRow);
			}
			
			if( opt.checkBox && obj.size() ){
				var ck = obj.find("td[field='ck'] .datagrid-cell-check input:checkbox");

				if(ck.length)
					ck.get(0).checked = true;
			}
			
			if( opt.singleSelect) {
				//var selects = opt.selectRows;
				var selects = self.getSlectRows();
				var _dr = [];
				for(var si=0;si<selects.length;si++){
					if(selects[si] == rowId) continue;
					_dr.push( selects[si] );
				}
				for(var si=0;si<_dr.length;si++){
					self.unselectRow(_dr[si]);
				}	
				
				self._clearSelectRows();
				opt._selectRows[rowId] = true;	
			}
			return self;
		},
		/*
		* 取消选择指定行
		*/
		unselectRow : function(rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;

			var rowId = typeof rowId === 'undefined' ? false : rowId;
			if(rowId === false) return self;
			var rowData = self.getRowData(rowId);

			var obj1 = $("#"+opt.id+"-row-"+rowId);
			var obj2 = $("#"+opt.id+"-view1-row-"+rowId);
			var obj = $(obj1).add(obj2);
			
			if( !obj.size() ) {
				var r = self.fireEvent('onUnselect',[obj,rowId,rowData,opt]);
				if(r === false) return r;	
			} else {
				if( !obj1.hasClass(opt.clsSelectRow) ) {
					return self;	
				}	
				var r = self.fireEvent('onUnselect',[obj,rowId,rowData,opt]);
				if(r === false) return r;
			}		
			
			opt._selectRows[rowId] = false;
			
			if( obj.size() ) {
				obj1.removeClass(opt.clsSelectRow);
				obj2.removeClass(opt.clsSelectRow);
			}
			//obj.find("td[field='ck'] .datagrid-cell-check input:checkbox").get(0).checked = false;
			if( opt.checkBox && obj.size() ){
				var ck = obj.find("td[field='ck'] .datagrid-cell-check input:checkbox");

				if(ck.length)
					ck.get(0).checked = false;
			}
			return self;
		},
		//showGroup : function(groupId,type){},
		//hideGroup : function(groupId){},
		//addGroupRow : function(isFirst){},
		//setGroupEvent : function(){},
		//对数据按指定的grouplist字段分类，并重新设置configs的data数据，途中会修改configs的 groupBy  groupList
		//groupByField : function(field,data,groupList){},
		//searchData : function(text,field,async,data){},
		//_refresh true 则 清除查询结果并刷新表格; false 不刷新表格
		//clearSearch : function( _refresh ){},
		onOverRow : function(tr,rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;	
			if( opt.clsOverRow ) {
				$("#"+opt.id+"-view1-row-"+rowId).addClass(opt.clsOverRow);
				$(tr).addClass(opt.clsOverRow);
			}
		},
		onOutRow : function(tr,rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;	
			if( opt.clsOverRow ) {	
				$("#"+opt.id+"-view1-row-"+rowId).removeClass(opt.clsOverRow);
				$(tr).removeClass(opt.clsOverRow);
			}
		},
		setGridBodyTextLimit : function(field,data){},
		bindRowEvent : function( tr,ltr ){
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
				
			if( typeof tr === "undefined" ) {
				tr = false;	
			}
			if( typeof ltr === "undefined" ) {
				ltr = false;	
			}
			var fields = opt.columns;
			
			var tr_events = {
				'click' : function(ev){
					var rowId = $(this).attr("datagrid-rid");
					var rowData = self.getRowData(rowId);
					//自动显示当前行隐藏部分
					if( opt.autoScrollToRow ) {
						self.scrollToRow(rowId);	
					}
					//触发单元格事件
					var cr = self.cellEvents(rowId,ev);
					if(cr === false) return false;
					
					var r = self.fireEvent('onClickRow',[this,rowId,rowData,ev]);
					if(r === false) return false;
					//触发行 是否选择事件
					var isSelect = $(this).hasClass(opt.clsSelectRow);
					var selects = self.getSlectRows();
					if( isSelect ) {
						if(opt.singleSelect) {
							if(selects.length==1 && selects[0] != rowId) {
								self.unselectRow(rowId);	
							}
						} else {
							self.unselectRow(rowId);
						}
					} else {
						self.selectRow(rowId);
					}
					
				},
				'mouseenter' : function(e){
					var rowId = $(this).attr("datagrid-rid");	
					var rowData = self.getRowData(rowId);
					//触发单元格事件
					var cr = self.cellEvents(rowId,rowData,e);	
					if(cr === false) return false;
					
					self.fireEvent("onMouseEnter",[this,rowId,rowData,e]);	
				},
				'mouseover' : function(e){//mouseenter
					var rowId = $(this).attr("datagrid-rid");	
					var rowData = self.getRowData(rowId);
					//触发单元格事件
					var cr = self.cellEvents(rowId,rowData,e);	
					if(cr === false) return false;
					
					self.fireEvent("onOverRow",[this,rowId,rowData,e]);
				},
				'mouseleave' : function(e){
					var rowId = $(this).attr("datagrid-rid");	
					var rowData = self.getRowData(rowId);
					//触发单元格事件
					var cr = self.cellEvents(rowId,e);	
					if(cr === false) return false;
					
					self.fireEvent("onMouseLeave",[this,rowId,rowData,e]);	
				},
				'mouseout' : function(e){//mouseleave
					var rowId = $(this).attr("datagrid-rid");	
					var rowData = self.getRowData(rowId);
					//触发单元格事件
					var cr = self.cellEvents(rowId,e);	
					if(cr === false) return false;
					
					self.fireEvent("onOutRow",[this,rowId,rowData,e]);
				},
				'dblclick' : function(e){
					var rowId = $(this).attr("datagrid-rid");
					var rowData = self.getRowData(rowId);

					//触发单元格事件
					var cr = self.cellEvents(rowId,e);
					if(cr === false) return false;
					
					var r = self.fireEvent('onDblClickRow',[this,rowId,rowData,e]);
					if(r == false) return false;
				},
				'contextmenu' : function(e){
					var rowId = $(this).attr("datagrid-rid");
					var rowData = self.getRowData(rowId);
					
					//触发单元格事件
					var cr = self.cellEvents(rowId,e);
					if(cr === false) return false;
					
					var r = self.fireEvent('onRowContextMenu',[this,rowId,rowData,e]);
					if(r == false) return false;
				}
			};
			
			if(tr) {
				tr.bind(tr_events);
				tr.each(function(){
					var tr = $(this);
					var rowId = $(this).attr("datagrid-rid");
					var rowData = self._getRowData(rowId);//因为这个是一次性过程 必须使用引用的rowData
					//行回调
					if( $.isFunction(opt.rowCallBack) && opt.rowCallBack != $.noop ) {
						opt.rowCallBack.call(self,tr,rowId,rowData);
					}
					if( opt.rowStyler ) {
						if( $.isFunction(opt.rowStyler) ) {
							var rstyle = opt.rowStyler.call(self,tr,rowId,rowData);
							if( typeof rstyle == 'string' ) {
								tr.addClass(rstyle);	
							}
						} else if( typeof opt.rowStyler == 'string' ) {
							tr.addClass(opt.rowStyler);	
						}	
					}
					//单元格回调
					var field = [];
					var j = 0,
						len = fields.length;
					for(;j<len;j++) {
						field = fields[j];
						if( !$.isFunction(field['callBack']) || field['callBack'] == opt.noop ) {
							//是否有单元格回调
							continue;	
						}
						
						var t = $("#"+opt.id+'_'+field["_colid"]+'_row_'+rowId+'_cell',tr);//FIX BUG 需要添加tr做限制，否则会取到旧的td
						field['callBack'].call(self,t,rowId,field,rowData);
					}
					
					//检测文字是否超出
					self.setGridBodyTextLimit(tr,rowData);
					
				});
			}
			
			if( ltr ) {
				
					var ltr_events = {
					'click' : function(e){
						var rowId = $(this).attr("datagrid-rid");
						var rowData = self.getRowData(rowId);
						var rid = rowId;
						
						var target = e.srcElement ? e.srcElement : e.target;
						
						//触发单元格事件
						var cr = self.cellEvents(rowId,e);	
						if(cr === false) return false;	
						//var tr = $("#"+opt.id+"-row-"+rowId).get(0);
						self.fireEvent('onClickRowNumber',[this,rid,rowData,e]);
						if( opt.rowNumbers2Row !== false ) {
							//self.selectRow(rid);
							$("#"+opt.id+"-row-"+rid).trigger('click');
						}
					},
					'mouseover' : function(e){
						var rowId = $(this).attr("datagrid-rid");
						var rowData = self.getRowData(rowId);
						//触发单元格事件
						var cr = self.cellEvents(rowId,e);	
						if(cr === false) return false;	
						var tr = $("#"+opt.id+"-row-"+rowId).get(0);
						self.fireEvent("onOverRow",[tr,rowId,rowData,e])
						
					},
					'mouseout' : function(e){
						
						var rowId = $(this).attr("datagrid-rid");
						var rowData = self.getRowData(rowId);
						//触发单元格事件
						var cr = self.cellEvents(rowId,e);	
						if(cr === false) return false;	
						var tr = $("#"+opt.id+"-row-"+rowId).get(0);
						self.fireEvent("onOutRow",[tr,rowId,rowData,e]);
					},
					'dblclick' : function(e){
						var rowId = $(this).attr("datagrid-rid");
						var rid = rowId;
						//触发单元格事件
						var cr = self.cellEvents(rowId,e);	
						if(cr === false) return false;	
						if( opt.rowNumbers2Row !== false ) {
							$("#"+opt.id+"-row-"+rid).trigger('dblclick');
						}
						
					},
					'contextmenu' : function(ev){
					}
				};
				//view1 行事件绑定
				ltr.bind(ltr_events);
			}
			self.fireEvent("onSetRowEvent",[tr,ltr,opt]);
		},
		isCell : function(o){
			
			if( !$(o).length )
				return false;
			
			//检测是否rowNumber
			if( $(o).is('td') && $(o).hasClass('datagrid-td-rownumber') ) {
				return false;
			}	
			if( $(o).is('tr') && $(o).hasClass('datagrid-row') ) {
				return false;	
			}
			//检测是否有datagrid-cell
			if( !$(o).hasClass("datagrid-cell") ) {
				var cell = $(o).closest("tr.datagrid-row div.datagrid-cell");	
				if( !cell.length ) {
					return false;
				}
			}
			
			return true;
		},
		cellEvents : function(rowId,e) {
			var self = this,
				opt = self.configs;
			var target = e.srcElement ? e.srcElement : e.target;
			
			//检测当前是否对象是否单元格
			if( !self.isCell(target) ) {
				return true;	
			}
			
			var cell = $(target).closest('.datagrid-cell');
			
			var field = cell.parent("td").attr("field");

			var value = self.getFieldValue(rowId,field);
			
			var r = true;
			
			switch( e.type ) {
				case 'click' :
					//自动显示当前行隐藏部分
					if( opt.autoScrollToField ) {
						self.scrollToField(field);	
					}
				
					r = self.fireEvent('onClickCell',[cell.eq(0),rowId,field,value,e]);
					break;
				case 'dblclick' :
					r = self.fireEvent('onDblClickCell',[cell.eq(0),rowId,field,value,e]);
					break;
				case 'mouseenter' : //case 'mouseenter' : 
					r = self.fireEvent('onMouseEnterCell',[cell.eq(0),rowId,field,value,e]);
					break;
				case 'mouseover' : //case 'mouseenter' : 
					r = self.fireEvent('onOverCell',[cell.eq(0),rowId,field,value,e]);
					break;
				case 'mouseleave' :
					r = self.fireEvent('onMouseLeaveCell',[cell.eq(0),rowId,field,value,e]);
					break;
				case 'mouseout' :
					r = self.fireEvent('onOutCell',[cell.eq(0),rowId,field,value,e]);
					break;
				case 'contextmenu' :
					r = self.fireEvent('onCellContextMenu',[cell.eq(0),rowId,field,value,e]);
					break;
			}
			return r;
		},
		//checkToRow : function(rid){}, 
		/*
		* 动态添加一行数据
		*  @rid {int} 行id
		*  @d   {Object} 行数据(可选)
		*  @ai  {boolean} true:直接插入到最后 默认,false:会根据rid选择合适的位置插入(可选)
		*  @return {Object} 
		*/
		_insert : function(rid,d,ai){
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			var fields = opt.columns;
			
			var rid = self._undef(rid,0);
			//判断当前行是否已经存在
			var isExists = false;
			var _tr = $("#"+opt.id+"-row-"+rid);
			if( _tr.size() ){
				isExists = true;
			}

			var i = rid;
			
			var ai = self._undef(ai,true);
			var d = self._undef(d,{});
			
			var view1_row_tpl = self.getTpl("view1_row");
			var view2_row_tpl = opt.rowTpl ? opt.rowTpl : self.getTpl("view2_row");

			var view2_tbodyId = $("#view2-datagrid-body-btable-tbody-"+opt.id);
			var view1_tbodyId = $("#view1-datagrid-body-btable-tbody-"+opt.id);	
			
			var $theader2 = $("#view2-datagrid-body-btable-tbody-header-"+opt.id);
			var $theader1 = $("#view1-datagrid-body-btable-tbody-header-"+opt.id);
			var $tfooter2 = $("#view2-datagrid-body-btable-tbody-footer-"+opt.id);
			var $tfooter1 = $("#view1-datagrid-body-btable-tbody-footer-"+opt.id);
			
			if( !isExists ) {
				
				var _d = {
						i : i,
						id : opt.id,
						fields : fields	,
						rowNumbersExpand : opt.rowNumbersExpand,
						data : d,
						isCreate : opt.isCreate,
						//groupBy : opt.groupBy,
						rowNumbersWidth : opt.rowNumbersWidth,
						opt : opt
					};
				
				var tr = $(self.tpl(view2_row_tpl,_d));
				
				var ltr = false;

				ltr = $(self.tpl(view1_row_tpl,_d));
				
			} else {
				var tr = _tr;
				var ltr = false;
				ltr = $("#"+opt.id+"-view1-row-"+rid);
			}
			
			if( ai ) {
			
				$tfooter2.before( tr );
				if( ltr!==false ) {
					
					$tfooter1.before( ltr );
				}
			} else {
				
				var rows = $(">tr.datagrid-row","#view2-datagrid-body-btable-tbody-"+opt.id);
				var rids = [];
				rows.each(function(i,t){
					rids.push( Number($(t).attr("datagrid-rid")) );				   
				});
				rids.push(rid);
				rids.sort(function(a,b){
					return a>=b?1:-1; 
				});
				var index = self.inArray(rid,rids);
				if( !index ) {//第一行数据
					$theader2.after(tr);
					if( ltr!==false ) {
						$theader1.after(ltr);	
					}	
				} else {
					var prid = rids[index-1];
					$("#"+opt.id+"-row-"+prid).after(tr);
					if( ltr!==false ) {
						$("#"+opt.id+"-view1-row-"+prid).after(ltr);	
					}	
				}
				
			}
			
			if( opt.rowTpl ) {
				self.parseRowTpl(tr,rid,d);	
			}
			//绑定该行数据
			tr.data("rowData",d);
			
			self.fireEvent("onAfterAddRow",[rid,d,opt]);
			//self.resetViewSize();
			self.methodInvoke('resetViewSize');
			
			return {tr:tr,ltr:ltr,isNew:!isExists};
		},
		/*
		* 动态添加一行数据
		*  @d   {Object} 行数据(可选)
		*  @ai  {boolean} true:自动识别是否超过pageSize超过pageSize则不创建直接添加到数据集 默认,false:不识别pageSize,直接创建一行(可选)
		*  @return {int}  rid
		*/
		addRow : function(d,ai){
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			var fields = opt.columns;
			var rid = data.length;
			var i = rid;
			
			var ai = self._undef(ai,true);
			
			var d = self._undef(d,{});
			
			//本地
			if( self.getAsync() ) {
				data.push( d );
				var datas = self.getData();
				datas.push( d );
			} else {
				data.push( d );	
			}
			
			opt.total++;

			var pk = opt.pk;
			
			if( !d[pk] ) {
				d[pk] = self.unique();	
			}
			
			var r = self.fireEvent("onBeforeAddRow",[d,opt]);
			if( r === false ) {
				return false;	
			}
			
			self.fireEvent("onSuccessAddRow",[rid,d,opt]);
			
			if( ai && (rid >= opt.pageSize) ) {
				return true;	
			}

			var tr_row = self._insert(rid,d);
			if( tr_row.isNew ) {
				//行事件绑定
				if( opt.denyRowEvents === false ) {
					self.bindRowEvent(tr_row.tr,tr_row.ltr);
				} else if( $.isFunction(opt.denyRowEvents) ) {
					opt.denyRowEvents.call(self,tr_row.tr,tr_row.ltr);	
				}
			}
			
			return rid;
		},
		/*
		* 更新指定行和数据
		*  @rid   {int} 行id
		*  @d   {Object} 行数据(可选)
		*  @return {boolean}
		*/
		updateRow : function(rid,d){
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;	
				
			var d = self._undef(d,{});
			
			var r = self.fireEvent("onBeforeUpdateRow",[rid,d,opt]);
			if( r === false ) {
				return false;	
			}
			
			//var fieldList = self.getColumnList();
			
			var editList = [];
			
			for(var f in d) {
				//if( self.inArray(f,fieldList)!=-1 ) {
					var ed = self.setFieldValue(rid,f,d[f]);	
					if( ed !== false ) {
						editList.push(f);
					}
				//} else {
				//	self.setRowData( rid,f,d[f] )	
				//}	
			}
			//editList:修改过的单元格
			self.fireEvent("onAfterUpdateRow",[rid,d,editList,opt]);
			return true;
		},
		/*
		* 删除指定行和数据
		*  @rid   {int} 行id
		*  @m   {boolean} true:删除行和数据 默认,false:删除行不删除数据(可选)
		*  @return {boolean} 
		*/
		deleteRow : function(rid,m){
			
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			var m = self._undef(m,true);	
			var r = self.fireEvent("onBeforeDeleteRow",[rid,opt]);
			if( r === false ) {
				return false;	
			}
			
			var tr = $("#"+opt.id+"-row-"+rid);
			/*if( !tr.size() ) {
				return false;	
			}*/
			
			var ltr = $("#"+opt.id+"-view1-row-"+rid);
			
			var data = tr.size() ? tr.data('rowData') : opt.data[rid,opt];
			if( !data ) return false;
			if( !data[opt.pk] ) {
				return false;	
			}
			
			if( m ) {
				for( var i=0;i<opt.data.length;i++ ) {
					if( opt.data[i][opt.pk] == data[opt.pk] ) {
						opt.data.splice(i,1);//删除	
						break;
					}	
				}
				if( self.getAsync() ) {
					var datas = self.getData();
					for( var i=0;i<datas.length;i++ ) {
						if( datas[i][opt.pk] == data[opt.pk] ) {
							datas.splice(i,1);//删除
							break;
						}	
					}
				}
				opt.total--;
			}
			
			tr.remove();
			ltr.remove();
			//self.destroyExpandRow(rid);
			
			self.fireEvent("onAfterDeleteRow",[rid,opt]);
			self.methodInvoke('resetViewSize');
			
			return true;
			
		},
		//解析用户自定义行
		parseRowTpl : function(tr,rid,d){
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			var fields = opt.columns;
			
			var i = rid,
				rowId = rid;
			
			var d = self._undef(d,false);
			
			if( !d ) {
				d = data[i] ? data[i] : {};
			}
			
			tr.find(">td,>th").each(function(f){
				var _colid = self.getColumnData( fields[f]['field'],'_colid' );
				var tdId = opt.id+'_'+_colid+'_row_'+rowId+'_td';
				var cellId = opt.id+'_'+_colid+'_row_'+rowId+'_cell';
				var $this = this;
				if( $(this).is("th") ) {
					$this = $("<td id='"+tdId+"' field='"+fields[f]['field']+"' align='"+fields[f]['align']+"'><div  id='"+cellId+"'  class='datagrid-cell datagrid-cell-"+_colid+" ' >"+$(this).html()+"</div></td>");//style='width:"+fields[f]['width']+";'
					$(this).replaceWith( $this );
				} else {
					$(this).attr("field",fields[f]['field'])
						   .attr("align",fields[f]['align'])
						   .attr("id",tdId)
						   .html("<div  id='"+cellId+"' class='datagrid-cell datagrid-cell-"+_colid+" ' >"+$(this).html()+"</div>");//style='width:"+fields[f]['width']+";'
				}						 
			});
			var modelTr = opt.stripeRows ? ((rid+1)%2 ? opt.clsSingleRow : opt.clsDoubleRow) : '';
			tr.addClass("datagrid-row "+modelTr)
			  .attr("id",opt.id+"-row-"+i)
			  .attr("datagrid-rid",i);
			if( typeof d["_groupid_"] != 'undefined') {
				tr.attr("datagrid-group-id",d["_groupid_"]);
			}
		},
		//行 生成
		setRow : function(n,_func){
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			var fields = opt.columns;
			
			var view1_row_tpl = self.getTpl("view1_row");
			var view2_row_tpl = opt.rowTpl ? opt.rowTpl : self.getTpl("view2_row");
			var _d = {};
			var view2_tbodyId = $("#view2-datagrid-body-"+opt.id);
			var view1_tbodyId = $("#view1-datagrid-body-"+opt.id);
			var _func = self._undef(_func,$.noop);
			var n = self._undef(n,0);
			
			var j = opt._lSize;
			var pos = 1;
			var rows_view1 = ['<table class="datagrid-btable" id="view1-datagrid-body-btable-'+opt.id+'" cellspacing="0" cellpadding="0" border="0"><tbody id="view1-datagrid-body-btable-tbody-'+opt.id+'"><tr class="datagrid-row-header" id="view1-datagrid-body-btable-tbody-header-'+opt.id+'" style="height:0px;"></tr>'];
			var rows_view2 = ['<table class="datagrid-btable" id="view2-datagrid-body-btable-'+opt.id+'" cellspacing="0" cellpadding="0" border="0"><tbody id="view2-datagrid-body-btable-tbody-'+opt.id+'"><tr class="datagrid-row-header" id="view2-datagrid-body-btable-tbody-header-'+opt.id+'" style="height:0px;"></tr>'];
			
			var rowIds = [];
			
			if(  !$.isArray(data) ) {
				data = [];	
			}
			var len = data.length;
			for(var i=n;i<len;i++){
				//只显示某部分数据
				if(j>0) {
					if(pos>j) {
						break;
					}
					pos++;
					opt._lStart = pos;
				}
				
				rowIds.push(i);
				
				_d = {
					i : i,
					id : opt.id,
					fields : fields	,
					rowNumbersExpand : opt.rowNumbersExpand,
					data : data[i],
					isCreate : opt.isCreate,
					//groupBy : opt.groupBy,
					rowNumbersWidth : opt.rowNumbersWidth,
					opt : opt
				};
				
				var tr = self.tpl(view2_row_tpl,_d);
				
				rows_view2.push(tr);
				
				var ltr = false;
				
				ltr = self.tpl(view1_row_tpl,_d);
				rows_view1.push(ltr);
				
			}
			
			rows_view2.push('<tr class="datagrid-row-footer" id="view2-datagrid-body-btable-tbody-footer-'+opt.id+'" style="height:0px;"></tr></tbody></table>');
			rows_view1.push('<tr class="datagrid-row-footer" id="view1-datagrid-body-btable-tbody-footer-'+opt.id+'" style="height:0px;"></tr></tbody></table>');
			
			view2_tbodyId.html(rows_view2.join(""));
			view1_tbodyId.html( rows_view1.join("") );
			
			var tr = false;
			var ltr = false;
			//如果自定义opt.rowTpl 那么就添加系统必要的元素
			if( opt.rowTpl ) {
				tr = $(">tr:not(.datagrid-row-header,.datagrid-row-footer)","#view2-datagrid-body-btable-tbody-"+opt.id);
				tr.each(function(t){
					var tr = $(this);
					var rowId = rowIds[t];
					var i = rowId;
					
					self.parseRowTpl(tr,rowId);
									 
				});
			} else {
				tr = $(">tr.datagrid-row","#view2-datagrid-body-btable-tbody-"+opt.id);	
			}

			tr.each(function(i){//2000 140ms
				var rid = $(this).attr("datagrid-rid"); 
				$(this).data("rowData",data[rid]);
			});
			
			ltr = $(">tr.datagrid-row","#view1-datagrid-body-btable-tbody-"+opt.id);
			
			if( opt.denyRowEvents === false ) {
				self.bindRowEvent(tr,ltr);
			} else if( $.isFunction(opt.denyRowEvents) ) {
				opt.denyRowEvents.call(self,tr,ltr);	
			}
			
			_func();
			
			self.afterGridShow();
			
		},
		//单元格内容映射检测
		_cellReader : function(val,maps,data , rid , field){
			var self = this,
				opt = self.configs;	
			var val = self._undef(val,'');
			var maps = self._undef(maps,{});
			var data = self._undef(data,{});
			if( $.isFunction( maps ) ) {
				 return self.tpl( maps , val ,data, rid , field);	
			} else if( val in maps ) {
				return self.tpl(maps[val],data,val, rid , field);	
			} else if( opt.readerDef in maps  ) {
				return self.tpl(maps[opt.readerDef],data,val, rid , field);		
			}
			return val;
		},
		//模版函数
		view2_row : function(d){
			
			if( !d ) return "";
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			//var  group_id = ( typeof d.data["_groupid_"] != "undefined" )? "datagrid-group-id="+d.data["_groupid_"] : "";
			if( typeof d.data[opt.pk] == "undefined" ) {
				d.data[opt.pk] = self.unique();
			}
			
			var group_id = [];
			if( typeof d.data["_groupid_"] != "undefined" ) {
				group_id.push('datagrid-group-id=');
				group_id.push(d.data["_groupid_"]);
			}
			group_id = group_id.join("");
			//var modelTr = opt.stripeRows ? ((rid+1)%2 ? opt.clsSingleRow : opt.clsDoubleRow) : '';
			var modelTr = opt.stripeRows ? ((d.i+1)%2 ? opt.clsSingleRow : opt.clsDoubleRow) : '';
			//var tr = ['<tr id="'+d.id+'-row-'+d.i+'" '+group_id+' datagrid-rid="'+d.i+'" datagrid-row-select="0" class="datagrid-row '+modelTr+'">'];
			var tr = [];
			tr.push('<tr id="');
			tr.push(d.id);
			tr.push('-row-');
			tr.push(d.i);
			tr.push('" ');
			tr.push(group_id);
			tr.push(' datagrid-rid="');
			tr.push(d.i);
			tr.push('" class="datagrid-row ');
			tr.push(modelTr);
			tr.push('">');
			
			var j = 0,
				len = d.fields.length;
			for(;j<len;j++) {
				//var tdId = opt.id+'_'+d.fields[j]["field"]+'_row_'+d.i+'_td';
				var tdId = [];
				tdId.push(opt.id);
				tdId.push('_');
				tdId.push(d.fields[j]["_colid"]);
				tdId.push('_row_');
				tdId.push(d.i);
				tdId.push('_td');
				tdId = tdId.join("");
				
				//var cellId = opt.id+'_'+d.fields[j]["field"]+'_row_'+d.i+'_cell';
				var cellId = [];
				cellId.push(opt.id);
				cellId.push('_');
				cellId.push(d.fields[j]["_colid"]);
				cellId.push('_row_');
				cellId.push(d.i);
				cellId.push('_cell');
				cellId = cellId.join("");
				
				var _colid = d.fields[j]["_colid"];
				var field = d.fields[j]["field"];
				var index = d.fields[j]["index"];
				var _expand = d.fields[j]["_expand"] !== false ? opt.self.tpl(d.fields[j]["_expand"],d.data , d.i ,field) : self._cellReader(d.data[index],d.fields[j]["reader"],d.data, d.i ,field );//d.data[index]
				
				//tr.push('<td class="datagrid_'+_colid+'" field="'+field+'" id="'+tdId+'" align="'+d.fields[j]["align"]+'">');
				tr.push('<td class="datagrid_');
				tr.push(_colid)
				tr.push('" field="');
				tr.push(field);
				tr.push('" id="');
				tr.push(tdId);
				tr.push('" align="');
				tr.push(d.fields[j]["align"]);
				tr.push('" valign="');
				tr.push(d.fields[j]["valign"]);
				tr.push('">');
				
				//tr.push('<div id="'+cellId+'" class="datagrid-cell datagrid-cell-c1-'+field+' '+d.fields[j]["bcls"]+'" style="width:'+d.fields[j]["width"]+';" >'+_expand+'</div></td>');
				tr.push('<div id="');
				tr.push(cellId);
				tr.push('" class="datagrid-cell');
				if( opt.nowrap ) {
					tr.push(' datagrid-cell-nowrap ');	
				}
				tr.push(' datagrid-cell-');
				tr.push(_colid);
				//tr.push(' datagrid-cell-c1-');
				//tr.push(field);
				tr.push(' ');
				tr.push(d.fields[j]["bcls"]);
				tr.push('" >');
				//tr.push('" style="width:');
				//tr.push(d.fields[j]["width"]);
				//tr.push(';" >');
				tr.push(_expand);
				tr.push('</div></td>');
			}
			tr.push('</tr>');
			
			return tr.join("");
		},
		//模版函数
		view1_row : function(d){
			if( !d ) return "";
			var self = this,
				opt = self.configs,
				data = opt.data,
				gid = opt.gid;
			//var  group_id = ( typeof d.data["_groupid_"] != "undefined" )? "datagrid-group-id="+d.data["_groupid_"] : "";
			var group_id = [];
			if( typeof d.data["_groupid_"] != "undefined" ) {
				group_id.push('datagrid-group-id=');
				group_id.push(d.data["_groupid_"]);
			}
			group_id = group_id.join("");
			
			var modelTr = ((d.i+1)%2 ? "datagrid-row-single" : "datagrid-row-double");
			//var tdId = opt.id+'_row_'+d.i+'_td_rownumber';
			var tdId = [];
				tdId.push(opt.id);
				tdId.push('_row_');
				tdId.push(d.i);
				tdId.push('_td_rownumber');
				tdId = tdId.join("");
			
			//var cellId = opt.id+'_row_'+d.i+'_cell_rownumber';
			var cellId = [];
				cellId.push(opt.id);
				cellId.push('_row_');
				cellId.push(d.i);
				cellId.push('_cell_rownumber');
				cellId = cellId.join("");
			
			//var tr = ['<tr id="'+d.id+'-view1-row-'+d.i+'" '+group_id+' datagrid-rid="'+d.i+'" datagrid-row-select="0" class="datagrid-row datagrid-row-view1 '+modelTr+'">'];
			var tr = [];
			tr.push('<tr id="');
			tr.push(d.id);
			tr.push('-view1-row-');
			tr.push(d.i);
			tr.push('" ');
			tr.push(group_id);
			tr.push(' datagrid-rid="');
			tr.push(d.i);
			tr.push('" class="datagrid-row datagrid-row-view1 ');
			tr.push(modelTr);
			tr.push('">');
			if( opt.rowNumbersWidth!==false ) {
				//tr.push('<td id="'+tdId+'" align="center" class="datagrid-td-rownumber"><div id="'+cellId+'" class="datagrid-cell-rownumber" style="width:'+parseFloat(d.rowNumbersWidth)+'px;">'+(d.rowNumbersExpand === false ? ++d.i : opt.self.tpl(d.rowNumbersExpand,d.data))+'</div></td>');//--
				tr.push('<td id="');
				tr.push(tdId);
				tr.push('" align="center" class="datagrid-td-rownumber"><div id="');
				tr.push(cellId);
				tr.push('" class="datagrid-cell-rownumber" style="width:');
				tr.push(parseFloat(d.rowNumbersWidth));
				tr.push('px;">');
				var _expand_Num = "";
				if( d.rowNumbersExpand === false ) {
					_expand_Num = (opt.pageNumber-1)*opt.pageSize + ( ++d.i );
				} else if( d.rowNumbersExpand == 'auto' ) {
					_expand_Num = ++d.i;
				} else if( $.isFunction( d.rowNumbersExpand ) ) {
					_expand_Num	= d.rowNumbersExpand.call(self,d.data);
				} else {
					_expand_Num = opt.self.tpl(d.rowNumbersExpand,d.data);	
				}
				//var _expand_Num = d.rowNumbersExpand === false ? ++d.i : opt.self.tpl(d.rowNumbersExpand,d.data);
				tr.push( _expand_Num );
				tr.push('</div></td>');
			}
			
			tr.push('</tr>');

			return tr.join("");
		},
		//该函数 需要用到加载lockrow or lockcolumn才有效
		resetHeader : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			if( ('lockColumns' in opt) && opt.lockColumns.length) {
				var j = 0,
					len = opt.lockColumns.length;
				for(;j<len;j++) {
					if(opt.lockColumns[j] != null) {
						self.setGridHeader();
						return;
					}	
				}	
			}
			if( ('lockRows' in opt) && opt.lockRows.length) {
				var j = 0,
					len = opt.lockRows.length;
				for(;j<len;j++) {
					if(opt.lockRows[j] != null) {
						self.setGridHeader();
						return;
					}	
				}	
			}
		},
		_selectLazyRows : function(rid){
			var self = this,
				opt = self.configs;			
			if( opt.lazyLoadRow ) {
				var selectRows = self.getSlectRows();
				if( self.inArray( rid,selectRows ) != -1 ) {
					//self.denyEventInvoke('selectRow',[rid]);	
					self.selectRow(rid);
				}	
			}					
		},
		//已知bug:如果 加载一条虚拟行,即opt.data中不存在改条数据时,如果在大于第一页的情况下rowNumber实际会比rid 大 pageNumber*pageSize
		//可设置rowNumbersExpand = auto 来修正
		/*
		* 动态加载一行 类似_insert addRow
		*  @rid   {int} 行id
		*  @m   {boolean} 同_insert的@ai
		*  @return {boolean} 
		*/
		_loadRow : function( rid,m ){
			var self = this,
				opt = self.configs,
				data = opt.data;
			var len = opt.pageTotal || data.length;	
			//if( !len || !data[rid] ) return;
			if( !len ) return;
			
			var m = self._undef(m,true);
			var tr_row = self.denyEventInvoke('_insert',rid,data[rid],m);	

			if( tr_row.isNew ) {
				//行事件绑定
				if( opt.denyRowEvents === false ) {
					self.bindRowEvent(tr_row.tr,tr_row.ltr);
				} else if( $.isFunction(opt.denyRowEvents) ) {
					opt.denyRowEvents.call(self,tr_row.tr,tr_row.ltr);	
				}
				self.fireEvent("onLazyRowShow",[rid,tr_row,opt]);
			}
		},
		/*
		*刷新当前滚动条所在位置的行
		*/
		_loadRows : function(){
			
			var self = this,
				opt = self.configs,
				data = opt.data;
			var len = opt.pageTotal || data.length;
			
			if( !opt.lazyLoadRow || !len ) return;
			
			var vh = $("#view2-datagrid-body-"+opt.id)._height();
			//console.log(opt.sTop);
			opt.__vh = vh;
			
			var totalRow = (opt.lazyMaxRow ? opt.lazyMaxRow : Math.ceil(vh/opt._trHeight)) + opt.lazyTopRows + opt.lazyBottomRows;
			var start = Math.ceil(opt.sTop/opt._trHeight) - opt.lazyTopRows;
			start = start>0 ? start : 1;
			var end = totalRow + start;
			end = end<=len ? end : len;
			if( start >= len ) {
				end = len;	
				start = end - totalRow;
				start = start>0 ? start : 1;
			}
			
			var r = self.fireEvent("onBeforeLazyLoadRow",[start,end,totalRow,data,opt]);
			if( r === false ) return false;
			
			var vheader = (start-1)*opt._trHeight;
			var vfooter = (len-end)*opt._trHeight;
			
			$("#view2-datagrid-body-btable-tbody-header-"+opt.id).height(vheader);
			$("#view1-datagrid-body-btable-tbody-header-"+opt.id).height(vheader);
			
			$("#view2-datagrid-body-btable-tbody-footer-"+opt.id).height(vfooter);
			$("#view1-datagrid-body-btable-tbody-footer-"+opt.id).height(vfooter);
		
			self.lockMethod('resetViewSize');
			
			var _dr = [];
			
			//添加行时如果不把rid 加入lazyRows 则会出现新添加的行会删除不了问题
			$("#view2-datagrid-body-btable-tbody-"+opt.id).find(">tr.datagrid-row").each(function(i){
				var rid = $(this).attr("datagrid-rid");
				if( self.inArray( rid,opt.lazyRows ) == -1 ) {
					opt.lazyRows.push(rid);	
				}
			});
			
			for( var x=0;x<opt.lazyRows.length;x++ ) {
				
				if( opt.lazyRows[x]>=(start-1) && opt.lazyRows[x]<=(end-1) ) {
					continue;
				}
				var rid = opt.lazyRows[x];
				
				//if( self.inArray( rid,opt.lockRows )!=-1 ) continue;
				var lr = self.fireEvent("onBeforeLazyRowHide",[rid,opt]);
				if( lr === false ) {
					continue
				}
				
				self.denyEventInvoke('deleteRow',rid,false);
				
				self.fireEvent("onLazyRowHide",[rid,opt]);
				
				_dr.push(rid);
			}
			
			for( var _de=0;_de<_dr.length;_de++ ) {
				var drid = _dr[_de];
				var _ix = self.inArray( drid,opt.lazyRows );
				if( _ix != -1 ) {
					opt.lazyRows.splice(_ix,1);		
				}
			}

			var $lazyRows = opt.lazyRows;
			
			for(var i=start;i<=end;i++ ) {
				var rid = i-1;
				if( self.inArray( rid,$lazyRows ) != -1 ) {
					continue;	
				}
				//if( self.inArray( rid,opt.lockRows )!=-1 ) continue;
				var lr = self.fireEvent("onBeforeLazyRowShow",[rid,opt]);
				if( lr === false ) {
					continue
				}
				
				var tr_row = self.denyEventInvoke('_insert',rid,data[rid],false);	
				
				if( tr_row.isNew ) {
					//行事件绑定
					if( opt.denyRowEvents === false ) {
						self.bindRowEvent(tr_row.tr,tr_row.ltr);
					} else if( $.isFunction(opt.denyRowEvents) ) {
						opt.denyRowEvents.call(self,tr_row.tr,tr_row.ltr);	
					}
				}
				
				opt.lazyRows.push(rid);
						
				self.fireEvent("onLazyRowShow",[rid,tr_row,opt]);
				
			}
			
			opt.lazyRows.sort(function(a,b){
				return a>=b ? 1 : -1;						   
			});
			
			self.unLockMethod('resetViewSize');
			
		},
		/*
		* 刷新当前滚动条所在位置的行
		*  @m {boolean} true:强制刷新,false:不强制刷新 默认(可选)
		*/
		loadRows : function(m){
			var self = this,
				opt = self.configs;
			var len = opt.pageTotal || opt.data.length;

			if( !opt.lazyLoadRow ) return;
			
			var m = self._undef(m,false);
			
			var tq= opt._tq;
			if( tq ) {
				clearTimeout(tq);
			}

			var _func = function(){
				var initLazy = opt._initLazy;
				opt._initLazy = false;
				
				if( opt._trHeight<=0 ) {
					self.lockMethod('resetViewSize');
					self.denyEventInvoke('_insert',0,{},false);	
					opt._trHeight = $("#"+opt.id+"-row-0")._outerHeight();
					self.denyEventInvoke('deleteRow',0,false);
					self.unLockMethod('resetViewSize');
				}
				
				opt._hc = Math.min(opt.lazyBottomRows,opt.lazyTopRows) * opt._trHeight - opt._lazyEdge;
				
				var needLoad = false;
				if( !initLazy ) {
					if( Math.abs(opt.sTop-opt._csTop)<=opt._hc && !m  ) {
						return;	
					} else {
						//计算相差值 如果太多则显示loading
						opt.__vh = opt.__vh || $("#view2-datagrid-body-"+opt.id)._height();
						if( Math.abs(opt.sTop-opt._csTop)>= opt.__vh ) {
							needLoad = true;	
						}
						
						opt._csTop = opt.sTop;	
					}	
				} else {
					opt.lazyRows = [];
					opt._csTop = opt.sTop;
				}
				
				self.lockEvent('onScroll');
				if( (needLoad || initLazy) && opt.showLazyLoading ) {
					self.showLoading();	
				}
				setTimeout(function(){
									
					self._loadRows();
					
					if( (needLoad || initLazy) && opt.showLazyLoading ) {
						self.hideLoading();	
					}
					self.lockMethod('resetViewSize');
					self.fireEvent('onShowLazyRows',[opt.lazyRows,opt]);
					self.unLockMethod('resetViewSize');
					if( initLazy ) {
						//code
						self.afterGridShow(true);
					} else {
						self.onScroll(true);//必须	
					}
					self.unLockEvent('onScroll');
					
				},0);	
			};
			
			var t;
			t = setTimeout(function(){
				self.lockMethod('resetViewSize');
				self.fireEvent('onBeforeShowLazyRows',[opt]);
				self.unLockMethod('resetViewSize');
				_func();
			},50);
			opt._tq = t;
		},
		lazyLoadRow : function(){
			var self = this,
				opt = self.configs,
				data = opt.data;
			
			var len = opt.pageTotal || opt.data.length;
			
			var fields = opt.columns;
			
			var view2_tbodyId = $("#view2-datagrid-body-"+opt.id);
			var view1_tbodyId = $("#view1-datagrid-body-"+opt.id);
			
			var rows_view1 = ['<table class="datagrid-btable" id="view1-datagrid-body-btable-'+opt.id+'" cellspacing="0" cellpadding="0" border="0"><tbody id="view1-datagrid-body-btable-tbody-'+opt.id+'"><tr class="datagrid-row-header" id="view1-datagrid-body-btable-tbody-header-'+opt.id+'" style="height:0px;"></tr>'];
			var rows_view2 = ['<table class="datagrid-btable" id="view2-datagrid-body-btable-'+opt.id+'" cellspacing="0" cellpadding="0" border="0"><tbody id="view2-datagrid-body-btable-tbody-'+opt.id+'"><tr class="datagrid-row-header" id="view2-datagrid-body-btable-tbody-header-'+opt.id+'" style="height:0px;"></tr>'];
			
			if(  !$.isArray(data) ) {
				data = [];	
			}
			
			rows_view2.push('<tr class="datagrid-row-footer" id="view2-datagrid-body-btable-tbody-footer-'+opt.id+'" style="height:0px;"></tr></tbody></table>');
			rows_view1.push('<tr class="datagrid-row-footer" id="view1-datagrid-body-btable-tbody-footer-'+opt.id+'" style="height:0px;"></tr></tbody></table>');
			
			view2_tbodyId.html(rows_view2.join(""));
			view1_tbodyId.html( rows_view1.join("") );
			
			//取得行高
			if( opt._trHeight<=0 ) {
				self.lockMethod('resetViewSize');
				self.denyEventInvoke('_insert',0,{},false);	
				opt._trHeight = $("#"+opt.id+"-row-0")._outerHeight();
				self.denyEventInvoke('deleteRow',0,false);
				self.unLockMethod('resetViewSize');
			}
			var vh = opt._trHeight*len;
			
			$("#view2-datagrid-body-btable-tbody-header-"+opt.id).height( vh );
			$("#view1-datagrid-body-btable-tbody-header-"+opt.id).height( vh );
			
		},
		_clearBeforeShow : function(){
			var self = this,
				opt = self.configs;
			self.showLoading();	
			self._clearSelectRows();
		},
		setGridBody : function(render,func){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			//self.showLoading();	
			//刷新gridHeader 数据
			
			/*
			ajax 下 如果不设置columns则会出现列宽问题，解决方法:
			1.判断列是否手动设置
			2.如果没有则调用getColumns
			3.调用onInitFieldWidth
			已知BUG ,如果开启checkbox editcolumn 后，一定要手动设置columns
			*/
			var _sc = true;
			if( !opt.columns.length ) {
				_sc = false;
			}
			//console.log('^^3',opt.columns);
			self.getColumns();
			
			if( !_sc ) {
				self.setGridHeader();
				self.onInitFieldWidth();	
			}
			
			var func = func || $.noop;
			
			var br = self.fireEvent('onBeforeShowGrid',[opt]);
			if( br === false ) {
				return false;	
			}
			self._clearBeforeShow();
			
			if( opt.lazyLoadRow ) {
				opt._initLazy = true;
				
				var sLeft = opt.sLeft;
				var sTop = opt.sTop;
				//修正FF下 刷新grid 滚动条回到原点问题，修正chrome下水平滚动条回归原点
				self.one("onShowGrid.lazy",function(){
					opt.sLeft = sLeft;	
					opt.sTop = sTop;
				});

				self.lazyLoadRow();
				self._setViewSize();
				self.fireEvent('onScroll',[]);
		
				self.hideLoading();
				return true;
			}
				
			//修正IE 下刷新白屏问题
			setTimeout(function(){
				
				var data = opt.data;
				//记录当前滚动条位置
				//self.setRow(0,func);//grid 生成
				var sLeft = opt.sLeft;
				var sTop = opt.sTop;
				
				self._setViewSize();
				
				self.setRow(0,function(){
					func();	
					opt.sLeft = sLeft;
					opt.sTop = sTop;
				});
				
				self.hideLoading();
			},0);
			
			return true;
		},
		//setRow 结束后需要处理的问题
		afterGridShow : function(lazy){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			
			var lazy =  self._undef(lazy,false);	
			
			self.methodCall('setGridBody');
			
			self.lockMethod('resetViewSize');
			self.fireEvent('onShowGrid',[opt]);
			self.unLockMethod('resetViewSize');

			self.methodInvoke('resetViewSize',function(){
				//是否初始加载
				self.onFinishDone = self.onFinishDone || false;
				if(!self.onFinishDone) {
					self.onFinishDone = true;
					self.fireEvent('onFinish',[opt]);
				}										   
			});

		},
		removeEmptyDiv : function(){
			var self = this;
			self._clearEmptyMsg();
			return true;
		},
		_setEmptyMsg : function( msg ){
			var self = this,
				opt = self.configs,
				gid = opt.gid;		
				
			var w = $("#view2-datagrid-header-inner-htable-"+opt.id)._outerWidth();
			
			if( parseInt(w)<=0 ) {
				w = $("#view2-datagrid-header-"+opt.id)._outerWidth();	
			}
			
			var vbody = $("#view2-datagrid-body-"+opt.id)
			var h = vbody._height();
			if( w>vbody._width() ) {
				var sbar = self.getScrollbarSize();
				h -= sbar.width;
			}
			var obj = $("#"+opt.id+"_empty-grid-msg");

			if( obj.size() ) {
				obj.html( self.tpl( msg || opt.emptyGridMsg,opt ) );
				obj._outerWidth( w );
				obj._outerHeight( h );
				return obj;
			}
			//
			var dom = $('<div class="empty-grid-msg" id="'+opt.id+'_empty-grid-msg" style="height:100%;">'+self.tpl( msg || opt.emptyGridMsg,opt )+'</div>');
			$("#view2-datagrid-body-"+opt.id).append( dom );
			dom._outerWidth( w );
			dom._outerHeight( h );		
			return dom;
		},
		_clearEmptyMsg : function(){
			var self = this,
				opt = self.configs;
			
			$("#"+opt.id+"_empty-grid-msg").remove();	
			
			return true;		
		},
		/*自动判断当前grid是否没有数据 并显示提示信息*/
		isEmptyGrid : function(){
			var self = this,
				opt = self.configs;
			
			if( !opt.showEmptyGridMsg ) {
				return;	
			}

			if( opt.data.length>=1 ) {
				self._clearEmptyMsg();	
			} else {
				self._setEmptyMsg();	
			}
		},
		//footerCellEvents : function(rowId,e) {},
		//bindFooterRowEvent : function( tr,ltr ){},
		//解析用户自定义行
		//parseFooterTpl : function(tr,rid,d){},
		//模版函数
		//view2_footer_row : function(d){},
		//模版函数
		//view1_footer_row : function(d){},
		//showFooter : function(){},
		//hideFooter : function(){},
		//行 生成
		//setFooterRow : function(){},
		//updateFooterData : function( data ){},
		//updateFooterRow : function( data ){},
		//setGridFooter : function(){},
		addFooterItems : function(elem1,elem2){
			var self = this,
				opt = self.configs;
			var $footer2 = $("#view2-datagrid-footer-inner-"+opt.id);
			var $footer1 = $("#view1-datagrid-footer-inner-"+opt.id);
			$footer1.append(elem1);
			$footer2.append(elem2);
			self.methodInvoke('resetViewSize');
		},
		//未完成
		onScroll : function(auto){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var render = render || gid+" .datagrid-view2";
			var render1 = gid+" .datagrid-view1";
			auto = self._undef(auto,false);	
			if(auto) { // IE 下 300ms ++
				if( opt.sLeft>=0 )
					opt.gbody.scrollLeft(opt.sLeft);
				if( opt.sTop>=0 )
					opt.gbody.scrollTop(opt.sTop);
			}
			
			//if(!auto) {
				opt.sLeft = opt.gbody._scrollLeft();
				opt.sTop = opt.gbody._scrollTop();
			//}
			
			//$(render+" .datagrid-header .datagrid-header-inner .datagrid-header-inner-wraper")._scrollLeft( opt.sLeft );
			$("#datagrid-view2-header-inner-wraper-"+opt.id)._scrollLeft( opt.sLeft );
			//$(render+" .datagrid-header .datagrid-header-outer .datagrid-header-outer-wraper")._scrollLeft( opt.sLeft );
			$("#datagrid-view2-header-outer-wraper-"+opt.id)._scrollLeft( opt.sLeft );
			
			//footer
			$("#view2-datagrid-footer-inner-"+opt.id)._scrollLeft( opt.sLeft );
			
			//$(render1+" .datagrid-body")._scrollTop( opt.sTop );
			$("#view1-datagrid-body-"+opt.id)._scrollTop( opt.sTop );

		},
		onScrollBar : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			
			//计算是否滚动到底
			var tbody = $("#view2-datagrid-body-"+opt.id);
			
			var sw = 0;
			
			if( tbody[0].scrollWidth>tbody._width() ) {
				sw = self.getScrollbarSize().width;	
			}
			
			var scrollHeight = tbody[0].scrollHeight;
			
			if( (opt.sTop + tbody.innerHeight() - sw)>=scrollHeight ) {
				self.fireEvent('onScrollEnd');
			}
		},
		//统一使用该函数来实现表格展示
		showGrid : function(successBack,errorBack,async){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var render = render || gid+" .datagrid-view2";
			
			var successBack = successBack || $.noop;
			var errorBack = errorBack || $.noop;
			var async = self._undef(async,false);	

			
			self.getGridData(function(){
				self.fireEvent('onGetGridData',[opt.data,opt]);//onGetData 修改为onGetGridData
				successBack.apply(this,arguments);	
			},function(){
				errorBack.apply(this,arguments);
			},async);
		},
		/*
		* 刷新表格数据
		*/
		refreshData : function(){
			var e = this.configs.events;
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var render = render || gid+" .datagrid-view2";
			//e.onBeforeRefresh.call(self);	
			self.fireEvent('onBeforeRefresh',[opt]);
			self.showGrid(function(){
				self.setGridBody(render,function(){
					//e.onRefresh.call(self);	
					self.fireEvent('onRefresh',[opt]);
				});						  
			});
		},
		/*
		* 更新当前分页表格数据
		* @data {Array} 当前页数据集
		*/
		updateGrid : function(data){
			var self = this,
				opt = self.configs;
			self.setGridData(data,false,true);
		},
		/*
		* 更新grid表格数据
		* @data {Array} 数据集
		*/
		updateGridData : function(data){
			var self = this,
				opt = self.configs;
			self.setGridData(data,true,true);
		},
		/*
		* 刷新表格数据(无ajax刷新)
		*/
		refreshDataCache : function(){
			var self = this;
			self.setGridBody();
		},
		/*
		*设置行高
		*/
		setRowHeight : function(rid,height){
			var self = this,
				opt = self.configs;
			$("#"+opt.id+"-view1-row-"+rid)._outerHeight( height );	
			$("#"+opt.id+"-row-"+rid)._outerHeight( height );	
			var t = self._undef( opt.__srh,0 );
			if( t ) {
				clearTimeout(t);	
			}
			opt.__srh = setTimeout(function(){
				opt.__srh = 0;	
				self.lockEvent("onScroll");
				self.methodInvoke('resetViewSize');
				self.unLockEvent("onScroll");
			},t);
			return self;
		},
		clearCache : function(){
			var opt = this.configs;
			//缓存清除
			opt.views = [];//清空视图缓存
			opt.isCreate = false;//已经废弃
			this.onFinishDone = false;
			opt.isShow = false;
			opt.pki = 0;
		},
		clearDataCache : function(){
			var opt = this.configs;
			opt.cacheData = {};
			return this;
		},
		//重新生成grid 慎用 setAll是否重置所有数据 否则保留source columns
		reLoadGrid : function(cfg,setAll/*废弃*/){
			//var setAll = self._undef(setAll,false);
			this.clearCache();
			this.clearDataCache();
			var _d = [];
			if(cfg.data) {
				_d = cfg.data ;
				cfg.data = [];
			}
			var opt = $.extend(true,{},cfg);
			opt.data = _d;
			cfg.data = _d;
			dataGrid.call(this,opt);
		},
		width : function(width){
			var self = this;
			var opt = self.configs;
			self.resetGridSize(width,opt.height);
			return self;	
		},
		height : function(height){
			var self = this;
			var opt = self.configs;
			self.resetGridSize(opt.width,height);
			return self;		
		},
		initWH : function(w,h){
			var self = this,
				opt = self.C();
			opt.__width = w;
			opt.__height = h;
			self.setWH(w,h);
		},
		setWH : function(width,height){
			var self = this;
			self.resetGridSize(width,height);
			return self;
		},
		/*
		* @m      {boolean} true:强制更新,false:大小都没变化时不更新大小返回false 默认(可选)
		*/
		resize : function(m){
			var self = this;	
			var opt = self.configs;
			
			//var render = $(opt.renderTo);
			//var _body = $(document.body);
			//_body.addClass('nex-overflow-hidden');
			//render.addClass('nex-overflow-hidden');
			setTimeout(function(){
				self._setBodyOverflowHidden();		
				var size = self.getResizeWH();
				self.resetGridSize(size.width,size.height,m);		
				//_body.removeClass('nex-overflow-hidden');
				//render.removeClass('nex-overflow-hidden');
			},0);
			
		},
		createGrid : function(render){
			
			var self = this,
				opt = self.configs,
				gid = opt.gid;
				
			
			var render = render || gid+" .datagrid-view2";
			
			self.setGridHeader(render);
			
			self._setGridViewWH();
			
			//opt.gbody = self.setGridBody(render);//grid数据列表
			self.showGrid(function(){
				self.setGridBody(render);
			});

			self.methodCall('createGrid');
			return self;
		}, 
		//对数据进行排序,返回排序后的结果，不支持中文排序 可对没显示字段进行排序
		sortData : function(field,data,type) {},
		//数据管理 addData 添加表格数据 updateData更新表格数据 removeData删除表格数据
		//如果是opt.url 存在则发送数据到服务器
		//如果async = true的话 就所有操作都在本地进行
		//最好通过自己的函数向服务器添加数据然后调用refreshData 如果本地的话就无所谓
		onDataChange : function(data){
			var self = this,
				opt = self.configs;	
			self.refreshData();
		},
		addData : function(data){
			var self = this,
				opt = self.configs;
				
			var async = self.getAsync();
			
			var datas = self._undef( datas , [] );
			datas = $.isPlainObject(datas) ? [datas] : datas;
			
			var pk = opt.pk;
			//本地添加
			if( async ) {
				var _d = self.getData();
				var len = datas.length;
				for(var n=0;n<len;n++) {
					var data = datas[n];
					data[pk] = self._undef( data[pk] , self.unique() );
					_d.push(data);
				}
				self.fireEvent("onAdd",[datas,true]);
				self.fireEvent("onDataChange",self,[datas]);
			} else {
				//远程处理		
				self.fireEvent("onAjaxAdd",[datas,function(){self.onDataChange(datas);}]);
			}
		},
		updateData : function(datas){
			var self = this,
				opt = self.configs;
				
			var async = self.getAsync();
			
			var datas = self._undef( datas , [] );
			datas = $.isPlainObject(datas) ? [datas] : datas;
			var pk = opt.pk;
			var setPk = false;
			//本地更新
			if( async ) {
				var len = datas.length;
				for(var n=0;n<len;n++) {
					var data = datas[n];
					if( !$.isPlainObject(data)) continue;
					setPk = self._undef( data[pk] , false );
					if(setPk === false) {
						continue;
					}
					
					var _d = self.getData();
					var i = 0;
					var xdlen = _d.length;
					for(;i<xdlen;i++) {
						if(_d[i][pk] == data[pk]) {
							_d[i] = data;
							break;
						}	
					}
				}
				self.fireEvent("onUpdate",[datas,true]);
				self.fireEvent("onDataChange",[datas]);
			} else {
				//远程处理	
				self.fireEvent("onAjaxUpdate",[datas,function(){self.onDataChange(datas);}]);
			}
		},
		deleteData : function(datas){
			var self = this,
				opt = self.configs;
				
			var async = self.getAsync();
			
			var datas = self._undef( datas , [] );
			datas = $.isPlainObject(datas) ? [datas] : datas;
			var pk = opt.pk;
			var setPk = false;
			//本地删除
			if( async ) {
				var _d = self.getData();
				var len = datas.length;
				for(var n=0;n<len;n++) {
					var data = datas[n];
					if( !$.isPlainObject(data)) continue;
					setPk = self._undef( data[pk] , false );
					if(setPk === false) {
						continue;
					}
					var i = 0,
						len = _d.length;
					for(;i<len;i++) {
						if(_d[i][pk] == data[pk]) {
							break;
						}	
					}
					var j = 0;
					var __d = [];//删除后的新数据
					for(;j<len;j++) {
						if( i == j ) continue;
						__d.push(_d[j]);	
					}
					_d = __d;
				}
				//opt.cacheData['source'] = __d;
				
				self.fireEvent("onDelete",[datas,true]);
				self.fireEvent("onDataChange",[datas]);
			} else {
				//远程处理	
				self.fireEvent("onAjaxDelete",[datas,function(){self.onDataChange(datas);}]);
			}
		},
		//判断当前的操作是 服务器还是本地 true 表示本地操作
		getAsync : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;	
			return (opt.url == "" || opt.url===false)  ? true : false;
		},
		/*
		* 更新grid表格数据
		* @data  {Array} 数据集
		* @async {Boolean} 当前数据获取模式 true:本地,false:远程服务器(可选)
		* @s     {Boolean} true:刷新表格,false:不刷新表格 默认(可选)
		*/
		setGridData : function(data , async , s){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var data = self._undef(data,false);	
			if( !data ) return false;
			var async = self._undef(async,null);	
			var s = self._undef(s,false);	
			if(async == null) {
				async = self.getAsync();
			}
			
			if( async ) {
				opt.cacheData['source'] = data;
			} else {
				opt.data = data;	
			}
			//数据重置后 PK值也的重置
			if(opt.pk == '_pk') {
				self.fireEvent("onSetPk",[data]);
			}
			
			//数据源改变时调用
			if( s ) {
				if( async )
					self.showGrid(function(){
						self.setGridBody();							   
					},$.noop,true);	
				else 
					self.refreshDataCache();
			}
			return true;
		},
		page : function( i ){
			var self = this,
				opt = self.configs;
			var i = self._undef(i,1);	
			opt.pageNumber = parseInt( i ) <= 0 ? 1 :  parseInt( i );
			self.refreshData();
		},
		//获取每页数据
		getPageData : function(){
				
		},
		/*
		* ajax返回数据过滤函数,可通过参数或者已知函数声明eg : xmlFilter,htmlFilter
		*/
		jsonFilter : function(data){
			return data;	
		},
		/*
		* 设置ajax返回的数据
		* @json  {Array} 数据集
		* @s     {Boolean} true:刷新表格,false:不刷新表格 默认(可选)
		*/
		metaData : function( json,s ){
			var self = this,
				opt = self.configs;
			
			var data = json || {};
			var s = self._undef(s,false);	
			
			if( $.isArray(json) ) {
				data = {
					rows : data	
				};
			}
			
			//data.rows = data.rows || [];
			/*if( data.footer ) {
				opt.footerData = data.footer;
			}*/
			if( $.isArray(data.footer) ) {
				opt.footerData = data.footer;
			} else if( $.isPlainObject( data.footer ) ) {
				opt.footerData = [ data.footer ];
			} else {
				opt.footerData = [];	
			}
			
			if( $.isArray(data.rows) ) {
				opt.data = data.rows;
			} else if( $.isPlainObject( data.rows ) ) {
				opt.data = [ data.rows ];
			} else {
				opt.data = [];	
			}
			//opt.data = data.rows;
			opt.total = data.total || opt.data.length;
			opt.pageSize = self.isNumber( data.pageSize ) ? data.pageSize : opt.pageSize;
			opt.pageNumber = self.isNumber( data.pageNumber ) ? data.pageNumber : opt.pageNumber;
			
			//检查是否返回了column
			if(data.columns) {
				opt.columns = data.columns;
				self.setGridHeader();
			}
			
			for( var c in data ) {
				if( self.inArray( c,['footer','rows','total','pageSize','pageNumber','columns'] ) == -1 ) {
					opt[c] = data[c];
				}	
			}
			
			if( s )
				self.refreshDataCache();
		},
		_loadSuccess : function(data,successBack){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			
			var dataType = opt.dataType.toLowerCase();
			
			var filter = dataType+'Filter';
			
			var data = data;
			
			if( filter in opt ) {
				if( $.isFunction( opt[filter] ) ) {
					data = opt[filter].call(self,data);
				}
			} else if( filter in self ) {
				if( $.isFunction( self[filter] ) ) {
					data = self[filter].call(self,data);
				}	
			} else if( filter in window ) {
				if( $.isFunction( window[filter] ) ) {
					data = window[filter].call(window,data);
				}	
			}
						
			self.fireEvent('onLoadSuccess',[data,successBack,opt]);
			
			//json
			self.metaData(data);
		},
		_loadError : function(msg,errorBack,xmlHttp){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
				
			var emsg = '<div class="datagrid-error-msg" title="'+xmlHttp.status+':'+xmlHttp.statusText+'">'+opt.loadErrorMsg+'</div>';
			
			self.showLoading(emsg);
			
			self.fireEvent('onLoadError',[emsg,msg,errorBack,xmlHttp,opt]);
			
			setTimeout(function(){
				self.hideLoading();	
				self.refreshDataCache();
			},opt.showErrorTime);
		},
		//获取ajax返回的data数据
		getGridData : function(successBack,errorBack,async){
			var self = this,
				undef,
				opt = self.configs,
				gid = opt.gid;
			
			var successBack = successBack || $.noop;
			var errorBack = errorBack || $.noop;
			
			var render = gid+" .datagrid-view2";
			
			var async = self._undef(async,false);	
			if(async == false) {
				async = self.getAsync();
			}
			
			//ajax部分
			opt.queryParams.pageNumber = opt.pageNumber;
			opt.queryParams.pageSize = opt.pageSize;
			
			self.methodCall('getGridData');
			//onGetGridData
			var _xr = self.fireEvent('onBeforeGetGridData',[successBack,errorBack,async]);
			if( _xr === false ) return;
			
			if(async) {
				self.showLoading();	
				//本地数据都会存储到source 只有显示部分才会放到data里 远程数据就都放在data 不会存放到source
				opt.cacheData['source'] = opt.cacheData['source'] || opt.data;
				
				self.fireEvent('onSetPk', [opt.cacheData['source']]);
				
				/*if(opt.sortName != '') {
					opt.cacheData['source'] = self.sortData();		
				}*/
				
				opt.total = opt.cacheData['source'].length;
				
				var start = (opt.pageNumber-1) * opt.pageSize;
				var end = opt.pageSize * opt.pageNumber;
				end = end>opt.total ? opt.total : end;
				var data = [];
				for(var i = start;i<end;i++){
					if( opt.cacheData['source'][i] )
						data.push(opt.cacheData['source'][i]);
				}
				opt.data = data;
				
				self.hideLoading();
				
				successBack.call(self,render);
				
				return;	
			}
			
			//ajax部分
			//opt.queryParams.pageNumber = opt.pageNumber;
			//opt.queryParams.pageSize = opt.pageSize;
			/*if(opt.sortName != '') {
				//opt.queryParams.sortName = opt.sortName;
				opt.queryParams.sortName = self.getColumnData(opt.sortName,'index');
				opt.queryParams.sortOrder = opt.sortOrder;
			}*/
			//var e = self.configs.events;
			var beforeSend = function(){
						var r = self.fireEvent('onBeforeLoad',[opt.queryParams,opt]);
						if( r === false ) return false;
						self.showLoading();	
					};
			var success = function(data){
				
						self._loadSuccess(data,successBack);
						
						self.fireEvent('onSetPk', [opt.data]);
						
						self.hideLoading();
						
						successBack.call(self);
						
					};
			var error = function(xmlHttp){
						//e.onLoadError.call(self,xmlHttp.responseText);
						var xmlHttp = $.isPlainObject( xmlHttp ) ? xmlHttp : {responseText:xmlHttp};
						
						self._loadError(xmlHttp.responseText,errorBack,xmlHttp);
						
						errorBack.call(self,xmlHttp.responseText);
					};
			var complete = function(data){
						self.fireEvent('onLoadComplete',[data,opt]);
					};	
			var _r = beforeSend();
			if( _r === false ) return;
			
			if( $.isFunction( opt.url ) ) {
				
				/*var _r = beforeSend();
				if( _r === false ) return;*/
				
				var rdata = opt.url.call(self,opt.queryParams,success,error);
				if( rdata !== undef ) {
					success( rdata );	
					complete();
				}
				
			} else {
				var ajaxOptions = {
					url : opt.url,
					type : opt.method,
					cache : opt.cache,
					dataType : opt.dataType,
					data : opt.queryParams,
					//beforeSend : beforeSend,
					success : success,
					error : error,
					complete : complete
				};
				self.fireEvent('onBeforeCreateAjax',[ajaxOptions,opt]);
				self.ajaxSend(ajaxOptions);	
			}
			
		},
		ajaxSend : function(ajaxOptions){
			var self = this;
			var opt = self.configs;
			if( $.isFunction( opt.ajaxSend ) ) {
				opt.ajaxSend.call( self,ajaxOptions )	;
			} else {
				$.ajax(ajaxOptions);
			}
		},
		setPk : function(data) {//data 必须是数组 这里是引用
			var self = this;
			var opt = self.configs;
			if(opt.pk != '_pk') return;
			//opt.pki = 1;
			$.each(data,function(i,n){
				var aid = Nex.aid++;
				data[i][opt.pk] = aid;//opt.pki++;			 
			});
		},
		show : function (){
			var self = this;
			var opt = self.configs;
			var views = opt.views;
			var container = $("#"+opt.id);
			//防止重复调用
			if(opt.isShow) {
				return;	
			}
			opt.isShow = true;
			
			var r = self.fireEvent('onBeforeShowContainer',[views]);
			if( r === false ) return;
			
			for(var i in views) {
				container.append( views[i] );	
			}
			
			self._setGridWH();
			
			self.setView();// 显示grid的容器
			
			self.fireEvent("onViewCreate",[]);
			
			self.createGrid();//gird数据显示开始...
			
			self.methodCall('show');
			self.fireEvent('onShowContainer',[views]);
			
			self.fireEvent('onCreate',[opt]);
			
		}
	});
	
	$.fn._scrollLeft=function(_10){
		if(_10==undefined){
			return this.scrollLeft();
	
		}else{
			return this.each(function(){
				//$(this)._scrollLeft(_10);			  
				$(this).css("marginLeft",_10*-1);
			});
		}
	};
		
	$.fn._scrollTop=function(_10){
		if(_10==undefined){
			return this.scrollTop();
		}else{
			return this.each(function(){
				//$(this).scrollTop(_10);
				$(this).css("marginTop",_10*-1);
			});
		}
	};
	
	$.fn.grid = function(_opt){
		if(this.size()<=0){
			//alert('容器不正确');
			return false;
		}
		var list = [],_opt=_opt||{};
		var _d = [];
		if( _opt.data ) {
			_d = _opt.data;
			_opt.data = [];
		}
		
		this.each(function(i){
			var self = $(this);
			
			if( self.data('datagrid') ) {
				list.push(self.data('datagrid'));
				return; 	
			}
			
			var u = {};
			
			if( self.attr('data-options') ) {
				u = eval("({"+self.attr('data-options')+"})");	
			}
			
			var opt = $.extend(true,u,_opt);
			
			opt.selector = self.selector;
			opt.renderTo = self;
			
			
			//opt.width = dataGrid._undef(opt.width,self.width());
			//opt.height = dataGrid._undef(opt.height,self.height());
			
			if( _opt.data ) {
				opt.data = _d;
			}
			
			self.data('metaData',opt);	
			
			var grid = new dataGrid(opt);
			
			self.data('datagrid',grid);	
			
			list.push(grid);
		});
		
		if( this.size() == 1 ) {
			return this.data('datagrid');
		} else {
			return list	;
		}
	};
	$.fn.datagrid = $.fn.datagrid || $.fn.grid;
	$.fn.dataGrid = $.fn.dataGrid || $.fn.grid;
	$.fn.extGrid = $.fn.grid;
	$.fn.extgrid = $.fn.grid;
	$.fn.nexGrid = $.fn.grid;
	$.fn.nexgrid = $.fn.grid;
	//迁移到togrid.js
	$.fn.togrid = function(cfg,_cfg){};
	$.fn.toGrid = $.fn.togrid;
	//resizeable
	$.fn._resize = function(opt){
		var opt = opt || {};
		var opt = $.extend({},opt);
		
		var self = this;
		function start(e,opt) {
			
			dataGrid.__resizing = true;
			
			$(document.body).css("cursor", "col-resize");
			$(document.body).disableSelection();
			//$(document.body).css("-moz-user-select", "none");
			//$(document.body).attr("unselectable", "on");
			opt.gheader.find(".datagrid-header-inner").css("cursor", "col-resize");
			opt.gheader.find("div.datagrid-cell").css("cursor", "col-resize");
			
			var _f = opt.self.getColumnData(opt.field,'_colid');
			var rtd = $('#'+opt.id+'_cols_'+_f);
			
			var line = $("<div class='datagrid-resize'></div>");
			var line2 = $("<div class='datagrid-resize'></div>");
			var render = $("#view_"+opt.id);
			render.append(line);
			render.append(line2);
			var offset = $(this).offset();
			var left = offset.left - render.offset().left;
			var height = render.height();
			var width = $(this).width();
			left = parseFloat(left)+parseFloat(width);
			line2.css({
				position:'absolute',
				'top':0,
				'zIndex':9999,
				'height':parseFloat(height),
				'left':left - rtd.outerWidth()
			});
			line.css({
				position:'absolute',
				'top':0,
				'zIndex':9999,
				'height':parseFloat(height),
				'left':left
			});
			opt.line = line;
			opt.line2 = line2;
			opt.x = e.clientX;
			opt.left = left;
			
			opt.offsetX = 0;
			
			/*$(document.body).bind("selectstart._resize", function(e){
				return false;
			});*/
			
			$(document).bind("mousemove._resize", function(e){
				//var r = opt.events.onResizeColumn(e,opt);
				var r = opt.self.fireEvent('onResizeColumn',[opt,e]);
				if(r === false) return;
				resize(e,opt);
			});
			$(document).bind("mouseup._resize", function(e){
				setTimeout(function(){
					dataGrid.__resizing = false;						
				},0);
				if( opt.offsetX ) {
					var r = opt.stop(e,opt);
					//if(r === false) return;
				}
				stop(e,opt);
			});
		}
		function resize(e,opt){
			
			var x = e.clientX;
			var left = opt.left + (x - opt.x);
			opt.offsetX = (x - opt.x);
			opt.line.css({
				'left':left
			});
		}
		function stop(e,opt){
			//opt.self.resizing = false;
			var render = "#view_"+opt.id;
			$(document).unbind("mousemove._resize");
			$(document).unbind("mouseup._resize");
			
			//$(document.body).unbind("selectstart._resize");
			
			$(document.body).css("cursor",'default');
			//$(document.body).removeAttr("unselectable");
			$(document.body).enableSelection();
			
			opt.gheader.find(".datagrid-header-inner").css("cursor", "default");
			opt.gheader.find("div.datagrid-cell").css("cursor", "default");
			
			$(opt.line).remove();
			$(opt.line2).remove();
		}
		self.each(function(idx){
			var p = $(this).parent();
			$('.datagrid_resize',p).remove();
			var resize = $("<div class='datagrid_resize'></div>");
				resize.bind({
					"mousedown._gresize":function(e){
						//opt.self.resizing = true;
						opt.field = p.attr("field");
						//var r = opt.events.onResizeColumnStart.call(this,e,opt);
						var r = opt.self.fireEvent('onResizeColumnStart',[this,opt,e]);
						if(r === false) return;
						start.call(this,e,opt);
						e.preventDefault();
						e.stopPropagation();
					},
					"click._gresize" : function(e){
						e.preventDefault();
						e.stopPropagation();
					}
				});
				p.append(resize);
		});
	};
	$.fn.moveColumn = function(opt) {
		var columns = this;
		var moving = false;
		dataGrid.__moving = false;
		columns.bind("mousedown.move",function(e){
			var self = this;
			var _t = setTimeout(function(){
				start.call(self,e);
				$(document.body).unbind("mousemove.wt");
			},opt.moveColumnTm);
			$(document.body).bind("mouseup.wt",function(e){
				clearTimeout(_t);
				$(document.body).unbind("mouseup.wt");
				$(document.body).unbind("mousemove.wt");
				//$(document.body).unbind("selectstart.wt");
				$(document.body).enableSelection();
			});	
			$(this).one("mouseout.wt",function(e){
				  clearTimeout(_t);
			});		
			/*setTimeout(function(){
				$(document.body).bind("mousemove.wt",function(e){
					clearTimeout(_t);
					$(document.body).unbind("mousemove.wt");
				});		
			},0);*/
			$(document.body).disableSelection();
			//e.preventDefault();
			//e.stopPropagation();
		});
		columns.bind("mousemove.h",function(e){
			if(moving == false) return;
			var p = $("#"+opt.id).offset();
			var pt = p.top;
			var pl = p.left;
			
			var w = $(this).outerWidth();
			var h = $(this).height() - 2;
			
			var wt = $(this).offset().top - pt;
			var w1 = $(this).offset().left - pl - 2;
			
			var w2 = e.pageX;
			var w3 = w2 - $(this).offset().left;
			
			opt.moveToField = $(this).attr("field");

			
			if( w3<=w/2 ) {
				$("#"+opt.id+"_line").css({
					left : w1,
					top : wt,
					height : h
				});
			opt.moveToFieldPos = 1;
				//console.log("前面");
			} else {
				$("#"+opt.id+"_line").css({
					left : w1 + w,
					top : wt,
					height : h
				});
			opt.moveToFieldPos = 0;
				//console.log("后面");
			}
		});
		function start(e) {
			moving = true;
			dataGrid.__moving = true;
			opt.moveField = $(this).attr("field");
			
			var _r = opt.self.fireEvent("onBeforeColumnMove",[opt.moveField,opt]);
			if(_r === false) {
				return _r;	
			}
			
			var _target = $('<div class="column-move" id="'+opt.id+'_move" style="position:absolute;z-index:9999;">'+$(".datagrid-cell",this).html()+'</div>').appendTo("#"+opt.id);
			var line = $('<div class="column-move-line" id="'+opt.id+'_line" style="position:absolute;height:'+$(this).outerHeight()+'px;"></div>').appendTo("#"+opt.id);
			var pos = $("#"+opt.id).offset();
			_target.css({
				left : e.pageX - pos.left + 10,
				top : e.pageY- pos.top + 10
			 });
		
			$(document.body).bind("mousemove.move",function(e){
			 	 _target.css({
					left : e.pageX - pos.left + 10,
					top : e.pageY- pos.top + 10
				 });
				
				var r = opt.self.fireEvent("onColumnMoving",[_target,opt.moveField,opt.moveToField,opt]);
				if(r === false) {
					opt.moveToField = opt.moveField;
					return;	
				}
				
			});	
			$(document.body).bind("mouseup.move",function(e){
				moving = false;
				dataGrid.__moving = false;
				_target.remove();
				line.remove();
				$(document.body).unbind("mousemove.move mouseup.move");
				opt.self.moveColumn()
				//e.preventDefault();
				//e.stopPropagation();
			});
		}
	};
})(jQuery);
/*
jquery.extGrid.pagination.js
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
+----------------------------------------------------------------------------------------------------------------------------+
*/

;(function($){
	"use strict";
	//参数
	$.nexGrid.addExtConf({
						  pagination:false,
						  pagerToolBar:false,
						  pageList : [10,20,30,40,50],
						  pagerMsg:'当前显示 {start} 到 {end} 条，共 {total} 条'
						 });
	//事件
	$.nexGrid.addExtEvent({
						   onPagerCreate:$.noop,
						   onPageChange:$.noop,
						   onPageSizeChange:$.noop,
						   onPageItemSelect:$.noop
						 });
	//事件名映射
	$.nexGrid.addEventMaps({
						   onSelectPage:'onPageItemSelect',
						   onChangePageSize:'onPageSizeChange'
						 });
	//模板
	$.nexGrid._Tpl['pager'] = '<div class="datagrid-pager pagination" id="<%=id%>_pager">'
								+' <table cellspacing="0" cellpadding="0" border="0">'
									+'<tbody>'
										+'<tr>'
											+'<td><select class="pagination-page-list">'
											+'<% var s = ""; for(var i=0;i<pageList.length;i++) {%>'
												+'<% if(pageList[i] == pageSize) {%>'
												+'<% s="selected";%>'
												+'<% } else {s="";} %>'
											+'<option value="<%=pageList[i]%>" <%=s%> ><%=pageList[i]%></option>'
											+'<% } %>'
											+'</select></td><td><div class="pagination-btn-separator"></div></td>'
											+'<td><a href="javascript:void(0)" class="pagination-first-btn p-plain <%=(pageNumber <= 1 )?"p-btn-disabled":""%>"><span class="pagination-first  p-btn">&nbsp;</span></a></td>'
											+'<td><a href="javascript:void(0)" class="pagination-prev-btn p-plain <%=(pageNumber <= 1 )?"p-btn-disabled":""%>"><span class="pagination-prev  p-btn">&nbsp;</span></a></td>'
											+'<td><div class="pagination-btn-separator"></div></td>'
											+'<td><span style="padding-left:6px;" class="pager-text">第</span></td>'
											+'<td><input class="pagination-num" type="text" value="<%=pageNumber%>" size="2"></td>'
											+'<td><span style="padding-right:6px;"  class="pager-text">页 共 <%=pages%> 页</span></td>'
											+'<td><div class="pagination-btn-separator"></div></td>'
											+'<td><a href="javascript:void(0)" class="pagination-next-btn p-plain <%=(pageNumber >= pages)?"p-btn-disabled":""%>"><span class="pagination-next p-btn">&nbsp;</span></a></td>'
											+'<td><a href="javascript:void(0)" class="pagination-last-btn p-plain <%=(pageNumber >= pages)?"p-btn-disabled":""%>"><span class="pagination-last p-btn ">&nbsp;</span></a></td>'
											+'<td><div class="pagination-btn-separator"></div></td>'
											+'<td><a href="javascript:void(0)" class="pagination-load-btn p-plain"><span class="pagination-load p-btn">&nbsp;</span></a></td>'
											+'<td id="pagination-toolbar-<%=id%>"></td>'
										+'</tr>'
									+'</tbody>'
								+'</table>'
								+'<div class="pagination-info"><%=pagerMsg%></div>'
								+'<div style="clear:both;"></div>'
							+'</div>';
	$.nexGrid.puglins.push(function(){
		var self = this,
			opt = self.configs;
		//防止重复绑定	
		self.unbind("onBeforeShowContainer.pagination");
		self.unbind("onBeforeShowGrid.pagination");
		self.unbind("onSuccessAddRow.pagination");
		self.unbind("onAfterDeleteRow.pagination");
		
		//事件绑定
		self.bind("onBeforeShowContainer.pagination",function(){
			this.setPager(true);													  
		});
		self.bind("onBeforeShowGrid.pagination",self.setPager);
		self.bind("onSuccessAddRow.pagination",self.refreshPager);
		self.bind("onAfterDeleteRow.pagination",self.refreshPager);
	});
	$.nexGrid.fn.extend({
		refreshPager : function(){
			var self = this;
			var opt = self.configs;	
			self.setPager();
		},
		addPagerEvent : function(){
			var self = this;
			var opt = self.configs;
			var obj = opt.views['pager'];
			//var e = opt.events;
			obj.find("a.pagination-first-btn").click(function(){
				if($(this).hasClass("p-btn-disabled")) return;
				
				var r = self.fireEvent('onPageChange',[1,opt]);
				if(r === false) return false;
				
				opt.pageNumber = 1;
				
				self.refreshData();	
			});
			obj.find("a.pagination-prev-btn").click(function(){
				if($(this).hasClass("p-btn-disabled")) return;
				var pageNumber = opt.pageNumber - 1;
				pageNumber = pageNumber<=0 ? 1 : pageNumber;	
				
				var r = self.fireEvent('onPageChange',[pageNumber,opt]);
				if(r === false) return false;
				
				opt.pageNumber = pageNumber;
				
				self.refreshData();											 
			});
			obj.find("a.pagination-next-btn").click(function(){
				if($(this).hasClass("p-btn-disabled")) return;																				
				var total = opt.total || opt.data.length;
				var pages = Math.ceil( parseInt(total)/parseInt(opt.pageSize) );
				var pageNumber = opt.pageNumber + 1;
				pageNumber = pageNumber>pages ? pages : pageNumber;	
				
				var r = self.fireEvent('onPageChange',[pageNumber,opt]);
				if(r === false) return false;
				
				opt.pageNumber = pageNumber;
				
				self.refreshData();	
			});
			obj.find("a.pagination-last-btn").click(function(){
				if($(this).hasClass("p-btn-disabled")) return;
				var total = opt.total || opt.data.length;
				var pages = Math.ceil( parseInt(total)/parseInt(opt.pageSize) );
				
				var r = self.fireEvent('onPageChange',[pages,opt]);
				if(r === false) return false;
				
				opt.pageNumber = pages;
				
				self.refreshData();	
			});
			obj.find("a.pagination-load-btn").click(function(){
				if($(this).hasClass("p-btn-disabled")) return;
				self.refreshData();											 
			});
			obj.find(".pagination-page-list").change(function(){
				var total = opt.total || opt.data.length;
				var pageSize = $(this).val();
				var pages = Math.ceil( parseInt(total)/parseInt(pageSize) );
				var pageNumber = opt.pageNumber;
				
				if( opt.pageNumber>pages ) {
					pageNumber = pages;		
				}
				
				var r = self.fireEvent('onPageSizeChange',[pageSize]);
				if(r === false) return false;
				
				var r = self.fireEvent('onPageItemSelect',[pageSize]);
				if(r === false) return false;
				
				opt.pageSize = pageSize;
				
				var xr = self.fireEvent('onPageChange',[pageNumber,opt]);
				if(xr === false) return false;
		
				opt.pageNumber = pageNumber;		
		
				self.refreshData();	
			});
			obj.find(".pagination-num").keydown(function(e){
				if(e.keyCode === 13) {
					var pageNumber;
					pageNumber = parseInt( obj.find(".pagination-num").val() );	
					pageNumber = self.isNumber( pageNumber ) ? pageNumber : 1;
					
					pageNumber = pageNumber<=0 ? 1 : pageNumber;	
					
					var total = opt.total || opt.data.length;
					var pages = Math.ceil( parseInt(total)/parseInt(opt.pageSize) );
					pageNumber = pageNumber>pages ? pages : pageNumber;	
					
					var r = self.fireEvent('onPageChange',[pageNumber,opt]);
					if(r === false) return false;
					
					opt.pageNumber = pageNumber;
					
					self.refreshData();	
				}
			});
			return self;
		},
		setPager : function(init) {

			var self = this;
			var opt = self.configs;
			var init = self._undef(init,false);
			if( !opt.pagination ) return self;
			//计算分页
			var data = {};
			data.id = opt.id;
			data.total = opt.total || opt.data.length;
			data.pageSize = opt.pageSize;
			data.pageNumber = opt.pageNumber;
			data.pageList = opt.pageList;
			data.pages = Math.ceil( parseInt(data.total)/parseInt(data.pageSize) );
			//检查pageNumber的合法性
			opt.pageNumber = opt.pageNumber > data.pages ? data.pages : opt.pageNumber;
			opt.pageNumber = opt.pageNumber<=0 ? 1 : opt.pageNumber;
			data.pageNumber = opt.pageNumber;
			
			data.start = (data.pageNumber*data.pageSize - data.pageSize + 1)<0 ? 0 : (data.pageNumber*data.pageSize - data.pageSize + 1);
			data.end = data.pageNumber*data.pageSize;
			
			data.pagerMsg = opt.pagerMsg.replace("{start}",data.start).replace("{end}",data.end).replace("{total}",data.total);

			var _pager = $("#"+opt.id+"_pager");

			var tpl = self.tpl("pager",data);
			
			if(!_pager.size()) {
				opt.views['pager'] = $(tpl);
			} else {
				opt.views['pager'] = $(tpl);
				_pager.after( opt.views['pager'] );
				_pager.remove();
			}
			
			//是否初始化
			if(init === true) {
				return self;	
			}

			self.addPagerEvent();
			
			if( $.isArray( opt.pagerToolBar ) && opt.pagerToolBar.length ) {
				$("#pagination-toolbar-"+opt.id).append( self.getTools( opt.pagerToolBar ) );
			}

			self.fireEvent("onPagerCreate",[opt.views['pager']]);
	
			self.methodCall('setPager');
			
			return self;	
		}					 
	}); 
})(jQuery);
/*
jquery.extGrid.expandrow.js
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

+----------------------------------------------------------------------------------------------------------------------------+
*/

;(function($){
	"use strict";
	//参数
	$.nexGrid.addExtConf({
						  expandAble			: true,
						  ctrlKeyAble 			: false,
						  shiftKeyAle			: false,
						  autoExpand			: false
						 });
	//事件
	$.nexGrid.addExtEvent({
						    onExpandRow       : $.noop,
							onBeforeExpandRow : $.noop,
							onHideExpandRow   : $.noop
						 });
	$.nexGrid.puglins.push(function(){
		var self = this,
			opt = self.configs;
		//防止重复绑定	
		self.unbind("onShowGrid.expandrow");
		self.unbind("onClickRow.expandrow");
		self.unbind("onFieldWidthChange.expandrow");
		self.unbind("onForceFitColumn.expandrow");
		self.unbind("onShowColumn.expandrow");
		self.unbind("onHideColumn.expandrow");
		self.unbind("onAfterLockRow.expandrow");
		self.unbind("onAfterUnLockColumn.expandrow");
		self.unbind("onShowGroup.expandrow");
		self.unbind("onHideGroup.expandrow");
		self.unbind("onAfterDeleteRow.expandrow");
		self.unbind("onLazyRowHide.expandrow");
		
		//事件绑定
		self.bind("onShowGrid.expandrow",self.autoExpand);
		//单击展示_expand
		self.bind("onClickRow.expandrow",self.setExpandEvent);
		self.bind("onFieldWidthChange.expandrow",self.setExpandRowSize);
		self.bind("onForceFitColumn.expandrow",self.setExpandRowSize);
		self.bind("onShowColumn.expandrow",self.setExpandRowSize);
		self.bind("onHideColumn.expandrow",self.setExpandRowSize);
		
		self.bind("onAfterLockColumn.expandrow",self.setExpandRowSize);
		self.bind("onAfterUnLockColumn.expandrow",self.setExpandRowSize);
		
		self.bind("onAfterLockRow.expandrow",self.setExpandPos);
		self.bind("onAfterUnLockRow.expandrow",self.setExpandPos);
		
		self.bind("onAfterDeleteRow.expandrow",self.destroyExpandRow);
		self.bind("onLazyRowHide.expandrow",self.destroyExpandRow);
		
	});
	$.nexGrid.fn.extend({
		setExpandEvent : function(t,rowId,rowData,e){
			var self = this;
			var opt = self.configs;
			
			if( !$.isPlainObject(rowData) ) {
				return;	
			}
			if( !opt.ctrlKeyAble ) {
				if( e.ctrlKey ) {
					return;	
				}	
			}
			if( !opt.shiftKeyAble ) {
				if( e.shiftKey ) {
					return;	
				}	
			}
			
			if('_expand' in rowData) {
				if( !self.isExpandRowShow(rowId) )
					self.expandRow(rowId,rowData['_expand']);	
				else 
					self.hideExpandRow(rowId);	
			}
		},
		setExpandPos : function(rids,prid){//rid
			var self = this,
				opt = self.configs;	

			var _r = function(rid){
				var tr = $("#"+opt.id+"-row-"+rid);
				var ltr = $("#"+opt.id+"-view1-row-"+rid);
				if( tr.size() ) {
					var _tr = $("#"+opt.id+"-expand-row-"+rid);
					if( _tr.size() ) {
						tr.after( _tr );		
					}
				}
				if( ltr.size() ) {
					var _ltr = $("#"+opt.id+"-expand-view1-row-"+rid);
					if( _ltr.size() ) {
						ltr.after( _ltr );		
					}
				}
			}
			_r(rids);
			if( prid >= 0 ) {
				_r(prid);	
			}
		},
		//当行的宽度改变时expand row的大小也要随之改变
		setExpandRowSize : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var render = gid+" .datagrid-view2";
			//var scolspan = self.getColumnList().length - opt.lockColumns.length;
			var scolspan = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find('td[field]').size();
			var w = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find(".datagrid-header-row")._outerWidth();
			$(render).find(".datagrid-row-expand").each(function(i){
				var rowId = $(this).attr("datagrid-expand-row-index");
				$(this).find(">td:first").attr("colspan",scolspan)._outerWidth(w);
				self._addExpandView1Row(rowId);
				self.resetExpandRowHeight(rowId);
			});
		},
		resetExpandRowHeight : function(rid){
			var self = this,
				opt = self.configs;	
			var _expand_id = $("#"+opt.id+"-expand-row-"+rid);
			var _expand_view1_id = $("#"+opt.id+"-expand-view1-row-"+rid);
			if( _expand_view1_id.size() ) {
				_expand_view1_id._outerHeight( _expand_id._outerHeight() );	
			}
		},
		isExpandRowShow : function(rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var _expand_id = opt.id+"-expand-row-"+rowId;
			
			return ( $("#"+_expand_id).size() && !$("#"+_expand_id).is(":hidden") ) ? true : false;
		},
		_addExpandView1Row : function(rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var obj1 = $("#"+opt.id+"-view1-row-"+rowId);
				
			var _expand_view1_id = opt.id+"-expand-view1-row-"+rowId;
			
			var td1 = "";
			if( opt.rowNumbersWidth !== false ) {
				td1 = "<td class='datagrid-td-rownumber'><div class='datagrid-cell-view1-expand'></div></td>";
			}
			
			//var tds = opt.lockColumns.length;
			var tds = $("#view1-datagrid-header-inner-htable-tbody-"+opt.id).find('td[field]').size();
			var td2 = "";
			if(tds) {
				td2 = '<td id="'+_expand_view1_id+'_td1" colspan="'+tds+'" class="datagrid-cell-rownumber-expand"></td>';
			}
			
			
			var _tr1 = 	$("#"+_expand_view1_id);
			if( _tr1.size() ) {
				var _td2 = $("#"+_expand_view1_id+"_td1");
				if( _td2.size() ) {
					//_td2.attr("colspan",opt.lockColumns.length);
					_td2.attr("colspan",tds);
				} else {
					if( td2 != "" ) {
						_tr1.append($(td2));	
					}
				}
				return _tr1;
			}
			
			var _tr1 = $("<tr id='"+_expand_view1_id+"' style='overflow:hidden;'  class='datagrid-row datagrid-row-view1' datagrid-expand-row-index='"+rowId+"'>"+td1+td2+"</tr>");
			obj1.after(_tr1);
			
			var _expand_id = opt.id+"-expand-row-"+rowId;
			//IE 6 7下还是无效 
			var h = $("#"+_expand_id).height();
			$("#"+_expand_view1_id).height(h);
			//修正ie 6 7多出1px问题
			if(h != $("#"+_expand_view1_id).height()) {
				var h = $("#"+_expand_view1_id).height();
				$("#"+_expand_view1_id).height( h-1 );
			}
			return _tr1;
		},
		//判断当前expandRow是否已经存在 如果不存在则重新创建,如果存在则显示
		expandRow : function(rowId,html){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
		
			var e = opt.events;
			var rowId = self._undef(rowId,false);
			if(rowId === false) return self;
			if( !opt.expandAble )  return self;
			var html = self._undef(html,"");
			var data = self.getRowData(rowId);
			html = self.tpl(html,data);//可以是模版
			var obj = $("#"+opt.id+"-row-"+rowId);
			var obj1 = $("#"+opt.id+"-view1-row-"+rowId);
			
			if(obj.size()<=0) return self;
			
			var _ep = self.fireEvent('onBeforeExpandRow',[rowId]);
			if( _ep === false ) return _ep;
			
			//var scolspan = self.getColumnList().length - opt.lockColumns.length;
			var scolspan = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find('td[field]').size();
			
			var _expand_id = opt.id+"-expand-row-"+rowId;
			var _expand = $("#"+_expand_id);
			
			var w = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find("tr.datagrid-header-row")._outerWidth();
			
			if( _expand.size() ) {
				var $_expand_id = $("#"+_expand_id);
				obj.after( $_expand_id );
				$_expand_id.find(">td:first").attr("colspan",scolspan)._outerWidth(w);
			} else {
				var _expand = $("<tr id='"+_expand_id+"' class='datagrid-row-expand' datagrid-expand-row-index='"+rowId+"'><td id='"+_expand_id+"_td' colspan='"+scolspan+"'><div class='datagrid-cell-expand' id='"+_expand_id+"_cell' style='overflow:hidden;'></div></td></tr>");
				//判断html是否纯文字或者是选择器or标签
				try {
					if( typeof html == 'object' ) {
						_expand.find("div.datagrid-cell-expand").append( $(html) );
					} else {
						_expand.find("div.datagrid-cell-expand").html( html );
					}
				} catch(e) {
					_expand.find("div.datagrid-cell-expand").html( html );	
				}
				obj.after(_expand);	
				_expand.find(">td:first")._outerWidth(w);
			}
			
			
			var _expand_view1 = self._addExpandView1Row(rowId);
			
			if( self.isRowHidden(rowId) ) {
				_expand.hide();
				_expand_view1.hide();
			} else {
				_expand.show();
				_expand_view1.show();
			}
			//var h = _expand.height();
			//_expand_view1.css({ height:h });
			
			self.fireEvent('onExpandRow',[rowId]);
			
			//self.fireEvent('onViewSizeChange',[]);
			//self.resetViewSize();
			self.methodInvoke("resetViewSize");
		},
		_hideExpandRow : function(rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var rowId = typeof rowId === 'undefined' ? false : rowId;
			if(rowId === false) return self;
			
			var _expand_id = opt.id+"-expand-row-"+rowId;
			var _expand_view1_id = opt.id+"-expand-view1-row-"+rowId;
			
			//$("#"+_expand_id).remove();
			//$("#"+_expand_view1_id).remove();
			
			$("#"+_expand_id).hide();
			$("#"+_expand_view1_id).hide();
			
			self.fireEvent('onHideExpandRow',[rowId]);
		},
		hideExpandRow : function(rowId){
			var self = this;
			
			self._hideExpandRow(rowId);
			
			//self.fireEvent('onViewSizeChange',[]);
			self.resetViewSize();
		},
		destroyExpandRow : function(rowId){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var rowId = typeof rowId === 'undefined' ? false : rowId;
			if(rowId === false) return self;
			
			var _expand_id = opt.id+"-expand-row-"+rowId;
			var _expand_view1_id = opt.id+"-expand-view1-row-"+rowId;
			
			$("#"+_expand_id).remove();
			$("#"+_expand_view1_id).remove();
			
			//self.fireEvent('onViewSizeChange',[]);
			//self.resetViewSize();
			self.methodInvoke('resetViewSize');
		},
		updateExpandRow : function(rowId,html){
			var self = this;
			self.destroyExpandRow( rowId );
			self.expandRow( rowId,html );
		},
		changeExpandPos : function(){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			$("#view2-datagrid-body-btable-tbody-"+opt.id).find(".datagrid-row-expand").each(function(i){
				if( !$(this).is(":hidden") ) {
					var rowId = $(this).attr("datagrid-expand-row-index");
					self.expandRow(rowId,"");
				}
			});
		},
		//当数据中包含 _expand _openExpand=true的时候调用
		autoExpand : function(){
			var self = this;
			var opt = self.configs;
			
			if( !opt.autoExpand ) {
				return;	
			}
		
			var tr = $(">tr.datagrid-row","#view2-datagrid-body-btable-tbody-"+opt.id);	
			self.showLoading();
			setTimeout(function(){
				tr.each(function(){
					var data = $(this).data('rowData');	
					var rid = $(this).attr('datagrid-rid');	
					if( $.isPlainObject(data) && ('_expand' in data) && ('_openExpand' in data) && data['_openExpand'] ) {
						//self._denyEvent = true;
						self.lockMethod("resetViewSize")
						self.expandRow(rid,data['_expand']);
						self.unLockMethod("resetViewSize")
						//self._denyEvent = false;
						//self.denyEventInvoke("expandRow",[rid,html]);
	
					}
				});	
				self.hideLoading();
				if( tr.size() ) {
					self.methodInvoke("resetViewSize");
				}
			},0);
		}
	}); 
})(jQuery);
/*
jquery.extGrid.sort.js
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱
+----------------------------------------------------------------------------------------------------------------------------+
*/

;(function($){
	"use strict";
	//参数
	$.nexGrid.addExtConf({
							sortable : true,//全局开关
							pageSort : false,//只对当前页做排序
							sortName : '',
							sortOrder : 'asc'
						 });
	//事件
	$.nexGrid.addExtEvent({
						   onBeforeSortColumn:$.noop,
						   onSortData:$.noop,
						   onSortColumn:$.noop
						 });
	
	$.nexGrid.puglins.push(function(){
		var self = this,
			opt = self.configs;
		//防止重复绑定	
		self.unbind("onColumnClick.sort");
		self.unbind("onBeforeGetGridData.sort");
		self.unbind("onGetGridData.sort");
		self.unbind("onHeaderCreate.sort");
		
		//事件绑定
		self.bind("onColumnClick.sort",self._sortColumn);
		self.bind("onHeaderCreate.sort",self._setSortIcon);
		self.bind("onBeforeGetGridData.sort",self._sortData);
	});
	$.nexGrid.fn.extend({
		_sortColumn : function(field,td,e){
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var field = field || false;
			if(field == false) return;
			
			if( !opt.sortable ) {
				return;	
			}
			
			//设置列是否可排序
			var sortable = self.getColumnData(field,'sortable');
			if( !sortable ) {
				return;
			} else {
				var _s = $(".datagrid-sort-icon",td);
				if( !_s.size() ) {
					$(".datagrid-cell",td).append($('<span class="datagrid-sort-icon">&nbsp;</span>'));
				}
			}
			
			opt.sortName = field;
			
			var v2 = $('#view2-datagrid-header-inner-htable-tbody-'+opt.id).find("div.datagrid-cell");
			var v1 = $('#view1-datagrid-header-inner-htable-tbody-'+opt.id).find("div.datagrid-cell");
			var hcell = $("div.datagrid-cell",td);
			 if( hcell.hasClass('datagrid-sort-asc') ) {
				v2.removeClass('datagrid-sort-desc datagrid-sort-asc');
				v1.removeClass('datagrid-sort-desc datagrid-sort-asc');
				hcell.addClass('datagrid-sort-desc');
				opt.sortOrder = 'desc';
			 } else {
				v2.removeClass('datagrid-sort-desc datagrid-sort-asc');
				v1.removeClass('datagrid-sort-desc datagrid-sort-asc');
				hcell.addClass('datagrid-sort-asc');	 
				opt.sortOrder = 'asc';
			 };
			 
			 self.refreshData();
		},
		_sortData : function( successBack,errorBack,async ){
			var self = this,
				opt = self.configs;
			if( opt.sortName=='' ) {
				return;
			}
			var sortField = opt.sortName;
			var _c = self.getColumnData(sortField);
			if( _c === null ) {
				opt.sortName = '';
				return;
			}
			var sortable = _c['sortable'];
			if( !sortable ) return;
			var index = _c['index'];
			
			var data = self.getData();
			var r = self.fireEvent("onBeforeSortColumn",[sortField,data,opt.sortOrder,successBack,errorBack,async]);
			if( r === false ) return r;
			
			if(async) {
				opt.cacheData['source'] = self.sortData();		
			} else {
				opt.queryParams.sortName = index;
				opt.queryParams.sortOrder = opt.sortOrder;	
			}	
			self.fireEvent("onSortColumn",[sortField,data,opt.sortOrder]);
		},
		_setSortIcon : function(){
			var self = this,
				opt = self.configs;	
			if( opt.sortName=='' ) {
				return;
			}
			var sortField = opt.sortName;
			
			var _c = self.getColumnData(sortField);
			if( _c === null ) {
				opt.sortName = '';
				return;
			}
			
			var sortable = _c['sortable'];
			if( !sortable ) return;
			//设置默认排序列
			var hcell = $("#view2-datagrid-header-inner-htable-tbody-"+opt.id).find(">tr.datagrid-header-row td[field='"+sortField+"']")
																  			  .find("div.datagrid-cell");
				var _s = $(".datagrid-sort-icon",hcell);
				if( !_s.size() ) {
					hcell.append($('<span class="datagrid-sort-icon">&nbsp;</span>'));
				}
				hcell.addClass('datagrid-sort-'+opt.sortOrder.toLowerCase());
		},
		//清空排序缓存
		clearSort : function(){
			var self = this,
				opt = self.configs;		
			opt.sortName = '';
			delete opt.queryParams.sortName;
			delete opt.queryParams.sortOrder;
		},
		//对数据进行排序,返回排序后的结果，不支持中文排序 可对没显示字段进行排序
		sortData : function(field,data,type) {//对field列进行排序 type = asc type= desc
			var self = this,
				opt = self.configs,
				gid = opt.gid;
			var field = self._undef(field,opt.sortName);
			if( field == '' ) return self;
			
			var fields = opt.columns;
			var _field = false;
			var index = false;
			
			for(var i=0;i<fields.length;i++) {
				if( fields[i]['field'] == field ) {
					_field = field;
					index = fields[i]['index'];
					break;	
				}
			}
			if( _field === false ) return self;
			//排序处理
			opt.cacheData['source'] = opt.cacheData['source'] || opt.data;
			var data = self._undef(data,opt.cacheData['source']);
			var type = self._undef(type,opt.sortOrder);
			var isAsc = type == "asc" ? true : false;
			
			data.sort(function(a,b){
				a[index] = self._undef(a[index],"");
				b[index] = self._undef(b[index],"");
				if( a[index] >  b[index] ) {
					return isAsc ? 1 : -1;
				} if( a[index] === b[index] ){
					return 0;
				} else {
					return isAsc ? -1 : 1;
				}
				/*if( a[index] >=  b[index]) return isAsc ? 1 : -1;
				return isAsc ? -1 : 1;*/
			});
			
			self.fireEvent("onSortData",[index,data,type]);
			
			return data;
		}				 
	}); 
})(jQuery);
/*
jquery.extGrid.edit.js
http://www.extgrid.com
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

新增 limitWidth属性
type 支持函数 注意应该返回editorProvider 而且需要定义val,checkVal,_destroy方法

所有编辑扩展事件：
	onBeforeCreateEditor 创建编辑单元格之前
	onCreateEditor  创建编辑单元格后
	onInsertEditorWrap 创建编辑单元格容器后
	onBeforeRemoveEditCell 在移除编辑单元格之前
	onRemoveEditCell	在移除编辑单元格后
	onBeforeEditRow	触发行编辑时
	onEditRow	触发行编辑后
	onBeforeSaveEditRow	在保存编辑状态行之前
	onRowEdit,onSaveEditRow 在保存编辑状态行之后
	onBeforeUnEditRow	在取消编辑之前
	onBeforeSaveEditCell 保存单元格之前
	onSaveEditCell 保存单元格后触发 该事件和onCellEdit基本一样只是少一个rowData参数,onCellEdit属於grid,onSaveEditCell只属於可编辑扩展事件
	onBeforeCheckEditCell 
	
修正 行锁列锁时出现的位置错乱问题	
*/

;(function($){
	"use strict";
	//参数
	$.nexGrid.addExtConf({
						  //...
						 });
	//事件
	$.nexGrid.addExtEvent({
						    onBeforeCreateEditor	: $.noop,
							onCreateEditor			: $.noop,
							onInsertEditorWrap		: $.noop,
							onResizeEditor			: $.noop,
							onBeforeRemoveEditCell	: $.noop,
							onRemoveEditCell		: $.noop,
							onShowEditCell			: $.noop,
							onHideEditCell			: $.noop,
							onBeforeCheckEditCell	: $.noop,
							onBeforeSaveEditCell	: $.noop,
							onSaveEditCell			: $.noop,
							onBeforeEditRow			: $.noop,
							onEditRow				: $.noop,
							onBeforeSaveEditRow		: $.noop,
							onSaveEditRow			: $.noop,
							onBeforeUnEditRow		: $.noop,
							onUnEditRow				: $.noop
						 });
	//事件名映射
	$.nexGrid.addEventMaps({
						   onCheckEditCell : 'onBeforeCheckEditCell',
						   onRowEdit       : 'onSaveEditRow'
						 });
	$.nexGrid.puglins.push(function(){
		var self = this;
		//刷新grid时,取消当前所有的编辑状态
		self.bind("onBeforeShowGrid",function(){
			self.unEditCell();									  
		});
		//列大小改变时，更新编辑列的大小
		self.bind("onViewSizeChange",function(){
			setTimeout(function(){
				self.resizeEditor();								
			},0);				  
		});
		
		self.bind("onResizeEditor",function(rid,field,editor,edit){
			if( edit.type == 'select' ) {
				//editor.editorProvider.hideSelect();
			}			  
		});
		
		self.bind("onColumnMove",function(){
			setTimeout(function(){
				self.resizeEditor();								
			},0);					  
		});
		
		self.bind("onShowColumn",function(field){
			setTimeout(function(){
				self.showEditField(field);		
				//self.resizeEditor();								
			},0);					  
		});
		self.bind("onHideColumn",function(field){
			setTimeout(function(){
				self.hideEditField(field);	
				//self.resizeEditor();								
			},0);					  
		});
		self.bind("onLazyRowHide",function(rid){
			//注意 此时 当前行 已经移除							   
			setTimeout(function(){
				self.hideEditRow(rid);							
			},0);					  
		});
		self.bind("onLazyRowShow",function(rid){
			setTimeout(function(){
				self.showEditRow(rid);	
				//self.resizeEditor();	//性能开销
			},0);					  
		});
	});
	var edits = {
		text : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	 
			return e;
		},
		textarea : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	 
			return e;
		},
		date : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	 
			return e;
		},
		//on off
		checkbox : function(editor,value){
			editor.on = editor.on === undefined ? '' : editor.on;
			editor.off = editor.off === undefined ? '' : editor.off;
			editor.items = [ {"value":editor.on} ];
			editor.xtype = 'form';		
			//editor.type = 'text';		  
			var e = Nex.Create(editor);
			var _val = e.val;
			e.val = function(){
				var self = e;
				var value = _val.apply(self,arguments);
				if( !arguments.length ) {
					if( value == '' ) {
						return 	editor.off;
					} else {
						return 	editor.on;	
					}
				} else {
					return value;	
				}
			}
			e.val( value );
			return e;
		},
		radio : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	 
			return e;
		},
		spinner : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	 
			return e;
		},
		number : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	 
			return e;
		},
		select : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	
			return e;
		},
		search : function(editor,value){
			editor.xtype = 'form';		
			//editor.type = 'text';			  
			var e = Nex.Create(editor);
			e.val(value);	
			return e;
		},
		"default" : function(editor,value){
			editor.xtype = editor.xtype || 'form';
			console.log( editor );			  
			var e = Nex.Create(editor);
			e.val(value);	
			return e;	
		}
	};
	$.nexGrid.fn.extend({
		editors : [],
		//基于insertEditor扩展
		createEditor : function(rid,field){
			var self = this,
				opt = self.configs;
			
			var column = self.getColumnData(field);
			
			var edit = column.editor;
			
			var rs = self.fireEvent('onBeforeCreateEditor',[rid,field,edit]);
			if( rs === false ) return false;
			
			if( !edit || $.isEmptyObject( edit ) ) {
				return false;	
			}
			
			var type = edit.type || 'default';
			
			if( !$.isFunction(type) ) {
				var undef = type in edits ? false : true;
				if( undef ) {
					return false;	
				}
			}
			
			var editable = self.insertEditor( rid,field );
			
			if( !editable ) {
				return false;	
			}
			
			var value = self.getFieldValue(rid,field);
			
			var _colid = column._colid;
			
			var edit_cell = opt.id + "_"+rid+"_"+_colid+"_edit";
			var edit_cell_id = edit_cell+"_cell";

			var cellId = opt.id+"_"+_colid+"_row_"+rid+"_cell";
			var width = edit.limitWidth ? edit.limitWidth : $("#"+cellId).width();

			edit.name = opt.id+"_"+_colid+"_"+rid;
			//edit.width = Math.floor( Math.max( parseFloat(width),parseFloat(w) ) );
			edit.width = width;
			edit.renderTo = "#"+edit_cell_id;
			edit.group = opt.id;
			if( !$.isFunction(type) ) {
				var editorProvider = edits[type].call(self,$.extend({},edit),value);	
			} else {
				var editorProvider = type.call(self,edit,value);
				editorProvider = $.isPlainObject(editorProvider) ? editorProvider : {};
				editorProvider['val'] = !!editorProvider['val'] ? editorProvider['val'] : $.noop;
				editorProvider['checkVal'] = !!editorProvider['checkVal'] ? editorProvider['checkVal'] : $.noop;
				editorProvider['_destroy'] = !!editorProvider['_destroy'] ? editorProvider['_destroy'] : $.noop;
				editorProvider['fireEvent'] = !!editorProvider['fireEvent'] ? editorProvider['fireEvent'] : $.noop;
				editorProvider['C'] = !!editorProvider['C'] ? editorProvider['C'] : $.noop;
			}
			//修改对列
			var list = self.editors;
			for(var x=0;x<list.length;x++) {
				if( list[x].id == edit_cell ) {
					list[x].editorProvider = editorProvider;
					break;
				}
			}
			
			self.fireEvent('onCreateEditor',[rid,field,editorProvider,edit]);
			
			return list[x];
		},
		_getEditorCellPos : function(rid,field){
			var self = this,
				opt = self.configs;
			var isLockRow,isLockColumn,isHidden,render;
			isLockRow = self.inArray(rid,opt.lockRows) == -1 ? false : true;
			isLockColumn = self.inArray(field,opt.lockColumns) == -1 ? false : true;
			isHidden = self.inArray(field,opt.hideColumns) == -1 ? false : true;
			if( isHidden ) {
				return false;	
			}
			
			var _top = 0;
			var _left = 0;
			
			if( isLockRow && isLockColumn ) {
				render = "datagrid-view1-header-outer-wraper-"+opt.id;
			} else if( isLockRow ) {
				render = "datagrid-view2-header-outer-wraper-"+opt.id;
			} else if( isLockColumn ) {
				render = "view1-datagrid-body-"+opt.id;	
			} else {
				render = "view2-datagrid-body-"+opt.id;	
				_left = opt.sLeft;
				_top = opt.sTop;
			}
			var _colid = self.getColumnData(field,'_colid');
			render = $("#"+render);
			var tid = opt.id+"_"+_colid+"_row_"+rid+"_td";
			var tdOffset,bodyOffset,pos;
			var _tid = $("#"+tid);
			if( !_tid.size() ) return false;
			tdOffset = _tid.offset(); 
			bodyOffset = render.offset();
			pos = {
				render : render,
				left : 	tdOffset.left - bodyOffset.left + _left,
				top : tdOffset.top - bodyOffset.top + _top
			};
			return pos;
		},
		insertEditor : function(rid,field){//创建一个容器定位到指定单元格处
			var self = this,
				opt = self.configs;
			var column = self.getColumnData(field);
			if( column == null ) return false;
			if( column.disabled ) {
				return false;	
			}
			
			var pos = self._getEditorCellPos(rid,field);
			if( !pos ) return false;
			
			var render = pos.render;
			var _colid = column._colid;//self.getColumnData(field,'_colid');
			
			var tid = opt.id+"_"+_colid+"_row_"+rid+"_td";
			var td = $("#"+tid);
			var cellId = opt.id+"_"+_colid+"_row_"+rid+"_cell";
			var cell = $("#"+cellId);
			
			
			var edit_cell = opt.id + "_"+rid+"_"+_colid+"_edit";
			
			if( $("#"+edit_cell).length ) {
				return	$("#"+edit_cell);
			}
			
			var edit_cell_id = edit_cell+"_cell";
			var editor = $("<table cellpadding=0 cellspacing=0 id='"+edit_cell+"'><tr><td id='"+edit_cell_id+"' valign=\"middle\" align=\"center\" ></td></tr></table>");
			editor.click(function(e){
				//e.preventDefault();
				e.stopPropagation();
			});
			
			var edit = column.editor;
			var tw = edit.width ? parseFloat(edit.width) : 0;
			var th = edit.height ? parseFloat(edit.height) : 0;
			
			editor.addClass('edit-cell edit-cell-'+_colid);
			editor.css({
				//width : Math.max(tw,td.outerWidth()),
				width : td.outerWidth(),
				height : Math.max(th,td.outerHeight()),
				left : pos.left,
				position : 'absolute',
				top : pos.top
			});
			
			editor.appendTo(render);//显示editor
			//加入eidtor队列
			var q = {
				id : edit_cell,
				rid : rid,
				field : field,
				_colid : _colid,
				column : column,
				isShow : true,
				viewValue : cell.html(),//当前grid显示内容,不是实际的内容
				editor : editor
			}
			self.editors.push(q);
			self.fireEvent('onInsertEditorWrap',[rid,field,editor,edit_cell,edit_cell_id]);
			return editor;
		},
		/*
		*重新设置编辑单元格大小和位置
		*/
		resizeEditor : function(rid,field){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			var field = typeof field == 'undefined' ? false : field;
			
			if( !arguments.length ) {
				for( var i=0;i<list.length;i++ ) {
					var editor = list[i];
					var pos = self._getEditorCellPos(editor.rid,editor.field);
					if( !pos ) continue;
					pos.render.append( $("#"+editor.id) );
					var tid = opt.id+"_"+editor._colid+"_row_"+editor.rid+"_td";
					var td = $("#"+tid);
					var ctd = $("#"+editor.id);
					ctd._outerWidth( td.outerWidth() );
					ctd.css({
						left : pos.left,
						top : pos.top
					});
					var edit = editor.column.editor;
					var cellId = opt.id+"_"+editor._colid+"_row_"+editor.rid+"_cell";
					var width = edit.limitWidth ? edit.limitWidth : $("#"+cellId).width();
					editor.editorProvider.C('width',width);
					editor.editorProvider.setSize();//('onSizeChange',[]);
					self.fireEvent("onResizeEditor",[rid,field,editor,edit]);
				}
			} else if( arguments.length == 2 ) {
				var editor = self.getEditor( rid,field );
				if( !editor )  return false;
				var pos = self._getEditorCellPos(editor.rid,editor.field);
				
				if( !pos ) return false;
				pos.render.append( $("#"+editor.id) );
				var tid = opt.id+"_"+editor._colid+"_row_"+editor.rid+"_td";
				var td = $("#"+tid);
				var ctd = $("#"+editor.id);
				ctd._outerWidth( td.outerWidth() );
				ctd.css({
					left : pos.left,
					top : pos.top
				});
				var edit = editor.column.editor;
				var cellId = opt.id+"_"+editor._colid+"_row_"+editor.rid+"_cell";
				var width = edit.limitWidth ? edit.limitWidth : $("#"+cellId).width();
				editor.editorProvider.C('width',width);
				editor.editorProvider.setSize();//('onSizeChange',[]);	
				self.fireEvent("onResizeEditor",[rid,field,editor,edit]);
			}
			return true;
		},
		removeEditor : function(rid,field,_reset){//_reset: true | false,true:移除后设置原来的内容,false:移除编辑后不设置原来的内容
			var self = this,
				opt = self.configs;
			var _reset = _reset || false;
			var _colid = self.getColumnData(field,'_colid');//column._colid;//
			var edit_cell = opt.id + "_"+rid+"_"+_colid+"_edit";
			var edit_cell_id = edit_cell+"_cell";
			
			var viewValue = false;
			var isEditable = false;
			var sr = self.fireEvent("onBeforeRemoveEditCell",[rid,field,self.editors,edit_cell,edit_cell_id]);
			if( sr === false ) return false;
			//出列
			var list = self.editors;
			for(var x=0;x<list.length;x++) {
				if( list[x].id == edit_cell ) {
					list[x].editorProvider._destroy();
					viewValue = list[x].viewValue;
					list.splice(x,1);
					isEditable = true;//当前单元格是否处于编辑状态
					break;
				}
			}
			
			$("#"+edit_cell).remove();
			
			if( _reset && isEditable && (viewValue !== false) ) {
				var cellId = opt.id+"_"+_colid+"_row_"+rid+"_cell";
				var cell = $("#"+cellId);	
				if( cell.size() ) {
					cell.html( viewValue );	
				}
			}
			self.fireEvent("onRemoveEditCell",[rid,field,cell,viewValue]);
			return self;
		},
		getEditor :　function( rid,field ){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			var editor = false;
			for(var x=0;x<list.length;x++) {
				if( list[x].rid == rid && list[x].field == field ) {
					editor = list[x];
					break;
				}
			}
			return editor;			
		},
		getCellEditor : function( rid,field ){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			var editor = self.getEditor( rid,field );
			if( editor ) {
				return 	editor.editorProvider;
			}
			return editor;		
		},
		focus : function(rid,field){
			var self = this,
				opt = self.configs;		
			var editor = self.getCellEditor( rid,field );
			editor.getInput().focus();
			return true;
		},
		showEditCell : function(rid,field){
			var self = this,
				opt = self.configs;	
			var editor = self.getEditor( rid,field );
			if( !editor ) return false;
			if( editor.isShow ) return false;	
			$("#"+editor.id).show();
			editor.isShow = true;
			
			var _colid = self.getColumnData(field,'_colid');//column._colid;//
			
			var cellId = opt.id+"_"+_colid+"_row_"+rid+"_cell";
			var cell = $("#"+cellId);	
			if( cell.size() ) {
				editor.viewValue = cell.html();	
				cell.html('');	
			}
			self.fireEvent("onShowEditCell",[rid,field,editor,editor.editorProvider]);
		},
		showEditRow : function(rid){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			for(var x=0;x<list.length;x++) {
				if( list[x].rid == rid ) {
					self.showEditCell( rid,list[x]['field'] );
				}
			}
			
		},
		hideEditCell : function(rid,field){
			var self = this,
				opt = self.configs;	
			var editor = self.getEditor( rid,field );
			if( !editor ) return false;	
			if( !editor.isShow ) return false;	
			$("#"+editor.id).hide();
			editor.isShow = false;
			var viewValue = editor.viewValue;
			
			var _colid = self.getColumnData(field,'_colid');//column._colid;//
			
			var cellId = opt.id+"_"+_colid+"_row_"+rid+"_cell";
			var cell = $("#"+cellId);	
			if( cell.size() ) {
				cell.html( viewValue );	
			}
			self.fireEvent("onHideEditCell",[rid,field,editor,editor.editorProvider]);
			return true;
		},
		hideEditRow : function(rid){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			for(var x=0;x<list.length;x++) {
				if( list[x].rid == rid ) {
					self.hideEditCell( rid,list[x]['field'] );
				}
			}
		},
		hideEditField : function(field){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			for(var x=0;x<list.length;x++) {
				if( list[x].field == field ) {
					self.hideEditCell( list[x].rid,list[x]['field'] );
				}
			}
		},
		showEditField : function(field){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			for(var x=0;x<list.length;x++) {
				if( list[x].field == field ) {
					self.showEditCell( list[x].rid,list[x]['field'] );
				}
			}
		},
		getEditCellValue : function(rid,field){
			var self = this,
				opt = self.configs;	
			var editor = self.getCellEditor( rid,field );
			var value = "";
			if( editor ) {
				value = editor.val();
			}
			return value;	
		},
		setEditCellValue : function(rid,field,value){
			var self = this,
				opt = self.configs;	
			var editor = self.getCellEditor( rid,field );
			if( editor ) {
				value = editor.val( value );
			}
			return true;	
		},
		//验证当前编辑单元格输入内容是否正确
		checkEditCell : function(rid,field){
			var self = this,
				opt = self.configs;	
			var list = self.editors;
			var isValid = true;
			
			var editorProvider = self.getCellEditor(rid,field);
			
			if( !editorProvider ) {
				return true;	
			}
			
			var sr = self.fireEvent("onBeforeCheckEditCell",[rid,field,editorProvider]);
			if( sr === false ) return false;
			
			var r = editorProvider.checkVal();
			if( r === false ) {
				isValid = false;	
			} 
			return isValid;
		},
		//编辑单元格
		editCell : function(rid,field){
			var self = this,
				opt = self.configs;
				
			var _colid = self.getColumnData(field,'_colid');//column._colid;//
				
			var cellId = opt.id+"_"+_colid+"_row_"+rid+"_cell";
			var cell = $("#"+cellId);
			if( !cell.size() ) {
				return false	
			}
			
			if( self.getEditor( rid,field ) ){
				return false;	
			}
			
			var editable = self.createEditor(rid,field);
			
			if( !editable ) return false;
			
			cell.empty();//清空单元格内容
			return true;
		},
		//保存并验证指定正处于编辑状态单元格,不带参数则保存所有目前正处于编辑状态的单元格
		//返回成功保存的的单元格数组 eg [ {rid:1,field:'name'} ]
		saveEditCell :　function(rid,field){
			var self = this,
				opt = self.configs;
			var list = self.editors;
			var len = list.length;
			var valid = valid || false;
			var successSave = [];
			if( arguments.length == 2 ) {
				for(var x=0;x<len;x++){
					var editor = list[x];
					var sr = self.fireEvent("onBeforeSaveEditCell",[rid,field,editor,editor.editorProvider]);
					if( sr === false ) return successSave;
					if( editor.rid == rid && editor.field == field ) { 
					
						var isValid = editor.editorProvider.checkVal();
						
						var value = editor.editorProvider.val();
						
						self.removeEditor( editor.rid,editor.field,true );
						
						if( isValid === false ) {
							break;
						}
						
						var isSave = self.setFieldValue( editor.rid,editor.field,value );
						self.fireEvent("onSaveEditCell",[editor.rid,editor.field,value]);
						if( isSave !== false ) {
							successSave.push({
								rid : editor.rid,
								field : editor.field
							});	
						}
						break;
					}
				}
			} else {
				for(var x=0;x<len;){
					var editor = list[x];
					
					var sr = self.fireEvent("onBeforeSaveEditCell",[editor.rid,editor.field,editor,editor.editorProvider]);
					if( sr === false ) return successSave;
					
					var isValid = editor.editorProvider.checkVal();
					
					
					var value = editor.editorProvider.val();
					
					self.removeEditor( editor.rid,editor.field,true );
					len = list.length;//因为removeEditor会对List进行删减 所以len是个可变的
					
					if( isValid === false ) {
						continue;
					}
					var isSave = self.setFieldValue( editor.rid,editor.field,value );
					self.fireEvent("onSaveEditCell",[editor.rid,editor.field,value]);
					if( isSave !== false ) {
						successSave.push({
							rid : editor.rid,
							field : editor.field
						});	
					}
				}
			}
			return successSave;
		},
		//不做任何保存,取消编辑指定单元格,不带参数则取消编辑所有目前正处于编辑状态的单元格
		unEditCell : function(rid,field){
			var self = this,
				opt = self.configs;
			if( arguments.length == 2 ) {
				self.removeEditor(rid,field,true);	
			} else {
				var list = self.editors;
				var len = list.length;
				for(var x=0;x<len;){
					var editor = list[x];
					self.removeEditor( editor.rid,editor.field,true );
					len = list.length;//因为removeEditor会对List进行删减 所以len是个可变的
				}
			}
		},
		editRow : function(rid){

			var self = this,
				opt = self.configs;
			
			var r = self.fireEvent("onBeforeEditRow",[rid]);
			if( r === false ) return false;
			
			var columns = self.getColumns();
			$.each( columns,function(i,column){
				self.editCell(rid,column.field);					 
			} );
			self.fireEvent("onEditRow",[rid]);

		},
		checkEditRow : function(rid){
			var self = this,
				opt = self.configs;
			var list = self.editors;
			var successSave = [];
			var isValid = true;
			for(var x=0;x<list.length;x++) {
				if( list[x].rid != rid ) {
					continue;	
				}
				var r = self.checkEditCell( rid,list[x].field );
				if( r === false ) {
					isValid = r;
				}
			}
			return isValid;
		},
		saveEditRow : function(rid){
			var self = this,
				opt = self.configs;
			var list = self.editors;
			var successSave = [];
			var rowList = [];
			var r = self.fireEvent("onBeforeSaveEditRow",[rid]);
			if( r === false ) return false;
			for(var x=0;x<list.length;x++) {
				if( list[x].rid != rid ) {
					continue;	
				}
				rowList.push({
					rid : rid,
					field : list[x].field,
					_colid : list[x]._colid
				});
			}
			for( var i=0;i<rowList.length;i++ ) {
				var isSave = self.saveEditCell( rid,rowList[i].field );
				if( isSave.length ) {
					successSave.push( rowList[i].field );	
				}	
			}
			var rowData = self.getRowData(rid);
			//self.fireEvent("onRowEdit",[rid,rowData,successSave]);//兼容
			self.fireEvent("onSaveEditRow",[rid,rowData,successSave]);
		},
		unEditRow : function(rid){
			var self = this,
				opt = self.configs;
			var columns = self.getColumns();
			var rowData = self.getRowData(rid);
			var r = self.fireEvent("onBeforeUnEditRow",[rid,rowData]);
			if( r === false ) return false;
			$.each( columns,function(i,column){
				self.unEditCell(rid,column.field);					 
			} );	
			self.fireEvent("onUnEditRow",[rid,rowData]);
		}
	});
})(jQuery);
$define(['Nex.Html','Nex.util.Date'],function(){
	var cal = Nex.define('Nex.date.Calendar','Nex.Html',{
		xtype : 'calendar',
		alias : 'Nex.Calendar',
		Date : Nex.util.Date,
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			Nex.Html.fn._sysEvents.apply(this,arguments);	
			self.bind('onDateClick.cal',self._onDateClick,self);
			if( Nex.IEVer < 8 ) {
				self.bind('onResize.cal',self._resizeAuto,self);//	
			}
			return self;
		},
		_initCalendar : function(){
			var self = this,
				opt=this.configs;
			//设置defaultDate
			self._initSystemDate()	
				._setCalendar();
		},
		/*
		*初始化当前日历时间
		*/
		_initSystemDate : function(){
			var self = this,
				opt=this.configs;
			if( opt.systemDate === null ) {
				opt.systemDate = new Date();	
			}	
			if( !self.Date.isDate( opt.systemDate ) ) {
				opt.systemDate = self.Date.parseDate( opt.systemDate, opt.dateFormat ) || new Date();		
			}
			
			opt._currentDate = opt.currentDate;
			opt.currentDate = opt.currentDate || new Date(opt.systemDate.getTime());	
			
			if( !self.Date.isDate( opt.currentDate ) ) {
				opt.currentDate = self.Date.parseDate( opt.currentDate, opt.dateFormat );	
			}
			//设置currentDate value
			if( opt.value === '' && opt.autoSelectToday ) {
				opt.value = 0;	
			}
			self._parseValue();
			
			self._parseMaxMinDate();
			
			return self;		
		},
		getSystemDate : function(){
			return this.configs.systemDate;	
		},
		__parse : function( defDate,date ){
			var self = this,
				opt = this.configs;	
			if( $.type( defDate ) === 'number' ) {
				self.Date.add( date, 'd', defDate );
			} else if( $.type(defDate) === 'string' && opt._dateCalcReg.test( defDate ) ) {
				var ds = defDate.split(/\s+/ig);
				$.each( ds,function(i,defDate){
					var matches = opt._dateCalcReg.exec( defDate );
					self.Date.add( date, matches[2], matches[1] );		
				} );
			} else {
				date = self.Date.parseDate( defDate, opt.dateFormat );	
			}			
			return date;
		},
		_parseValue : function( value ){
			var self = this,
				_value = [],
				opt=this.configs;
			var curr = opt.currentDate;
			var value = self._undef(value , opt.value);
			value = $.isArray( value ) ? value : ( value+'' ).split( opt.sepStr );
			//value = $.isArray( value ) ? value : [ value ];
			//初始化选中日期
			opt._selectDate = {};
			
			for( var i=0;i<value.length;i++ ) {
				if( value[i] === '' || value[i] === null ) continue; 
				var _d = self.__parse( value[i], self.Date.clone(curr) );
				_value.push( _d );
				opt._selectDate[ self.format( _d,'YYYYMMDD' ) ] = true;
			}
			
			opt.value = _value;
			//按asc 排序
			opt.value.sort( function( a,b ){
				return a - b;	
			} );
			//处理开始显示日历的月份数
			if( !opt._currentDate ) {
				opt.currentDate = self._getCurrentDate();
			}
			
			//触发初始化日期事件
			self.fireEvent( 'onParseDefaultDate',[ opt ] );
			
			return self;		
		},
		_parseMaxMinDate : function(){
			var self = this,
				opt = this.configs;	
			var curr = opt.currentDate;	
			if( opt.maxDate !== null ) {
				opt.maxDate = self.Date.parseDate( opt.maxDate,opt.dateFormat );
			}
			if( opt.minDate !== null ) {
				opt.minDate = self.Date.parseDate( opt.minDate,opt.dateFormat );	
			}	
			var disabledDate = $.isArray( opt.disabledDate ) ? opt.disabledDate : [ opt.disabledDate ];	
			var enabledDate = $.isArray( opt.enabledDate  ) ? opt.enabledDate  : [ opt.enabledDate  ];
			
			opt.disabledDate = [];
			opt.enabledDate = [];
			
			$.each( disabledDate,function(i,date){
				var _d = self.__parse( date, self.Date.clone(curr) );	
				opt.disabledDate.push( _d );
			} );
			$.each( enabledDate,function(i,date){
				var _d = self.__parse( date, self.Date.clone(curr) );	
				opt.enabledDate.push( _d );
			} );
			return self;
		},
		//是否属于同一日期
		_isEqual : function(d1,d2){
			return this.format( d1,'YYYYMMDD' ) === this.format( d2,'YYYYMMDD' ) ? true : false;
		},
		//是否属于同一日期
		_isEqualDate : function(d1,d2){
			return this._isEqual( d1,d2 );
		},
		//同月
		_isEqualMonth : function(d1,d2){
			return this.format( d1,'YYYYMM' ) === this.format( d2,'YYYYMM' ) ? true : false;
		},
		//同年
		_isEqualYear : function(d1,d2){
			return this.format( d1,'YYYY' ) === this.format( d2,'YYYY' ) ? true : false;
		},
		_inDisabledList : function( date ){
			var self = this,
				opt = this.configs;	
			var r = false;
			
			var ds = opt.disabledDate;
			
			for( var i=0;i<ds.length;i++ ) {
				if( self._isEqual( date,ds[i] ) ) {
					r = true;
					break;	
				}
			}
			
			return r;		
		},
		_inEnabledList : function( date ){
			var self = this,
				opt = this.configs;	
			var r = false;
			
			var ds = opt.enabledDate;
			
			for( var i=0;i<ds.length;i++ ) {
				if( self._isEqual( date,ds[i] ) ) {
					r = true;
					break;	
				}
			}
			
			return r;		
		},
		isDisabledDate : function( date ){
			var self = this,
				opt = this.configs;	
			//equal	
			var date = self.Date.parseDate( date,opt.dateFormat );	
			date.setHours(0);
			date.setMinutes(0);
			date.setSeconds(0);
			var r = false;
			if( opt.maxDate !== null ) {
				r = date > opt.maxDate ? true : false;
			}	
			if( opt.minDate !== null && !r ) {
				r = date < opt.minDate ? true : false;
			}	
			if( !r ) {
				r = self._inDisabledList( date );	
			}
			if( r ) {
				r = !self._inEnabledList( date );		
			}
			return r;
		},
		setDisabledDate : function( dates ){
			var self = this,
				opt = this.configs;	
			var curr = opt.currentDate;			
			var dates = $.isArray( dates ) ? dates : [dates];
			$.each( dates,function(i,date){
				if( date === '' || date === null ) return;
				var _d = self.__parse( date, self.Date.clone(curr) );	
				var fmt = self.format( _d,'YYYYMMDD' );
				opt.disabledDate.push( _d );	
				$('#'+opt.id+'_'+fmt).addClass('nex-cal-date-disabled');
			} );
			return self;	
		},
		setEnabledDate : function( dates ){
			var self = this,
				opt = this.configs;	
			var curr = opt.currentDate;			
			var dates = $.isArray( dates ) ? dates : [dates];
			$.each( dates,function(i,date){
				if( date === '' || date === null ) return;
				var _d = self.__parse( date, self.Date.clone(curr) );	
				var fmt = self.format( _d,'YYYYMMDD' );
				opt.enabledDate.push( _d );	
				$('#'+opt.id+'_'+fmt).removeClass('nex-cal-date-disabled');
			} );
			return self;	
		},
		//从value中获取最佳显示日期 currentDate
		_getCurrentDate : function(){
			var self = this,
				opt = this.configs;	
			var num = opt.numberOfMonths;
			var _Date = self.Date;
			
			var dates = opt.value;
			var len = dates.length;
			var current = opt.currentDate;
			for( var i=0;i<len;i++ ) {
				var isOk = true;
				var diff = 0;
				var d1 = dates[i];
				for( var j=i+1;j<len;j++ ) {
					var d2 = dates[j];	
					diff = Math.abs(_Date.diff( d1,d2,'m' ));
					if( (diff+1) > num ) {
						isOk = false;
						break;	
					}
				}
				if( isOk ) {
					current = d1;	
					break;
				}
			}
			return current;	
		},
		/*
		*设置默认选中日期 默认选中当天
		*/
		format : function(date,str){
			return this.Date.format( date,str );	
		},
		/*
		*获取thead
		*@param opts 设置参数 默认是configs
		*/
		_getTheadHtml : function( opts ){
			var self = this,
				opt = opts || this.configs;
			var dn = opt.dayNamesMin;
			var html = ['<tr class="nex-cal-row nex-cal-row-h">'];
			if( opt.showWeek ) {
				html.push( '<th class="nex-cal-cell nex-cal-cell-w">' );
				html.push( opt.weekHeader );
				html.push( '</th>' );		
			}
			var len2 = 7 + opt.firstDay;
			for( var i=opt.firstDay;i<len2;i++ ) {
				var day = i%7;
				html.push( '<th class="nex-cal-cell nex-cal-cell-h nex-cal-day'+day+'" data-day="'+day+'">' );
				html.push( dn[day] );
				html.push( '</th>' );	
			}
			html.push('</tr>');
			return html.join('');	
		},
		/*
		*获取指定月份需要显示的日期数
		*返回开始和结束日期
		*/
		_getDateRange : function( date,opts ){
			var self = this,
				opt= opts || this.configs;
			var currentDate = date || opt.currentDate;
			var maxDays = self.Date.maxDay( currentDate );	
			var cDate = new Date( currentDate.getTime() );
			cDate.setDate(1);
			var startDate,endDate;
			var html = [];
			if( !opt.showOtherMonths ) {
				endDate = self.Date.lastDay( cDate );
				var eday = endDate.getDay(); 
				var next = eday<opt.firstDay?(7*1)+eday:eday;
				self.Date.add( endDate,'d',next-eday );
				
				var cday = cDate.getDay(); 
				var prev = cday<opt.firstDay?(7*1)+cday:cday;
				self.Date.add( cDate,'d',opt.firstDay-prev );
				startDate = self.Date.clone( cDate );
			} else {
				var cday = cDate.getDay(); 
				if( cday != opt.firstDay ) {
					var prev = cday<opt.firstDay?(7*1)+cday:cday;
					self.Date.add( cDate,'d',opt.firstDay-prev );
				} else {
					self.Date.add( cDate,'d',-7 );	
				}
				startDate = self.Date.clone( cDate );	
				endDate =  self.Date.clone( self.Date.add( cDate,'d',41 ) );
			}	
			return [ startDate, endDate ];	
		},
		//如果不需要显示其他月份日期则显示6行 每行7天	
		_getTbodyHtml : function( opts ){
			var self = this,
				_opt = this.configs,
				opt = opts || this.configs;	
				
			var dateRange = self._getDateRange( opt.currentDate,opt );
			
			var diff = self.Date.diff( dateRange[0],dateRange[1],'d' ) + 1;
			var startDate = dateRange[0];
			var endDate = dateRange[1];
			var html = [];
			var rows = [];
			var k = 0;
			for( var i=0;i<diff;i++ ) {
				if( i%7 == 0 ) {
					rows[k] = [];
				}
				rows[k].push( self.Date.clone(startDate) );
				if( i%7 == 6 ) {
					k++;
				}	
				self.Date.add( startDate,'d',1 );	
			}
			//autoFillOthers
			if( opt.autoFillOthers ) {
				for( var n=0;n<6;n++ ) {
					var _row = rows[n] || [];
					rows[n] = _row;
					for( var b=_row.length;b<7;b++ ) {
						_row[b] = null;	
					}	
				}	
			}
			var getPad = function(){
				var s = [];
				s.push('<td class="nex-cal-pad">');
				s.push( '&nbsp;' );
				s.push('</td>');	
				return s.join('');	
			};
			var len = rows.length;
			
			var rlast = len ? rows[0][6] : null;
			
			if( rlast )
			
			for( var j=0;j<len;j++ ) {
				var row = rows[j];
				if( j == 0 ) {
					var plast = row[6];
					if( self._isOtherMonth(plast, opt.currentDate) && !opt._showPrevMonths ) {
						continue;	
					}
				}
				if( j == len-1 ) {
					var nlast = row[0];
					if( self._isOtherMonth(nlast, opt.currentDate) && !opt._showNextMonths ) {
						continue;	
					}
				}
				html.push('<tr class="nex-cal-row nex-cal-row-b">');	
				if( opt.showWeek ) {
					var index = 0;
					if( opt.weekIndex != 'firstDay' ) {
						//计算星期索引位置
						index = parseInt(opt.weekIndex,10)<opt.firstDay?(7-opt.firstDay+opt.weekIndex):(opt.weekIndex-opt.firstDay);	
					}
					var week = self.Date.weekOfYear( row[index] );
					html.push( '<td class="nex-cal-cell nex-cal-cell-w" data-week="'+week+'">' );
					html.push( week );
					html.push( '</td>' );		
				}	
				for( var k=0;k<7;k++ ) {
					var date = row[ k ];
					if( date === null || !self.Date.isDate( date ) ) {
						html.push( getPad() );
						continue;
					}
					var day = date.getDay();
					var part = self.Date.dateObject(date);
					var isOtherMonth = self._isOtherMonth(date, opt.currentDate);
					//_showPrevMonths _showNextMonths
					if( isOtherMonth && !opt.showOtherMonths ) {//isOtherMonth && 
						html.push( getPad() );
						continue;
					}
					if( isOtherMonth ) {
						if( date.getTime() < opt.currentDate.getTime() && !opt._showPrevMonths ) {
							html.push( getPad() );
							continue;	
						}
						if( date.getTime() > opt.currentDate.getTime() && !opt._showNextMonths ) {
							html.push( getPad() );	
							continue;
						}
					}
					var tips = '';
					if( opt.showDateTips ) {
						tips = self._dateTipsFilter( date );	
					}
					
					var isToday = self._isToday( date );
					var cls = ['nex-cal-cell','nex-cal-cell-b','nex-cal-day'+day];//,'nex-cal-day'+k
					
					self.fireEvent('onSetDateClass',[ {'class':cls,data:date},_opt ]);
					
					if( isOtherMonth ) {
						cls.push( 'nex-cal-other-month' );	
					}
					if( isToday ) {
						cls.push( 'nex-cal-today' );	
					}
					if( self.isDisabledDate( date ) ) {
						cls.push( 'nex-cal-date-disabled' );		
					}
					
					html.push('<td id="'+opt.id+'_'+ self.format( date,'YYYYMMDD' ) +'" calid="'+opt.id+'" class="'+cls.join(' ')+'" data-year="'+part['y+']+'" data-month="'+part['M+']+'" data-date="'+part['d+']+'" '+tips+'>');
					html.push( self._dateFiter( self.format( date,'d' ), date ) );
					html.push('</td>');
				}
				html.push('</tr>');	
			}
			return html.join('');
		},
		/*
		*获取日历显示内容
		*@param opts 设置参数
		*/
		_getCalendarHtml : function( opts ){
			var self = this;
			var opt = this.configs;
			if( $.type( opts ) === 'string' ) {
				opts = {
					currentDate : opts
				};
			}
			var opts = opts || {};
			var _d = $.extend( {},opt );
			opts = $.extend( {},_d,opts );	
			var html = [
				'<table class="nex-cal-table" cellpadding="0" cellspacing="0" border="0">',
					'<thead>'+self._getTheadHtml(opts)+'</thead>',
					'<tbody>'+self._getTbodyHtml(opts)+'</tbody>',
				'</table>'
			];
			return html.join('');
		},
		/*
		*显示提示日期内容过滤
		*/
		_dateTipsFilter : function( startDate ){
			var self = this,
				opt=this.configs;
			var tips = '';	
			var str = '';
			tips += opt.dateTipsTag+'="';
			if( $.isFunction( opt.dateTipsFilter ) ) {
				str += opt.dateTipsFilter.call( self, self.format( startDate,opt.dateTipsFormat ), startDate);	
			} else {
				str += self.format( startDate,opt.dateTipsFormat );
			}
			var d = {
				value : str,
				date : startDate
			};
			self.fireEvent('onDateTipsFilter',[d,opt]);
			tips += Nex.htmlEncode(d.value);
			tips += '"';	
			return tips;	
		},
		/*
		*显示日期内容过滤
		*/
		_dateFiter : function( s,date ){
			var self = this,
				opt=this.configs;
			var str = s;
			if( $.isFunction( opt.dateFilter ) ) {
				str	= opt.dateFilter.call( self,str,date );
			}	
			var d = {value:str,date:date};
			self.fireEvent('onDateFilter',[d,opt]);
			return d.value;	
		},
		/*
		*判断日期否属于当日
		*/
		_isToday : function( date ){
			var self = this,
				opt=this.configs;
			var currentDate = opt.systemDate;	
			if( $.type( date ) === 'string' ) {
				date = self.Date.strToDate( date );	
			}	
			var p1 = self.Date.dateObject( currentDate );
			var p2 = self.Date.dateObject( date );
			if( p1['y+'] != p2['y+'] ) return false;
			if( p1['M+'] != p2['M+'] ) return false;
			if( p1['d+'] != p2['d+'] ) return false;
			return true;	
		},
		/*
		*判断当前日期是否不输入本月
		*/
		_isOtherMonth : function(date,curr){
			var self = this,
				opt=this.configs;
			var currentDate = curr||opt.currentDate;	
			if( $.type( date ) === 'string' ) {
				date = self.Date.strToDate( date );	
			}	
			var p1 = self.Date.dateObject( currentDate );
			var p2 = self.Date.dateObject( date );
			if( p1['y+'] != p2['y+'] ) return true;
			if( p1['M+'] != p2['M+'] ) return true;
			return false;
		},
		_setCalendarItemHeader : function( i,opts ){
			var self = this,
				opt  = this.configs,
				opts  = opts || this.configs;
			var bd = $('#'+opt.id+'_item'+i);	
			var html = $('<div id="'+opt.id+'_item'+i+'_header" class="nex-cal-item-header"></div>');
			bd.append( html );
			//showChangeMonthBtn
			//topTitleFilter
			var topTitle = self.format( opts.currentDate,opt.topTitleFormat );
			if( $.isFunction( opts.topTitleFilter ) ) {
				topTitle = opts.topTitleFilter.call( self,opts.currentDate );
			}
			var wrap = [
				'<div class="nex-cal-item-title">',
					'<div class="nex-cal-prev-icons">',
						opts.showChangeYearBtn && opts._showChangeYearNextBtn ? '<a href="javascript:void(0);" title="'+opt.prevYearTitle+'" class="nex-cal-aicon nex-cal-prevyear"></a>' : '',
						opts.showChangeMonthBtn && opts._showChangeMonthPrevBtn ? '<a href="javascript:void(0);" title="'+opt.prevMonthTitle+'" class="nex-cal-aicon nex-cal-prevmonth"></a>' : '',
					'</div>',
					'<span class="nex-cal-ymlabel">'+topTitle+'</span>',
					'<div class="nex-cal-next-icons">',
						opts.showChangeMonthBtn && opts._showChangeMonthRightBtn ? '<a href="javascript:void(0);" title="'+opt.nextMonthTitle+'" class="nex-cal-aicon nex-cal-nextmonth"></a>' : '',
						opts.showChangeYearBtn && opts._showChangeYearRightBtn ? '<a href="javascript:void(0);" title="'+opt.nextYearTitle+'" class="nex-cal-aicon nex-cal-nextyear"></a>' : '',
					'</div>',
				'</div>'
			];
			
			html.html( wrap.join('') );
			
			return self;
		},
		_setCalendarItemBody : function( i,opts ){
			var self = this,
				opt  = this.configs,
				opts  = opts || this.configs;
			var bd = $('#'+opt.id+'_item'+i);	
			var html = $('<div id="'+opt.id+'_item'+i+'_body" class="nex-cal-item-body">'+self._getCalendarHtml( opts )+'</div>');
			bd.append( html );
			
			return self;
		},
		_setCalendarItemFooter : function( i,opts ){
			var self = this,
				opt  = this.configs,
				opts  = opts || this.configs;
			var bd = $('#'+opt.id+'_item'+i);	
			var html = $('<div id="'+opt.id+'_item'+i+'_footer" class="nex-cal-item-footer"></div>');
			bd.append( html );	
			return self;			
		},
		getCurrentDate : function(){
			return this.configs.currentDate;	
		},
		setCurrentDate : function( date ){
			var opt = this.configs;
			opt.currentDate = this.Date.parseDate( date,opt.dateFormat )
			return this;	
		},
		_setCalendarItemEvents : function(){
			var self = this,
				opt=this.configs;
			var dom = self.getDom();
			var call = function(evt,e,func){
				var $this = $(this);
				
				var date = new Date( $this.data('year'),parseInt($this.data('month'),10)-1,$this.data('date') );
				
				var r = self.fireEvent(evt,[ date,this,e,opt ]);	
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				} else {
					if( $.isFunction( func ) ) {
						func.call( this,date );	
					}
				}
			};
			var events = {
				'click.cal' : function(e){
					call.call( this,'onDateClick',e );
				},
				'mouseenter.cal' : function(e){
					call.call( this,'onDateOver',e,function(){
						if( !$(this).hasClass('nex-cal-date-disabled') ) {
							$(this).addClass('nex-cal-date-over');			
						}
					} );
				},
				'mouseleave.cal' : function(e){
					call.call( this,'onDateOut',e,function(){
						if( !$(this).hasClass('nex-cal-date-disabled') ) {
							$(this).removeClass('nex-cal-date-over');	
						}
					} );	
				},
				'mousedown.cal' : function(e){
					call.call( this,'onDateMouseDown',e );		
				},	
				'mouseup.cal' : function(e){
					call.call( this,'onDateMouseUp',e );			
				},
				'contextmenu.cal' : function(e){
					call.call( this,'onDateContextMenu',e );			
				},
				'dblclick.cal' : function(e){
					call.call( this,'onDateDblClick',e );	
				}
			};
			dom.undelegate('.cal')
			   .delegate('[calid="'+opt.id+'"]',events)
			   .delegate('.nex-cal-prevyear',{
					'click.cal' : function(e){
						var r = self.fireEvent('onPrevYear',[ opt ]);
						if( r === false ) return;
						self.prevYear();	
					}   
			    })
				.delegate('.nex-cal-nextyear',{
					'click.cal' : function(e){
						var r = self.fireEvent('onNextYear',[ opt ]);
						if( r === false ) return;
						self.nextYear();	
					}   
			    })
				.delegate('.nex-cal-prevmonth',{
					'click.cal' : function(e){
						var r = self.fireEvent('onPrevMonth',[ opt ]);
						if( r === false ) return;
						self.prevMonth();	
					}   
			    })
				.delegate('.nex-cal-nextmonth',{
					'click.cal' : function(e){
						var r = self.fireEvent('onNextMonth',[ opt ]);
						if( r === false ) return;
						self.nextMonth();	
					}   
			    })
				.delegate('.nex-cal-ymlabel',{
					'click.cal' : function(e){
						var _item = $(this).closest('.nex-cal-item');
						var citem = _item.attr('citem');
						var y = _item.data('year');
						var m = parseInt(_item.data('year'),10);
						var date = new Date(y,m-1);
						var r = self.fireEvent('onItemTitleClick',[ date,citem,opt ]);
						if( r === false ) return;
						if( opt.ymChangeEnable ) {
							self.showYearMonthPicker(citem);
						}
					}   
			    }); 
			return self;		
		},
		_getMonthPickerHtml : function( ci ){
			var self = this,
				opt = this.configs;	
			var months = [
				[0,1,2,3],
				[4,5,6,7],
				[8,9,10,11]
			];	
			var m = '';
			for( var i=0;i<months.length;i++ ) {
				var t = months[i];
				m += '<tr>';
					for( var j=0;j<t.length;j++ ) {
						m += '<td width="25%" class="nex-cal-mpicker-b nex-cal-mpicker-'+t[j]+'" data-month="'+(t[j]+1)+'" id="'+opt.id+'_'+ci+'_m'+t[j]+'">'+opt.monthNames[t[j]]+'</td>'; 
					}
				m += '</tr>';	
			}
			var html = [
				'<table class="nex-cal-mpicker-table" cellpadding="0" cellspacing="0" border="0">',
					m,
				'</table>',
			];	
			return html.join('');
		},
		_getYearPickerHtml : function( i ){
		},
		_getYearMonthPickerHtml : function(i){
			var self = this,
				opt = this.configs;	
			var html = [
				'<div id="'+opt.id+'_item'+i+'_ympicker" class="nex-cal-ympicker">',
					'<div id="'+opt.id+'_item'+i+'_ypicker_wrap"'+' class="nex-cal-ypicker-wrap">',
						'<span class="prev-ypicker"></span><input class="nex-cal-ypicker" id="'+opt.id+'_item'+i+'_ypicker" type="text" value=""><span class="next-ypicker"></span>',
					'</div>',
					'<div id="'+opt.id+'_item'+i+'_line" class="nex-cal-ympicker-line"></div>',
					'<div id="'+opt.id+'_item'+i+'_mpicker"'+' class="nex-cal-mpicker-wrap">',
						self._getMonthPickerHtml( i ),
					'</div>',
				'</div>'
			];	
			return html.join('');
		},
		__activePicker : null,
		hideYearMonthPicker : function( i,func ){
			var self = this,
				opt = this.configs;	
			var i = self._undef( i,self.__activePicker );
			if( i === null ) {
				if( $.isFunction( func ) ) {
					func();	
				}
				return self;	
			} 
			self.__activePicker = null;
			var picker = $('#'+opt.id+'_item'+i+'_ympicker');
			picker.stop(true).animate({
				top : picker._outerHeight()*-1,
				opacity : 0
			},opt.ymPickerDuration || 1,opt.ymPickerAnim,function(){
				if( $.isFunction( func ) ) {
					func();	
				}	
				self.fireEvent('onYearMonthPickerHide',[ picker, i, opt]);	
			});
		},
		//显示年月份选择框
		showYearMonthPicker : function( citem ){
			var self = this,
				opt = this.configs;	
				
			var citem = self._undef( citem,1 );
			
			var _itemWrap = $('#'+opt.id+'_item'+citem);
			var _item = $('#'+opt.id+'_item'+citem+'_body');
			
			var picker = $('#'+opt.id+'_item'+citem+'_ympicker');
			var _isInit = false;
			if( !picker.length ) {		
				picker = $( self._getYearMonthPickerHtml( citem ) );
				_item.append( picker );
				self.setYearMonthPickerEvents( citem );
				_isInit = true;
				self.fireEvent('onYearMonthPickerCreate',[ picker, citem, opt]);
			}
			
			var y = _itemWrap.data('year'),
				m = _itemWrap.data('month');
			
			if( self.__activePicker === citem && !_isInit ) {
				self.hideYearMonthPicker( citem );
			} else {
				
				self.hideYearMonthPicker( self.__activePicker );
				
				self.setYearMonthPickerSize( citem );
				self.setYearMonthPickerValue( citem,y,m );
					
				self.__activePicker = citem;	
				picker.stop(true).animate({
					top : 0,
					opacity : 1
				},opt.ymPickerDuration || 1,opt.ymPickerAnim,function(){
					self.fireEvent('onYearMonthPickerShow',[ picker, citem, opt]);	
				});	
			}	
			return self;
		},
		//设置month year picker大小
		setYearMonthPickerSize : function( i ){
			var self = this,
				opt = this.configs;	
			var _item = $('#'+opt.id+'_item'+i+'_body');
			var w = _item.width();
			var h = _item.height();	
			var picker = $('#'+opt.id+'_item'+i+'_ympicker');
			picker._outerHeight( h );	
			picker._outerWidth( w );
			var ph = Math.min(picker.height(),h);//使用Math.min主要是兼容IE6 。。。
			var pw = Math.min(picker.width(),w);
			var bh = ph - $('#'+opt.id+'_item'+i+'_ypicker_wrap')._outerHeight(true) - $('#'+opt.id+'_item'+i+'_line')._outerHeight(true);
			var mpicker = $('#'+opt.id+'_item'+i+'_mpicker');
			mpicker._outerHeight( bh );
			mpicker._outerWidth( pw );
		},
		setYearMonthPickerValue : function(i,y,m){
			var self = this,
				opt = this.configs;
			var picker = $('#'+opt.id+'_item'+i+'_ympicker');	
			m--;	
			$('.nex-cal-month-selected',picker).removeClass('nex-cal-month-selected');
			$('#'+opt.id+'_item'+i+'_ypicker').val( y );
			$('#'+opt.id+'_'+i+'_m'+m).addClass('nex-cal-month-selected');
				
		},
		_selectMonthPicker : function( citem,y,m,t ){
			var self = this,
				opt = this.configs;
				
			var picker = $('#'+opt.id+'_item'+citem+'_ympicker');
				
			$('.nex-cal-month-selected',picker).removeClass('nex-cal-month-selected');
			$(t).addClass('nex-cal-month-selected');
			
			var date = new Date( y,m-1 );
			
			self.Date.add(date,'m',citem*-1);
			
			
			
			if( opt.ymPickerAutoClose ) { 
				self.hideYearMonthPicker( citem,function(){
					self.changeMonth( date.getFullYear(),date.getMonth()+1 );
				} );
			}	
		},
		setYearMonthPickerEvents : function( citem ){
			var self = this,
				opt = this.configs;
			var picker = $('#'+opt.id+'_item'+citem+'_ympicker');
			$('#'+opt.id+'_item'+citem+'_ypicker_wrap').disableSelection();
			var t1 = 0,
				t2 = 0;
			picker.undelegate('.cal')
			   	  .delegate( '.nex-cal-mpicker-b',{
						'click.cal' : function(e){
							var y = $('#'+opt.id+'_item'+citem+'_ypicker').val(),
								m =  parseInt( $(this).data('month'), 10);
								
							var  r = self.fireEvent('onMonthPickerClick',[ y, m, this, e, opt]);
							if( r === false ) return;
							
							self._selectMonthPicker( citem,y,m,this );
							
						},  
						'mouseenter.cal' : function(e){
							var y = $('#'+opt.id+'_item'+citem+'_ypicker').val(),
								m =  parseInt( $(this).data('month'), 10);
							var  r = self.fireEvent('onMonthPickerOver',[ y,m,this, e, opt]);
							if( r === false ) return;
							$(this).addClass('nex-cal-mpicker-over');	
						},
						'mouseleave.cal' : function(e){
							var y = $('#'+opt.id+'_item'+citem+'_ypicker').val(),
								m =  parseInt( $(this).data('month'), 10);
							var  r = self.fireEvent('onMonthPickerOut',[ y,m,this, e, opt]);
							if( r === false ) return;
							$(this).removeClass('nex-cal-mpicker-over');		
						},
						'dblclick.cal' : function(e){
							var y = $('#'+opt.id+'_item'+citem+'_ypicker').val(),
								m =  parseInt( $(this).data('month'), 10);
							var  r = self.fireEvent('onMonthPickerDblClick',[ y,m,this, e, opt]);
							if( r === false ) return;	
						}
				  } )
				  .delegate( '.nex-cal-ypicker',{
					  	'click.cal' : function(e){
							var y = $(this).val();
							var  r = self.fireEvent('onYearPickerClick',[ y,this, e, opt]);
							if( r === false ) return;	
							$(this).select();		
						},
						'mouseente.calr' : function(e){
							var y = $(this).val();
							var  r = self.fireEvent('onYearPickerOver',[ y,this, e, opt]);
							if( r === false ) return;	
							$(this).addClass('nex-cal-ypicker-over');	
						},
						'mouseleave.cal' : function(e){
							var y = $(this).val();
							var  r = self.fireEvent('onYearPickerOut',[ y,this, e, opt]);
							if( r === false ) return;	
							$(this).removeClass('nex-cal-ypicker-over');		
						},
						'focus.cal' : function(e){
							var y = $(this).val();
							var  r = self.fireEvent('onYearPickerFocus',[ y,this, e, opt]);
							if( r === false ) return;
							$(this).addClass('nex-cal-ypicker-focus');
							setTimeout(function(){
								$(this).select();	
							},0);
						},
						'blur.cal' : function(e){
							var y = $(this).val();
							var  r = self.fireEvent('onYearPickerBlur',[ y,this, e, opt]);
							if( r === false ) return;
							$(this).removeClass('nex-cal-ypicker-focus');		
						} 
				  } )
				  .delegate( '.prev-ypicker',{
					  	'click.cal' : function(e){
							var ypicker = $('#'+opt.id+'_item'+citem+'_ypicker');
							y = parseInt(ypicker.val(),10);
							var  r = self.fireEvent('onYearPickerPrevClick',[ y,this, e, opt]);
							if( r === false ) return;	
							y--;
							y = Math.max( 0,y );
							ypicker.val( y );	
						},
						'mousedown.cal' : function(e){//处理鼠标100ms后触发自动计算
							var ypicker = $('#'+opt.id+'_item'+citem+'_ypicker');
							y = parseInt(ypicker.val(),10);
							var  r = self.fireEvent('onYearPickerPrevMouseDown',[ y,this, e, opt]);
							if( r === false ) return;	
							t1 = setTimeout(function(){
								t2 = setInterval( function(){
									y--;
									y = Math.max( 0,y );
									ypicker.val( y );	
								},opt.yPickerPoll );
							},opt.yPickerDelay);
						},
						'mouseup.cal' : function(e){
							var ypicker = $('#'+opt.id+'_item'+citem+'_ypicker');
							y = parseInt(ypicker.val(),10);
							var  r = self.fireEvent('onYearPickerPrevMouseDownUp',[ y,this, e, opt]);
							if( r === false ) return;		
							clearTimeout(t1);
							clearTimeout(t2);
						},
						'mouseleave.cal' : function(){
							clearTimeout(t1);
							clearTimeout(t2);		
						}
				  } )
				  .delegate( '.next-ypicker',{
					  	'click.cal' : function(e){
							var ypicker = $('#'+opt.id+'_item'+citem+'_ypicker');
							y = parseInt(ypicker.val(),10);
							var  r = self.fireEvent('onYearPickerNextClick',[ y,this, e, opt]);
							if( r === false ) return;	
							y++;
							ypicker.val( y );	
						},
						'mousedown.cal' : function(e){
							var ypicker = $('#'+opt.id+'_item'+citem+'_ypicker');
							y = parseInt(ypicker.val(),10);
							var  r = self.fireEvent('onYearPickerNextMouseDown',[ y,this, e, opt]);
							if( r === false ) return;		
							t1 = setTimeout(function(){
								t2 = setInterval( function(){
									y++;
									ypicker.val( y );	
								},opt.yPickerPoll );
							},opt.yPickerDelay);
						},
						'mouseup.cal' : function(e){
							var ypicker = $('#'+opt.id+'_item'+citem+'_ypicker');
							y = parseInt(ypicker.val(),10);
							var  r = self.fireEvent('onYearPickerNextMouseDownUp',[ y,this, e, opt]);
							if( r === false ) return;	
							clearTimeout(t1);
							clearTimeout(t2);	
						},
						'mouseleave.cal' : function(){
							clearTimeout(t1);
							clearTimeout(t2);		
						}
				  } );	
		},
		getYearMonthPickerDate : function( i ){
			var self = this,
				opt = this.configs;
			var i = self._undef( i,0 );	
			var y = $('#'+opt.id+'_item'+i+'_ypicker').val(  );
			var m = $('#'+opt.id+'_item'+i+'_mpicker').find( '.nex-cal-month-selected:first' ).data('month');
			return new Date( y,parseInt( m,10 ) );
		},
		setYearMonthPickerDate : function(i,y,m){
			return this.setYearMonthPickerValue(i,y,m);	
		},
		_setCalendarHeader : function(){
			var self = this,
				opt = this.configs;
			var html = $('<div class="nex-cal-header" id="'+opt.id+'_header"></div>');
			self.el.append( html );
			self.headerEl = html;
			self.fireEvent('onCalendarHeaderCreate',[ html, opt ]);
			return self;
		},
		getBody : function(){
			return this.bodyEl;
		},
		_setCalendarBody : function(){
			var self = this,
				opt = this.configs;
			var html = $('<div class="nex-cal-body" id="'+opt.id+'_body"></div>');
			self.el.append( html );	
			self.bodyEl = html;
			self.fireEvent('onCalendarBodyCreate',[ html, opt ]);
			return self;	
		},
		_setCalendarFooter :　function(){
			var self = this,
				opt = this.configs;
			var html = $('<div class="nex-cal-footer" id="'+opt.id+'_footer"></div>');
			self.el.append( $('<div class="nex-cal-clear"></div>') )	
				   .append( html )
				   .append( $('<div class="nex-cal-clear"></div>') );	
			self.footerEl = html;
			self.fireEvent('onCalendarFooterCreate',[ html, opt ]);
			return self;		
		},
		/*
		*设置日历的布局
		*/
		_setCalendar : function(){
			var self = this,
				opt = this.configs;
			self._setCalendarHeader()
				._setCalendarBody()
				._setCalendarFooter()
				._setCalendarItemEvents()
				._setCalendarItems()
				._afterRender();
			return self;	
		},
		_getCalendarItemsTpl : function( num ){
			var opt = this.configs;
			var num = this._undef( num,1 );
			var html = [];
			html.push(
					'<table cellpadding="0" cellspacing="0" border="0" class="nex-cal-items-table" id="'+opt.id+'_items_table">',
						'<tbody>',
							'<tr>'
					);
							for( var i=0;i<num;i++ ) {
								html.push(
									'<td class="nex-cal-item-table-td" citem="'+i+'">',
										'<div id="'+opt.id+'_item'+i+'" citem='+i+' class="nex-cal-item"></div>',
									'</td>'
								);
								var showSep = true;
								if( i == num-1 ) {
									showSep = false;	
								}
								var d = {show : showSep};
								var r = this.fireEvent('onSetItemSplitTd',[d,i,num,opt]);
								if( r !== false && d.show ) {
									html.push(
										'<td class="nex-cal-item-split-td" citem="'+i+'">',
											'<div class="nex-cal-item-split-line"></div>',
										'</td>'
									);		
								}
							}
					html.push(
							'</tr>',
						'</tbody>',
					   '</table>'
					);	
			return html.join('');		
		},
		_setCalendarItems : function(){
			var self = this,
				opt = this.configs;
			//numberOfMonths
			var num = parseInt(opt.numberOfMonths,10) || 1;
			self.bodyEl.html( self._getCalendarItemsTpl( num ) );
			
			var last = num - 1;
			for( var i=0;i<num;i++ ) {
				
				var d = $.extend( {},opt );
				d.currentDate = new Date(opt.currentDate.getTime());
				
				self.Date.add(d.currentDate,'m',i);
				
				if( i == 0 ) {
					d._showChangeMonthPrevBtn = true;
					d._showChangeYearNextBtn = true;
					
					d._showPrevMonths = true;
				} else {
					d._showChangeMonthPrevBtn = false;
					d._showChangeYearNextBtn = false;
					
					d._showPrevMonths = false;
				}
				if( i == last ) {
					d._showChangeMonthRightBtn = true;
					d._showChangeYearRightBtn = true;
					
					d._showNextMonths = true;
				} else {
					d._showChangeMonthRightBtn = false;
					d._showChangeYearRightBtn = false;	
					
					d._showNextMonths = false;
				}
				//设置showOtherMonths
				if( opt.showOtherMonths ) {
					if( i == 0 || i == last ) {
						d.showOtherMonths = true;
					} else {
						d.showOtherMonths = false;	
					}
				}
				
				var _item = $('#'+opt.id+'_item'+i);
				var part = self.Date.dateObject( d.currentDate );
				_item.attr('data-year',part['y+']);
				_item.attr('data-month',part['M+']);
				
				self.fireEvent('onBeforeCalendarItemCreate',[d,i,opt]);	
				self._setCalendarItemHeader( i,d )
					._setCalendarItemBody( i,d )
					._setCalendarItemFooter( i,d );
				self.fireEvent('onCalendarItemCreate',[_item,i,opt]);	
			}
			//items设置后 应该重新设置宽高
			if( !opt._isInit ) {
				self._refreshCalendarItemsSize();	
			}
			self._afterRenderItems();
			self.fireEvent('onCalendarItemsRender',[opt]);	
			return this;		
		},
		_currentDate : null,
		_afterRenderItems : function(){
			this._currentDate = this.Date.clone(this.getCurrentDate());
			this._refreshSelectDate();	
		},
		//刷新日期列表
		_refreshItems : function(){
			this._setCalendarItems();
			this._resizeAuto();	
		},
		/*
		*刷新日历
		*/
		refreshItems : function( m ){
			
			if( !m && this._currentDate ) {
				if( this._isEqualMonth( this._currentDate,this.getCurrentDate() ) ) {
					return this;	
				}	
			}
			
			this._refreshItems();
			this.fireEvent('onRefreshCalendarItems',[ this.configs ]);
			return this;	
		},
		refreshCalendar : function(m){
			return this.refreshItems( m );
		},
		//往后翻n月
		prevMonth : function( n ){
			var self = this,
				opt=this.configs;
			var n = self._undef(n,1);
			
			self.Date.add( opt.currentDate,'m',Math.abs(n)*-1 );
			
			self.refreshItems();
			return self;		
		},
		nextMonth : function( n ){
			var self = this,
				opt=this.configs;
			var n = self._undef(n,1);
				
			self.Date.add( opt.currentDate,'m',Math.abs(n));
			
			self.refreshItems();	
			return self;		
		},
		prevYear : function( n ){
			var self = this,
				opt=this.configs;
			var n = self._undef(n,1);
				
			self.Date.add( opt.currentDate,'y',Math.abs(n)*-1);
			
			self.refreshItems();	
			return self;		
		},
		nextYear : function( n ){
			var self = this,
				opt=this.configs;
			var n = self._undef(n,1);
				
			self.Date.add( opt.currentDate,'y',Math.abs(n));
			
			self.refreshItems();
			return self;			
		},
		/*IE6 7时使用*/
		_resizeAuto : function(){
			var self = this,
				opt=this.configs;
			if( Nex.IEVer == 6 || Nex.IEVer == 7 ) {	
				if( self.isAutoWidth() ) {
					var w = $('#'+opt.id+'_items_table')._width();
					self.getBody().width( w );
				}	
			}	
		},
		_isOutside : function( date ){
			var self = this,
				opt=this.configs;
			var num = opt.numberOfMonths;
			for( var i=0;i<num;i++ ) {
				var curr = self.Date.clone( opt.currentDate );
				if( !self._isOtherMonth( date,self.Date.add(curr,'m',i) ) ) {
					return false;	
				}	
			}	
			return true;
		},
		_onDateClick : function( date,t,e ){
			var self = this,
				opt=this.configs;
			//无效日期不可点击
			if( $(t).hasClass( 'nex-cal-date-disabled' ) ) {
				return;	
			}
				
			var r = self.fireEvent('onBeforeDateSelected',[date,t,e]);	
			if( r === false ) return;
			//如果日期是属于别的月份 且自动滚动日期 则自动切换日期
			if( self._isOutside( date ) && opt.autoChangeMonth ) {
				if( date>opt.currentDate ) {
					self.nextMonth();
				} else {
					self.prevMonth();	
				}
			}
			
			self.toggleSelectDate( date );	
		},
		_afterRender : function(){
			var opt = this.configs;
			this.fireEvent('onCalendarCreate',[ opt ]);	
			if( opt.autoShowymPickerIndex !== null && !isNaN( parseInt( opt.autoShowymPickerIndex, 10 ) ) ) {
				this.showYearMonthPicker( Math.min( opt.autoShowymPickerIndex,opt.numberOfMonths-1 ) );	
			}
		},
		_setHeightAuto : function(){
			var self = this;
			var opt = self.configs;	
			var views = opt.views;	
			var bd = self.getBody();
			var container = self.getContainer();
			container._removeStyle('height',true);
			if( bd ) {
				bd._removeStyle('height',true);	
			}
			$('.nex-cal-item-body',bd)._removeStyle('height',true);
		},
		_setWidthAuto : function(){
			var self = this;
			var opt = self.configs;	
			var views = opt.views;	
			var bd = self.getBody();
			var container = self.getContainer();
			container._removeStyle('width',true);
			if( bd ) {
				bd._removeStyle('width',true);	
			}
		},
		_setViewSize : function(){
			var self = this;
			var opt = self.configs;
			var container = self.getContainer();	
			if( !self.isAutoHeight() ) {
				container.removeClass('nex-cal-height-auto');
				var height = container._height() - self.headerEl._outerHeight() - self.footerEl._outerHeight();
				self.bodyEl._outerHeight( height );
			} else {
				container.addClass('nex-cal-height-auto');
			}
			if( !self.isAutoWidth() ) {
				container.removeClass('nex-cal-width-auto');
				self.bodyEl._outerWidth( container._width() );
			} else {
				container.addClass('nex-cal-width-auto');	
			}
			self._refreshCalendarItemsSize();
			return Nex.Html.fn._setViewSize.apply(self,arguments);	
		},
		/*设置items的的大小*/
		_refreshCalendarItemsSize : function(){
			var self = this;
			var opt = self.configs;		
			if( !self.isAutoHeight() ) {
				var bheight = self.bodyEl._height();
				//大部分浏览器td的div如果不给td设置宽度div的百分比设置无效。 chrome上就没问题
				$('.nex-cal-item-table-td,.nex-cal-item-split-td',self.bodyEl).each( function(){
					$(this)._outerHeight( bheight );
				} );	
				$('.nex-cal-item',self.bodyEl).each( function(){
					var $this = $(this);
					var height = $this._height() - $('>.nex-cal-item-header',$this)._outerHeight() - $('>.nex-cal-item-footer',$this)._outerHeight();	
					$('>.nex-cal-item-body',$this)._outerHeight(height);
				} );
			}
			if( !self.isAutoWidth() ) {
			}
			self.fireEvent('onSetCalendarItemsSize',[opt]);
			return self;
		},
		//刷新日期选中状态
		_refreshSelectDate : function(){
			var self = this;
			var opt = self.configs;
			var last = null;
			$.each( opt._selectDate,function(d,v){
				last = d;
				if( v && opt.multiSelect ) {
					self._selectDate( d,true  );	
				}	
			} );	
			if( !opt.multiSelect && last ) {
				self._selectDate( last,true  );	
			}
			return self;
		},
		/*
		*取消所有选中日期
		*/
		_unselectAll : function(){
			var self = this;
			var opt = self.configs;
			
			opt._selectDate = {};
			
			$('.nex-cal-date-selected',self.bodyEl).removeClass('nex-cal-date-selected');
			
			/*$.each( opt._selectDate,function(d,v){
				if( v ) {
					self._unselectDate( d,true  );	
				}	
			} );	*/
			return self;	
		},
		//判断是否已经被选中
		isSelected : function(date,m){
			var self = this;
			var opt = self.configs;
			
			var fmt = self._parseSDate( date,m );
			
			return opt._selectDate[ fmt ] ? true : false;	
		},
		/*
		*把日期转化成YYYYMMDD格式
		*/
		_parseSDate : function( date,m ){
			var self = this;
			var opt = self.configs;	
			var date = date || opt.currentDate;
			var _Date = self.Date;
			var fmt;
			if( m !== true ) {
				if( !_Date.isDate( date ) ) {
					date = _Date.strToDate( date,m );	
				}
				fmt = self.format(date,'YYYYMMDD');
			} else {
				fmt = date;	
			}
			return fmt;
		},
		/*
		*设置日期的选中状态 
		*@param date 日期对象或者YYYY-MM-DD格式的日期
		*/
		_selectDate : function( date,m ){
			var self = this;
			var opt = self.configs;
			
			var fmt = self._parseSDate( date,m );
			
			var id = opt.id+'_'+fmt;
			//单选
			if( !opt.multiSelect ) {
				self._unselectAll();	
			}
			
			$( '#'+id ).addClass('nex-cal-date-selected');
			
			opt._selectDate[ fmt ] = true;
			
			return date;
		},
		/*
		*设置日期的选中状态 
		*@param date 日期对象或者YYYY-MM-DD格式的日期
		*/
		_unselectDate : function( date,m ){
			var self = this;
			var opt = self.configs;
			
			var fmt = self._parseSDate( date,m );
			
			var id = opt.id+'_'+fmt;
			
			$( '#'+id ).removeClass('nex-cal-date-selected');
			
			opt._selectDate[ fmt ] = false;
			delete opt._selectDate[ fmt ];
			
			return date;
		},
		unselectAll : function(){
			var self = this;
			var r = this.fireEvent('onDateUnSelectedAll',[date,m,this.configs]);
			if( r === false ) return this;
			
			this._unselectAll();
			
			self.fireEvent('onDateChange',[this.getValue(),this.configs]);
			
			return this;	
		},
		unselectDate : function(date,m){
			var self = this;
			var r = this.fireEvent('onDateSelected',[date,m,this.configs]);
			if( r === false ) return this;
			
			this._unselectDate(date,m);
			
			self.fireEvent('onDateChange',[this.getValue(),this.configs]);
			
			return this;	
		},
		selectDate : function( date,m ){
			var self = this;
			var opt = self.configs;
			
			var r = self.fireEvent('onDateSelected',[date,m,opt]);
			if( r === false ) return self;
			
			self._selectDate(date,m);	
			
			self.fireEvent('onDateChange',[this.getValue(),opt]);
			
			return self;
		},
		toggleSelectDate : function( date,m ){
			var self = this;
			var opt = self.configs;
			
			var fmt = self._parseSDate( date,m );
			
			if( opt.multiSelect ) {
				if( self.isSelected( date,m ) ) {
					self.unselectDate( date,m );					
				} else {
					self.selectDate( date,m );					
				}
			} else {
				self.selectDate( date,m );					
			}
			return self;
		},
		/*
		*选择一段日期范围
		*/
		_selectDateRange : function( start, end ){
			var self = this;
			var opt = self.configs;	
			var undef;
			if( start === undef ) return self;
			
			end = end === undef ? start : end;
			
			start = self.Date.parseDate( start,opt.dateFormat );
			end = self.Date.parseDate( end,opt.dateFormat );
			
			var diff = self.Date.diff( start,end,'d' );
			
			start = self.Date.clone( start );
			end = self.Date.clone( end );
			//--	
			var _s,_e,_curr;
			_curr = self.getCurrentDate();
			_s = self.Date.clone( _curr );
			_s.setDate(1);
			self.Date.add(_s,'d',-7);
			_e = self.Date.clone( _s );
			_e = self.Date.add( _e,'d',42*opt.numberOfMonths );
			
			var isOutSide = function( date ){
				if( Math.abs( diff )<42*opt.numberOfMonths ) return false;
				if( date<_s ) return true;
				if( date>_e ) return true;	
				return false;
			};
			//--
			var curr = diff<0?end:start;
			for( var j=0;j<=Math.abs(diff);j++ ) {
				if( isOutSide( curr ) ) {
					opt._selectDate[ self.format( curr,'YYYYMMDD' ) ] = true;	
				} else {
					self._selectDate( curr );	
				}
				self.Date.add( curr,'d',1 );
			}
			
			return self;
		},
		selectDateRange : function( start,end ){
			var self = this;
			var opt = self.configs;	
			self._selectDateRange( start,end );
			self.fireEvent('onDateChange',[ this.getValue(),opt ]);
			self.fireEvent('onSelectDateRange',[ start,end,opt ]);
			return self;	
		},
		today : function(){
			this.goAndSelectDate( this.configs.systemDate );	
		},
		/*
		*翻到指定日历并选中
		*/
		goAndSelectDate : function(date,m){
			var self = this;
			var opt = self.configs;	
			self.selectDate( date );
			self.goToDate( date );
			return self;
		},
		/*
		*把日历翻到指定日期
		*/
		goToDate : function( date ){
			var self = this;
			var opt = self.configs;	
			
			opt.currentDate = self.Date.parseDate( date,opt.dateFormat );
			
			self.refreshItems();	
			return self;
		},
		//改变日历月份
		changeMonth : function( y,m ){
			var self = this;
			var opt = self.configs;	
			opt.currentDate.setFullYear( y );	
			opt.currentDate.setMonth( m-1 );	
			self.refreshItems();	
			return self;	
		},
		//改变年份月份
		changeYear : function( y ){
			var self = this;
			var opt = self.configs;	
			opt.currentDate.setFullYear( y );	
			self.refreshItems();	
			return self;		
		},
		/**
		* 设置默认选中日期,当前操作会重置已经选中的日期 如果只是选中日期 请使用selectDate
		*/
		setValue : function( value ){
			var self = this;
			var opt = self.configs;
			
			var argvs = [].slice.apply(arguments);
			
			self.fireEvent('onSetValue',[argvs]);
			
			self._parseValue( argvs[0] );
			self.refreshItems( true );
			return this;
		},
		setDate : function(){
			return this.setValue.apply( this,arguments );	
		},
		/*获取当前日期 根据dateFormat格式化*/
		getValue : function(){
			var self = this;
			var opt = self.configs;
			var sel = [];
			$.each( opt._selectDate,function(k,v){
				if( v ){
					var date = self.Date.parseDate(k,'YYYYMMDD');
					sel.push( self.format( date,opt.dateFormat ) );	
				}	
			} );
			
			var value = null;
			
			if( $.isFunction( opt.getFormater ) ) {
				var val = opt.getFormater.call( self,sel );
				value = val === undef ? value : val;
			} else {
				if( opt.multiSelect ) {
					value = sel;
				} else {
					value = sel[0];	
				}	
			}
			
			var _d = {
				value : value	
			};
			
			self.fireEvent('onGetValue',[ _d ]);
			
			return _d.value;
		},
		getStrValue : function(){
			var v = this.getValue();
			if( $.isArray( v ) ) {
				v = v.join( this.configs.sepStr );	
			}	
			return v;
		},
		getDate : function(){
			return this.getValue.apply( this,arguments );	
		},
		getStrDate : function(){
			return this.getStrValue.apply( this,arguments );	
		},
		initComponent : function(){
			Nex.Html.fn.initComponent.apply( this,arguments );
			this._resizeAuto();	//兼容IE67
		}
	});	
	cal.extend( Nex.util.Date );
	cal.setOptions(function(opt){
		return {
			prefix : 'nexcal-',
			autoScroll : false,
			//关闭默认事件
			denyEvents : 'focusin focusout focus blur scroll keydown keyup keypress mousewheel mouseover mouseout'.split(/\s+/),
			disabledItems : true,
			width : 'auto',
			height : 'auto',
			borderCls : opt.borderCls+' nex-calendar-border',
			containerCls : opt.containerCls+' nex-calendar',
			autoScrollCls : opt.autoScrollCls+' nex-calendar-auto-scroll',
			dateFormat : 'YYYY-MM-DD',
			sepStr : ',',//获取时设置分隔符
			//没用上
			dayNames: ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'],
			//没用上
			dayNamesShort: ['周日','周一','周二','周三','周四','周五','周六'],
			dayNamesMin: ['日','一','二','三','四','五','六'],
			weekHeader : '周',
			monthNames: ['一月','二月','三月','四月','五月','六月',
			'七月','八月','九月','十月','十一月','十二月'],
			//没用上
			monthNamesShort: ['一月','二月','三月','四月','五月','六月',
			'七月','八月','九月','十月','十一月','十二月'],
			prevMonthTitle:"上一月",
       		nextMonthTitle:"下一月",
			prevYearTitle:"上一年",
       		nextYearTitle:"下一年",
			firstDay: 0,//0~6 日~六
			weekIndex : 'firstDay',//默认是根据firstDay来当作是一周的开始计算日起 ，可自定义星期数 0~6
			//默认系统时间 默认取当前时间
			systemDate : null,
			//当前日历面板显示的月份
			//默认是取今天 或者value的值 如果value是数组则默认取最后一个值
			currentDate : null,
			//y m d w q  年 月 日 周 季度
			//默认显示到指定日期的月份
			//默认选中的日期 默认是当天
			_dateCalcReg : /([\-|\+]\d+)(y|m|d|w|q)/i,//匹配是否是 +1d -1d ...等格式
			value : '',//默认不设置选中日期  eg : '+1d' 0 [ '2014-08-09','+1d' ] 
			getFormater : null,
			setFormater : null,
			autoSelectToday : false,//默认选择今天
			//日期所选的日子
			_selectDate : {}, //默认是defaultDate 可以是是数组表示多个选中日期
			multiSelect : false, //是否可多选
			autoFillOthers : false,//自动填充不足日期的td，日期面板显示的长度是41个单元格 如果不足用空的td填充
			autoChangeMonth : true,//点击其他月份日期时会自动滚动指定月份
			//是否在当前面板显示上、下两个月的一些日期数
			showOtherMonths : true,
			_showPrevMonths : true,//显示上个月的日期
			_showNextMonths : true,//显示下个月的日期
			//板显示上、下两个月的一些日期数时 是否不可选
			otherMonthsDisabled : false,
			//是否显示周
			showWeek : false,
			showDateTips : true,
			dateTipsTag : 'title',
			dateTipsFormat : 'YYYY-MM-DD',
			dateTipsFilter : null,
			dateFilter : null,
			maxDate : null,//最大有效日期
			minDate : null,//最小有效日期
			disabledDate : [],//可以单独指定无效日期
			enabledDate   : [],//如果指定了一个无效范围，但是有个别日期是可选的，就需要使用这个参数
			numberOfMonths : 1,//默认显示多少个月
			topTitleFormat : 'YYYY年M月',
			topTitleFilter : null,
			showChangeMonthBtn : true,//显示 <  >
			_showChangeMonthPrevBtn : true,
			_showChangeMonthRightBtn : true,
			showChangeYearBtn : true,//显示 << >>
			_showChangeYearNextBtn : true,
			_showChangeYearRightBtn : true,
			ymChangeEnable : true,//可通过年月日选择框改变年月
			autoShowymPickerIndex : null,//默认展开第几个年月选择框 0~numberOfMonths-1 该数值
			ymPickerDuration : 100,
			ymPickerAnim : 'easeOutQuad',
			ymPickerAutoClose : true,//点击月份后 年月选择框会自动关闭
			yPickerDelay : 300,
			yPickerPoll  : 50,
			//调用顺序
			_initMethod : ['_initCalendar']
		};	
	});
});
$define(['Nex.date.Calendar','Nex.button.Button'],function(){
	var cal = Nex.define('Nex.date.DatePicker','Nex.date.Calendar',{
		xtype : 'datepicker',
		alias : 'Nex.DatePicker',
		/*
		*@private
		*/
		_setDatePickerCls : function(){
			var self = this;
			var opt = self.configs;
			opt.containerCls += " nex-datepicker-"+opt.display;
		},
		/*
		*@private
		*/
		_setAutoCloseYearMonthPicker : function(picker,i,opt){
			if( !opt.ymPickerAutoClose ) return;
			var self = this;
			var _id = opt.id+'_'+i;
			$(document).bind('mousewheel.cal_'+_id+' contextmenu.cal_'+_id+' mousedown.cal_'+_id,function(e){
				var target = e.target || e.srcElement;
				if( !$(target).closest( '#'+opt.id+'_item'+i ).size() ) {
					self.hideYearMonthPicker(i);		
				} 
			});
			$(window).bind('resize.cal_'+_id,function(){
				self.hideYearMonthPicker(i);			
			});		
		},
		/*
		*@private
		*/
		_unsetAutoCloseYearMonthPicker : function(picker,i,opt){
			if( !opt.ymPickerAutoClose ) return;
			var _id = opt.id+'_'+i;	
			$(document).unbind('.cal_'+_id);
			$(window).unbind('.cal_'+_id);	
		},
		/*
		*选中今天
		*/
		_selectToday : function(){
			this.selectDate( this.getSystemDate() );
			this.submit();
			this.hide();		
		},
		/*
		*@private
		*/
		_setFooterBtns : function( inner ){
			var self = this;
			var opt = self.configs;
			
			self.addComponent( opt.btns,inner );
			
			if( opt.showTodayBtn ) {
				Nex.Create('button',{
					text : opt.todayText,
					renderTo : inner,
					context : this,
					cls : 'nex-cal-btns nex-cal-today-btn',
					overCls : 'nex-cal-today-btn-over',
					pressedCls : 'nex-cal-today-btn-click',
					callBack : function(){
						this._selectToday();
					}
				});
			}
			if( opt.showCancelBtn ) {
				Nex.Create('button',{
					text : opt.cancelText,
					context : this,
					renderTo : inner,
					cls : 'nex-cal-btns nex-cal-cancel-btn',
					overCls : 'nex-cal-cancel-btn-over',
					pressedCls : 'nex-cal-cancel-btn-click',
					callBack : function(){
						this.hide();	
					}
				});
			}
			if( opt.showOkBtn ) {
				Nex.Create('button',{
					text : opt.okText,
					context : this,
					cls : 'nex-cal-btns nex-cal-ok-btn',
					overCls : 'nex-cal-ok-btn-over',
					pressedCls : 'nex-cal-ok-btn-click',
					renderTo : inner,
					callBack : function(){
						this.submit();	
						this.hide();	
					}
				});
			}
		},
		/**
		* 提交当前选中的日期 作用在于触发onSubmit
		*/
		"submit" : function(){
			var opt = this.configs;
			return this.fireEvent('onSubmit',[ opt.submitToString ? this.getStrValue() : this.getValue() ]);		
		},
		showPos : function( at ){
			var self = this;
			var opt = self.configs;
			var at = self._undef( at,{} );
			var showAt = $.extend({}, opt._showAt, opt.showAt,at );
			//console.log( showAt );
			this.show();
			self.getDom().showAt( showAt );		
		},
		initComponent : function(){
			Nex.date.Calendar.fn.initComponent.apply( this,arguments );	
			if( this.configs.display === 'absolute' ) {
				this.showPos();
			}
		},
		checkToSubmit : function(){
			var self = this;
			var opt = self.configs;
			if( opt.autoSubmit ) {
				var r = this.submit();
				r !== false ? this.hide() : '';	
			}	
		}
	});	
	cal.setOptions(function(opt){
		return {
			/*
			*@private
			*/
			'onStart._sys0001' : function(){
				this._setDatePickerCls();	
			},
			/*
			*@private
			*/
			'onCalendarFooterCreate._sys0001' : function( footer,opt ){
				var inner = $('<div id="'+opt.id+'_footer_inner" class="nex-cal-footer-inner"></div>');
				footer.append( inner );
				this._setFooterBtns( inner );
			},
			/*
			*@private
			*/
			'onYearMonthPickerShow._sys0001' : function( picker,i,opt ){
				this._setAutoCloseYearMonthPicker.apply( this,arguments );
			},
			/*
			*@private
			*/
			'onYearMonthPickerHide._sys0001' : function( picker,i,opt ){
				this._unsetAutoCloseYearMonthPicker.apply( this,arguments );
			},
			/*
			*@private
			*/
			'onDateClick._sys0001' : function(){
				this.checkToSubmit();
			},
			borderCls : opt.borderCls+' nex-datepicker-border',
			containerCls : opt.containerCls+' nex-datepicker',
			display : 'absolute',//position(指定位置显示) inline(平面显示)
			showAt : {},
			_showAt : {
				xAlign : 'left',
				yAlign : 'bottom'	
			},
			showOkBtn : false, 
			showCancelBtn : false,
			showTodayBtn : false,
			okText : '确定',
			cancelText : '取消',
			todayText : '今天',
			btns : [],
			submitToString : true,//通过onSubmit得到的date时是一个字符串 而不是一个数组
			autoSubmit : true//是否自动提交
		};	
	});
});
$define(['Nex.date.DatePicker'],function(){
	var cal = Nex.define('Nex.date.DateRangePicker','Nex.date.DatePicker',{
		xtype : 'daterangepicker',
		alias : 'Nex.DateRangePicker',
		/*
		*@private 继承
		*默认选中日期处理
		*/
		_parseValue : function( value ){
			var self = this,
				opt=this.configs;
			//var curr = opt.currentDate;
			var value = self._undef(value , opt.value);
			value = $.isArray( value ) ? value : ( value+'' ).split( opt.sepStr );
			
			if( value.length === 1 ) {
				value.push(value[0]);	
			}
			if( value.length>1 ) {
				value[1] = value[value.length-1];	
				value.length = 2;
			}
			
			//会触发onParseDefaultDate
			Nex.date.DatePicker.fn._parseValue.call( self,value );	
		},
		/*
		*@private
		*刷新日期选中状态
		*/
		_refreshSelectDate : function(){
			var self = this;
			var opt = self.configs;
			var first = null;
			var last = null;
			
			$.each( opt._selectDate,function(d,v){
				last = d;
				first = first ? first : d;
			} );
			
			if( !first ) return;
			
			self.selectDateRange( first,last );
				
			return self;
		},
		/*
		*@private
		*取消所有选中日期
		*/
		_unselectAll : function(){
			var self = this;
			var opt = self.configs;
			
			opt._selectDate = {};
			
			$('.nex-cal-date-selected',self.bodyEl).removeClass('nex-cal-date-selected nex-cal-date-start nex-cal-date-end nex-cal-date-dequal');
			
			return self;	
		},
		/*
		*@private
		*选择一段日期范围 
		*/
		_selectDateRange : function( start, end ){
			var self = this;
			var opt = self.configs;	
			var undef;
			if( start === undef ) return self;
			
			self._unselectAll();
			
			end = end === undef ? start : end;
			
			start = self.Date.parseDate( start,opt.dateFormat );
			end = self.Date.parseDate( end,opt.dateFormat );
			
			if( start > end ) {
				var _t = start;
				start = end;
				end = _t;	
			}
			
			Nex.date.DatePicker.fn._selectDateRange.call( self,start,end );
			
			var first = self.format( start,'YYYYMMDD' );
			var last = self.format( end,'YYYYMMDD' );
			
			if( first !== last ) {
				$('#'+opt.id+'_'+first).addClass('nex-cal-date-start');
				$('#'+opt.id+'_'+last).addClass('nex-cal-date-end');
			} else {
				$('#'+opt.id+'_'+first).addClass('nex-cal-date-dequal');		
			}
			
			opt._selectDate = {};
			opt._selectDate[first] = true;
			opt._selectDate[last] = true;
			
			return self;
		},
		//因为日期范围需要点击2次鼠标才算是选择结束
		_startDate : false,
		_endDate : false,
		_selectStart : function( start,m ){
			var self = this;
			var opt = self.configs;	
			
			start = self.Date.parseDate( start,m || opt.dateFormat );
			
			self._startDate = start;
			self._endDate = false;
			//清空之前选择的范围
			self._unselectAll();
			self._selectDate( start,m || opt.dateFormat );
			
			return self;
		},
		selectStart : function( start,m ){
			var self = this;
			var opt = self.configs;	
			self._selectStart( start,m );
			self.fireEvent('onSelectStart',[ start,m,opt ]);		
			return self;
		},
		_selectEnd : function( end,m ){
			var self = this;
			var opt = self.configs;	
			
			end = self.Date.parseDate( end,m || opt.dateFormat );
			
			self._endDate = end;	
			
			self.selectDateRange( self._startDate,self._endDate );
			
			self._startDate = false;
			self._endDate = false;
			
			return self;
		},
		selectEnd : function( end,m ){
			var self = this;
			var opt = self.configs;	
			self._selectEnd( end,m );
			self.fireEvent('onSelectEnd',[ end,m,opt ]);		
			return self;
		},
		_selectToday : function(){
			var date = this.getSystemDate();	
			this._selectStart( date );
			this._selectEnd( date );
			this.submit();
			this.hide();
		},
		//鼠标点击日期时选中日期 并检测是否需要自动提交
		toggleSelectDateRange : function( date ){
			var self = this;
			var opt = self.configs;	
			if( !self._startDate ) {
				self.selectStart( date );	
			} else {
				self.selectEnd( date );	
				//检测是否需要自动提交
				self.checkToSubmit();
			}
		},
		/*
		*@private
		*/
		_setDateRangePickerCls : function(){
			var self = this;
			var opt = self.configs;
			opt.containerCls += " nex-daterangepicker-"+opt.display;
		},
		_onDateClick : function( date,t,e ){
			var self = this,
				opt=this.configs;
			//无效日期不可点击
			if( $(t).hasClass( 'nex-cal-date-disabled' ) ) {
				return;	
			}
				
			var r = self.fireEvent('onBeforeDateSelected',[date,t,e]);	
			if( r === false ) return;
			//如果日期是属于别的月份 且自动滚动日期 则自动切换日期
			if( self._isOutside( date ) && opt.autoChangeMonth ) {
				if( date>opt.currentDate ) {
					self.nextMonth();
				} else {
					self.prevMonth();	
				}
			}
			
			self.toggleSelectDateRange( date );	
		}
	});	
	cal.setOptions(function(opt){
		return {
			/*
			*@private
			*/
			'onStart._sys0002' : function(){
				this.configs.multiSelect = true;
				this._setDateRangePickerCls();	
			},
			/*
			*@private 覆盖
			*/
			'onDateClick._sys0001' : function(){
				//不做处理
			},
			'onGetValue._sys0001' : function(d){
				var dates = d.value;
				if( $.isArray( dates ) ) {
					if( dates.length>1 ) {
						dates[1] = dates[dates.length-1];	
						dates.length = 2;
					}
					if( dates.length == 1 ) {
						dates.push( dates[0] );	
					}
				}
			},
			/*
			*@private 不可更改
			*/
			multiSelect : true,
			numberOfMonths : 2,
			sepStr : ' 至 '
			
		};	
	});
});
$define(['Nex.date.DateRangePicker'],function(){
	var cal = Nex.define('Nex.date.WeekPicker','Nex.date.DateRangePicker',{
		xtype : 'weekpicker',
		alias : 'Nex.WeekPicker',
		_getWeekRange : function( date ){
			var self = this;
			var opt = self.configs;	
			
			///date
			var day = date.getDay();
			day = day ? day : 7;
			
			var start = self.Date.add( date,'d',1-day );
			
			var end = self.Date.clone( start );
			
			end = self.Date.add( end,'d',6 );
			return [ start,end ];	
		},
		/*
		*@private 继承
		*默认选中日期处理
		*/
		_parseValue : function( value ){
			var self = this,
				opt=this.configs;
			var curr = opt.currentDate;
			var value = self._undef(value , opt.value);
			value = $.isArray( value ) ? value : ( value+'' ).split( opt.sepStr );
			
			if( value.length>1 ) {
				value[0] = value[value.length-1];	
				value.length = 1;
			}
			var date = null;
			if( value.length ) {
				date = self.__parse( value[0],curr );
			}
			
			if( date ) {
				value = self._getWeekRange( date );
			}
			
			//会触发onParseDefaultDate
			Nex.date.DatePicker.fn._parseValue.call( self,value );	
		},
		_selectToday : function(){
			var date = this.getSystemDate();	
			var range = this._getWeekRange( date );
			
			this._selectStart( range[0] );
			this._selectEnd( range[1] );	
			
			this.submit();
			this.hide();
		},
		//鼠标点击日期时选中日期 并检测是否需要自动提交
		toggleSelectDateRange : function( date ){
			var self = this;
			var opt = self.configs;	
			
			var range = self._getWeekRange( date );
			
			self.selectStart( range[0] );
			self.selectEnd( range[1] );	
			//检测是否需要自动提交
			self.checkToSubmit();
		}
	});	
	cal.setOptions(function(opt){
		return {
			numberOfMonths : 1
		};	
	});
});
/*
layout组件继承 html
author:nobo
zere.nobo@gmail.com
qq : 505931977
*/
;$define([
	'Nex.Html'
],function(){
	"use strict";
	var layout = Nex.extend('Nex.layout.Layout','Nex.Html',{
		alias : 'Nex.Layout',
		xtype : 'layout'		
	});
	
	layout.extend({
		version : '1.0',
		_Tpl : {				
		}
	});
	layout.setOptions(function( opt ){
		return {
			prefix : 'nexLayout-',
			autoDestroy : true,
			autoResize : true,
			_hasBodyView : false,
			_checkScrollBar : false,
			position : 'relative',
			renderTo: document.body,
			width : '100%',
			height : '100%',
			easing : 'easeOutCirc',
			layouts : ['north','south','west','east'],
			isCreate : false,
			closeTime : 300,
			cls : '',
			borderCls : [opt.borderCls,'nex-layout-border'].join(' '),
			containerCls : [opt.containerCls,'nex-layout nex-layout-wrap'].join(' '),
			autoScrollCls : '',
			autoScrollRegionCls : 'nex-layout-auto-scroll',
			borderRegionCls : 'nex-layout-region-border',
			cssText : '',
			style : {},//css
			bodyCls : '',
			bodyStyle : {},
			padding : null,
			dblclickToClose : true,
			_north : {
				handles : 's',
				"split" : true,
				splitBtn : true,
				splitSize : 5,
				resizable : true,
				isClosed : false,
				autoScroll : false,
				selectionable : true,
				border : true,
				borderCls : '',
				attrs : {},
				cls : '',
				clsText : '',
				style : {},//css
				padding : 0,
				html : '',
				items : [],
				maxSize : 0,//maxHeight 
				minSize : 28,//minHeight
				height : 80
			},
			_south : {
				handles : 'n',
				"split" : true,
				splitBtn : true,
				splitSize : 5,
				resizable : true,
				isClosed : false,
				autoScroll : false,
				selectionable : true,
				border : true,
				borderCls : '',
				attrs : {},
				cls : '',
				clsText : '',
				style : {},//css
				padding : 0,
				html : '',
				items : [],
				maxSize : 0,//maxHeight 
				minSize : 28,//minHeight
				height : 40
			},
			_east : {
				handles : 'w',
				"split" : true,
				splitBtn : true,
				splitSize : 5,
				resizable : true,
				isClosed : false,
				autoScroll : false,
				selectionable : true,
				border : true,
				borderCls : '',
				attrs : {},
				cls : '',
				clsText : '',
				style : {},//css
				padding : 0,
				html : '',
				items : [],
				maxSize : 0,//maxHeight 
				minSize : 28,//minHeight
				width : 80
			},
			_west : {
				handles : 'e',
				"split" : true,
				splitBtn : true,
				splitSize : 5,
				resizable : true,
				isClosed : false,
				autoScroll : false,
				selectionable : true,
				border : true,
				borderCls : '',
				attrs : {},
				cls : '',
				clsText : '',
				style : {},//css
				padding : 0,
				html : '',
				items : [],
				maxSize : 0,//maxHeight 
				minSize : 28,//minHeight
				width : 160
			},
			_center : {
				minWidth : 20,
				minHeight : 20,
				autoScroll : false,
				selectionable : true,
				border : true,
				borderCls : '',
				attrs : {},
				cls : '',
				clsText : '',
				style : {},//css
				padding : 0,
				html : '',
				items : []
			},
			maxWidth : 0,
			minWidth : 0,
			maxHeight : 0,
			minHeight : 0,
			dir : '',
			denyEvents : [ 'scroll' ],
			events : {
				onCreate : $.noop,
				onBeforeRegionCreate : $.noop,
				onRegionCreate : $.noop,
				onBeforeRegionRemove : $.noop,
				onRegionRemove : $.noop,
				onBeforeSplitDrag : $.noop,
				onSplitDrag : $.noop,
				onSplitStopDrag : $.noop
			}
		};	
	});
	layout.fn.extend({
		_init : function(opt) {
			var self = this;
			self.initOptions(opt);
			self.setContainer();
			self.setBody();
			self.initComponent();
		},
		initOptions : function(opt){
			var self = this;
			var regions =['north','south','west','east','center'];
			var cfs = {};
			for( var i=0;i<regions.length;i++ ) {
				var cf = {};
				var region = regions[i];
				$.extend(cf,opt['_'+region],opt[region] || {});
				cfs[region] = cf;
			}
			opt = $.extend(opt,cfs);
		},
		_setPadding : function(){
			var self = this,
				opt = self.configs;
			var bd = self.getContainer();
			if( opt.padding !== null ) {
				bd.css('padding',opt.padding);
			}
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return opt.views['body'];
		},
		setBody : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var bd = $( '<div class="nex-layout-container '+opt.bodyCls+'" id="'+opt.id+'_container" style=""></div>' );
			opt.views['body'] = bd;
			container.append(bd);
			//bd.css('padding',opt.padding);
			bd.css(opt.bodyStyle);
			//self.bindBodyEvents();	 
			self.fireEvent("onBodyCreate",[bd,opt]);
			return self;
		},
		getBodyWidth : function(){
			var vbody = this.getBody();
			return vbody.width();	
		},
		getBodyHeight : function(){
			var vbody = this.getBody();
			return vbody.height();	
		},
		initComponent : function(){
			var self = this;
			var opt = self.configs;	
			self.fireEvent('onInitComponent',[opt]);
			//初始是不应该触发onSizeChange事件
			self.lockEvent('onSizeChange');
			self.resetHtmlSize();
			self.unLockEvent('onSizeChange');
			
			self._createLayouts();
			
			self.fireEvent('onCreate',[opt]);
			opt._isInit = false;
		},
		//系统事件
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			Nex.Html.fn._sysEvents.apply(self,arguments);
			//self.bind("onRegionSizeChange",self.setExpandSize);	
			self.bind("onRegionCreate._sys",self.bindReginEvent,self);
		//	self.bind("onRegionCreate",self.onRegionCreate);
			//self.bind("onCreate",self.onCreate);	
			self.bind("onRegionCreate._sys",self.closeDefault,self);	
			self.bind("onSplitBtnClick._sys",self.splitClickToClose,self);
			self.bind("onSplitDblClick._sys",self.splitDblClickToClose,self);
			self.bind("onRegionCreate._sys",self.dragSplit,self);
		},
		dragSplit : function(region){
			var self = this,opt=this.C();
			var bar = $("#"+opt.id+"_"+region+"_split");
			if( !bar.length || !Nex.draggable ) return;
			
			if( !opt[region]['resizable'] ) return;
			
			var axis = 'h';
			var cursor = 'default';
			switch( region ) {
				case 'north':
				case 'south':
					axis = 'v';
					cursor = 'row-resize';
					break;
				case 'west':
				case 'east':
					axis = 'h';
					cursor = 'col-resize';
					break
			}
			
			var _setRegionSize = function(x,y){
				var _s = self.inArray(region,['north','south']) == -1 ? x : y;
				if( self.inArray(region,['east','south']) != -1 ) {
					_s *= -1; 	
				}
				var size = self._undef(opt[region]['height'],opt[region]['width']) + _s;
				size = size < 0 ? 0 : size;
				var layoutSize = {width:$("#"+opt.id+"_container").width(),height:$("#"+opt.id+"_container").height()};
				var maxHeight = 0,maxWidth = 0;
				switch( region ) {
					case 'south':
					case 'north':
						maxHeight = size + ( region==='south' ? opt['north']['height'] : opt['south']['height'] ) + opt['center']['minHeight'];
						if( maxHeight>=layoutSize.height ) {
							size -= maxHeight - layoutSize.height;
						}
						break;
					case 'west':
					case 'east':
						maxWidth = size + ( region==='west' ? opt['east']['width'] : opt['west']['width'] ) + opt['center']['minWidth'];
						if( maxWidth>=layoutSize.width ) {
							size -= maxWidth - layoutSize.width;
						}
						break;
				}
				self.setRegionSize(region,size);
				self.refresh();
			}
			
			Nex.Create('draggable',{
				helper : bar,
				axis :　axis,			 
				cursor : cursor,
				onBeforeDrag : function(e,ui){
					var self = this;
					var target = e.srcElement ? e.srcElement : e.target;
					if( !$(target).hasClass('nex-layout-split') ) return false;
					if( !opt[region]['resizable'] || opt[region]['isClosed'] ) {
						return false;	
					}
					var r = self.fireEvent('onBeforeSplitDrag',[ region,e,opt ]);
					if( r === false ) return f;
					
					$(bar).addClass('nex-split-drag');
					$(bar).css('zIndex',99999);
					
					var clone = $(bar).clone();	
					clone.attr('id','_dragSplit');
					clone.css('zIndex',-1);
					clone.addClass('nex-split-proxy-drag');
					clone.empty();
					$(bar).after(clone);
					
					self.__clone = clone;
				},
				onDrag : function(e,ui){
					var self = this;
					var r = self.fireEvent('onSplitDrag',[ region,ui,e,opt ]);
					if( r === false ) return r;
					//return false;	
				},
				//如果要用 onStopDrag 那么 就需要使用setTimeout来调用_setRegionSize和fireEvent(onSplitStopDrag)
				onAfterDrag : function(e,ui){
					var self = this;
					$(bar).removeClass('nex-split-drag');
					$(bar).css('zIndex',0);
					self.__clone.remove();
					_setRegionSize( ui.left - ui._sLeft,ui.top-ui._sTop );
					self.fireEvent('onSplitStopDrag',[ region,ui.left - ui._sLeft,ui.top-ui._sTop,ui,e,opt ]);
				}
			});
		},
		splitClickToClose : function(bar,region,e){
			var self = this;
			var opt = self.C();	
			if( opt[region]['isClosed'] ) {
				self.openRegion( region );	
			} else {
				self.closeRegion( region );	
			}		
		},
		splitDblClickToClose : function(bar,region,e){
			var self = this;
			var opt = self.C();	
			if( !opt.dblclickToClose ) return;
			if( opt[region]['isClosed'] ) {
				self.openRegion( region );	
			} else {
				self.closeRegion( region );	
			}
		},
		onCreate : function(){
			/*var self = this;
			var opt = self.configs;	
			var ename = "resize."+opt.id;
			$(window).unbind(ename);
			$(window).bind(ename,function(){
				self.resize();						  
			});*/
		},
		closeDefault : function(region,lbody){
			var self = this;
			var opt = self.C();	
			var rg = opt[region];
			if( region == 'center' ) return;
			if( rg['isClosed'] ) {
				self.closeRegion(region);	
			}
		},
		bindReginEvent : function(region,lbody){
			var self = this;
			var opt = self.configs;	
			if( !opt[region]['split'] ) return;
			var $split = $("#"+opt.id+"_"+region+"_split");
			var $split_i = $("#"+opt.id+"_"+region+"_split").find(">a.nex-layout-split-i");
			var callBack = function(type,e){
				var target = e.srcElement ? e.srcElement : e.target;
				if( !$(target).hasClass('nex-layout-split') ) return;
				var r = self.fireEvent(type,[ this,region,e ]);
				if( r === false ) return r;
				var r = self.fireEvent(type.replace('Split',self._toUpperCase(region)+'Split'),[ this,region,e ]);
				if( r === false ) return r;
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				}
			};
			var events = {
				'click' : function(e) {
					callBack.call(this,'onSplitClick',e);
				},
				'dblclick' : function(e) {
					callBack.call(this,'onSplitDblClick',e);
				},
				'keydown' : function(e) {
					callBack.call(this,'onSplitKeyDown',e);
				},
				'keyup' : function(e) {
					callBack.call(this,'onSplitKeyUp',e);
				},
				'keypress' : function(e){
					callBack.call(this,'onSplitKeyPress',e);
				},
				'mouseover' : function(e){
					callBack.call(this,'onSplitMouseOver',e);
				},
				'mouseout' : function(e){
					callBack.call(this,'onSplitMouseOut',e);
				},
				'mousedown' : function(e) {
					callBack.call(this,'onSplitMouseDown',e);
				},
				'mouseup' : function(e) {
					callBack.call(this,'onSplitMouseUp',e);
				},
				'contextmenu' : function(e){	
					callBack.call(this,'onSplitContextMenu',e);
				}
			};
			var callBack2 = function(type,e){
				var target = e.srcElement ? e.srcElement : e.target;
				if( !$(target).hasClass('nex-layout-split-i') ) return;
				var r = self.fireEvent(type,[ this,region,e ]);
				if( r === false ) return r;
				var r = self.fireEvent(type.replace('SplitBtn',self._toUpperCase(region)+'SplitBtn'),[ this,region,e ]);
				if( r === false ) return r;
				
				if( r === false ) {
					e.stopPropagation();
					e.preventDefault();
				}
				
			};
			var events2 = {
				'click' : function(e) {
					callBack2.call(this,'onSplitBtnClick',e);
				},
				'dblclick' : function(e) {
					callBack2.call(this,'onSplitBtnDblClick',e);
				},
				'keydown' : function(e) {
					callBack2.call(this,'onSplitBtnKeyDown',e);
				},
				'keyup' : function(e) {
					callBack2.call(this,'onSplitBtnKeyUp',e);
				},
				'keypress' : function(e){
					callBack2.call(this,'onSplitBtnKeyPress',e);
				},
				'mouseover' : function(e){
					callBack2.call(this,'onSplitBtnMouseOver',e);
				},
				'mouseout' : function(e){
					callBack2.call(this,'onSplitBtnMouseOut',e);
				},
				'mousedown' : function(e) {
					callBack2.call(this,'onSplitBtnMouseDown',e);
				},
				'mouseup' : function(e) {
					callBack2.call(this,'onSplitBtnMouseUp',e);
				},
				'contextmenu' : function(e){	
					callBack2.call(this,'onSplitBtnContextMenu',e);
				}
			};
			$split.bind(events);
			$split_i.bind(events2);
		},
		getRegion : function(region){
			var self = this;
			var opt = self.C();
			var $region = $("#"+opt.id+'_'+region);
			if( $region.size() ) {
				return  $region;	
			}
			return false;
		},
		getRegionBody : function(region){
			var self = this;
			var opt = self.C();
			var $region = $("#"+opt.id+'_'+region+'_body');
			if( $region.size() ) {
				return  $region;	
			}
			return false;
		},
		//设置 标题,collapsible宽度
		setExpandSize : function(region){
			var self = this;
			var opt = self.configs;	
			var $region = $("#"+opt.id+'_'+region);
			var h = 0;
			$(">div:not(div.nex-layout-body)",$region).each(function(){
				h += $(this)._outerHeight();												 
			});
			
			$("#"+opt.id+'_'+region+'_body')._outerWidth( $region._width() );
			$("#"+opt.id+'_'+region+'_body')._outerHeight( $region._height()-h );

		},
		getRegionSize : function(region,mod){
			var self = this;
			var opt = self.configs;
			
			var mod = self._undef( mod,true );
			
			var $region = opt[region].isClosed ? false : $("#"+opt.id+'_'+region);
			var size = 0;
			
			var $split = opt[region]['split'] ? $("#"+opt.id+'_'+region+'_split') : false;
			
			if( self.inArray( region,['north','south'] ) != -1 ) {
				size += $region ? $region._outerHeight() : 0;
				size += $split ? $split._outerHeight() : 0;
			} else if( self.inArray( region,['west','east'] ) != -1 ) {
				size += $region ? $region._outerWidth() : 0;
				size += $split ? $split._outerWidth() : 0;	
			}
			return size;
		},
		//设置region的大小 初始设置必须先设置 north,south 然后再设置 west,east
		setRegionSize : function(region,size,b){
			var self = this;
			var opt = self.configs;
			
			var b = self._undef( b,false );
			
			if( self.inArray( region,opt.layouts ) == -1 ) { 
				return self; 
			}
			
			var r = self.fireEvent('onBeforeRegionSizeChange',[region]);
			if( r===false ) return r;
			//var r = self.fireEvent('onBefore'+self._toUpperCase(region)+'SizeChange',[region]);
			//if( r===false ) return r;
			
			var layoutW = self.getBodyWidth();
			var layoutH = self.getBodyHeight();
			
			var isChange = false;
			
			if( self.inArray( region,['north','south'] ) != -1 ) {
				
				if( typeof size != 'undefined' ) {
					if( size == opt[region].height ) return false;
				}
				
				var size = size || opt[region].height;
				
				if( opt[region].minSize>0 ) {
					size = Math.max(size,opt[region].minSize);
				}
				if( opt[region].maxSize>0 ) {
					size = Math.min(size,opt[region].maxSize);
				}
				
				if( size != opt[region].height ) {
					isChange = true;
				}
				
				opt[region].height = size;
				var $region = $("#"+opt.id+'_'+region);
				$region._outerWidth( layoutW );
				$region._outerHeight( size );
				
				if( opt[region]['split'] ) {
					var $split = $("#"+opt.id+'_'+region+'_split');
					$split._outerWidth( layoutW );
					$split._outerHeight( opt[region]['splitSize'] );
				}
				
			} else if( self.inArray( region,['west','east'] ) != -1 ) {
				
				if( typeof size != 'undefined' ) {
					if( size == opt[region].width ) return false;
				}
				
				var size = size || opt[region].width;
				
				if( opt[region].minSize>0 ) {
					size = Math.max(size,opt[region].minSize);
				}
				if( opt[region].maxSize>0 ) {
					size = Math.min(size,opt[region].maxSize);
				}
				
				if( size != opt[region].width ) {
					isChange = true;
				}
				
				opt[region].width = size;
				var $region = $("#"+opt.id+'_'+region);
				
				var height = layoutH - self.getRegionSize('north',!b) - self.getRegionSize('south',!b);
				
				$region._outerHeight( height );
				$region._outerWidth( size );
				
				if( opt[region]['split'] ) {
					var $split = $("#"+opt.id+'_'+region+'_split');
					$split._outerWidth( opt[region]['splitSize'] );
					$split._outerHeight( height );
				}
				
			} else {//center
				region = 'center';
				var $region = $("#"+opt.id+'_'+region);	
				var w = $region.width();
				var h = $region.height();
				$region._outerWidth( layoutW-self.getRegionSize('west')-self.getRegionSize('east') );
				$region._outerHeight( layoutH-self.getRegionSize('north')-self.getRegionSize('south') );
				var _w = $region.width();
				var _h = $region.height();
				if( w != _w || h != _h ) {
					isChange = true;	
				}
			}
			
			self.setExpandSize(region);
			
			if(  isChange ) {
				self.fireEvent('onRegionSizeChange',[region]);
				//self.fireEvent('on'+self._toUpperCase(region)+'SizeChange',[opt]);
			}
			return true;
		},
		setRegionPos : function(region,mod){//mod  false 只设置split bar的位置 不设置region的
			var self = this;
			var opt = self.configs;
			if( self.inArray( region,opt.layouts ) == -1 ) { 
				return self; 
			}
			
			var r = self.fireEvent('onBeforeRegionPositionChange',[region]);
			if( r===false ) return r;
			
			var mod = self._undef( mod,true );
			
			var layoutW = self.getBodyWidth();
			var layoutH = self.getBodyHeight();
			
			if( self.inArray( region,['north','south'] ) != -1 ) {
				
				var left = 0,top = 0;
				
				var $region = $("#"+opt.id+'_'+region);
				
				var h=$region._outerHeight();
				
				var $region_h = opt[region].isClosed ?  0 :h ;
				
				var $split = opt[region]['split'] ? $("#"+opt.id+'_'+region+'_split') : false;
				
				if( region == 'north' ) {
					top = opt[region].isClosed ? -h : 0;
					if( mod ) {
						$region.css({
							left : left,
							top :　top,
							position : 'absolute'
						});	
					}
					if( $split ) {
						$split.css({
							left : left,
							top :　$region_h,
							position : 'absolute'
						});		
					}
				} else if( region == 'south' ) {
					top = opt[region].isClosed ? layoutH : layoutH - self.getRegionSize('south') + ($split?$split._outerHeight():0);
					if( $split ) {
						$split.css({
							left : left,
							top :　layoutH - self.getRegionSize('south'),
							position : 'absolute'
						});		
					}
					if( mod ) {
						$region.css({
							left : left,
							top :　top,
							position : 'absolute'
						});	
					}
				}
			} else if( self.inArray( region,['west','east'] ) != -1 ) {
				var left = 0,top = 0;
				
				var $region = $("#"+opt.id+'_'+region);
				
				var w = $region._outerWidth();
				
				var $region_w = opt[region].isClosed ? 0 : w;
				
				var $split = opt[region]['split'] ? $("#"+opt.id+'_'+region+'_split') : false;
				
				if( region == 'west' ) {
					left = opt[region].isClosed ? -w : 0;
					if( mod ) {
						$region.css({
							left : left,
							top :　self.getRegionSize('north'),
							position : 'absolute'
						});	
					}
					if( $split ) {
						$split.css({
							left : $region_w,
							top :　self.getRegionSize('north'),
							position : 'absolute'
						});		
					}
				} else if( region == 'east' ) {
					left = opt[region].isClosed ? layoutW : layoutW - self.getRegionSize('east') + ($split?$split._outerWidth():0);
					if( $split ) {
						$split.css({
							left :　layoutW - self.getRegionSize('east'),
							top :　self.getRegionSize('north'),
							position : 'absolute'
						});	
					}
					if( mod ) {
						$region.css({
							left :　left,
							top :　self.getRegionSize('north'),
							position : 'absolute'
						});	
					}
				}
			} else { //center
				region = 'center';
				var left = 0,top = 0;
				var $region = $("#"+opt.id+'_'+region);
				$region.css({
					left :　self.getRegionSize('west'),
					top :　self.getRegionSize('north'),
					position : 'absolute'
				});
			}
			self.fireEvent('onRegionPositionChange',[region]);
			return self
		},
		openRegion : function( region ){
			var self = this,undef;
			var opt = self.configs;
			
			if( region == 'center' ) {
				return self;	
			}
			
			var r = self.fireEvent('onBeforeOpenRegion',[region]);
			if( r === false ) return r;
			var r = self.fireEvent('onBefore'+ self._toUpperCase(region) +'Open',[]);
			if( r === false ) return r;
			
			var openCallBack = function(){
				self.refresh();
				self.fireEvent('onOpenRegion',[region]);	
				self.fireEvent('on'+ self._toUpperCase(region) +'Open',[]);
				//设置split bar css
				$("#"+opt.id+"_"+region+"_split").removeClass("nex-layout-split-closed nex-layout-"+region+"-split-closed");
			}
			
			opt[region]['isClosed'] = false;
			
			var layoutW = self.getBodyWidth();
			var layoutH = self.getBodyHeight();
			
			var $region = $("#"+opt.id+'_'+region);
			switch( region ) {
				case 'north' :
					$region.animate({
						top : 0			 
					},opt.closeTime,opt.easing,function(){
						openCallBack();
					});
					break;
				case 'south':
					$region.animate({
						top : layoutH-$region._outerHeight()				 
					},opt.closeTime,opt.easing,function(){
						openCallBack();
					});
					break;
				case 'west' :
					$region.animate({
						left : 0				 
					},opt.closeTime,opt.easing,function(){
						openCallBack();
					});
					break;
				case 'east':
					$region.animate({
						left : layoutW-$region._outerWidth()				 
					},opt.closeTime,opt.easing,function(){
						openCallBack();
					});
					break;
			}
		},
		closeRegion : function( region ){
			var self = this,undef;
			var opt = self.configs;
			
			if( region == 'center' ) {
				return self;	
			}
			
			var r = self.fireEvent('onBeforeCloseRegion',[region]);
			if( r === false ) return r;
			var r = self.fireEvent('onBefore'+ self._toUpperCase(region) +'Close',[]);
			if( r === false ) return r;
			
			var closeCallBack = function(){
				self.fireEvent('onCloseRegion',[region]);	
				self.fireEvent('on'+ self._toUpperCase(region) +'Close',[]);
				//设置split bar css
				$("#"+opt.id+"_"+region+"_split").addClass("nex-layout-split-closed nex-layout-"+region+"-split-closed");
			}
			
			opt[region]['isClosed'] = true;
			
			var layoutW = self.getBodyWidth();
			var layoutH = self.getBodyHeight();
			//剔除当前正关闭的region
			var regions =['north','south','west','east','center'];
			var pos = self.inArray( region,regions );
			if( pos !== -1 ) {
				regions.splice(pos,1);
			}
			
			self.refresh(regions);
			//只设置当前正在关闭的split bar
			self.setRegionPos(region,false);
			
			var $region = $("#"+opt.id+'_'+region);
			switch( region ) {
				case 'north' :
					$region.animate({
						top : -$region._outerHeight()				 
					},opt.closeTime,opt.easing,function(){
						closeCallBack();
					});
					break;
				case 'south':
					$region.animate({
						top : layoutH	 
					},opt.closeTime,opt.easing,function(){
						closeCallBack();
					});
					break;
				case 'west' :
					$region.animate({
						left : -$region._outerWidth()				 
					},opt.closeTime,opt.easing,function(){
						closeCallBack();
					});
					break;
				case 'east':
					$region.animate({
						left : layoutW		 
					},opt.closeTime,opt.easing,function(){
						closeCallBack();
					});
					break;
			}
			//self.fireEvent('onRegionSizeChange',[region]);
		},
		_appendContent : function(region,lbody){
			var self = this;
			var opt = self.C();	
			var lbody = lbody || $('#'+opt.id+'_'+region+'_body');
			//因为创建后立马写入内容，宽高都没设置，放到回调里
			var items = opt[region]['html'];
			self.addComponent( lbody,items );
			var items = opt[region]['items'];
			self.addComponent( lbody,items );
		},
		_createRegion : function( region ){
			var self = this;
			var opt = self.configs;
			
			if( $("#"+opt.id+'_'+region).size() ) {
				return false;	
			}
			
			var container = $("#"+opt.id+'_container');
			
			if( region =='center' ) {
				var ln = $('<div class="nex-layout-panel nex-layout-'+region+'" id="'+opt.id+'_'+region+'"></div>');
				container.append(ln);	
				
			} else {
				var ln = $('<div class="nex-layout-panel nex-layout-'+region+'" id="'+opt.id+'_'+region+'"></div>');
				container.append(ln);
				if( opt[region]['split'] ) {
					var lns = $('<div class="nex-layout-panel nex-layout-split nex-layout-'+region+'-split" id="'+opt.id+'_'+region+'_split"></div>');
					if( opt[region]['splitBtn'] ) {
						lns.append($('<a href="javascript:void(0)" class="nex-layout-split-i nex-layout-'+region+'-split-i"></a>'));
					}
					container.append(lns);
				}
			}
			var lbody = $('<div class="nex-layout-body '+( opt[region]['autoScroll'] ? opt.autoScrollRegionCls : '' )+' nex-layout-'+region+'-body '+opt[region]['cls']+'"  id="'+opt.id+'_'+region+'_body"></div>');
			
			lbody[0].style.cssText = opt[region]['cssText'];
			
			if( opt[region]['padding'] ) {
				lbody.css('padding',opt[region]['padding'])	;
			}
			lbody.attr(opt[region]['attrs']).css(opt[region]['style']);
			
			ln.append(lbody);
			
			if( opt[region]['border'] ) {
				ln.addClass( opt.borderRegionCls );	
				ln.addClass( opt[region]['borderCls'] );	
			}
			
			if( !opt.selectionable ) {	
				ln.disableSelection();	
			}
			
			return lbody;
		},
		_refresh : function(regions){
			var self = this;
			var opt = self.C();
			regions = regions || ['north','south','west','east','center'];
			for( var x=0;x<regions.length;x++ ) {
				self.setRegionSize( regions[x] );
				self.setRegionPos( regions[x]);	
			}
		},
		/*
		*更新region的大小以及位置 @regions需要更新的regions Array , @m 是否更新后触发onResize事件 默认 true , false不触发
		*/
		refresh : function( regions,m ){
			var self = this;
			var opt = self.configs;	
			var m = self._undef( m,true );
			var regions =regions || ['north','south','west','east','center'];
			
			self._refresh(regions);

			if( Nex.Manager && m ) {
				if( opt.__onresize ) {
					clearTimeout( opt.__onresize );	
				}
				opt.__onresize = setTimeout(function(){
					Nex.Manager.fireEvent("onResize",[opt.id]);		
				},0);
			}	
			
		},
		updateRegionSize : function( region,size ){
			var self = this;
			var opt = self.configs;	
			var r = self.setRegionSize( region,size );
			if( r === false ) return r;
			self.refresh();
		},
		/*
		*继承浏览器大小改变时 会调用
		*/
		_setViewSize : function(w,h){
			var self = this,
				opt = self.configs,
				container = self.getContainer(),
				vbody = self.getBody();
			
			vbody._outerWidth( container._width() );
			vbody._outerHeight( container._height() );
			
			self.fireEvent("onSetViewSize",[opt]);	
			
		},
		resetViewSize : function( func ){
			var self = this,
				opt = self.configs;	
			var callback = function(){
				if( !opt._isInit ) {
					self._refresh();//初始化时 这个不需要调用
				}	
				if( func && $.isFunction( func ) ) {
					func();	
				}
			};	
			Nex.Html.fn.resetViewSize.apply(self,[callback]);
			
			return self;
		},
		//首字母大写
		_toUpperCase : function(str){
				return str.replace(/\s[a-z]/g,function($1){return $1.toLocaleUpperCase()}).replace(/^[a-z]/,function($1){return $1.toLocaleUpperCase()});	
		},
		removeRegion : function(region){
			var self = this;
			var opt = self.C();
			var pos = self.inArray( region,opt.layouts );
			if( pos == -1 ) return true;
			
			var r = self.fireEvent('onBeforeRegionRemove',[region]);
			if( r === false ) return r;
			var r = self.fireEvent('onBefore'+_toUpperCase(region)+'Remove',[region]);
			if( r === false ) return r;
			
			var _toUpperCase = self._toUpperCase;
			
			opt.layouts.splice(pos,1);
			$("#"+opt.id+'_'+region).remove();
			$("#"+opt.id+'_'+region+'_split').remove();
			self.refresh();
			self.fireEvent('onRegionRemove',[region]);
			self.fireEvent('on'+_toUpperCase(region)+'Remove',[region]);
			
			return true;
		},
		createRegion : function( region,d ){
			var self = this;
			var opt = self.configs;
			var d = self._undef(d,{});
			
			var r = self.fireEvent('onBeforeRegionCreate',[region]);
			if( r === false ) return r;
			var r = self.fireEvent('onBefore'+_toUpperCase(region)+'Create',[region]);
			if( r === false ) return r;
			
			var _toUpperCase = self._toUpperCase;
			var $region = $("#"+opt.id+'_'+region);
			if( !$region.size() ) {
				opt.layouts.push( region );
				//添加数据
				$.extend(opt[region],d);
				
				var lbody = self._createRegion( region );
				//self.setRegionSize( region );	
				//self.setRegionPos( region  );	
				
				self.fireEvent('onRegionCreate',[region,lbody]);
				self.fireEvent('on'+_toUpperCase(region)+'Create',[region,lbody]);
				
				self.refresh();	
				//填入内容
				self._appendContent(region,lbody);
			}
			
			return true;
		},
		/*
		*初始化布局
		*/
		_createLayouts : function(){
			var self = this;
			var opt = self.configs;
			
			if( opt.isCreate ) return;
			
			opt.layouts.push('center');
			
			var _l = ['north','south','west','east','center'];
			var _lbody = {};
			//初始化region和大小以及位置
			for( var i=0;i<_l.length;i++ ) {
				if( self.inArray( _l[i],opt.layouts ) == -1 ) continue;
				var _lb = self._createRegion( _l[i] );	
				_lbody[ _l[i] ] = _lb;
				//初始化设置大小和位置 可以加isClosed = true的时候 才执行下面
				//layout 不占用太多性能 可不考虑
				self.denyEventInvoke( 'setRegionSize',_l[i] );
				self.denyEventInvoke( 'setRegionPos',_l[i] );	
			}
			
			for( var i=0;i<opt.layouts.length;i++ ) {
				self.fireEvent('onRegionCreate',[opt.layouts[i],_lbody[ opt.layouts[i] ]]);
				self.fireEvent('on'+self._toUpperCase(opt.layouts[i])+'Create',[opt.layouts[i],_lbody[ opt.layouts[i] ]]);
			}
			//初始化创建时 不应该触发regionResize事件
			self.denyEventInvoke( '_refresh' );
			//self._refresh();	
			
			for( var i=0;i<_l.length;i++ ) {	
				self._appendContent(_l[i],_lbody[ _l[i] ]);
			}
			opt.isCreate = true;
		},
		_insert : function( item , after , region ){
			var self = this;
			var opt = self.C();	
			var region = self._undef( region,'center' );
			var lbody = self.getRegionBody(region);
			if( !lbody ) return self;
			var list = self.addComponent( lbody,item,after );
			
			return list;
		},
		_empty : function( region ){
			var self = this;
			var opt = self.C();	
			var lbody = self.getRegionBody( region || 'center' );	
			if( !lbody ) return self;
			
			lbody.empty();
			
			var ls = Nex.Manager._getDomComps( lbody );
			$.each( ls,function(i,cmp){
				cmp.removeCmp();	
			} );
			
			return self;
		}
	});
});
/*
FileButton组件继承 Button
http://www.extgrid.com/button
author:nobo
zere.nobo@gmail.com
qq : 505931977
*/
;(function($){
	"use strict";
	var button = Nex.extend('Nex.button.FileButton','Nex.button.Button',{
		alias : 'Nex.FileButton',
		xtype : 'filebutton'	
	});
	button.extend({
		version : '1.0'
	});
	button.setOptions( function( opt ){
		return {
			name : 'file'//file时使用
		};						
	} );
	
	button.fn.extend({
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.bind("onCreate._sys_",self._setFile,self);
			self.bind("onSizeChange._sys_",self.resetFileSize,self);
			
			Nex.Button.fn._sysEvents.call( self );
			
			return self;
		},
		disabled : function( m ){
			var self = this,
				opt=this.configs,
				file = opt.views['file'],
				undef;
			var m = m === undef ? true : m;
			
			var r = Nex.Button.fn.disabled.call( self,m );
			
			if( file ) {
				if( m ) {
					file.attr('disabled',true);	
				} else {
					file.attr('disabled',false);		
				}
			}
			
			return r;
		},
		_isIE67 : function(){
			if(navigator.userAgent.indexOf("MSIE 6.0")>0) 
			{ 
				return true;
			} 
			else if(navigator.userAgent.indexOf("MSIE 7.0")>0)  
			{ 
				return true;
			} 
			return false;
		},
		resetFileSize : function(){
			var self = this;
			var opt = self.C();	
			var file = opt.views['file'];
			if( !file ) return self;
			file.height( self.getHeight() );	
			return self;
		},
		getFileName : function(){
			var self = this;
			var opt = self.C();	
			return opt.views['file'] ? opt.views['file'].val() : '';
		},
		_setFile : function(){
			var self = this;
			var opt = self.C();	
			
			var btn = self.getDom();
			var name = opt.name == '' ? opt.id+'_file' : opt.name;
			$('#'+opt.id+'_bf').remove();
			var file = $('<input id="'+opt.id+'_bf" hideFocus=true class="nex-btn-file-input" type="file" size="1" name="'+name+'" />');
			opt.views['file'] = file;
			
			var isIE67 = function(){
				if(navigator.userAgent.indexOf("MSIE 6.0")>0) 
				{ 
					return true;
				} 
				else if(navigator.userAgent.indexOf("MSIE 7.0")>0)  
				{ 
					return true;
				} 
				return false;
			}
			var h =  btn._height();
			if( isIE67() ) {
				btn.height( h );
			}
			btn.append( file );
			file.height( h );
			file.bind( 'change',function(e){
				self.fireEvent('onFileChange',[ this,$(this).val(),e ]);	
			} );
			return self;
		},
		resetFile : function(){
			return this._setFile();		
		}
	});
})(jQuery);
/*
FileButton组件继承 Button
http://www.extgrid.com/button
author:nobo
zere.nobo@gmail.com
qq : 505931977
*/
$define([
	'Nex.button.FileButton',
	'Nex.util.UploadFile'
],function(){
	"use strict";
	var button = Nex.extend('Nex.button.FileUploadButton','Nex.button.FileButton',{
		xtype : 'fileuploadbutton',
		alias : 'Nex.FileUploadButton'	
	});
	button.extend({
		version : '1.0'
	});
	button.setOptions( function( opt ){
		return {
			name : 'file',//$_FILES
			url : '', //提交地址
			data : {}
		};						
	} );
	
	button.fn.extend({
		_setFile : function(){
			var self = this;
			var opt = self.C();	
			
			var btn = self.getDom();
			var name = opt.name == '' ? opt.id+'_file' : opt.name;
			$('#'+opt.id+'_bf').remove();
			var _form = $('<form class="nex-btn-file-form" id="'+opt.id+'_btn_upload_form" action="'+opt.url+'" method="post" enctype="multipart/form-data"><input id="'+opt.id+'_bf" hideFocus=true class="nex-btn-file-input" type="file" size="1" name="'+name+'" /><div class="nex-btn-file-data" id="'+opt.id+'_file_data"></div></form>');
			opt.views['_form'] = _form;
			
			var isIE67 = function(){
				if(navigator.userAgent.indexOf("MSIE 6.0")>0) 
				{ 
					return true;
				} 
				else if(navigator.userAgent.indexOf("MSIE 7.0")>0)  
				{ 
					return true;
				} 
				return false;
			}
			var h =  btn._height();
			if( isIE67() ) {
				btn.height( h );
			}
			btn.append( _form );
			
			opt.views['file'] = $('#'+opt.id+'_bf');
			var file = opt.views['file']; 
			
			file.height( h );
			file.bind( 'change',function(e){
				self.fireEvent('onFileChange',[ this,$(this).val(),e ]);
				self.fireEvent('onSelect',[ $(this).val(),e ]);	
			} );
			return self;
		},
		setUploadUrl : function( url ){
			var self = this;
			var opt = self.C();	
			opt.url = url;
			$('#'+opt.id+'_btn_upload_form').attr('action',url);	
			
		},
		upload : function(){
			var self = this;
			var opt = self.C();	
			var fileData = $('#'+opt.id+'_file_data');
			
			var r = self.fireEvent('onUploadStart',[ opt.data ]);
			
			if( r === false ) return false;
			
			fileData.empty();
			
			var str = [];
			$.each( opt.data,function(k,v){
				str.push('<input type="hidden" name="'+k+'" value="'+v+'" />');	
			} );
			
			fileData.html( str.join('') );
			
			var uploader = Nex.getUtil('UploadFile');
			
			uploader.submit( document.getElementById(opt.id+'_btn_upload_form'),function(s){
					self.fireEvent('onUploadComplete',[ s ]);
					fileData.empty();	
				} );
				
		}
	});
});
/*
SplitButton组件继承 Button
http://www.extgrid.com/button
author:nobo
zere.nobo@gmail.com
qq : 505931977
*/
;(function($){
	"use strict";
	var button = Nex.extend('Nex.button.SplitButton','Nex.button.Button',{
		alias : 'Nex.SplitButton',
		xtype : 'splitbutton'		
	});
	button.extend({
		version : '1.0'
	});
	button.setOptions( function( opt ){
		return {
		};						
	} );
	
	button.fn.extend({
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			
			Nex.Button.fn._sysEvents.call( self );
			
			self.bind("onSplitBtnClick.menu",self._showSplitMenu,self);
			
			return self;
		},
		disabled : function( m ){
			var self = this,
				opt=this.configs,
				file = opt.views['file'],
				undef;
			var m = m === undef ? true : m;
			
			var r = Nex.Button.fn.disabled.call( self,m );
			
			if( file ) {
				if( m ) {
					file.attr('disabled',true);	
				} else {
					file.attr('disabled',false);		
				}
			}
			
			return r;
		}
		
	});
})(jQuery);
/*
SimpleTab.js
http://www.extgrid.com/tabs
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

*/

$define([
	'Nex.Html',
],function(){
	"use strict";
	var tab = Nex.extend('Nex.tab.SimpleTab','Nex.Html',{
		alias : 'Nex.SimpleTab',
		xtype : 'simpletab stab'		
	});
	tab.extend({
		version : '1.0',
		_Tpl : {}
	});
	tab.setOptions( function(opt){
		return {
			prefix : 'nexstab-',
			_initMethod : opt._initMethod.concat(['_initTabStart']),
			autoResize : true,
			renderTo : document.body,
			disabledItems : true,
			border : false,
			autoScroll : false,
			denyEvents : true,
			borderCls : [opt.borderCls,'nex-stab-border'].join(' '),
			containerCls : [opt.containerCls,'nex-stab'].join(' '),
			autoScrollCls : [opt.autoScrollCls,'nex-stab-auto-scroll'].join(' '),
			titleSelectionable : true,
			animate : false,//开启动画方式切入tab
			animateEasing : 'easeOutCirc',
			animateDuration : 200,
			showTabTips : false,//预留
			tabLayout : 'top',//top bottom
			forceFit : false,//tab header会自动分配列宽
			tabHeaderCls : '',
			tabBodyCls : '',
			width : '100%',
			height : '100%',
			lazyLoad : true,//切换Tab时才生成Tab内容
			titleFormat : null,//标题格式化
			_tabsData : function(){
				return {
					id : null,
					title : '',
					html : '',
					hcls : '',
					bcls : '',
					style : {},
					padding : null,
					autoShow : false,
					autoScroll : false,
					closeable : false,
					items : [],
					icon : '',
					iconCls : '',
					disabled : false
				}
			},
			defaults : {},
			items : [],
			views : {},
			cls : '',
			showOnType : 1,//0 mouseover 1 click 
			events : {
				onStart : $.noop,
				onCreate : $.noop,
				onSizeChange : $.noop,
				onViewSizeChange : $.noop,
				onDestroy : $.noop
			}
		};
	} );
	tab.fn.extend({
		_initTabStart : function(){
			var self = this;
			var opt = self.configs;
			opt.items = $.isArray(opt.items) ? opt.items.concat([]) : [];
			self._initTabsData()
				._setTabHeader()
				._setTabBody()
				._setTabEvents()
				._setTabLayout();	
		},
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.bind("onCreate._sys",self._initTab,self);
			self.bind("onTabClick._sys",self._clickToShow,self);
			self.bind("onTabOver._sys",self._setTabOverCls,self);
			self.bind("onTabOver._sys",self._overToShow,self);
			self.bind("onTabOut._sys",self._unsetTabOverCls,self);
			return self;
		},
		_parseTabData : function(d){
			var self = this;
			var opt = self.configs;	
			
			if( $.isPlainObject( d ) && d.__init ) {
				return d;	
			} 
			
			var d = $.extend({},opt._tabsData.call( self ),opt.defaults,d);
			if( d.id === null || d.id==="" || typeof d.id !== 'string' ) {
				d.id = 'tab_'+self.unique();	
			}
			d.__init = true;
			
			self._tabItems[d.id] = d;
			
			return d;
		},
		_tabItems : {},
		_initTabsData : function(){
			var self = this;
			var opt = self.configs;	
			self._tabItems = {};
			var tab = {};
			var len = opt.items.length;
			for( var i=0;i<len;i++ ) {
				var item = opt.items[i];
				tab = self._parseTabData( item );
				opt.items[i] = tab;
			}
			return self;
		},
		//设置items
		setItems : function( items ){
			var list = $.isArray(items) ? items.concat([]) : [];
			this.C( 'items',list );
			return this._initTabsData();	
		},
		getItems : function(){
			return this.configs.items;	
		},
		getItemData : function( id ){
			return this._tabItems[ id ];	
		},
		getTabData : function( id ){
			return this._tabItems[ id ];		
		},
		_setViewSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			var container = self.getContainer();	
			var header = $('#'+opt.id+'_tab_header');
			var header_inner = $('#'+opt.id+'_header_inner');
			var body = $('#'+opt.id+'_tab_body');
			var cw = container._width();
			var ch = container._height();
			if( !self.isAutoWidth() ) {
				header.width( cw );
				var hw = header._width();
				header_inner.width( hw );
				body._outerWidth( cw );
				//==========
				if( opt.forceFit ) {
					$('.nex-stab-header-wrap',header).width( hw );
				} else {
					$('.nex-stab-header-wrap',header)._removeStyle( 'width' );	
				}
				$('>.nex-stab-body-item',body)._outerWidth( body._width() );
			} else {
				header._removeStyle( 'width' );
				header_inner._removeStyle( 'width' );
				body._removeStyle( 'width' );
				if( opt.forceFit ) {
					$('.nex-stab-header-wrap',header)._removeStyle( 'width' );	
				}
				$('>.nex-stab-body-item',body)._removeStyle( 'width' );
			}
			if( !self.isAutoHeight() ) {
				var th = ch - header._outerHeight();
				body._outerHeight( th );
				$('>.nex-stab-body-item',body)._outerHeight( body._height() );
			} else {
				body._removeStyle( 'height' );		
				$('>.nex-stab-body-item',body)._removeStyle( 'height' );		
			}
			Nex.Html.fn._setViewSize.apply( self,arguments );
		},
		_clickToShow : function(tid,d,opt){
			var self = this;
			var opt = self.configs;
			if( opt.showOnType === 1 ) {
				self.switchTab(tid);	
			}
		},
		_overToShow : function(tid,d,opt){
			var self = this;
			var opt = self.configs;
			if( opt.showOnType === 0 ) {
				self.switchTab(tid);	
			}	
		},
		unselectHeader : function(){
			var self = this;
			var opt = self.configs;	
			opt.views['header'].bind('selectstart.tabs',function(){return false;});	
			return self;
		},
		/*
		*tabLayout top bottom
		*/
		_getTabHeaderInner : function( d ){
			var self = this;
			var opt = self.configs;	
			var html = [];
			
			var closeCls = d.closeable ? 'nex-stab-header-item-closeable' : '';
			var hasIcon = d.icon || d.iconCls ? true : false;
			var disabledCls = !d.disabled ? '' : 'nex-stab-header-item-disabled';
			html.push( '<td><div class="nex-stab-header-item '+ [disabledCls,closeCls,d.hcls].join(' ') +'" id="'+d.id+'_header" tid="'+d.id+'"><div class="nex-stab-item-inner">' );	
			if( $.isFunction(opt.titleFormat) ) {
				d.title = opt.titleFormat.call( self,d.title,d,opt );	
			}
			if( hasIcon ) {
				var style = d.icon ? ("background-image: url("+d.icon+")") : "";
				html.push( '<span class="nex-stab-item-icon '+d.iconCls+'" style="'+style+'"></span>' );	
			}
			html.push( '<span class="nex-stab-item-text">'+d.title+'</span>' );
			if( closeCls ) {
				html.push( '<a href="javascript:void(0);" class="nex-stab-item-close"></a>' );			
			}
			html.push( '</div></div></td>' );	
			
			return html.join('');	
		},
		_getTabHeader : function(){
			var self = this;
			var opt = self.configs;	
			var html = [
				'<div class="nex-stab-header '+opt.tabHeaderCls+'" id="'+opt.id+'_tab_header">',
					'<div id="'+opt.id+'_header_inner" class="nex-stab-header-inner">',//辅助作用
					'<table cellpadding="0" cellspacing="0" border="0" class="nex-stab-header-wrap">',
						'<tbody><tr id="'+opt.id+'_items_wraper">'
			];
			var items = opt.items;
			var len = items.length;
			
			for( var i=0;i<len;i++ ) {
				html.push( self._getTabHeaderInner( items[i] ) );
			}
			
			html.push( '</tr></tbody></table></div></div>' );
			return html.join('');
		},
		_setTabHeader : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var header = $( self._getTabHeader() );
			opt.views['header'] = header;
			container.append(header);
			if( !opt.titleSelectionable ) {
				header.disableSelection();	
			}
			self.fireEvent("onTabHeaderCreate",[header],opt);
			return self;
		},
		_getTabBody : function(){
			var self = this;
			var opt = self.configs;	
			return '<div class="nex-stab-body '+opt.tabBodyCls+'" id="'+opt.id+'_tab_body"></div>';
		},
		_setTabBody : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var bodys = $( self._getTabBody() );
			opt.views['body'] = bodys;
			container.append(bodys);
			self.fireEvent("onTabBodyCreate",[bodys],opt);
			
			return self;
		},
		_setTabEvents : function(){
			var self = this,
				opt=this.configs;
			var header = $('#'+opt.id+'_tab_header');
			var body = $('#'+opt.id+'_tab_body');		
			header.undelegate('._tab').delegate('.nex-stab-header-item',{
				'click._tab' : function(e){
					if( $(this).hasClass('nex-stab-header-item-disabled') ) {
						return;	
					}
					var tid = $(this).attr('tid');
					var data = self.getTabData( tid );
					self.fireEvent('onTabClick',[tid,data,opt]);	
				},
				'dblclick._tab' : function(e){
					if( $(this).hasClass('nex-stab-header-item-disabled') ) {
						return;	
					}
					var tid = $(this).attr('tid');
					var data = self.getTabData( tid );
					self.fireEvent('onTabDblClick',[tid,data,opt]);		
				},
				'mouseenter._tab' : function(e){
					if( $(this).hasClass('nex-stab-header-item-disabled') ) {
						return;	
					}
					var tid = $(this).attr('tid');
					var data = self.getTabData( tid );
					self.fireEvent('onTabOver',[tid,data,opt]);	
				},
				'mouseleave._tab' : function(e){
					if( $(this).hasClass('nex-stab-header-item-disabled') ) {
						return;	
					}
					var tid = $(this).attr('tid');
					var data = self.getTabData( tid );
					self.fireEvent('onTabOut',[tid,data,opt]);		
				}
			});
			
			header.undelegate('._tabc').delegate( '.nex-stab-item-close',{
				'click._tabc' : function(e){
					var $p = $(this).closest('.nex-stab-header-item');
					if( $p.hasClass('nex-stab-header-item-disabled') ) {
						return;	
					}
					
					var tid = $p.attr('tid');
					
					self.removeTab( tid );	
					
					e.preventDefault();
					e.stopPropagation();
				}	
			} );
			
			self.fireEvent("onSetTabEvents",[header,body,opt]);
			return self;
		},
		_setTabLayout : function(){
			var self = this;
			var opt=this.configs;
			
			var tabLayout = (opt.tabLayout+'').toLowerCase();
			opt.tabLayout = tabLayout;
			self._removeAlignCls();
			
			switch( tabLayout ) {
				case 'top' :
					self._setTopAlign();
					break;
				case 'bottom' :
					self._setBottomAlign();
					break;
				case 'right' :
					self._setRightAlign();
					break;	
				case 'left' :
					self._setLeftAlign();
					break;		
				default : 	
					self._setTopAlign();
					break;
			}
			
			return self;	
		},
		setTabLayout : function( align ){
			var self = this;
			var opt=this.configs;	
			
			var r = self.fireEvent("onBeforeTabLayoutChange",[align,opt]);
			if( r === false ) return r;
			
			opt.tabLayout = align;
			self._setTabLayout();
			
			self.fireEvent("onTabLayoutChange",[align,opt]);
			
			return self;
		},
		_removeAlignCls : function(){
			var self = this;
			var opt=this.configs;	
			var h = self.getTabHeader();
			var b = self.getTabBody();
			h.removeClass('nex-stab-header-top nex-stab-header-bottom nex-stab-header-right nex-stab-header-left');
			b.removeClass('nex-stab-body-top nex-stab-body-bottom nex-stab-body-right nex-stab-body-left');	
		},
		_setTopAlign : function(){
			var self = this;
			var opt=this.configs;	
			var h = self.getTabHeader();
			var b = self.getTabBody();
			h.addClass( 'nex-stab-header-top' );
			b.addClass( 'nex-stab-body-top' );
			b.before( h );
		},
		_setBottomAlign : function(){
			var self = this;
			var opt=this.configs;	
			var h = self.getTabHeader();
			var b = self.getTabBody();
			h.addClass( 'nex-stab-header-bottom' );
			b.addClass( 'nex-stab-body-bottom' );
			h.before( b );
		},
		_setTabOverCls : function( tid,data,opt ){
			var self = this;
			var tab = $('#'+tid+'_header');
			tab.addClass('nex-stab-header-item-over');
		},
		_unsetTabOverCls : function( tid,data,opt ){
			var self = this;
			var tab = $('#'+tid+'_header');
			tab.removeClass('nex-stab-header-item-over');
		},
		getTabHeader : function(){
			var opt=this.configs;	
			return $('#'+opt.id+'_tab_header');		
		},
		getTabBody : function(){
			var opt=this.configs;	
			return $('#'+opt.id+'_tab_body');		
		},
		getHeader : function(){
			return this.getTabHeader();	
		},
		getBody : function(){
			return this.getTabBody();
		},
		getTabItemHeader : function( tid ){
			return $('#'+tid+'_header');	
		},
		getTabItemBody : function( tid ){
			return $('#'+tid+'_body');			
		},
		/*
		*清空tab内容
		*/
		empytTabContent : function(tid){
			var self = this;
			var opt = self.C();		
			var tbody = $('#'+tid+'_body');
			tbody.empty();
			Nex.gc();
			return self;
		},
		/*
		*向tab追加内容
		*/
		addTabContent : function(tid,items){
			var self = this,undef;
			var opt = self.C();
			if( items === undef ) return;
			var tbody = $('#'+tid+'_body');
			if( tbody.length ) {
				self.addComponent( tbody,items );	
			}
			return self;
		},
		/*
		*更新指定tab的body大小
		*/
		_resizeTabItem : function( id ){
			var self = this,
				opt=this.configs,
				undef;
			var container = self.getContainer();	
			var header = $('#'+opt.id+'_tab_header');
			var body = $('#'+opt.id+'_tab_body');
			var tbd = $('#'+id+'_body');
			if( !self.isAutoWidth() ) {
				var cw = body._width();
				tbd._outerWidth( cw );
			} else {
				tbd._removeStyle( 'width' );
			}//nex-stab-header-item
			if( !self.isAutoHeight() ) {
				var th = body._height();
				tbd._outerHeight( th );
			} else {
				tbd._removeStyle( 'height' );			
			}	
			return self;
		},
		/*
		*创建指定的Tab内容
		*/
		_setTabBodyItem : function( tid ){
			var self = this,
				opt=this.configs;
			var data = self.getTabData( tid );
			if( !data ) return self;
			var body = $('#'+opt.id+'_tab_body');		
			
			if( $('#'+data.id+'_body').length ) {
				return self;	
			}
			
			var bd = $('<div class="'+['nex-stab-body-item',data.bcls].join(' ')+'" id="'+data.id+'_body" tid="'+data.id+'"></div>');		
			body.append(bd);
			if( data.padding && data.padding > 0 ) {
				bd.css( 'padding',data.padding );		
			}
			
			bd.css( data.style );
			
			if( data.autoScroll ) {
				bd.addClass('nex-stab-body-item-auto-scroll');	
			}
			
			self._resizeTabItem( tid );
			
			var items = data['html'];
			self.addComponent( bd,items );
			var items = data['items'];
			self.addComponent( bd,items );
			
			return self;
		},
		getCurrentTab : function(){
			var self = this,
				opt=this.configs;
			if( self._currentTab !== null ) {
				return 	self._currentTab;
			}
			var header = $('#'+opt.id+'_tab_header');
			
			var ls = $('.nex-stab-header-item-selected',header);
			if( ls.length ) {
				return ls.attr('tid');	
			}
			return null;
		},
		getActiveTab : function(){
			return this.getCurrentTab();	
		},
		_isAfterActiveTab : function( tid,otid ){
			var self = this,
				opt=this.configs;
			//默认是在后面的 after = true	
			var after = true;	
			var curr = otid;
			if( curr === null ) return after;
			if( tid === curr ) return after;
			
			$.each( opt.items,function( i,d ){
				//如果d.id == curr 先找到， 那么 tid就是在 curr后面 跳出循环 直接返回after
				if( d.id === curr ) {
					after = true;
					return false;	
				}
				//如果id == tid 那么先找到tid ，那就实在curr前面 跳出循环
				if( d.id === tid ) {
					after = false;
					return false;	
				}	
			} );	
			return after;
		},
		_checkToCreateTab : function( tid ){
			if( !$('#'+tid+'_body').length ) {
				this._setTabBodyItem( tid );	
			}
			return this;	
		},
		_currentTab : null,
		__zIndex : 2,
		_showTab : function( tid,fn ){
			var self = this,
				opt=this.configs;
			//检测tab内容是否创建	
			self._checkToCreateTab( tid );
			
			var bd = self.getBody();
			
			//otid
			var otid = self._currentTab;
			self._currentTab = tid;
				
			var h = $("#"+tid+'_header');
			var b = $('#'+tid+'_body');
			
			var w = bd.outerWidth();
			
			h.addClass('nex-stab-header-item-selected');	
			//动画执行后的回调
			var call = function(){
				if( $.isFunction( fn ) ) {
					fn();	
				}
				self._hideTab( otid );
				b.addClass( 'nex-stab-body-item-show' );	
				self.fireEvent('onShowTab',[ tid,opt ]);
			};
			
			var left = parseFloat(bd.css('paddingLeft'),10) || 0;
			var top = parseFloat(bd.css('paddingTop'),10) || 0;
			//检测当前tid和值钱的tid的位置 影响动画效果
			var isAfter = self._isAfterActiveTab( tid,otid );
			
			if( opt.animate ) {
				b.css({
					zIndex : self.__zIndex++,
					top : top,
					left : isAfter ? w : -w
				});		
				b.stop(true,true).animate( {
					left : left	
				},opt.animateDuration,opt.animateEasing,function(){
					call();	
				} );
			} else {
				b.css({
					zIndex : self.__zIndex++,
					left : left,
					top : top
				});	
				call();	
			}	
			
			return self;
		},
		_hideTab : function( tid,fn ){
			var self = this,
				opt=this.configs;
			var h = $("#"+tid+'_header');
			var b = $('#'+tid+'_body');	
			h.removeClass('nex-stab-header-item-selected');	
			
			b.removeClass('nex-stab-body-item-show')._removeStyle('left')._removeStyle('top')._removeStyle('z-index');
			
			if( $.isFunction( fn ) ) {
				fn();	
			}
			
			self.fireEvent('onHideTab',[ tid,opt ]);
			
			return self;		
		},
		_getTabItemsWrap : function(){
			var opt = this.configs;	
			return $('#'+opt.id+'_items_wraper');
		},
		/*动态添加Tab*/
		_addTab : function( d,after ){
			var self = this,
				opt=this.configs;
			var d = self._parseTabData( d );
			var after = self._undef( after,true );		
			
			var wrap = self._getTabItemsWrap();
			
			var item = $( self._getTabHeaderInner( d ) );
			if( after ) {
				opt.items.push( d );
				wrap.append( item );
			} else {
				opt.items.splice( 0,0,d );	
				wrap.prepend( item );
			}
			return d.id;
		},
		addTab : function( d,after ){
			var self = this,
				opt=this.configs;
			var html = after;
			var _d = {};
			if( !$.isPlainObject(d) ) {
				_d.title = String(d);	
				if( $.type(html) !== 'boolean' ) {
					_d.html = html;		
				}
			} else {
				_d = d;	
			}
			after = $.type(after) === 'boolean' ? after : true;
			
			var d = self._parseTabData( _d );		
				
			var r = self.fireEvent('onBeforeAddTab',[ d.id,d,opt ]);
			if( r === false ) return self;		
			
			self._addTab( d,after );
			
			if( d.autoShow ) {
				self.switchTab( d.id );	
			}
			
			self.fireEvent('onAddTab',[ d.id,d,opt ]);	
			
			return d.id;	
		},
		/*
		*移除指定tab
		*/
		_removeTab : function( tid ){
			var self = this,
				opt=this.configs;
			var tabs = opt.items;	
			var curr = self.getCurrentTab();
			var i = 0;
			var len = tabs.length;
			for( ;i<len;i++ ) {
				if( tabs[i]['disabled'] ) continue;
				if( tabs[i]['id'] == tid ) break;	
			}
			
			if( curr == tid ) {
				var t = i+1 > len-1 ? i-1 : i+1;
				if( tabs[t] && !tabs[t]['disabled'] ) {
					self.switchTab(tabs[t]['id']);	
				} else {
					self._currentTab = null;	
				}
			}
			
			self.empytTabContent( tid );
			
			var th = self.getTabItemHeader( tid );
			var tb = self.getTabItemBody( tid );	
			
			th.parent().remove();
			tb.remove();
			
			delete self._tabItems[tid];
			
			tabs.splice(i,1); 	
			
			return self;	
		},
		removeTab : function( tid ){
			var self = this,
				opt=this.configs;
			var d = self.getTabData( tid );
			
			if( !d ) return self;
		
			var r = self.fireEvent('onBeforeRemoveTab',[ tid,d,opt ]);
			if( r === false ) return self;		
			
			self._removeTab( tid );
			
			self.fireEvent('onRemoveTab',[ tid,d,opt ]);
			
			return self;
		},
		//删除多个Tab
		removeTabs : function( iarr ){
			var self = this,
				opt=this.configs;
			var tids = $.isArray(iarr) ? iarr : [iarr];
			var len = tids.length;
			if( !len ) {
				return self;	
			} 
			var curr = self.getCurrentTab();
			var lastId = null;
			for( var i=0;i<len;i++ ) {
				var tid = tids[i];
				if( tid == curr ) {
					lastId = tid;
					continue;	
				}	
				self.removeTab( tid );
			}
			if( lastId ) {
				self.removeTab( lastId );	
			}
			return self;				
		},
		closeTab : function( tid ){
			return this.removeTab( tid );	
		},
		/*
		*关闭所有标签
		*/
		removeAllTab : function(){
			var self = this,
				opt=this.configs;
			var tids = [];	
			$.each( opt.items,function(i,d){
				tids.push( d.id );
			} );	
			self.removeTabs( tids );
			return self;		
		},
		/*
		*关闭所有无效的tab
		*/
		removeAllDisabledTab : function(){
			var self = this,
				opt=this.configs;
			var tids = [];	
			$.each( opt.items,function(i,d){
				if( d.disabled ) {
					tids.push( d.id );
				}	
			} );	
			self.removeTabs( tids );
			return self;	
		},
		/*
		*关闭所有可关闭的标签
		*/
		removeAllCloseableTab : function(){
			var self = this,
				opt=this.configs;
			var tids = [];	
			$.each( opt.items,function(i,d){
				if( d.closeable ) {
					tids.push( d.id );
				}	
			} );	
			self.removeTabs( tids );
			return self;
		},
		switchTab : function(tid){
			var self = this,
				opt=this.configs;
				
			var ctid = self.getCurrentTab();
			if( ctid == tid ) {
				return true;	
			}
			
			var d = self.getTabData( tid );
			
			var r = self.fireEvent('onBeforeSwitchTab',[ tid, d ,opt ]);
			if( r === false ) return false;
			
			self._showTab( tid );
			
			self.fireEvent('onSwitchTab',[ tid, d ,opt ]);
			
			self.fireEvent('onTabChange',[ tid, d ,opt ]);
			
			return true;
		},
		_initTab : function(){
			var self = this,
				opt=this.configs;
			var items = opt.items;	
			var len = items.length;
			if( !opt.lazyLoad ) {
				for( var i=0;i<len;i++ ) {
					self._setTabBodyItem(items[i]['id']);	
				}
			}	
			self._showDefaultTab();
			return self;
		},
		switchFirstTab : function(){
			var self = this,
				opt=this.configs;
			var tabs = opt.items;
			
			if( !tabs.length ) return self;
			
			var tab = tabs[0];
			
			self.switchTab(tab['id']);
			
			return self;
		},
		switchLastTab : function(){
			var self = this,
				opt=this.configs;
			var tabs = opt.items;
			
			if( !tabs.length ) return self;
			
			var tab = tabs[tabs.length-1];
			
			self.switchTab(tab['id']);
			
			return self;
		},
		_showDefaultTab : function(){
			var self = this,
				opt=this.configs;
			var tabs = opt.items;
			if( !tabs.length ) return self;
 			var tid = null;	
			
			$.each( tabs,function(i,d){
				if( d.disabled ) return;
				if( tid === null ) {
					tid = d.id;	
				}
				if( d.autoShow ) {
					tid = d.id;	
				}	
			} );
			self._showTab(tid);
			return self;
		}
	});
});
/*
jquery.nexTabs.js
http://www.extgrid.com/tabs
author:nobo
qq:505931977
QQ交流群:13197510
email:zere.nobo@gmail.com or QQ邮箱

*/
$define([
	'Nex.tab.SimpleTab',
],function(){
	"use strict";
	var tab = Nex.extend('Nex.tab.Tab','Nex.tab.SimpleTab',{
		alias : 'Nex.Tab',
		xtype : 'tab'		
	});
	tab.extend({
		version : '1.0',
		_Tpl : {}
	});
	tab.setOptions( function(opt){
		return {
			prefix : 'nextab-',
			borderCls : [opt.borderCls,'nex-tab-border'].join(' '),
			containerCls : [opt.containerCls,'nex-tab'].join(' '),
			autoScrollCls : [opt.autoScrollCls,'nex-tab-auto-scroll'].join(' '),
			tabLayout   : 'top',//top bottom right left
			sideWidth   : 150,//tabLayout为right left 时的宽度
			forceFit    : false,//tab header会自动分配列宽
			tabHeaderCls: '',
			tabBodyCls  : '',
			tabScrollAnimate :　true,
			tabScrollDuration : 200,
			tabScrollEasing : 'easeOutQuad',
			scrollStep  : 100,
			scrollDelay : 100,
			scrollSpeed : 10
		};
	} );
	tab.fn.extend({
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			//必须要先执行---??
			self.bind("onCreate._sys",self._checkScroll,self);
			
			Nex.tab.SimpleTab.fn._sysEvents.apply( self,arguments );
			//检测是需要出现 left right 按钮
			self.bind("onAddTab._sys",self._checkScroll,self);
			self.bind("onRemoveTab._sys",self._checkScroll,self);
			//_checkScrollEdge 必须要在执行_checkScroll后才执行  因为需要检测scrollBar是否创建
			self.bind("onRemoveTab._sys",self._checkScrollEdge,self);
			self.bind("onAddTab._sys",self._isDisabledSTools,self);
			self.bind("onSwitchTab._sys",self.scrollToTab,self);
			self.bind("onTabLayoutChange._sys",self._refreshTabScrollBtn,self);
			self.bind("onSizeChange._sys",self._refreshTabScrollBtn,self);
			
			return self;
		},
		_setTabLayout : function(){
			var self = this;
			var opt=this.configs;
			
			Nex.tab.SimpleTab.fn._setTabLayout.apply( self,arguments );
			
			if( !self._isInit() ) {
				self.refreshViewSize();
			}
			
			return self;	
		},
		_setLeftAlign : function(){
			var self = this;
			var opt=this.configs;	
			var h = self.getTabHeader();
			var b = self.getTabBody();
			h.addClass( 'nex-stab-header-left' );
			b.addClass( 'nex-stab-body-left' );
		},
		_setRightAlign : function(){
			var self = this;
			var opt=this.configs;	
			var h = self.getTabHeader();
			var b = self.getTabBody();
			h.addClass( 'nex-stab-header-right' );
			b.addClass( 'nex-stab-body-right' );
		},
		//水平
		_setHLViewSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			var container = self.getContainer();	
			var header = $('#'+opt.id+'_tab_header');
			var header_inner = $('#'+opt.id+'_header_inner');
			var body = $('#'+opt.id+'_tab_body');
			var cw = container._width();
			var ch = container._height();
			
			header._removeStyle('width height left top right');
			header_inner._removeStyle('width height left top right');
			body._removeStyle('margin-left margin-right');
			
			var sideWidth = parseInt(opt.sideWidth,10);
			var bw = cw - sideWidth;
			
			header._outerWidth( sideWidth );
			header_inner._outerWidth( header._width() );
			
			header.css( {
				left : container.css('paddingLeft'),	
				top : container.css('paddingTop')
			} );
			
			body.css('marginLeft',sideWidth);
			
			if( !self.isAutoWidth() ) {
				body._outerWidth( bw );
				$('>.nex-stab-body-item',body)._outerWidth( body._width() );
			} else {
				body._removeStyle( 'width' );
				$('>.nex-stab-body-item',body)._removeStyle( 'width' );
			}
			if( !self.isAutoHeight() ) {
				header._outerHeight( ch );
				header_inner._outerHeight( header._height() );
				body._outerHeight( ch );
				$('>.nex-stab-body-item',body)._outerHeight( body._height() );
			} else {	
				header._removeStyle( 'height' );		
				header_inner._removeStyle( 'height' );	
				body._removeStyle( 'height' );		
				$('>.nex-stab-body-item',body)._removeStyle( 'height' );		
			}
		},
		_setHRViewSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			var container = self.getContainer();	
			var header = $('#'+opt.id+'_tab_header');
			var header_inner = $('#'+opt.id+'_header_inner');
			var body = $('#'+opt.id+'_tab_body');
			var cw = container._width();
			var ch = container._height();
			
			header._removeStyle('width height left top right');
			header_inner._removeStyle('width height left top right');
			body._removeStyle('margin-left margin-right');
			
			var sideWidth = parseInt(opt.sideWidth,10);
			var bw = cw - sideWidth;
			
			header._outerWidth( sideWidth );
			header_inner._outerWidth( header._width() );
			
			header.css( {
				right : container.css('paddingRight'),	
				top : container.css('paddingTop')
			} );
			
			body.css('marginRight',sideWidth);
			
			if( !self.isAutoWidth() ) {
				body._outerWidth( bw );
				$('>.nex-stab-body-item',body)._outerWidth( body._width() );
			} else {
				body._removeStyle( 'width' );
				$('>.nex-stab-body-item',body)._removeStyle( 'width' );
			}
			if( !self.isAutoHeight() ) {
				header._outerHeight( ch );
				header_inner._outerHeight( header._height() );
				body._outerHeight( ch );
				$('>.nex-stab-body-item',body)._outerHeight( body._height() );
			} else {	
				header._removeStyle( 'height' );		
				header_inner._removeStyle( 'height' );	
				body._removeStyle( 'height' );		
				$('>.nex-stab-body-item',body)._removeStyle( 'height' );		
			}
		},
		//垂直
		_setVViewSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			var container = self.getContainer();	
			var header = $('#'+opt.id+'_tab_header');
			var header_inner = $('#'+opt.id+'_header_inner');
			var body = $('#'+opt.id+'_tab_body');
			var cw = container._width();
			var ch = container._height();
			
			header._removeStyle('width height left top right');
			header_inner._removeStyle('width height left top right');
			body._removeStyle('margin-left margin-right');
			
			if( !self.isAutoWidth() ) {
				header._outerWidth( cw );
				var hw = header._width();
				header_inner._outerWidth( hw );
				body._outerWidth( cw );
				$('>.nex-stab-body-item',body)._outerWidth( body._width() );
			} else {
				header._removeStyle( 'width' );
				header_inner._removeStyle( 'width' );
				body._removeStyle( 'width' );
				$('>.nex-stab-body-item',body)._removeStyle( 'width' );
			}
			if( !self.isAutoHeight() ) {
				var th = ch - header._outerHeight();
				body._outerHeight( th );
				$('>.nex-stab-body-item',body)._outerHeight( body._height() );
			} else {
				body._removeStyle( 'height' );		
				$('>.nex-stab-body-item',body)._removeStyle( 'height' );		
			}
		},
		_setViewSize : function(){
			var self = this,
				opt=this.configs,
				undef;
			var tabLayout = (opt.tabLayout+'').toLowerCase();
			
			switch( tabLayout ) {
				case 'left':
					self._setHLViewSize();
					break;
				case 'right':
					self._setHRViewSize();
					break;
				default : 
					self._setVViewSize();
					break; 	
			};
				
			Nex.Html.fn._setViewSize.apply( self,arguments );
		},
		_getTabItemsWrap : function(){
			var opt = this.configs;	
			return $('#'+opt.id+'_items_t');
		},
		_getTabHeaderInner : function( d ){
			var self = this;
			var opt = self.configs;	
			var html = [];
			
			var closeCls = d.closeable ? 'nex-stab-header-item-closeable' : '';
			var hasIcon = d.icon || d.iconCls ? true : false;
			var disabledCls = !d.disabled ? '' : 'nex-stab-header-item-disabled';
			html.push( '<div class="nex-stab-header-item nex-tab-header-item '+ [disabledCls,closeCls,d.hcls].join(' ') +'" id="'+d.id+'_header" tid="'+d.id+'"><div class="nex-stab-item-inner">' );	
			if( $.isFunction(opt.titleFormat) ) {
				d.title = opt.titleFormat.call( self,d.title,d,opt );	
			}
			if( hasIcon ) {
				var style = d.icon ? ("background-image: url("+d.icon+")") : "";
				html.push( '<span class="nex-stab-item-icon '+d.iconCls+'" style="'+style+'"></span>' );	
			}
			html.push( '<span class="nex-stab-item-text">'+d.title+'</span>' );
			if( closeCls ) {
				html.push( '<a href="javascript:void(0);" class="nex-stab-item-close"></a>' );			
			}
			html.push( '</div></div>' );	
			
			return html.join('');	
		},
		_getTabTools : function(){
			var html = [];
			html.push('<div class="nex-tab-tool nex-tab-left"></div>');	
			html.push('<div class="nex-tab-tool nex-tab-right"></div>');	
			return html.join('');
		},
		_getTabHeader : function(){
			var self = this;
			var opt = self.configs;	
			var html = [
				'<div class="nex-stab-header nex-tab-header '+opt.tabHeaderCls+'" id="'+opt.id+'_tab_header">',
					'<div id="'+opt.id+'_header_inner" class="nex-stab-header-inner nex-tab-header-inner">',//辅助作用
					'<div id="'+opt.id+'_items_wraper" class="nex-stab-header-wrap nex-tab-header-wrap">',
					'<div id="'+opt.id+'_items_t" class="nex-tab-header-wrap-inner">'
			];
			var items = opt.items;
			var len = items.length;
			
			for( var i=0;i<len;i++ ) {
				html.push( self._getTabHeaderInner( items[i] ) );
			}
			
			html.push( '</div><div class="nex-tab-clear"></div></div>' );
			html.push( '<div id="'+opt.id+'_tools" class="nex-tab-tools clearFix">'+self._getTabTools()+'</div>' );
			html.push( '</div></div>' );
			return html.join('');
		},
		_setTabHeader : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var header = $( self._getTabHeader() );
			opt.views['header'] = header;
			container.append(header);
			if( !opt.titleSelectionable ) {
				header.disableSelection();	
			}
			self.fireEvent("onTabHeaderCreate",[header],opt);
			return self;
		},
		__scroll_t : 0,
		__scroll_t2 : 0,
		//重载
		_setTabEvents : function(){
			var self = this;
			var opt = self.configs;	
			
			Nex.tab.SimpleTab.fn._setTabEvents.apply(self,arguments);	
			var tool = $('#'+opt.id+'_tools');
			var header = $('#'+opt.id+'_tab_header');
			tool.disableSelection();
			header.undelegate('._tool')
			header.delegate('.nex-tab-left',{
				'click._tool' : function(e){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}
					var r = self.fireEvent('onTabLeftClick',[opt]);
					if( r !== false ) {
						self.scrollTabLeft();	
					}	
				},
				'mouseenter._tool' : function(e){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}
					self.fireEvent('onTabLeftOver',[opt]);	
				},
				'mouseleave._tool' : function(e){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}
					self.fireEvent('onTabLeftOut',[opt]);	
				},
				'mousedown._tool' : function(){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}	
					self.fireEvent('onTabLeftMouseDown',[opt]);	
					if( self.__scroll_t ){
						clearTimeout( self.__scroll_t );	
						clearTimeout( self.__scroll_t2 );	
						self.__scroll_t = 0;
						self.__scroll_t2 = 0;
					}
					//_getCurrentLeft
					self.__scroll_t = setTimeout(function(){
						self.__scroll_t2 = setInterval(function(){
							self._scrollTab( self._getCurrentLeft() + 10,false );
						},opt.scrollSpeed);
					},opt.scrollDelay);
					$(document).one('mouseup._tool',function(){
						clearTimeout( self.__scroll_t );	
						clearTimeout( self.__scroll_t2 );	
						self.__scroll_t = 0;
						self.__scroll_t2 = 0;
					});
				},
				'mouseup._tool' : function(){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}	
					self.fireEvent('onTabLeftMouseUp',[opt]);	
					clearTimeout( self.__scroll_t );	
					clearTimeout( self.__scroll_t2 );	
					self.__scroll_t = 0;
					self.__scroll_t2 = 0;
				}
			}).delegate('.nex-tab-right',{
				'click._tool' : function(e){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}
					var r = self.fireEvent('onTabRightClick',[opt]);	
					if( r !== false ) {
						self.scrollTabRight();	
					}	
				},
				'mouseenter._tool' : function(e){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}
					self.fireEvent('onTabRightOver',[opt]);	
				},
				'mouseleave._tool' : function(e){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}
					self.fireEvent('onTabRightOut',[opt]);	
				},
				'mousedown._tool' : function(){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}	
					self.fireEvent('onTabRightMouseDown',[opt]);	
					if( self.__scroll_t ){
						clearTimeout( self.__scroll_t );	
						clearTimeout( self.__scroll_t2 );	
						self.__scroll_t = 0;
						self.__scroll_t2 = 0;
					}
					//_getCurrentLeft
					self.__scroll_t = setTimeout(function(){
						self.__scroll_t2 = setInterval(function(){
							self._scrollTab( self._getCurrentLeft() - 10,false );
						},opt.scrollSpeed);
					},opt.scrollDelay);
					$(document).one('mouseup._tool',function(){
						clearTimeout( self.__scroll_t );	
						clearTimeout( self.__scroll_t2 );	
						self.__scroll_t = 0;
						self.__scroll_t2 = 0;
					});
				},
				'mouseup._tool' : function(){
					if( $(this).hasClass('nex-tab-tool-disabled') ) {
						return;	
					}	
					self.fireEvent('onTabRightMouseUp',[opt]);	
					clearTimeout( self.__scroll_t );	
					clearTimeout( self.__scroll_t2 );	
					self.__scroll_t = 0;
					self.__scroll_t2 = 0;
				}		
			});
		
			return this;
		},
		_getTabBody : function(){
			var self = this;
			var opt = self.configs;	
			return '<div class="nex-stab-body '+opt.tabBodyCls+'" id="'+opt.id+'_tab_body"></div>';
		},
		_setTabBody : function(){
			var self = this;
			var opt = self.configs;	
			var container = opt.views['container'];
			var bodys = $( self._getTabBody() );
			opt.views['body'] = bodys;
			container.append(bodys);
			self.fireEvent("onTabBodyCreate",[bodys],opt);
			
			return self;
		},
		_removeTab : function( tid ){
			var self = this,
				opt=this.configs;
			var tabs = opt.items;	
			var curr = self.getCurrentTab();
			var i = 0;
			var len = tabs.length;
			for( ;i<len;i++ ) {
				if( tabs[i]['disabled'] ) continue;
				if( tabs[i]['id'] == tid ) break;	
			}
			
			if( curr == tid ) {
				var t = i+1 > len-1 ? i-1 : i+1;
				if( tabs[t] && !tabs[t]['disabled'] ) {
					self.switchTab(tabs[t]['id']);	
				} else {
					self._currentTab = null;	
				}
			}
			
			self.empytTabContent( tid );
			
			var th = self.getTabItemHeader( tid );
			var tb = self.getTabItemBody( tid );	
			
			th.remove();
			tb.remove();
			
			delete self._tabItems[tid];
			
			tabs.splice(i,1); 	
			
			return self;	
		},
		_disabledTabLeft : function(){
			var self = this;
			var opt = self.C();
			var scrollBar = $('#'+opt.id+'_tools');	
			$('.nex-tab-left',scrollBar).addClass('nex-tab-tool-disabled');
		},
		_disabledTabRight : function(){
			var self = this;
			var opt = self.C();
			var scrollBar = $('#'+opt.id+'_tools');		
			$('.nex-tab-right',scrollBar).addClass('nex-tab-tool-disabled');
		},
		_enableTabLeft : function(){
			var self = this;
			var opt = self.C();
			var scrollBar = $('#'+opt.id+'_tools');	
			$('.nex-tab-left',scrollBar).removeClass('nex-tab-tool-disabled');
		},
		_enableTabRight : function(){
			var self = this;
			var opt = self.C();
			var scrollBar = $('#'+opt.id+'_tools');		
			$('.nex-tab-right',scrollBar).removeClass('nex-tab-tool-disabled');
		},
		/*
		*检测left right btn是否可以禁用
		*/
		_isDisabledSTools : function(){
			var self = this;
			var opt = self.configs;	
			
			if( opt.tabLayout !== 'top' && opt.tabLayout !== 'bottom' ) return;
				
			var wrap = $('#'+opt.id+'_header_inner');
			var scrollBar = $('#'+opt.id+'_tools');
			var ul = $('#'+opt.id+'_items_t');
			var left = 0;
			if( self.__lastLeft !== null ) {
				left = self.__lastLeft;
			} else {
				left = parseInt(ul.css('marginLeft'));
				left = isNaN( left ) ? 0 : left;
			}
			//left
			if( left>=0 ) {
				self._disabledTabLeft();	
			} else {
				self._enableTabLeft();		
			}
			//right
			var wrap_w = wrap.width()-scrollBar.outerWidth();
			var width = ul.outerWidth();
			var diff = wrap_w - width;
			diff = diff >= 0 ? 0 : diff;
			if( diff>=0 || Math.abs(left)>=Math.abs(diff) ) {
				self._disabledTabRight();		
			} else {
				self._enableTabRight();	
			}
		},
		/*
		*...
		*/
		__lastLeft : null,
		_scrollTab : function(left,func){
			var self = this;
			var opt = self.C();	
			
			if( opt.tabLayout !== 'top' && opt.tabLayout !== 'bottom' ) return;
			
			var ul = $('#'+opt.id+'_items_t');
			var wrap = $('#'+opt.id+'_header_inner');
			
			var wrap_w = wrap.width()- self._getScrollBarWidth();
			var width = ul.outerWidth();
			var diff = wrap_w - width;
			diff = diff >= 0 ? 0 : diff;
			
			left = left >= 0 ? 0 : left;
			left = Math.abs( left ) > Math.abs(diff) ? diff : left;
			
			if( self.__lastLeft !== null && self.__lastLeft === left ) {
				return self;	
			}
			
			self.__lastLeft = left;
			var ul = $('#'+opt.id+'_items_t');
			if( !opt.tabScrollAnimate || func === false ) {
				ul.css('marginLeft',left);	
			} else {
				ul.stop(true,true)
				  .animate({
						marginLeft : left	   
					},opt.tabScrollDuration,opt.tabScrollEasing,function(){
						if( $.isFunction( func ) ) {
							func.call(self);	
						}
					});
			}
			/*检测是否滚到到边缘*/	
			self._isDisabledSTools();
			return self;
		},
		_getCurrentLeft : function(){
			var self = this;
			var opt = self.configs;
			
			if( opt.tabLayout !== 'top' && opt.tabLayout !== 'bottom' ) return;
			
			if( self.__lastLeft !== null ) {
				return self.__lastLeft;	
			}
			
			var ul = $('#'+opt.id+'_items_t');	
			var left = ul.css('marginLeft');
			return isNaN( parseFloat( left ) ) ? 0 : parseFloat( left );
		},
		//水平
		_getScrollToTabPos1 : function( item,wrap,bd,pos ){
			var self = this;
			var opt = self.configs;
			
			//if( opt.tabLayout !== 'top' && opt.tabLayout !== 'bottom' ) return;
			
			var args = arguments;
			var _lp = args[ args.length-1 ];
			var wp = wrap || item.parent();
			var bd = bd;
			var f = item;
			var pos = !isNaN(parseInt( _lp )) ? parseInt( _lp ) : wp.css('marginLeft');
			var sLeft = 0;
			var _sLeft = pos;
			_sLeft = isNaN( parseFloat( _sLeft ) ) ? 0 : parseFloat( _sLeft );
			
			var offset = bd.offset();
			var borderWidth = parseInt(bd.css('borderLeftWidth')) || 0;
			var paddingLeft = parseInt(bd.css('paddingLeft')) || 0;
			//校正可视区域
			offset.left += borderWidth + paddingLeft;
			var w = bd.width() - self._getScrollBarWidth();
			
			var fo = f.offset();
			var fw = f.outerWidth();
			
			var outerWidth = 0;
			if( offset.left > fo.left ) {
				outerWidth = offset.left - fo.left;
			} else if( (offset.left+w) < (fo.left+fw) ) {
				outerWidth = (offset.left+w) - (fo.left+fw);
			}
			
			sLeft = _sLeft + outerWidth;
			
			return sLeft;	
		},
		//垂直
		_getScrollToTabPos2 : function( item,bd,pos ){
			var self = this;
			var opt = self.configs;
			
			var args = arguments;
			var _lp = args[ args.length-1 ];
			//var wp = wrap || item.parent();
			//var bd = bd;
			var f = item;
			var pos = !isNaN(parseInt( _lp )) ? parseInt( _lp ) : bd.scrollTop();
			var sTop = 0;
			var _sTop = pos;
			_sTop = isNaN( parseFloat( _sTop ) ) ? 0 : parseFloat( _sTop );
			
			var offset = bd.offset();
			var borderTop = parseInt(bd.css('borderTopWidth')) || 0;
			var paddingTop = parseInt(bd.css('paddingTop')) || 0;
			//校正可视区域
			offset.top += borderTop + paddingTop;
			
			var h = bd.height();
			
			var fo = f.offset();
			var fh = f.outerHeight();
		
			var outerHeight = 0;
			if( offset.top > fo.top ) {
				outerHeight = fo.top - offset.top;
			} else if( (offset.top+h) < (fo.top+fh) ) {
				outerHeight = (fo.top+fh) - (offset.top+h);
			}
			
			sTop = _sTop + outerHeight;
			
			return sTop;	
		},
		scrollToTab : function( tid ){
			var self = this;
			var opt = self.configs;
			
			if( !self._toolBarShow ) {
				return;	
			}
			
			var bd = $('#'+opt.id+'_header_inner');//nextab-7_header_inner
			var wrap = $('#'+opt.id+'_items_t');//_items_t	
			var item = $('#'+tid+'_header');
			if( !item.length ) return;
			var pos = 0;
			if( opt.tabLayout === 'top' || opt.tabLayout === 'bottom' ) {
				pos = self._getScrollToTabPos1( item,wrap,bd );
				self._scrollTab( pos );
			} else {
				var sTop = bd.scrollTop();
				pos = self._getScrollToTabPos2( item,bd,bd.scrollTop() );
				bd.scrollTop( Math.abs(pos) );
			}
		},
		scrollTabLeft : function(){
			var self = this;
			var opt = self.configs;
			
			if( !self._toolBarShow ) {
				return;	
			}
			
			if( opt.tabLayout !== 'top' && opt.tabLayout !== 'bottom' ) return;
			
			var ul = $('#'+opt.id+'_items_t');
			var left = ul.css('marginLeft');
			left = isNaN( parseFloat( left ) ) ? 0 : parseFloat( left );
			left += opt.scrollStep;
		
			self._scrollTab( left );
		},
		scrollTabRight : function(){
			var self = this;
			var opt = self.configs;
			
			if( !self._toolBarShow ) {
				return;	
			}
			
			if( opt.tabLayout !== 'top' && opt.tabLayout !== 'bottom' ) return;
			
			var ul = $('#'+opt.id+'_items_t');
			
			var left = ul.css('marginLeft');
			left = isNaN( parseFloat( left ) ) ? 0 : parseFloat( left );
			
			left -= opt.scrollStep;
			
			self._scrollTab( left );
		},
		//vertical horizontal
		_getTabCast : function(){
			var self = this;
			var opt = self.configs;	
			if( opt.tabLayout === 'top' || opt.tabLayout === 'bottom' ) {
				return 'horizontal';	
			} else {
				return 'vertical';		
			}	
		},
		/*
		*检测tab选项卡是否需要添加滚动按钮 只支持top bottom
		*/
		_toolBarShow : false,
		_checkScroll : function(){
			var self = this;
			var opt = self.configs;	
			
			var inner_header = $('#'+opt.id+'_header_inner');//nextab-7_header_inner
			var inner_items = $('#'+opt.id+'_items_t');//_items_t
			
			var isScroll = false;
			var cast = self._getTabCast();
			if( cast === 'horizontal' ) {
				isScroll = inner_header._width() > inner_items._width() ? false : true;
			} else {
				isScroll = inner_header._height() > inner_items._height() ? false : true;	
			}
			
			self._toolBarShow = isScroll;
		
			if( cast !== 'horizontal' ) return self;
			
			var scrollBar = $('#'+opt.id+'_tools');
			
			if( isScroll ) {
				scrollBar.stop(true,true).fadeIn();
			} else {
				scrollBar.stop(true,true).fadeOut();
			}
			return self;
		},
		_getScrollTools : function(){
			var opt = this.configs;		
			return $('#'+opt.id+'_tools');
		},
		_getScrollBarWidth : function(){
			var opt = this.configs;	
			if( this._toolBarShow )	{
				return $('#'+opt.id+'_tools').outerWidth();	
			}
			return 0;
		},
		/*删除tab时 会自动滚动到边缘 防止删除最后的tab而不会自动滚动*/
		_checkScrollEdge : function(){
			var self = this;
			var opt = self.C();	
			if( opt.tabLayout !== 'top' && opt.tabLayout !== 'bottom' ) return;
			var inner_header = $('#'+opt.id+'_header_inner');//nextab-7_header_inner
			var inner_items = $('#'+opt.id+'_items_t');//_items_t
			var wrap_w = inner_header._width()-self._getScrollBarWidth();
			var items_w = inner_items.outerWidth();
			var ml = parseInt(inner_items.css('marginLeft'));
			ml = isNaN( ml ) ? 0 : ml;
			var visible_w = items_w - Math.abs( ml );
			var diff = wrap_w - visible_w;	
			var left = ml + diff;
			left = left > 0 ? 0 : left;
			if( diff>=0 ) {
				self._scrollTab( left );
			}
		},
		_refreshTabScrollBtn : function( align ){
			var cast = this._getTabCast();
			if( cast !== 'horizontal' ) {
				var tools = this._getScrollTools();
				tools.stop(true,true).fadeOut();
			}
			this._checkScroll();
			this._checkScrollEdge();
			this.scrollToTab( this.getCurrentTab() );		
		}
	});
});
/*
Nex.TableLayout组件说明：
组件名称       : Nex.TableLayout 可通过 new Nex.TableLayout() 或者 Nex.Create('Nex.TableLayout') 来创建
组件别名xtype  : tablelayout  可通过Nex.Create('tablelayout')
加载名称       : Nex.Html 组件存放目录结构 {{nex目录}}/Html.js
eg:
items : [
		[1,2,{ items : { xtype:'html',html:'3232' },width : 100,height:100 }],
		['a','b','c']
	]
defaults : rowspan 	colspan width height align valign items
*/
;$define([
	'Nex.Html'
],function(){
	"use strict";
	//var tablelayout = Nex.extend('Nex.TableLayout','Nex.Html').setXType('tablelayout');
	var tablelayout = Nex.extend('Nex.tableLayout.TableLayout','Nex.Html',{
		alias : 'Nex.TableLayout',
		xtype : 'tablelayout tableLayout'		
	});
	tablelayout.extend({
		version : '1.0',
		_Tpl : {}
	});
	tablelayout.setOptions(function(opt,t){
		return {
			prefix : 'nexTL-',
			tag : 'div',
			autoDestroy : true,
			autoScroll : false,
			autoResize : true,
			selectionable : true,
			_checkScrollBar : false,//检查是否出现滚动条 如果出现会触发onViewSizeChange
			_hasBodyView : false,//是否有view部分 html 没有这部分 应该关闭 提高效率
			width : '100%',// 设为auto后 大小将不会设置 宽度 高度都是auto 或者css控制的,设为0 相当于100% 
			height : 'auto',
			border : false,
			tableCls : '',
			autoWidthCls : [opt.autoWidthCls,'nex-tablelayout-auto-width'].join(' '),
			autoHeightCls : [opt.autoHeightCls,'nex-tablelayout-auto-height'].join(' '),
			borderCls : [opt.borderCls,'nex-tablelayout-border'].join(' '),
			containerCls : [opt.containerCls,'nex-tablelayout'].join(' '),
			autoScrollCls : [opt.autoScrollCls,'nex-tablelayout-auto-scroll'].join(' '),
			padding : 0,
			style : {},
			'class' : '',
			align : 'center',
			valign : 'middle',
			rowsData : [],//所有单元格源数据
			defaults : {},
			items : [],
			denyEvents : [ 'scroll' ],
			events : {
				onStart : $.noop,
				onCreate : $.noop,
				onInitComponent : $.noop,
				onSetContainerSize : $.noop,
				onSizeChange : $.noop,
				onSetContainerEvent : $.noop
			}
		};	
	});
	tablelayout.fn.extend({
		_sysEvents : function(){
			var self = this;
			var opt = self.configs;
			Nex.Html.fn._sysEvents.apply(self,arguments);
			//self.bind("onSetLayout",self._setPadding2,self);
			//self.bind("onCreate",self.setTableCellData,self);
			return self;
		},
		_setPadding : function(){
			//...
		},
		_setPadding2 : function(){
			var self = this,
				opt = self.configs;
			var w = self.getContainer();
			if( opt.padding ) {
				$('.nex-tablelayout-cell[tableid="'+opt.id+'"]',w).css('padding',opt.padding);
			}
		},
		initComponent : function(func){
			var self = this;
			var opt = self.configs;	
			
			var _init = function(){
				self.fireEvent('onTableLayoutCreate',[opt]);
				if( $.isFunction( func ) ) {
					func.call(self);		
				}
				self.setTableCellData();
			};
			
			Nex.Html.fn.initComponent.apply(self,[_init]);
			
		},
		_appendContent : function(){
			var self = this;
			var opt = self.C();	
			var lbody = self.getContainer();
			self.setLayout();
			self.setTableCellSize();
			return lbody;
		},
		setTableCellData : function(){
			var self = this,
				opt = self.C();
			$.each( opt.rowsData,function(i,cells){
				$.each( cells,function(j,cell){
					var $cell = $(['#',opt.id,'_',i,'_',j].join(''));	
					//if( cell ) {
						if( cell.items === '' 
							|| $.type( cell.items ) === 'boolean' 
							|| $.type( cell.items ) === 'null' 
							|| $.type( cell.items ) === 'undefined' 
						  ) {
							$cell.html('&nbsp;');
						} else {
						
						$cell.empty();
						//if( $.isPlainObject( cell ) ) {
							if( cell.items ) {
								self.addComponent( $cell,cell.items );
							}
						//}
						
						}
					//}
					self.fireEvent('onSetCellData',[ $cell,i,j,cell ]);
				} );							  
			} );	
			return self;	
		},
		setTableCellSize : function(){
			var self = this,
				opt = self.C();
			$.each( opt.rowsData,function(i,cells){
				$.each( cells,function(j,cell){
					var $cell = $(['#',opt.id,'_',i,'_',j].join(''));	
					if( $.isPlainObject( cell ) && !$.isEmptyObject( cell ) ) {
						if( cell.width ) {
							var w = cell.width+'';
							if( w.indexOf('%') !== -1 ) {
								$cell.css('width',w);	
							} else {
								$cell._outerWidth( parseFloat( w ) );	
							}
						}	
						if( cell.height ) {
							var h = cell.height+'';
							if( w.indexOf('%') !== -1 ) {
								$cell.css('height',h);	
							} else {
								$cell._outerHeight( parseFloat( h ) );	
							}
						}	
					}
					self.fireEvent('onSetCellSize',[ $cell,i,j,cell ]);
				} );							  
			} );	
			return self;
		},
		createTable : function(items){
			var self = this,
				opt = self.C(),
				items = self._undef( items,[] );
			if( $.isFunction( items ) ) {
				items = items.call( self,opt );
			}	
			var items = $.isArray( items ) ? items : [items];
			
			var html = [
					'<table id="',opt.id,'_table" class="nex-tablelayout-table ',opt.tableCls,'" cellpadding="0" cellspacing="0" border="0">',
						'<tbody id="',opt.id,'_tbody">'
				];
			for( var i=0,len=items.length;i<len;i++ ) {
				var row = items[i];
				if( row === '' 
				   	|| $.type( row ) === 'boolean' 
					|| $.type( row ) === 'null' 
					|| $.type( row ) === 'undefined' 
				  ) {
					continue;	
				}
				html.push('<tr id="'+opt.id+'_'+i+'" class="nex-tablelayout-row">');
				html.push( self.createTableRow( i,row ) );
				html.push('</tr>');
			}
			
			html.push('</tbody>');
			html.push('</table>')
			return html.join('');
		},
		createTableRow : function( rid,rwos ){
			var self = this,
				opt = self.C(),
				rwos = self._undef( rwos,[] );
			if( $.isFunction( rwos ) ) {
				rwos  = rwos.call( self,opt );
			}	
			var html = [];
			var rwos = $.isArray( rwos ) ? rwos : [rwos];	
			for( var i=0,len=rwos.length;i<len;i++ ) {
				var cell = rwos[i];
				
				if( !$._isPlainObject( cell ) || Nex.isXtype( cell ) ) {
					cell = {
						items : cell	
					};		
				}
				
				$.extend( cell,opt.defaults );
				
				opt.rowsData[rid] = opt.rowsData[rid] || [];
				var cellid = opt.rowsData[rid].push( cell );
				cellid -= 1;
				
				html.push( self.createTableCell( rid,cellid,cell ) );	
				
			}
			return html.join('');
		},
		createTableCell : function( rid,cellid,cell ){
			var self = this,
				opt = self.C(),
				cell = self._undef( cell ,null );
			
			var html = [];
			
			var html = [
				'<td id="',opt.id,'_',rid,'_',cellid,'" class="nex-tablelayout-cell" tableid="'+opt.id+'" '
			];
			
			if( $.isPlainObject( cell ) && !$.isEmptyObject( cell ) ) {
				
				self.fireEvent('onSetCellAttr',[ html,rid,cellid,cell,opt ]);
				
				if( !isNaN(parseInt(cell.rowspan)) ) {
					html.push(' rowspan=');
					html.push(parseInt(cell.rowspan));
				}	
				if( !isNaN(parseInt(cell.colspan)) ) {
					html.push(' colspan=');
					html.push(parseInt(cell.colspan));
				}
				html.push(' align=');
				if( cell.align ) {
					html.push(cell.align);
				} else {
					html.push(opt.align);	
				}
				html.push(' valign=');	
				if( cell.valign ) {
					html.push(cell.valign);
				} else {
					html.push(opt.valign);	
				}
			} else {
				html.push(' align=');	
				html.push(opt.align);
				html.push(' valign=');	
				html.push(opt.valign);	
			}
			
			html.push(' >&nbsp;</td>')
			
			self.fireEvent('onGetTableCell',[ html,rid,cellid,cell,opt ]);
			
			return html.join('');	
		},
		setLayout : function( items ){
			var self = this,
				opt = self.C(),
				el = self.getContainer,
				items = self._undef( items,opt.items );
			self.empty();
			var table = self.add( self.createTable(items) );
			self._setPadding2();
			self.fireEvent('onSetLayout',[opt]);
			return table;
		}
	});
});
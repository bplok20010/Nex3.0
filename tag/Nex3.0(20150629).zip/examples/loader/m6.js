console.log('aaa');
Define('m6','m6');
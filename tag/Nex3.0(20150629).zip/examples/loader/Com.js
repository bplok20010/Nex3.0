console.log(22222);
$define(function(){
	Nex.define('OSC.Com');
	console.log('com');
});

Define( 'm4',['m5'],function(m5){
	console.log(m5)
	return 'm4'	;
} );
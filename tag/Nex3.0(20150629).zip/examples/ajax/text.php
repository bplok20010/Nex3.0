<?php
sleep($_REQUEST['C']);
echo "Hello World!".$_REQUEST['C'];
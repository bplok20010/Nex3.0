/*
Nex.Separator
*/
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([
			'Nex.Html'
		], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	"use strict";
	var separator = Nex.define('Nex.Separator','Nex.Html').setXType('separator');
	separator.setOptions( function(opt){
		return 	{
			autoResize : false,
			tabIndex : false,
			disabledItems : true,
			denyEvents : true,
			cls : opt.containerCls+' nex-separator',
			width : 'atuo',
			height : 'auto'
		};
	} );
}));
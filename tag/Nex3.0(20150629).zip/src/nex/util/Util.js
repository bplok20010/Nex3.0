/*
*Util工具
*Nex.util.Util
*/
Nex.addUtil('Util',{

});
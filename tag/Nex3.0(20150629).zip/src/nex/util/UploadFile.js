/*
*UploadFile处理工具
*Nex.util.UploadFile
*/
Nex.addUtil('UploadFile',{
	frame : function(c) {
		var n = 'f' + Math.floor(Math.random() * 99999);
		var d = document.createElement('DIV');
		d.innerHTML = '<iframe style="display:none" src="about:blank" id="'+n+'" name="'+n+'" onload="Nex.getUtil(\'UploadFile\').loaded(\''+n+'\')"></iframe>';
		console.log(d);
		document.body.appendChild(d);

		var i = document.getElementById(n);
		if (c && typeof c == 'function') {
			i.onComplete = c;
		}
		return n;
	},
	form : function(f, name) {
		f.setAttribute('target', name);
	},
	'submit' : function(f, func) {
		if( typeof f !== 'object' ) {
			f = document.getElementById(f);	
		}
		this.form(f, this.frame(func));
		f.submit();
		return true;
	},
	loaded : function(id) {
		function getDoc(frame) {
			var doc = frame.contentWindow ? frame.contentWindow.document : frame.contentDocument ? frame.contentDocument : frame.document;
			return doc;
		}
		var i = document.getElementById(id);
		var s = '';
		var doc = getDoc( i );
		if (doc.location.href == "about:blank") {
			return;
		}

		var docRoot = doc.body ? doc.body : doc.documentElement;

		//var pre = doc.getElementsByTagName('pre')[0];
		var pre = doc.getElementsByTagName('body')[0];
		//console.log(pre);
		if (pre) {
			s = pre.textContent ? pre.textContent : pre.innerText;
		}
		/*else if (b) {
		 s = b.textContent ? b.textContent : b.innerText;
		 }*/
		if (typeof(i.onComplete) == 'function') {
			i.onComplete(s);
		}
	}
});
apply  : function(){
		
},
widget : function(name,xtype){
			var undef,
				//observe
				base = function(){
					this.init.apply(this,arguments);	
				},
				name = name === undef ? Nex.unique(8) : name,
				xtype = xtype === undef ? name : xtype;
			
			Nex[name] = base;	
			Nex.classes[ name ] = base;
			
			/*
			*添加xtype
			*/
			if( Nex.Manager ) {
				Nex.Manager.addXtype(xtype,function(opt){
					return new Nex.classes[name](opt);									   
				});	
			}
			
			base.fn = base.prototype = {};
			base.fn.extend = function( obj, overwrite ){//overwrite = true
				var overwrite = overwrite === undefined ? true : overwrite;
				if( $.isFunction( obj ) ) {
					obj = obj();	
				}
				if( typeof obj !== 'object' ) {
					return;	
				}
				if( 'configs' in obj && obj.configs ) {
					var configs = obj.configs;
					delete obj.configs; 	
				}
				//setOptions
				this.constructor.setOptions( configs );
				$.extend(this,obj);
			};
			base.extend = function(obj){
				$.extend(this,obj);	
			};
			
			//原型设置
			base.constructor = base.prototype.constructor = base;
			base.prototype.superclass = null;
			base.superclass = null;
			
			base.fn = base.prototype;
			
			base.extend({
				//标识当前函数是属于Nex类
				_isNexConstructor : true,
				puglins : [],
				puglinsConf : {},
				puglinsEvent : {},
				defaults : {},
				eventMaps : {},//事件名映射或者别名 别名:映射名
				addExtConf : function(conf){
					var d = {};
					if( $.isFunction( conf ) ) {
						var d = conf.call( this ) || {};	
					} else {
						d = conf;	
					}
					$.extend( this.puglinsConf,d );
				},
				addExtEvent : function(events){	
					var d = {};
					if( $.isFunction( events ) ) {
						var d = events.call( this ) || {};	
					} else {
						d = events;	
					}
					$.extend( this.puglinsEvent,d );
				},
				addEventMaps : function(maps){	
					var d = {};
					if( $.isFunction( maps ) ) {
						var d = maps.call( this ) || {};	
					} else {
						d = maps;	
					}
					$.extend( this.eventMaps,d );
				},
				_optionsList : [],
				setOptions : function( options ){
					if( $.isPlainObject( options ) ) {//转化成函数方式
						var _opts = options;
						options = function(){
							return $.extend(true,{},_opts);//深复制对象
						}
					}
					if( $.isFunction( options ) ) {
						//方法一 ： 设置的时候确定superclass的参数 缺点 如果superclass做改变时不会更新  不要使用此方法！！
						//var popts = this.getSuperClassOptions();
						this._optionsList.push( function( opt,t ){
							//方法2 1.能够保证所有setOptions的第二个参数是当前对象 2.不会出现方法一的缺点
							var popts = this.getSuperClassOptions(t);
							popts = $.extend( {},popts,opt );//继承属性
							return $.extend(popts,options.call( this,popts,t ));
						} );
					}
					return this;
				},
				getSuperClassOptions : function(t){
					var ptype = this.getSuperClassXType();
					if( !ptype ) {//ptype === null || 
						return {};	
					}
					return Nex.getClass(ptype).getOptions(t);
				},
				getOptions : function(self){
					var list = this._optionsList;
					var opt = {};
					if( list.length ) {
						for( var i=0,len=list.length;i<len;i++ ) {
							var o = list[i];
							$.extend( opt, $.isFunction( o ) ? o.call(this,opt,self||this) : o  );	
						}
					} else {
						$.extend( opt, this.getSuperClassOptions( self||this )  );		
					}
					opt = this.getDefaults( opt,self || this );
					return opt;
				},
				/*
				*基础类默认参数
				*/
				_def : function(self){ 
					var self = self || this;
					return {
						_base : this.constructor,
						prefix : 'nex_',
						id : '',
						//autoRender自动渲染 会自动调用_init
						autoRender : true,//--由于部分组件没有继承html 直接继承 base 所以有些属性 还是放在base 如果后面统一后再做修改
						renderAfter : true,//true:append false:prepend
						_isInit : false,
						_isResize : false,
						//设备上下文，慎用
						context : null,
						parent : null,//指定父组件的ID 如果不指定则自动获取
						stopOnFalse : true,
						denyManager : false,//不受Manager管理组件 不建议开启
						//autoDestroy 自动回收机制 如果Nex在触发检查的时候检查不到当前元素存在时如果开启后就删除当前组件，所以如果你创建的是一个服务那就应该设为false
						autoDestroy : true,//自动回收 回收后通过Nex.get获取不到组件  autoRecovery
						autoSetResize : false,//是否根据用户的width height 自动设置autoResize --尚未实现
						autoResize : false, //接受Manager的resize调整
						autoScroll : false,
						groupName : '',//组件分组，一般有批量sendMessage 时会使用到
						resizeOnHidden : Nex.resizeOnHidden,//作废
						cls : '',
						cutHeight : 0,
						cutWidth : 0,
						deferred : $.Deferred ? $.Deferred() : null,
						autoSize : false,
						width : '100%',
						height : '100%',
						maxWidth : 0,
						maxHeight : 0,
						minHeight : 0,
						minWidth : 0,
						realWidth : null,//实际 ,width=auto时 如果max min width height 没起作用那么realWidth = auto
						realHeight : null,//同上
						_width : null,//和realWidth 不同的是 _width是一个数值
						_height : null,
						__width : 0,
						__height : 0,
						tpl : {},
						template : Nex.getTemplate(),//typeof template === 'undefined' ? Nex.template : template,//模板引擎对象
						scrollbarSize : false,
						noop : $.noop,
						self : null,
						init : $.noop,//初始化调用
						renderTo : null,//helper
						views : {},
						defalutType : 'panel',//默认items的xtype 可通过defaluts覆盖
						defaluts : {},
						items : [],
						isEscape : false,
						cacheData : {},
						//_childrenList : [],//当前组件下的之组件，并不严禁， 一般做清除用
						_boxModel : true,
						eventMaps : {},
						events : {}//事件组合 	
					};
				},
				extSet : function( opt,self ){
					
					var opt = $.extend( {},this._def(self),opt );
					//扩展事件
					$.extend( opt.events,this.puglinsEvent );	
					//事件名映射扩展
					$.extend( opt.eventMaps,this.eventMaps );	
					
					return $.extend({},this.puglinsConf,opt);
				},
				getDefaults : function(opt,self){
					var _opt = {};
					var _opt = this.extSet(_opt,self);
					
					return $.extend({},_opt,opt);
				},
				_undef : function (val, defaultVal) {
					return val === undefined ? defaultVal : val;
				},
				getSuperClassXType : function(){
					return null;	
				},
				getSuperClass : function(){
					return this.superclass;	
				},
				/*
				*调用当前类的API 
				*@param method api名称
				*@param scope 作用域
				*@param data 数组参数
				*/
				invokeMethod : function( method,scope,data ){
					var obj = this;
					var func = obj.fn[method];
					if( func && $.isFunction( func ) ) {
						return func.apply( scope,$.isArray(data) ? data : [ data ] );
					}
					return;
				},
				/*
				*调用父类的API
				*@param method api名称
				*@param scope 作用域
				*@param data 数组参数
				*/
				_super : function( method,scope,data ){
					var _super = this.superclass;
					if( !_super ) return;
					var func = _super.fn[method];
					if( func && $.isFunction( func ) ) {
						return func.apply( scope,$.isArray(data) ? data : [ data ] );
					}
					return;
				},
				setXType : function(xtype){
					var b = this,
						undef;
					if( xtype === undef ) return b;
					
					b.getXType = function(){
						return xtype;	
					};
					b.fn.getXType = function(){
						return xtype;	
					};
					
					Nex.classes[ xtype ] = b;
					
					/*
					*添加xtype
					*/
					if( Nex.Manager ) {
						Nex.Manager.addXtype(xtype,function(opt){
							return new b(opt);									   
						});	
					}
					return b;	
				},
				getXType : function(){
					return xtype;	
				},
				setAliasName : function( aliasName ){
					var self = this;
					if( aliasName ) {
						var __psc = Nex.__psc;
						Nex.__psc = true;
						var aliasNames = $.trim(aliasName).split(/\s+/g);
						$.each( aliasNames,function(i,n){
							Nex.parseSubClass( n,self );
							Nex.addClass( n,self );
						} );
						Nex.__psc = __psc;
					}	
					return self;
				},
				create : function( opt ){
					return new this(opt||{});	
				},
				_Tpl : {}
				
			});
			base.fn.extend({
				//标识当前对象是Nex对象实例
				_isNex : true,
				getSuperClassXType : function(){
					return null;	
				},
				getSuperClass : function(){
					return this.superclass;	
				},
				/*
				*调用父类
				*一定不能用this.superclass.fn.method.call( self )...因为js中没有虚函数的概念 里面的this 都是指向当前对象 ，
				*如果多级继承就会出现死循环 应该明确类名eg : Nex.Form.fn.method.call( self ) or Nex.Form._super(method,self,[  ])	-推荐
				*所以在fn中无法实现super的方法
				_super : function(){
				},
				*/
				getXType : function(){
					return xtype;	
				},
				//动态添加组合 动态组合的参数不会覆盖原有参数和方法，因为会把重复的参数和方法当作用户重载
				addMixins : function( d,dep ){
					var self = this;
					var opt = this.configs;
					var mconfigs = {};
					
					if( $.isFunction( d ) ) {
						d = d();	
					}
					if( !$.isPlainObject( d ) && !$.isArray( d ) && !$.isFunction( d ) ) {
						d = Nex.getMixins( d );
					}
					
					//组合对象的configs也会被当作组件的参数
					if( $.isPlainObject( d ) && !$.isEmptyObject( d ) ) {
						d = $.extend( true,{},d );
						if( 'configs' in d && d.configs ) {
							mconfigs = $.extend(true,{},d.configs);
							delete d.configs; 	 	
						}
						for( var p in mconfigs ) {
							if( !dep && (p in opt) ) {
								continue;	
							}	
							opt[p] = mconfigs[p];//应该使用复制
						}
						for( var m in d ) {
							if( !dep && (m in self) ) {
								continue;	
							}	
							self[m] = d[m];//应该使用复制
						}
					}
					return self;
				},
				initConfigs : function(){
					var self = this;
					var argvs = [].slice.apply(arguments);
					var constructor = self.constructor;
					var opts = constructor.getOptions( self );
					var configs = $.extend({},opts);
					for( var i=0,len = argvs.length;i<len;i++ ) {
						var options = argvs[i];
						if( $.isFunction( options ) ) {
							options = options.call( self,configs ) || {};	
						} else {
							options = $.extend( {},options );//防止options不是一个对象 这里不建议深复制 因为怕大数据带来性能问题
						}
						//这里的event 不会被覆盖 --- 这里是否会有问题呢？
						//self.initEvents(options);//初始化用户自定义事件
						$.extend( configs,options );
					}
					//事件只初始化一次把， 会被后面的覆盖
					self.initEvents(configs);//初始化用户自定义事件
					
					if( Nex.isNex(configs.parent) ) {
						var pid = configs.parent.C('id');
						configs.parent = pid;	
					}
					
					self.configs = configs;
					
					if( 'mixins' in configs ) {
						var mixins = configs.mixins;
						delete configs.mixins;
						mixins = $.isArray( mixins ) ? mixins : [mixins];
						for( var t=0,n = mixins.length;t<n;t++ ) {
							 self.addMixins( mixins[t] );
						}
					}
					
					/*如果参数中有prototype,则当前属性会赋值到当前对象的prototype*/
					var prototype = configs.prototype;
					configs.prototype = null;
					delete configs.prototype;
					
					if( prototype && $.isFunction( prototype ) ) {
						prototype = prototype.call( self,configs );
					}
					
					if( prototype && $._isPlainObject( prototype ) ) {
						$.extend( self,prototype );	
					}
					
					return self;
				},
				init : function(options) {
					var self = this;
					var argvs = [].slice.apply(arguments);
					
					//var constructor = self.constructor;
					self.initConfigs.apply( self,argvs );
					var opt = self.configs;
					opt.self = self;
		
					self._eventLocks = {};
					self._executeEventMaps = {};
		
					opt.id = opt.id || self.getId();
					
					opt._isInit = true;
					
					$.support.boxModel = $.support.boxModel === null ? opt._boxModel : $.support.boxModel;
					
					if( opt.autoRender ) {
						self._render();
					}
				},
				_init : function(){},
				//private
				rendered : false,
				_render : function( el,after ){
					var self = this;
					var opt = this.configs;
					//如果已经渲染则不能重复渲染
					if( this.rendered ) {
						return this;	
					}
					var el = this._undef( el,opt.renderTo );
					var after = this._undef( after,opt.renderAfter );
					
					opt.renderTo = el;	
					opt.renderAfter = after;	
					
					//系统初始化调用
					if( $.isFunction( opt.init ) && opt.init!==$.noop ) {
						opt.init.call(self,opt);
					}
					
					//系统事件绑定
					self.sysEvents();
					
					self._onStart(opt);//设置用户自定义事件
					//这些应该是html组件信息 等所有组件都继承html后可以修改
					//保存初始设置值
					opt.__width = opt.width;
					opt.__height = opt.height;
					
					this.fireEvent("onStart",[opt]);
					
					//设置状态， 已经渲染
					this.rendered = true;
					//添加组件到组件管理器
					if( !opt.denyManager && Nex.Manager ) {
						Nex.Manager.addCmp( opt.id,self );
					}
					//此处应该触发onRender事件 or onAfterRender onBefreoRender
					opt.cls = 'nex-component-item '+opt.cls;
					
					this._init( opt );
					
					return this;	
				},
				render : function( el,after ){
					if( this.rendered ) {
						this.renderTo.apply( this,arguments );
					} else {
						this._render.apply( this,arguments );	
					}
					return this;	
				},
				//判断是否render
				isRendered : function(){
					return this.rendered;	
				},
				_checkToRender : function(){
					if( !this.rendered ) {
						this.render();	
					}	
				},
				/*
				* @m default=false true(更新层级关系)
				*/
				enableAutoResize : function(  ){	
					this.configs.autoResize = true;
					return this;
				},
				/*
				* @m default=false true(更新层级关系)
				*/
				disabledAutoResize : function( m ){
					this.configs.autoResize = false;
					return this;
				},
				//数组移动算法
				// pos 要移动的元素
				array_move : Nex.array_move,
				/*
				*删除数组元素 index 为下标或者下表数组 或者回调函数 回调返回true即可
				*/
				array_splice : Nex.array_splice,
				/*				
				*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面
				*/
				array_insert : Nex.array_insert,
				array_clear : Nex.array_clear,
				array_copy : Nex.array_copy,
				//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
				copyArray : Nex.copyArray,
				//copy只是对数组或对象只是增加一个引用计数，并不是深复制
				copy : Nex.copy,
				/*
				*判断元素垂直滚动条是否滚动到底 @dom
				*/
				_checkYScrollEnd : function( el ){
					return Nex._checkYScrollEnd( el );
				},
				/*
				*判断元素水平滚动条是否滚动到底 @dom
				*/
				_checkXScrollEnd : function( el ){
					return Nex._checkXScrollEnd( el );	
				},
				/*
				*验证是否滚动到低 @el dom @a left/top
				*/
				isScrollEnd : function( el,a ){
					return Nex.isScrollEnd( el,a );	
				},
				str_number : Nex.str_number,
				_undef : function (val, d) {
					return val === undefined ? d : val;
				},
				distArr : function( arr ){
					var obj={},temp=[];
					for(var i=0;i<arr.length;i++){
						if(!obj[arr[i]]){
							temp.push(arr[i]);
							obj[arr[i]] =true;
						}
					}
					return temp;	
				},
				//只接受 字符串 number 
				inArray : function(elem,arr){
					if( $.type( elem ) === 'number' ) {
						elem = elem+'';	
					}
					if ( arr ) {
						var len = arr.length;
						var i = 0;
						for ( ; i < len; i++ ) {
							// Skip accessing in sparse arrays
							var v = arr[ i ];
							if( $.type( v ) === 'number' ) {
								v = v+'';	
							}
							if ( i in arr && (v === elem) ) {
								return i;
							}
						}
					}
					return -1;
				},
				/*判断是否出现滚动条*/
				hasScroll: function( el, a ) {
					return Nex.hasScroll( el,a );
				},
				/*
				* 获取浏览器滚动条大小
				*/
				getScrollbarSize: function () {
					var self = this,
						opt = self.configs;
					if( Nex.scrollbarSize ) {//全局缓存
						opt.scrollbarSize = Nex.scrollbarSize;
					}	
					if (!opt.scrollbarSize) {
						var db = document.body,
							div = document.createElement('div');
		
						div.style.width = div.style.height = '100px';
						div.style.overflow = 'scroll';
						div.style.position = 'absolute';
		
						db.appendChild(div); 
						
						opt.scrollbarSize = {
							width: div.offsetWidth - div.clientWidth,//竖
							height: div.offsetHeight - div.clientHeight//横
						};
						//IE下 出现过有一边获取不到的情况 就是为0
						opt.scrollbarSize.width = opt.scrollbarSize.width || opt.scrollbarSize.height;
						opt.scrollbarSize.height = opt.scrollbarSize.height || opt.scrollbarSize.width;
						
						opt.scrollbarSize.x = opt.scrollbarSize.height;
						opt.scrollbarSize.y = opt.scrollbarSize.width;
						
						db.removeChild(div);
						
						Nex.scrollbarSize = opt.scrollbarSize;
					}
					return opt.scrollbarSize;
				},
				resize : function(){
					var self = this;
					var opt = self.configs;
					if( Nex.Manager ) {
						setTimeout(function(){
							Nex.Manager.fireEvent("onResize",[opt.id]);		
						},0);
					}	
				},	
				__ars : true,
				//判断当前组件是否接受autoResize
				isAcceptResize : function(){
					var opt = this.configs;
					return opt.autoResize && this.__ars;	
				},
				setAcceptResize : function(m){
					var m = m === undefined ? true : m;
					this.__ars = !!m;
					return this;	
				},
				//计算 max/min/cut width height 
				__getCalcSize : function( size,t ){
					var self = this,
						undef,
						opt = this.configs;	
					if( $.isFunction( size ) ) {
						size = size.call( self );	
					}
					if( size === undef ) size = 0;
					//暂不提供百分比支持
					size = parseInt(size);
					return 	isNaN(size)?0:size;	
				},
				_getCutWidth : function(){
					var self = this,
						opt = this.configs;	
					//var pw = opt.pWidth;
					var size = opt.cutWidth;
					return 	self.__getCalcSize(size,0);
				},
				_getCutHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.cutHeight;
					return 	self.__getCalcSize(size,1);
				},
				_getMinWidth : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.minWidth;
					return 	self.__getCalcSize(size,0);
				},
				_getMaxWidth : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.maxWidth;
					return 	self.__getCalcSize(size,0);	
				},
				_getMinHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.minHeight;
					return 	self.__getCalcSize(size,1);		
				},
				_getMaxHeight : function(){
					var self = this,
						opt = this.configs;	
					var size = opt.maxHeight;
					return 	self.__getCalcSize(size,1);			
				},
				/*
				*组件参数设置和获取
				*/
				C : function(key,value){
					if( typeof key == 'undefined') {
						return this.configs;	
					}
					if( typeof value == 'undefined' && typeof key !== 'object' ) {
						return this.configs[key];
					}
					if( $.isFunction( value ) ) {
						this.configs[key] = value.call( this,this.configs[key] );	
					} else if( $.isPlainObject( key ) ) {
						var conf = key;
						var opt = this.configs;
						
						if( value ) {
							$.extend( opt,conf );
							return this;	
						}
						
						for (var k in conf) {
							var newValue = conf[k];
							var oldValue = opt[k];
			
							if ( $.isArray( oldValue ) ) {
								oldValue.push.apply(oldValue, newValue);
							} else if ($.isPlainObject( oldValue )) {
								$.extend( oldValue, newValue)
							} else {
								opt[k] = newValue;
							}
						}
					} else {
						this.configs[key] = value;
					}
					return this;
				},
				set : function(){
					return this.C.apply(this,arguments);	
				},
				get : function(){
					return this.C.apply(this,arguments);	
				},
				setConfig : function(){
					return this.C.apply(this,arguments);		
				},
				getConfig : function(){
					return this.C.apply(this,arguments);		
				},
				/**
				 * 模板处理函数(用户自定义模版级别最高,其次模板函数,最后_Tpl中的模版)
				 *  @tpl {String,Function} 模板内容
				 *  @data {Object} 模板数据 如果tpl是Function data不一定需要Object
				 *  @return {String} 模板内容
				 */
				tpl : function(tpl,data){
					
					var self = this;
					var opt = self.configs;
					var constructor = self.constructor;
					if( typeof tpl == 'undefined' ) tpl = "";
					if( typeof data == 'undefined' ) data = {};
					
					var _tpl_ = {};
					if( typeof opt.cacheData['_tpl_'] == 'undefined' ) {
						opt.cacheData['_tpl_'] = {};
						_tpl_ = opt.cacheData['_tpl_'];
					} else {
						_tpl_ = opt.cacheData['_tpl_'];
					}
					
					var argvs = [];
					var len = arguments.length;
					for( var i=2;i<len;i++ ) {
						argvs.push( arguments[i] );	
					}
					var argvs = [data].concat( argvs );
					
					var html = "";
					
					if( !opt.template ) {
						if( $.isFunction(tpl) ){
							html = tpl.apply(self,argvs);
						} else if( tpl in self ) {
							html = self[tpl].apply(self,argvs);
						} else {
							html = 	tpl;
						}
						return html;
					}
					
					opt.template.isEscape = opt.isEscape;
					
					if( $.isFunction(tpl) ){
						html = tpl.apply(self,argvs);
					}else if( tpl in opt.tpl && opt.tpl[tpl] ) {
						if( opt.tpl[tpl] in _tpl_ ) {
							var render = _tpl_[ opt.tpl[tpl] ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( opt.tpl[tpl] );
							
							_tpl_[ opt.tpl[tpl] ] = render;
							
							html = render.apply(self,argvs);		
						}
					} else if( tpl in self ) {
						html = self[tpl].apply(self,argvs);
					} else if( tpl in constructor._Tpl && constructor._Tpl[tpl] ) {
						if( constructor._Tpl[tpl] in _tpl_ ) {
							var render = _tpl_[ constructor._Tpl[tpl] ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( constructor._Tpl[tpl] );
							
							_tpl_[ constructor._Tpl[tpl] ] = render;
							
							html = render.apply(self,argvs);		
						}
					} else {
						if( tpl.toString() in _tpl_ ) {
							var render = _tpl_[ tpl.toString() ];
							html = render.apply(self,argvs);
						} else {
							var render = opt.template.compile( tpl.toString() );
							
							_tpl_[ tpl.toString() ] = render;
							
							html = render.apply(self,argvs);		
						}
					}
					return html;
				},
				/*
				*  调用当前对象里的某个API，但是不会触发里面的事件(部分函数除外例如setGridBody,因为里面事件通过计时器触发)
				*  @param1 {String} 需要调用的API
				*  @param2~N 被调用的API参数(可选)
				*/
				denyEventInvoke : function(){//method,arg1,arg2....
					var self = this;
					var r;
					if( arguments.length ){
						var argvs = [];
						for( var i=0;i<arguments.length;i++ ) {
							argvs.push(arguments[i]);	
						}
						var method = argvs[0];
						if( method in self ) {
							self._denyEvent = true;
							argvs.splice(0,1);
							r = self[method].apply(self,argvs);
							self._denyEvent = false;
						}
					}
					return r;
				},
				/*
				* API调用管理,作用在于通过该函数调用的会过滤被锁定的函数
				*  @param1 {String} 需要调用的API
				*  @param2~N 被调用的API参数(可选)
				*/
				methodInvoke : function(){//method,arg1,arg2....
					var self = this;
					var r;
					
					var methodLocks = self._methodLocks || {};
					
					if( arguments.length ){
						var argvs = [];
						for( var i=0;i<arguments.length;i++ ) {
							argvs.push(arguments[i]);	
						}
						var method = argvs[0];
						
						if( methodLocks[method] ) {
							return;	
						}
						
						if( method in self ) {
							argvs.splice(0,1);
							r = self[method].apply(self,argvs);
						}
					}
					return r;
				},
				/*
				* 事件绑定
				*  @eventType {String} 事件名
				*  @func      {Function|{ scope,fn }} 事件回调
				*  @scope     {Object} this对象(可选)
				*  @return    {int} 事件ID or false
				*/
				bind : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					if( eventType === '' || eventType === '@' ) {
						return false;	
					}
					//var _f = func;
					//var func = func || $.noop;
					var self = this;
					var opt = self.configs;
					var event = opt.events;
					//批量绑定支持
					if( $.type( eventType ) === 'object' ) {
						var ids = [];
						for( var ev in eventType ) {
							var context = scope;
							var fn = eventType[ev];
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.scope || fn.context || context;
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							var _i = self.bind( ev,fn,context );	
							ids.push( _i );
						}
						return ids;
					} else {//字符串 但是没有做检查 
						var _ev = [ eventType ].join('').split(/\s+|,/);	
						if( _ev.length>1 ) {
							var len = _ev.length;
							var ids = [];
							for( var _e=0;_e<len;_e++ ) {
								if( !_ev[_e] ) continue;
								ids.push( self.bind( _ev[_e],func,scope ) );
							}
							return ids;
						}					
					}
					
					var _f1 = eventType.charAt(0);
					if( _f1 === '@' ) {
						scope = self;
						eventType = eventType.slice(1);	
					}	
					
					var _type = eventType.split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');//_type.length == 2 ? _type[1] : '';
					
					if( !eventType ) {
						return false;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					event[eventType] = self._undef(event[eventType],[]);
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
					}
					
					if( !$.isFunction( func ) || func === $.noop ) {
						return false;	
					}
					
					var _e = {
							scope : !!scope ? scope : null,
							func : func,
							ext : ext
						};
					
					var id = event[eventType].push(_e);
				
					return id-1;
				},
				on : function(){
					return this.bind.apply(this,arguments);	
				},
				/*
				*同bind 区别在于只执行一次
				*/
				one : function(eventType,func,scope){
					if( typeof eventType == "undefined" ) {
						return false;	
					}
					var func = func || $.noop;
					var self = this;
					var scope = !!scope ? scope : self;
					
					var _ = function(){
							self.unbind(eventType,_.id);
							var r = func.apply(scope,arguments);
							return r;
						},
						id = null;
						
					id = self.bind( eventType,_,scope );
					_.id = id;
					return id;
				},
				/*
				* 取消事件绑定
				*  @eventType {String} 事件名
				*  @id        {int} 事件ID(可选)
				*/
				unbind : function(eventType,id){
					var self = this;
					var opt = self.configs;
					
					var _ev = [ eventType ].join('').split(/\s+|,/);	
					if( _ev.length>1 ) {
						var len = _ev.length;
						for( var _e=0;_e<len;_e++ ) {
							if( !_ev[_e] ) continue;
							self.unbind( _ev[_e] );
						}
						return self;
					}					
					
					var event = opt.events;
					var id = self._undef(id,false);
					
					var _type = String(eventType).split(".");
					eventType = _type[0];
					_type = _type.slice(1);
					var ext = _type.join('.');
					
					if( eventType === '' && ext !== '' ) {
						for( var tp in event ) {
							self.unbind( [tp,ext].join('.') );	
						}
						return self;	
					}
					
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					if( !(eventType in event) ) {
						return self;	
					}
					
					if( $.isFunction( event[eventType] ) ) {
						event[eventType] = [];
						return self;
					}
					
					if(id === false) {
						if( ext === '' ) {
							event[eventType] = [];
						} else {
							
							var j = 0;//用于splice
							for(var i=0;i<event[eventType].length;i++) {
								var _e = event[eventType][i];
								if( $.isPlainObject( _e ) && _e.ext === ext ) {
									event[eventType][i] = null;	
									j++;
								}
							}
						}
					} else {
						event[eventType][id] = null;	
					}
					return self;
				},
				off : function(){
					return this.unbind.apply(this,arguments);	
				},
				/*
				* 锁定API
				*  @method {String} API名
				*/
				lockMethod : function(method){
					var self = this;	
					//事件锁
					var methodLocks = self._methodLocks || {};
					methodLocks[method] = true;
					self._methodLocks = methodLocks;
					return true;	
				},
				/*
				* 取消锁定API
				*  @method {String} API名
				*/
				unLockMethod : function(method){
					var self = this;	
					//事件锁
					var methodLocks = self._methodLocks || {};
					methodLocks[method] = false;
					self._methodLocks = methodLocks;
					return true;	
				},
				/*
				* 锁定事件
				*  @eventType {String} 事件名
				*/
				lockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = true;
					self._eventLocks = eventLocks;
					return true;
				},
				/*
				* 取消锁定事件
				*  @eventType {String} 事件名
				*/
				unLockEvent : function(eventType){
					var self = this;	
					//事件锁
					var eventLocks = self._eventLocks || {};
					eventLocks[eventType] = false;
					self._eventLocks = eventLocks;
					return true;
				},
				_eventLocks : {},
				_executeEventMaps : {},//正在的执行的事件
				/*
				* 事件触发
				*  @eventType {String} 事件名 如果事件名带@开头 说明当前事件是系统事件 不会因为睡眠而阻止
				*  @data      {Array} 事件参数(可选)
				*/
				fireEvent : function(eventType,data){
					var self = this;
					if( self._denyEvent ) {
						return;	
					}
					var opt = self.configs;
					
					var context = opt.context || self;
					
					var ct = String(eventType).charAt(0);
					var _sys = false;
					if( ct === '@' ) {
						_sys = true;
						eventType = String(eventType).slice(1);	
					}	
					/*
					if( !_sys && self._isSleep() ) {
						return;	
					}
					*/
					if( !eventType ) {
						return;	
					}
					//事件名映射处理
					//eventMaps
					if( eventType in opt.eventMaps ) {
						eventType = opt.eventMaps[eventType];
					}
					
					var events = opt.events[eventType];
					var data = self._undef(data,[]);
					
					//判断data 是否 arguments
					if( $.isArray( data ) ) {
						data = data;	
					} else if( $.type( data ) === 'object' ){
						if( 'callee' in data && 'length' in data ) {
							data = data	
						} else {
							data = [data];	
						}
					} else {
						data = [data];
					}
					//data = $.isArray( data ) ? data : [data];
					//添加事件锁
					var eventLocks = self._eventLocks || {};
					if( eventLocks[eventType] ) {
						return;	
					}
					//防止死循环事件
					if( self._executeEventMaps[eventType] ) {
						return;	
					}
					self._executeEventMaps[eventType] = true;
					
					var r = true;
					if($.isArray(events) ) {
						var len = events.length;
						for(var i=0;i<len;i++) {
							var _e = events[i];
							if( $.isPlainObject( _e ) ) {
								r = _e.func.apply(_e.scope || context,data);
							} else if( $.isFunction( _e ) ){
								r = _e.apply(self,data);
							}
							if( opt.stopOnFalse ) {
								if(r === false) break;	
							}
						}	
						
					} else if($.isFunction(events)) {
						r = events.apply(self,data);
					}
					
					self._executeEventMaps[eventType] = false;
					
					return r;
				},
				fire : function(){
					return this.fireEvent.apply(this,arguments);	
				},
				__sleep : false,
				isSleep : function(){
					return this.__sleep;	
				},
				//睡眠 睡眠后无法通过sendMessageToGroup给组件发送消息 并不会影响fireEvent
				sleep : function(){
					this.__sleep = true;
					return this;	
				},
				//唤醒
				wakeup : function(){
					this.__sleep = false;
					return false;
				},
				loadPuglins : function(){
					var self = this;
					var constructor = self.constructor;
					$.each( constructor.puglins,function(i){
						if( $.isFunction( this ) )
							this.call(self);									
					} );
				},
				initEvents : function(opt){
					var self = this;
					var e = opt.events ? opt.events : {};
					opt.events = {};
					var events = {};
					if( $.isPlainObject(e) && !$.isEmptyObject(e) ) {
						for(var i in e){
							var _evt = String(i),
								fn = e[i],
								context = null;	
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.scope || fn.context || null;
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							if( $.isFunction( fn ) && fn !== $.noop ) {
								self.bind(_evt,fn,context);	
							}
						}
					}
					//opt.events = events;
				},
				sysEvents : function(){
					var self = this;
					var opt = self.configs;
					//系统事件 注意：顺序不可随意更改
					if( '_sysEvents' in self ) {
						self._sysEvents();
					}
					
					self.bind("onStart._sys",self.loadPuglins,self);	
				},
				generateMixed : function(n){
					 return Nex.generateMixed( n );	
				},
				_getId : function(){
					var aid = Nex.aid++;
					var self = this;
					var opt = self.configs;
					return opt.prefix + aid;	
				},
				getDom : function(){
					var self = this,
						opt = self.configs;
					return $('#'+opt.id);
				},
				getEl : function(){
					return this.el || this.getDom();	
				},
				getId : function(){
					if( this.configs.id === '' || this.configs.id === null || this.configs.id === undefined ) {
						return this._getId();	
					}
					return this.configs.id;	
				},
				//获取组件的父级组件
				getParent : function(  ){
					var el = this.getDom(),
						opt = this.configs,
						cmp = null;
					if( !el.length ) return cmp;
					if( opt.parent !== null ) {
						if( Nex.isNex( opt.parent ) ) {
							return opt.parent;	
						}
						var _p = Nex.get(opt.parent);
						if( _p ) return _p;
					}
					var p = el.parent('.nex-component-item'),
						_id = p.attr('id');
					cmp = _id ? Nex.get(id) : null;
					return cmp ? cmp : null;
				},
				unique : function(n){
					return Nex.unique(n);	
				},
				isNumber : function(value) {
					return Nex.isNumber( value );	
				},
				/*
				*系统事件
				*/
				_onStart : function(){
					var self = this;
					var opt = self.configs;
					var e = opt.events ? opt.events : {};
					var reg = /^@?on[A-Z][\S|\.]*$/;///^@?on[A-Z][\w|\.]*$/
					for(var x in opt ) {
						if( reg.test(x) ) {
							var fn = opt[x],
								context = null;
							
							if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
								context = fn.context || fn.scope || null;	
								fn = fn.func || fn.fn || fn.callBack || fn.callback;
							}
							if( $.isFunction(fn) && fn !== $.noop ){
								self.bind(x,fn,context);	
							}
						}
					}
				},
				isNexConstructor : function(obj){
					return  Nex.isNexConstructor( obj );
				},
				isNex : function(obj){
					return  Nex.isNex( obj );
				},
				isXtype : function(obj){
					return Nex.isXtype( obj );
				},
				isjQuery : function(obj){
					return Nex.isjQuery( obj );
				},
				/*
				*解析xtype 到容器
				*@param {String,Dom} 容器
				*@param {Array,Nex,Xtype} 组件列表 
				*@param {Boolean}  true:append(默认) false:prepend,
				*@param {Object} defaluts
				*/
				parseItems : function(renderTo,items,after,def){
					var self = this,
						opt = self.configs,
						undef;
					var after = (after === undef) || (after === null) ? true : after;
					
					var def = $.type(def) === 'object' ? def : {};
					
					var ac = after ? 'append' : 'prepend';
					if( $.isFunction( items ) && !Nex.isNexConstructor( items ) ) {
						items = items.call( self,renderTo );
					}
					var components = [];
					var items = $.isArray( items ) ? items : [items];
					if( renderTo && items.length ) {
						for( var i=0;i<items.length;i++ ) {
							var _item = items[i];
							if( _item === '' || _item === undef ) continue;
							if( $.isFunction( _item ) && !Nex.isNexConstructor( _item ) ) {
								_item = _item.call(self,renderTo,opt);	
								if( _item === '' 
								    || $.type( _item ) === 'boolean' 
									|| $.type( _item ) === 'null' 
									|| $.type( _item ) === 'undefined' 
								) {
									continue;	
								}
							}
							if( Nex.isNex( _item ) ) {
								//$( renderTo )[ac]( _item.getDom() );
								_item.render( renderTo,ac );
								components.push( _item );
								//self.addChildCmpList( _item );
							} else if( Nex.isNexConstructor( _item ) || Nex.isXtype( _item ) ){
								if( !Nex.Create ) continue;
								var cmp;
								if( Nex.isXtype( _item ) ) {
									cmp = Nex.Create( $.extend( $.extend({ parent : opt.id },def),_item,{renderTo:renderTo,autoRender:true} ) );	
								} else {
									cmp = Nex.Create( _item,$.extend({},def,{renderTo:renderTo,parent : opt.id,autoRender:true}) );		
								}
								components.push( cmp );
								//self.addChildCmpList( cmp );
								//这里可以改成设置参数 renderAfter : after
								if( !after ) {
									$( renderTo )[ac]( cmp.getDom() );	
								}
							} else if( Nex.isjQuery( _item ) || Nex.isElement( _item ) ) {
								$( renderTo )[ac]( _item );	
								components.push( _item );
							} else {
								_item = _item + '';
								var html = $._parseHTML( _item );//修正相同字符 不创建bug
								html = $(html).clone();
								components.push( html );
								$( renderTo )[ac]( html );				
							}	
						}
					}
					return components;
				},
				addComponent :　function( renderTo,items,after ){
					return this.parseItems( renderTo,items,after );
				},
				addCmp :　function( renderTo,items,after ){
					return this.parseItems( renderTo,items,after );
				},
				/*
				*解析xtype 到容器
				*@param {Array,Nex,Xtype} 组件列表 
				*@param {String,Dom} 容器
				*@param {Boolean} 内部插入 默认是 后 
				*/
				renderComponent : function( items,renderTo,after ){
					return this.parseItems( renderTo,items,after );	
				},
				//应该放到Html组件 因为有部分组件没有继承Html 所以先放在这里
				renderTo : function( obj,after ){
					var self = this;
					var opt = this.configs;
					var undef;
					var after = after === undef ? true : after;
					var ac = after ? 'append' : 'prepend';
					if( !obj ) return self;
					if( !self.isExists() ) return self;
					var _st = false;
					if( Nex.isNex( obj ) && obj.isExists() ) {
						var bd = obj.getBody();
						bd[ac]( self.getEl() );
						_st = true;
					} else {
						var el = $(obj);
						if( el.length ) {
							el[ac]( self.getEl() );	
							_st = true;
						}	
					}
					if( opt.autoResize && _st ) {
						self.resize();
						if( Nex.Manager ) {
							Nex.Manager.cmpChange();	
						}
					}
					return self;
				},
				/*
				addChildCmpList :　function(obj){
					var self = this;
					var opt = self.configs;
					opt._childrenList.push( obj );
				},
				*/
				//m @true 默认删除本身, false 删除子元素
				removeCmp :  function(m){
					var self = this,undef;
					var m = m === undef ? true : m;
					var opt = self.configs;
					//opt._childrenList.length = 0;
					if( Nex.Manager ) {
						Nex.gc();
					}
				},
				/*
				*移除组件 最好需要重载
				*/
				destroy : function( m ){
					this.removeCmp( m );
					return this;
				},
				getChildrens : function(){
					var opt = this.configs;
					return Nex.Manager.getChildrens( opt.id );	
				},
				getAllChildrens : function(){
					var opt = this.configs;
					return Nex.Manager.getAllChildrens( opt.id );	
				},
				//作废
				_setBodyOverflowHidden : function(){},
				getDeferred : function(){
					var opt = this.configs;
					return opt.deferred;
				},
				/*
				*获取异步数据 必须要加载Nex.Ajax
				*方式一 通过URL设置
				*getAsyncData(url[success,error,complete,options]);
				*success,error,complete {Function}  options {Object}
				*eg getAsyncData( 'a.json',function( data ){ console.log( data ) },{ dataType:'json' } );
				*/
				getAsyncData : function( url ){
					var self = this,
						undef,
						success,
						error,
						complete,
						options,
						args = [].slice.apply(arguments);	
					var ins = null;	
					//参数处理	
					var len = args.length;
					for( var i=1;i<len;i++ ) {
						if( typeof args[i] === 'object' ) {
							options = args[i];
							break;	
						}
						if( typeof args[i] === 'function' ){
							switch( i ) {
								case 1:
									success = args[1];
									break;
								case 2:
									error = args[2];
									break;
								case 3:
									complete = args[3];
									break;		
							}
						}
					}	
					//url的处理方式	
					if( $.type( url ) === 'string' ) {
						var obj = {
								xtype : 'ajax',
								url : url,
								context : self
							};
						if( options ) {
							$.extend( obj,options );	
						}
						if( success ) {
							obj['onSuccess.__async'] = success;
						}
						if( error ) {
							obj['onError.__async'] = error;
						}
						if( complete ) {
							obj['onComplete.__async'] = complete;
						}
						ins = Nex.Create( obj );
					} else if( $.type( url ) === 'function' ) {//用户自定义函数处理方式
						var _data = url.call(self,options,success,error,complete);
						if( _data !== undef ) {
							success( _data );	
							complete();
						}	
					} else if( typeof url === 'object' ) {
						var obj = {
							xtype : 'ajax'	
						};
						if( !Nex.isXtype( url ) ) {
							$.extend( obj,url )	
						} else {
							obj = url;	
						}
						if( success ) {
							obj['onSuccess.__async'] = success;
						}
						if( error ) {
							obj['onError.__async'] = error;
						}
						if( complete ) {
							obj['onComplete.__async'] = complete;
						}
						ins = Nex.Create( obj );
					}
					return ins;
				},
				//ajax api
				loadData : function(url,data,options){//loader
					var self = this,
						undef,
						opt = self.configs;
						
				}
			});
		//	base.fn.extend( Nex.createEventObject );
			
			return base;
		},
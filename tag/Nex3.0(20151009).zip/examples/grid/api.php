<?php
//var_dump($_GET);
//var_dump($_SERVER);
?>
<root>
<![CDATA[<div>tesst</div>]]>
</root>
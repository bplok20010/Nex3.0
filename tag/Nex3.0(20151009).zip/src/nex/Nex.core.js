/*
jquery.easing.js
*/
jQuery.easing['jswing']=jQuery.easing['swing'];jQuery.extend(jQuery.easing,{def:'easeOutQuad',swing:function(x,t,b,c,d){return jQuery.easing[jQuery.easing.def](x,t,b,c,d);},easeInQuad:function(x,t,b,c,d){return c*(t/=d)*t+b;},easeOutQuad:function(x,t,b,c,d){return-c*(t/=d)*(t-2)+b;},easeInOutQuad:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t+b;return-c/2*((--t)*(t-2)-1)+b;},easeInCubic:function(x,t,b,c,d){return c*(t/=d)*t*t+b;},easeOutCubic:function(x,t,b,c,d){return c*((t=t/d-1)*t*t+1)+b;},easeInOutCubic:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t+b;return c/2*((t-=2)*t*t+2)+b;},easeInQuart:function(x,t,b,c,d){return c*(t/=d)*t*t*t+b;},easeOutQuart:function(x,t,b,c,d){return-c*((t=t/d-1)*t*t*t-1)+b;},easeInOutQuart:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t*t+b;return-c/2*((t-=2)*t*t*t-2)+b;},easeInQuint:function(x,t,b,c,d){return c*(t/=d)*t*t*t*t+b;},easeOutQuint:function(x,t,b,c,d){return c*((t=t/d-1)*t*t*t*t+1)+b;},easeInOutQuint:function(x,t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t*t*t+b;return c/2*((t-=2)*t*t*t*t+2)+b;},easeInSine:function(x,t,b,c,d){return-c*Math.cos(t/d*(Math.PI/2))+c+b;},easeOutSine:function(x,t,b,c,d){return c*Math.sin(t/d*(Math.PI/2))+b;},easeInOutSine:function(x,t,b,c,d){return-c/2*(Math.cos(Math.PI*t/d)-1)+b;},easeInExpo:function(x,t,b,c,d){return(t==0)?b:c*Math.pow(2,10*(t/d-1))+b;},easeOutExpo:function(x,t,b,c,d){return(t==d)?b+c:c*(-Math.pow(2,-10*t/d)+1)+b;},easeInOutExpo:function(x,t,b,c,d){if(t==0)return b;if(t==d)return b+c;if((t/=d/2)<1)return c/2*Math.pow(2,10*(t-1))+b;return c/2*(-Math.pow(2,-10*--t)+2)+b;},easeInCirc:function(x,t,b,c,d){return-c*(Math.sqrt(1-(t/=d)*t)-1)+b;},easeOutCirc:function(x,t,b,c,d){return c*Math.sqrt(1-(t=t/d-1)*t)+b;},easeInOutCirc:function(x,t,b,c,d){if((t/=d/2)<1)return-c/2*(Math.sqrt(1-t*t)-1)+b;return c/2*(Math.sqrt(1-(t-=2)*t)+1)+b;},easeInElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d)==1)return b+c;if(!p)p=d*.3;if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);return-(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;},easeOutElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d)==1)return b+c;if(!p)p=d*.3;if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);return a*Math.pow(2,-10*t)*Math.sin((t*d-s)*(2*Math.PI)/p)+c+b;},easeInOutElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d/2)==2)return b+c;if(!p)p=d*(.3*1.5);if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);if(t<1)return-.5*(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;return a*Math.pow(2,-10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p)*.5+c+b;},easeInBack:function(x,t,b,c,d,s){if(s==undefined)s=1.70158;return c*(t/=d)*t*((s+1)*t-s)+b;},easeOutBack:function(x,t,b,c,d,s){if(s==undefined)s=1.70158;return c*((t=t/d-1)*t*((s+1)*t+s)+1)+b;},easeInOutBack:function(x,t,b,c,d,s){if(s==undefined)s=1.70158;if((t/=d/2)<1)return c/2*(t*t*(((s*=(1.525))+1)*t-s))+b;return c/2*((t-=2)*t*(((s*=(1.525))+1)*t+s)+2)+b;},easeInBounce:function(x,t,b,c,d){return c-jQuery.easing.easeOutBounce(x,d-t,0,c,d)+b;},easeOutBounce:function(x,t,b,c,d){if((t/=d)<(1/2.75)){return c*(7.5625*t*t)+b;}else if(t<(2/2.75)){return c*(7.5625*(t-=(1.5/2.75))*t+.75)+b;}else if(t<(2.5/2.75)){return c*(7.5625*(t-=(2.25/2.75))*t+.9375)+b;}else{return c*(7.5625*(t-=(2.625/2.75))*t+.984375)+b;}},easeInOutBounce:function(x,t,b,c,d){if(t<d/2)return jQuery.easing.easeInBounce(x,t*2,0,c,d)*.5+b;return jQuery.easing.easeOutBounce(x,t*2-d,0,c,d)*.5+c*.5+b;}});
/*
jquery.mousewheel.js
*/
(function($){var types=['DOMMouseScroll','mousewheel'];if($.event.fixHooks){for(var i=types.length;i;){$.event.fixHooks[types[--i]]=$.event.mouseHooks;}}
$.event.special.mousewheel={setup:function(){if(this.addEventListener){for(var i=types.length;i;){this.addEventListener(types[--i],handler,false);}}else{this.onmousewheel=handler;}},teardown:function(){if(this.removeEventListener){for(var i=types.length;i;){this.removeEventListener(types[--i],handler,false);}}else{this.onmousewheel=null;}}};$.fn.extend({mousewheel:function(fn){return fn?this.bind("mousewheel",fn):this.trigger("mousewheel");},unmousewheel:function(fn){return this.unbind("mousewheel",fn);}});function handler(event){var orgEvent=event||window.event,args=[].slice.call(arguments,1),delta=0,returnValue=true,deltaX=0,deltaY=0;event=$.event.fix(orgEvent);event.type="mousewheel";if(orgEvent.wheelDelta){delta=orgEvent.wheelDelta/120;}
if(orgEvent.detail){delta=-orgEvent.detail/3;}
deltaY=delta;if(orgEvent.axis!==undefined&&orgEvent.axis===orgEvent.HORIZONTAL_AXIS){deltaY=0;deltaX=-1*delta;}
if(orgEvent.wheelDeltaY!==undefined){deltaY=orgEvent.wheelDeltaY/120;}
if(orgEvent.wheelDeltaX!==undefined){deltaX=-1*orgEvent.wheelDeltaX/120;}
args.unshift(event,delta,deltaX,deltaY);return($.event.dispatch||$.event.handle).apply(this,args);}})(jQuery);
/*
 * jQuery hashchange event - v1.3 - 7/21/2010
 * http://benalman.com/projects/jquery-hashchange-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function($,e,b){var c="hashchange",h=document,f,g=$.event.special,i=h.documentMode,d="on"+c in e&&(i===b||i>7);function a(j){j=j||location.href;return"#"+j.replace(/^[^#]*#?(.*)$/,"$1")}$.fn[c]=function(j){return j?this.bind(c,j):this.trigger(c)};$.fn[c].delay=50;g[c]=$.extend(g[c],{setup:function(){if(d){return false}$(f.start)},teardown:function(){if(d){return false}$(f.stop)}});f=(function(){var j={},p,m=a(),k=function(q){return q},l=k,o=k;j.start=function(){p||n()};j.stop=function(){p&&clearTimeout(p);p=b};function n(){var r=a(),q=o(m);if(r!==m){l(m=r,q);$(e).trigger(c)}else{if(q!==m){location.href=location.href.replace(/#.*/,"")+q}}p=setTimeout(n,$.fn[c].delay)}$.browser.msie&&!d&&(function(){var q,r;j.start=function(){if(!q){r=$.fn[c].src;r=r&&r+a();q=$('<iframe tabindex="-1" title="empty"/>').hide().one("load",function(){r||l(a());n()}).attr("src",r||"javascript:0").insertAfter("body")[0].contentWindow;h.onpropertychange=function(){try{if(event.propertyName==="title"){q.document.title=h.title}}catch(s){}}}};j.stop=k;o=function(){return a(q.location.href)};l=function(v,s){var u=q.document,t=$.fn[c].domain;if(v!==s){u.title=h.title;u.open();t&&u.write('<script>document.domain="'+t+'"<\/script>');u.close();q.location.hash=v}}})();return j})()})(jQuery,this);
/*******************************************
***************jQuery功能扩展****************
********************************************/
/*
*因为父元素的display为none 那么隐藏的子元素获取高度为0
*可调用_display短暂的显示，要记得调用后也要_hidden返回原始状态
*@param {string} 如果设置就会对元素添加样式否则直接设置display:block
*/
$.fn._display = function(_e){
	var _e = _e || 'nex-hide2show';
	var $this = $(this);
	return $this.add( $this.parents(':hidden') ).filter(function(){
			return $(this).css('display') == 'none';
		}).each( function(){
			$(this).addClass(_e);		
		} );
};
/*状态
*@param {string} 如果设置就会对元素移除样式否则直接设置display:none
*/
$.fn._hidden = function(_e){
	var _e = _e || 'nex-hide2show';
	return this.each(function(i){
		$(this).removeClass(_e);	
	});
};
/*
*获取和设置元素宽高
*使用同$.fn.width,不同在于如果元素隐藏也能正确获取到宽高
*/
$.fn._width = function(_e){
	if(_e==undefined){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.width()||document.body.clientWidth;
		}
		var p = null,
			$f = $(f);
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var w = $f.width();
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return w||0;
	}
	return this.width(_e);
};
/*
*获取和设置元素宽高
*使用同$.fn.height,不同在于如果元素隐藏也能正确获取到宽高
*/
$.fn._height = function(_e){
	if(_e==undefined){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.height()||document.body.clientHeight;
		}
		var p = {},
			$f = $(f);
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var h = $(f).height();
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return h||0;
	}
	return this.height(_e);
}; 
/*
*获取和设置元素宽高
*@param {int} 设置宽高
*使用同$.fn.outerWidth,不同在于可以设置宽高
*/
$.fn._outerWidth = function(_e){
	if(_e==undefined || _e === false || _e === true){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.width()||document.body.clientWidth;
		}
		var $f = $(f),p = null;
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var w = this.outerWidth(!!_e)||0;
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return w;
	}
	var isIE= Nex.isIE;
	return this.each(function(){
		var $this = $(this);					  
		if( !$.support.boxModel ){
			$this.width(_e);
		}else{
			var $f = $this,
				p = null,
				isHidden = $f.is(":hidden");
			if( isHidden ) {
				p = $f._display('nex-hide2show');
			}
			var _w = _e-($f.outerWidth()-$f.width());
			_w = _w<0?0:_w;
			$f.width(_w);
			if( isHidden ) {
				p._hidden('nex-hide2show');	
			}
		}
	});
}; 
/*
*获取和设置元素宽高
*@param {int} 设置宽高
*使用同$.fn.outerHeight,不同在于可以设置宽高
*/
$.fn._outerHeight = function(_f){
	if(_f==undefined || _f === false || _f === true){
		var f = this[0];
		if(f==window || f==document || f==document.body ){
			return this.height()||document.body.clientHeight;
		}
		var $f = $(f),p = null;
		var isHidden = $f.is(":hidden");
		if( isHidden ) {
			p = $f._display('nex-hide2show');
		}
		var h = this.outerHeight(!!_f)||0;
		if( isHidden ) {
			p._hidden('nex-hide2show');	
		}
		return h;
	}
	var isIE= Nex.isIE;
	return this.each(function(){
		var $this = $(this);					  
		if( !$.support.boxModel ){
			$this.height(_f);
		}else{
			var $f = $this,
				p = null,
				isHidden = $f.is(":hidden");
			if( isHidden ) {
				p = $f._display('nex-hide2show');
			}
			var _h = _f-($f.outerHeight()-$f.height());
			_h = _h<0?0:_h;
			$f.height(_h);
			if( isHidden ) {
				p._hidden('nex-hide2show');	
			}
		}
	});
};
/*
*返回相对offsetParent的绝对高度，而不是相对
*/
$.fn._position = function(_f){
	var undef;
	if( _f === undef ) {
		var t = this.eq(0);
		var op = t.offsetParent();
		if( op.is('body') || op.is('html') ) {
			return t.offset();	
		} else {
			var _a = t.offset(),
				_b = op.offset(),
				_c = parseFloat(op.css('borderLeftWidth')) || 0,
				_e = parseFloat(op.css('paddingLeft')) || 0,
				_c1 = parseFloat(op.css('borderTopWidth')) || 0,
				_e1 = parseFloat(op.css('paddingTop')) || 0;
			/*_c = isNaN( _c ) ? 0 : _c;
			_e = isNaN( _e ) ? 0 : _e;
			_c1 = isNaN( _c1 ) ? 0 : _c1;
			_e1 = isNaN( _e1 ) ? 0 : _e1;	*/
			var pos = {
				top : _a.top - _b.top - _c1 - _e1,
				left : _a.left - _b.left - _c - _e
			};
			return {
				top : pos.top + op.scrollTop(),	
				left : pos.left + op.scrollLeft()
			};
		}
	} else {
		return this.css( _f );	
	}
};
/*
*用CSS设置top=-100000px来达到隐藏的效果
*/
$.fn._show = function(fn){
	this.removeClass('nex-hidden');	
	if( fn && $.isFunction(fn) ) {
		fn.call(this);	
	}
	return this;
};
/*
*去除_show的隐藏效果
*/
$.fn._hide = function(fn){
	this.addClass('nex-hidden');	
	if( fn && $.isFunction(fn) ) {
		fn.call(this);	
	}
	return this;
};
/*
*检测是否是纯对象
*/
$._isPlainObject = function(obj){
	var r = $.isPlainObject(obj);
	if( r && '_outerWidth' in obj ) {
		r = false;	
	}
	return r;
};
/*
*兼容jquery低版本也支持parseHtml
*/
$._parseHTML = $.parseHTML = $.parseHTML || function( data, context, scripts ){
	var parsed,rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>)?$/;
	if ( !data || typeof data !== "string" ) {
		return null;
	}
	if ( typeof context === "boolean" ) {
		scripts = context;
		context = 0;
	}
	context = context || document;

	// Single tag 
	if ( (parsed = rsingleTag.exec( data )) ) {
		return [ context.createElement( parsed[1] ) ];
	}

	parsed = jQuery.buildFragment( [ data ], $(context), scripts ? null : [] );
	return jQuery.merge( [],parsed.fragment.childNodes );

};
/*
*移除元素css内联样式扩展
*/
jQuery.fn.extend({
	/*
	*移除style属性(移除cssText的css)
	*@param {string} 需要移除的样式属性 可用 "," " " 分割
	*@param {boolean} 是否全匹配  否则模糊匹配 默认模糊匹配
	IE9以上最好直接用css('border','')
	*/
	_removeStyle : function(proto,m){
		proto = proto+'';
		var _proto = $.trim(proto.toLowerCase());
		_proto = _proto.replace(/\s+/g,',').split(',');
		var proto = {};
		$.each( _proto,function(i,v){
			proto[v] = true;						
		} );
		return this.each(function(){
			var cssText = this.style.cssText;
			if( cssText ) {
				var css = cssText.split(';');
				var data = {};
				$.each( css , function(i,v){
					if( v ) {
						var d = v.split(':');
						if( d.length ) {
							data[$.trim(d[0].toLowerCase())] = $.trim(d[1]);
						}
					}
				} );
				var t = [];
				for( var k in data ) {
					if( m ) {
						if( k in proto ) continue;	
					} else {
						//if( k.indexOf(proto) === 0 ) continue;	
						var r = false;
						for( var key in proto ) {
							if( k.indexOf(key) === 0 ) r=true;	
						}
						if( r ) {
							continue;	
						}
					}
					t.push( k+":"+data[k]+';' );
				}
				this.style.cssText = t.join("");
			}
		});	
	},
	_visible : function( bool ){
		var undef;
		bool = bool === undef ? true : bool;
		var visible = !!bool;
		return this.each(function(){
			var $this = $(this);					  
			if( visible ) {
				$this._removeStyle('visibility');
			} else {
				$this.css('visibility','hidden');	
			}
		});	
	}				 
});
/*
selection扩展
*/
jQuery.support.selectstart = false;
jQuery.fn.extend({
	disableSelection: function() {
		return this.bind( ( $.support.selectstart ? "selectstart" : "mousedown" ) +
			".nex-disableSelection", function( event ) {
				event.preventDefault();
			});
	},
	enableSelection: function() {
		return this.unbind( ".nex-disableSelection" );
	}
});
/*
兼容 jquery 1.9 以上 移除 $.support.boxMoal
*/
if( jQuery.support.boxModel === undefined ) {
	jQuery.support.boxModel = document.compatMode === "CSS1Compat";
}
/*
是否支持 onselectstart 检查
*/
jQuery(function() {
	var body = document.body,
		div = body.appendChild( div = document.createElement( "div" ) );
		
	$.support.selectstart = "onselectstart" in div;

	// set display to none to avoid a layout bug in IE
	// http://dev.jquery.com/ticket/4014
	body.removeChild( div ).style.display = "none";
});

/*
*Core.js
*/
var Nex = Nex || {};
(function(win,$){
	//"use strict";	
	var global = win,
        objectPrototype = Object.prototype,
        toString = objectPrototype.toString,
        enumerables = true,
        enumerablesTest = { toString: 1 },
        emptyFn = function(){},
        i;

    if (typeof Nex === 'undefined') {
        global.Nex = {};
    }

    Nex.global = global;

    for (i in enumerablesTest) {
        enumerables = null;
    }

    if (enumerables) {
        enumerables = ['hasOwnProperty', 'valueOf', 'isPrototypeOf', 'propertyIsEnumerable',
                       'toLocaleString', 'toString', 'constructor'];
    }

    /**
     * An array containing extra enumerables for old browsers
     * @property {String[]}
     */
    Nex.enumerables = enumerables;
	
	Nex.apply = function(object, config, defaults) {
        if (defaults) {
            Nex.apply(object, defaults);
        }

        if (object && config && typeof config === 'object') {
            var i, j, k;

            for (i in config) {
                object[i] = config[i];
            }

            if (enumerables) {
                for (j = enumerables.length; j--;) {
                    k = enumerables[j];
                    if (config.hasOwnProperty(k)) {
                        object[k] = config[k];
                    }
                }
            }
        }

        return object;
    };
	Nex.applyIf = function(object, config) {
        var property;
		if (object) {
			for (property in config) {
				if (object[property] === undefined) {
					object[property] = config[property];
				}
			}
		}

		return object;
    };
	
	var userAgent = navigator.userAgent.toLowerCase();
	var uaMatch = /msie ([\w.]+)/.exec( userAgent ) || [];
	function getCurrentScript(h) {
		var stack,
			DOC = document,
			undef,
			h = h === undef ? true : false,
			head = DOC.getElementsByTagName("head")[0]
			;
		try {
		  a._b.c(); //强制报错,以便捕获e.stack
		} catch (e) { //safari的错误对象只有line,sourceId,sourceURL
		  if( e.sourceURL ) {
			return e.sourceURL; //safari
		  }
		  stack = e.stack;
		  if (!stack && window.opera) {//opera
			  //opera 9没有e.stack,但有e.Backtrace,但不能直接取得,需要对e对象转字符串进行抽取
			  stack = (String(e).match(/of linked script \S+/g) || []).join(" ");
		  }
		}
		if (stack) {//chrome
		  stack = stack.split(/[@ ]/g).pop(); //取得最后一行,最后一个空格或@之后的部分
		  stack = stack[0] === "(" ? stack.slice(1, -1) : stack.replace(/\s/, ""); //去掉换行符
		  return stack.replace(/(:\d+)?:\d+$/i, ""); //去掉行号与或许存在的出错字符起始位置
		}
		//IE
		var context = h ? head : DOC;
		var nodes = context.getElementsByTagName("script");
		for (var i = nodes.length, node; node = nodes[--i]; ) {
		  if ( node.readyState === "interactive") {
			  return node.src;//node.className = 
		  }
		}
	}
	var baseUrl = getCurrentScript( false );
	baseUrl = baseUrl.split('/');
	baseUrl.pop();
	baseUrl = baseUrl.join('/');
	//baseUrl = baseUrl ? baseUrl+'/':baseUrl;
	/*如果是IE浏览器 加上各版本样式*/
	$(document).ready(function(){
		if( Nex.isIE && Nex.IEVer ) {
			var cls = ['nex-ie'];
			var bd = $(document.body);
			cls.push( 'nex-ie'+Nex.IEVer );
			if( Nex.IEVer<8 ) {
				cls.push( 'nex-ielt8' );
			}
			if( Nex.IEVer<9 ) {
				cls.push( 'nex-ielt9' );
			}
			bd.addClass( cls.join(' ') );
		}
	});
	
	function getTemplate(o){
		var o = o || {};
		return {
			cache1 : {},
			cache2 : {},
			helper : $.noop,//兼容用
			ltag : o.ltag || '<%',
			rtag : o.rtag || '%>',
			simple :  o.simple || false,
			compile1 : function(str, data, extArgs){
				var fn = this.cache1[str] ? this.cache1[str] :
				 new Function(extArgs ? "obj,"+extArgs : "obj",
				"var p=[],print=function(){p.push.apply(p,arguments);};" +
				"with(obj){p.push('" +
				str
				  .replace(/[\r\t\n]/g, " ")
				  .split(this.ltag).join("\t")
				  .replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
				  .replace(new RegExp("\t=(.*?)"+this.rtag,"g"), "',$1,'")
				  .split("\t").join("');")
				  .split(this.rtag).join("p.push('")
				  .split("\r").join("\\'")
			  + "');}return p.join('');");
				this.cache1[str] = fn;
				return data ? fn( data ) : fn;
			},
			compile2 : function(str, data, extArgs){//简单的模版
				var fn = this.cache2[str] ? this.cache2[str] :
				 new Function(extArgs ? "obj,"+extArgs : "obj",
				"var p=[],print=function(){p.push.apply(p,arguments);};" +
				"with(obj){p.push('" +
				str
				  .replace(/[\r\t\n]/g, " ")
				  .split(this.ltag).join("\t")
				  //.replace(new RegExp("((^|"+this.rtag+")[^\t]*)'","g"), "$1\r")
				  .replace(new RegExp("\t(.*?)"+this.rtag,"g"), "',$1,'")
				  .split("\t").join("');")
				  .split(this.rtag).join("p.push('")
				  .split("\r").join("\\'")
			  + "');}return p.join('');");
				this.cache2[str] = fn;
				return data ? fn( data ) : fn;
			},
			compile : function(){
				if( this.simple ) {
					return this.compile2.apply(this,arguments);	
				} else {
					return this.compile1.apply(this,arguments);		
				}
			}	
		};	
	}
	//common
	Nex.apply( Nex, {
		userAgent : userAgent,
		aid : 1,
		tabIndex : 1,
		zIndex : 99999,
		topzIndex : 99999999,
		scrollbarSize : false,
		resizeOnHidden : true,	
		easingDef : $.easing.def ? $.easing.def : 'swing',
		/*
		*根据参数返回模版对象
		*@param {Object} o ltag rtag simple(简单模式) 
		*@return {Object}
		*/
		getTemplate : getTemplate,
		/*
		*dirname
		*/
		dirname : function(baseUrl){
			baseUrl = baseUrl + '';
			baseUrl = baseUrl.split('/');
			baseUrl.pop();
			baseUrl = baseUrl.join('/');
			return baseUrl;
		},
		/*
		*private
		*safair不支持
		*/
		/*getcwd : function(h){
			return getCurrentScript(h);	
		},*/
		baseUrl : baseUrl,
		getCurrentScriptUrl : function(){
			return this.baseUrl;	
		},
		template : getTemplate(),
		/*
		*返回随机字符串
		*@param {Number} 返回自定的长度的随机字符串 默认是6位
		*@return {String}
		*/
		generateMixed : function(n){
			var n = n || 6;
			var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
			var res = "";
			 for(var i = 0; i < n ; i ++) {
				 var id = Math.ceil(Math.random()*35);
				 res += chars[id];
			 }
			 return res;	
		},
		/*
		*返回一个不重复字符串,使用方法同generateMixed
		*/
		unique : function(n){
			return this.uuid(n)
		},
		uuid : function(n){
			var str = Nex.generateMixed(n||6);
			var aid = str+'-'+Nex.aid++;
			return aid;		
		},
		distArr : function( arr ){
			var obj={},temp=[];
			for(var i=0;i<arr.length;i++){
				if(!obj[arr[i]]){
					temp.push(arr[i]);
					obj[arr[i]] =true;
				}
			}
			return temp;	
		}
	} );
	
	Nex.apply( Nex, {
		/*
		*检测当前对象是否是Nex类
		*/
		isClass : function(v){
			return  typeof v === 'function' && v.$isClass  ? true : false;
		},
		isNexConstructor : function(obj){
			return this.isClass(obj);	
		},
		/*
		*检测当前对象是否是Nex实例对象
		*/
		isNex : function(obj){
			return this.isInstance(obj);	
		},
		isInstance : function(v){
			return  typeof v === 'object' && v.isInstance  ? true : false;
		},
		/*
		*判断当前对象是否是xtype的对象类型 
		*/
		isXtype : function(obj){
			return typeof obj === 'object' && ('xtype' in obj )	? true : false;
		},
		/*
		*检测是否是jquery实例
		*/
		isjQuery : function(obj){
			return $.type(obj) === 'object' && ('_outerWidth' in obj) ? true :　false;	
		},
		/**
         * Clone almost any type of variable including array, object, DOM nodes and Date without keeping the old reference
         * @param {Object} item The variable to clone
         * @return {Object} clone
         */
        clone: function(item) {
            if (item === null || item === undefined) {
                return item;
            }

            // DOM nodes
            // TODO proxy this to Ext.Element.clone to handle automatic id attribute changing
            // recursively
            if (item.nodeType && item.cloneNode) {
                return item.cloneNode(true);
            }

            var type = toString.call(item);

            // Date
            if (type === '[object Date]') {
                return new Date(item.getTime());
            }

            var i, j, k, clone, key;

            // Array
            if (type === '[object Array]') {
                i = item.length;

                clone = [];

                while (i--) {
                    clone[i] = Nex.clone(item[i]);
                }
            }
            // Object
            else if (type === '[object Object]' && item.constructor === Object) {
                clone = {};

                for (key in item) {
                    clone[key] = Nex.clone(item[key]);
                }

                if (enumerables) {
                    for (j = enumerables.length; j--;) {
                        k = enumerables[j];
                        clone[k] = item[k];
                    }
                }
            }

            return clone || item;
        },
        /**
         * Returns the type of the given variable in string format. List of possible values are:
         *
         * - `undefined`: If the given value is `undefined`
         * - `null`: If the given value is `null`
         * - `string`: If the given value is a string
         * - `number`: If the given value is a number
         * - `boolean`: If the given value is a boolean value
         * - `date`: If the given value is a `Date` object
         * - `function`: If the given value is a function reference
         * - `object`: If the given value is an object
         * - `array`: If the given value is an array
         * - `regexp`: If the given value is a regular expression
         * - `element`: If the given value is a DOM Element
         * - `textnode`: If the given value is a DOM text node and contains something other than whitespace
         * - `whitespace`: If the given value is a DOM text node and contains only whitespace
         *
         * @param {Object} value
         * @return {String}
         * @markdown
         */
        typeOf: function(value) {
            if (value === null) {
                return 'null';
            }

            var type = typeof value;

            if (type === 'undefined' || type === 'string' || type === 'number' || type === 'boolean') {
                return type;
            }

            var typeToString = toString.call(value);

            switch(typeToString) {
                case '[object Array]':
                    return 'array';
                case '[object Date]':
                    return 'date';
                case '[object Boolean]':
                    return 'boolean';
                case '[object Number]':
                    return 'number';
                case '[object RegExp]':
                    return 'regexp';
            }

            if (type === 'function') {
                return 'function';
            }

            if (type === 'object') {
                if (value.nodeType !== undefined) {
                    if (value.nodeType === 3) {
                        return (/\S/).test(value.nodeValue) ? 'textnode' : 'whitespace';
                    }
                    else {
                        return 'element';
                    }
                }

                return 'object';
            }

			throw new Error('Failed to determine the type of the specified value "' + value + '". This is most likely a bug.');			
        },

        /**
         * Returns true if the passed value is empty, false otherwise. The value is deemed to be empty if it is either:
         *
         * - `null`
         * - `undefined`
         * - a zero-length array
         * - a zero-length string (Unless the `allowEmptyString` parameter is set to `true`)
         *
         * @param {Object} value The value to test
         * @param {Boolean} allowEmptyString (optional) true to allow empty strings (defaults to false)
         * @return {Boolean}
         * @markdown
         */
        isEmpty: function(value, allowEmptyString) {
            return (value === null) || (value === undefined) || (!allowEmptyString ? value === '' : false) || (Nex.isArray(value) && value.length === 0);
        },

        /**
         * Returns true if the passed value is a JavaScript Array, false otherwise.
         *
         * @param {Object} target The target to test
         * @return {Boolean}
         * @method
         */
        isArray: ('isArray' in Array) ? Array.isArray : function(value) {
            return toString.call(value) === '[object Array]';
        },

        /**
         * Returns true if the passed value is a JavaScript Date object, false otherwise.
         * @param {Object} object The object to test
         * @return {Boolean}
         */
        isDate: function(value) {
            return toString.call(value) === '[object Date]';
        },

        /**
         * Returns true if the passed value is a JavaScript Object, false otherwise.
         * @param {Object} value The value to test
         * @return {Boolean}
         * @method
         */
        isObject: (toString.call(null) === '[object Object]') ?
        function(value) {
            // check ownerDocument here as well to exclude DOM nodes
            return value !== null && value !== undefined && toString.call(value) === '[object Object]' && value.ownerDocument === undefined;
        } :
        function(value) {
            return toString.call(value) === '[object Object]';
        },

		isPlainObject : function(obj){
			return $._isPlainObject ? $._isPlainObject( obj ) : $.isPlainObject( obj );
		},
        /**
         * @private
         */
        isSimpleObject: function(value) {
            return value instanceof Object && value.constructor === Object;
        },
        /**
         * Returns true if the passed value is a JavaScript 'primitive', a string, number or boolean.
         * @param {Object} value The value to test
         * @return {Boolean}
         */
        isPrimitive: function(value) {
            var type = typeof value;

            return type === 'string' || type === 'number' || type === 'boolean';
        },

        /**
         * Returns true if the passed value is a JavaScript Function, false otherwise.
         * @param {Object} value The value to test
         * @return {Boolean}
         * @method
         */
        isFunction:
        // Safari 3.x and 4.x returns 'function' for typeof <NodeList>, hence we need to fall back to using
        // Object.prorotype.toString (slower)
        (typeof document !== 'undefined' && typeof document.getElementsByTagName('body') === 'function') ? function(value) {
            return toString.call(value) === '[object Function]';
        } : function(value) {
            return typeof value === 'function';
        },

        /**
         * Returns true if the passed value is a number. Returns false for non-finite numbers.
         * @param {Object} value The value to test
         * @return {Boolean}
         */
        isNumber: function(value) {
            return typeof value === 'number' && isFinite(value);
        },

        /**
         * Validates that a value is numeric.
         * @param {Object} value Examples: 1, '1', '2.34'
         * @return {Boolean} True if numeric, false otherwise
         */
        isNumeric: function(value) {
            return !isNaN(parseFloat(value)) && isFinite(value);
        },

        /**
         * Returns true if the passed value is a string.
         * @param {Object} value The value to test
         * @return {Boolean}
         */
        isString: function(value) {
            return typeof value === 'string';
        },

        /**
         * Returns true if the passed value is a boolean.
         *
         * @param {Object} value The value to test
         * @return {Boolean}
         */
        isBoolean: function(value) {
            return typeof value === 'boolean';
        },

        /**
         * Returns true if the passed value is an HTMLElement
         * @param {Object} value The value to test
         * @return {Boolean}
         */
        isElement: function(value) {
            return value ? value.nodeType === 1 : false;
        },

        /**
         * Returns true if the passed value is a TextNode
         * @param {Object} value The value to test
         * @return {Boolean}
         */
        isTextNode: function(value) {
            return value ? value.nodeName === "#text" : false;
        },

        /**
         * Returns true if the passed value is defined.
         * @param {Object} value The value to test
         * @return {Boolean}
         */
        isDefined: function(value) {
            return typeof value !== 'undefined';
        },
		isPlainObject : function(value){
			return $._isPlainObject(value);	
		},
		unDefined: function (val, d) {
			return val === undefined ? d : val;
		}
    });

    var check = function(regex){
            return regex.test(Nex.userAgent);
        },
		isStrict = document.compatMode == "CSS1Compat",
        version = function (is, regex) {
            var m;
            return (is && (m = regex.exec(Nex.userAgent))) ? parseFloat(m[1]) : 0;
        },
		docMode = document.documentMode,
        isOpera = check(/opera/),
        isOpera10_5 = isOpera && check(/version\/10\.5/),
        isChrome = check(/\bchrome\b/),
        isWebKit = check(/webkit/),
        isSafari = !isChrome && check(/safari/),
        isSafari2 = isSafari && check(/applewebkit\/4/), 
        isSafari3 = isSafari && check(/version\/3/),
        isSafari4 = isSafari && check(/version\/4/),
        isSafari5 = isSafari && check(/version\/5/),
        isIE = !isOpera && check(/msie/),
        isIE7 = isIE && ((check(/msie 7/) && docMode != 8 && docMode != 9) || docMode == 7),
        isIE8 = isIE && ((check(/msie 8/) && docMode != 7 && docMode != 9) || docMode == 8),
        isIE9 = isIE && ((check(/msie 9/) && docMode != 7 && docMode != 8) || docMode == 9),
		isIE10 = isIE && ((check(/msie 10/) && docMode != 7 && docMode != 8 && docMode != 9) || docMode == 10),
        isIE6 = isIE && check(/msie 6/),
        isGecko = !isWebKit && check(/gecko/),
        isGecko3 = isGecko && check(/rv:1\.9/),
        isGecko4 = isGecko && check(/rv:2\.0/),
        isGecko5 = isGecko && check(/rv:5\./),
        isFF3_0 = isGecko3 && check(/rv:1\.9\.0/),
        isFF3_5 = isGecko3 && check(/rv:1\.9\.1/),
        isFF3_6 = isGecko3 && check(/rv:1\.9\.2/),
        isWindows = check(/windows|win32/),
        isMac = check(/macintosh|mac os x/),
        isLinux = check(/linux/),
        chromeVersion = version(true, /\bchrome\/(\d+\.\d+)/),
        firefoxVersion = version(true, /\bfirefox\/(\d+\.\d+)/),
        ieVersion = version(isIE, /msie (\d+\.\d+)/),
        operaVersion = version(isOpera, /version\/(\d+\.\d+)/),
        safariVersion = version(isSafari, /version\/(\d+\.\d+)/),
        webKitVersion = version(isWebKit, /webkit\/(\d+\.\d+)/),
        isSecure = /^https/i.test(window.location.protocol);

    try {
        document.execCommand("BackgroundImageCache", false, true);
    } catch(e) {}

    var nullLog = function () {};
    nullLog.info = nullLog.warn = nullLog.error = Nex.emptyFn;

    Nex.apply( Nex, {
        
		
        SSL_SECURE_URL : isSecure && isIE ? 'javascript:\'\'' : 'about:blank',


        USE_NATIVE_JSON : false,


        isStrict: isStrict,


        isIEQuirks: isIE && !isStrict,

        
        isOpera : isOpera,

        
        isOpera10_5 : isOpera10_5,

        
        isWebKit : isWebKit,

        
        isChrome : isChrome,

        
        isSafari : isSafari,

        
        isSafari3 : isSafari3,

        
        isSafari4 : isSafari4,

        
        isSafari5 : isSafari5,

        
        isSafari2 : isSafari2,

		IEVer : ieVersion,
        
        isIE : isIE,

        
        isIE6 : isIE6,

        
        isIE7 : isIE7,

        
        isIE8 : isIE8,

        
        isIE9 : isIE9,

        
        isGecko : isGecko,

        
        isGecko3 : isGecko3,

        
        isGecko4 : isGecko4,

        
        isGecko5 : isGecko5,

        
        isFF3_0 : isFF3_0,

        
        isFF3_5 : isFF3_5,

        
        isFF3_6 : isFF3_6,

        
        isFF4 : 4 <= firefoxVersion && firefoxVersion < 5,

        
        isFF5 : 5 <= firefoxVersion && firefoxVersion < 6,

        
        isLinux : isLinux,

        
        isWindows : isWindows,

        
        isMac : isMac,

        
        chromeVersion: chromeVersion,

        
        firefoxVersion: firefoxVersion,

        
        ieVersion: ieVersion,

        
        operaVersion: operaVersion,

        
        safariVersion: safariVersion,

        
        webKitVersion: webKitVersion,

        
        isSecure: isSecure,

        
        escapeRe : function(s) {
            return s.replace(/([-.*+?^${}()|[\]\/\\])/g, "\\$1");
        },
		
        
        log :
            nullLog,
		
        
        invoke : function(arr, methodName){
            var ret = [],
                args = Array.prototype.slice.call(arguments, 2);
            $.each(arr, function(i,v) {
                if (v && typeof v[methodName] == 'function') {
                    ret.push(v[methodName].apply(v, args));
                } else {
                    ret.push(undefined);
                }
            });
            return ret;
        }
		
		
    } );
	Nex.apply( Nex, {
		htmlEncode: (function() {
			var entities = {
				'&': '&amp;',
				'>': '&gt;',
				'<': '&lt;',
				'"': '&quot;'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					return entities[capture];
				});
			};
		})(),
		htmlDecode: (function() {
			var entities = {
				'&amp;': '&',
				'&gt;': '>',
				'&lt;': '<',
				'&quot;': '"'
			}, keys = [], p, regex;
	
			for (p in entities) {
				keys.push(p);
			}
	
			regex = new RegExp('(' + keys.join('|') + '|&#[0-9]{1,5};' + ')', 'g');
	
			return function(value) {
				return (!value) ? value : String(value).replace(regex, function(match, capture) {
					if (capture in entities) {
						return entities[capture];
					} else {
						return String.fromCharCode(parseInt(capture.substr(2), 10));
					}
				});
			};
		})(),
		addCssRules : function(style, cssSelector, cssText, update){
			function fcamelCase( all, letter ) {
				return ( letter + "" ).toUpperCase();
			}
			function camelCase( string ){
				var rmsPrefix = /^-ms-/,
					rdashAlpha = /-([\da-z])/gi;
				return string.replace( rmsPrefix, "ms-" ).replace( rdashAlpha, fcamelCase );
			}
			function $caller(cssSelector, cssText, update){
				var undef;
				var update = update === undef ? true : update;
				return update ? updateRules.apply(this,[cssSelector, cssText]) : addRules.apply(this,[cssSelector, cssText]);
			};
			function addRules( cssSelector, cssText ){
				var styleSheet = style.styleSheet?style.styleSheet:style.sheet;
				var rules = styleSheet.cssRules || styleSheet.rules;
				if( styleSheet.addRule ) {
					styleSheet.addRule(cssSelector,cssText);	
				} else {
					styleSheet.insertRule(cssSelector+"{"+cssText+"}", rules.length);	
				}
				return $caller;
			}
			function updateRules( cssSelector, cssText ){
				var styleSheet = style.styleSheet?style.styleSheet:style.sheet;
				var rules = styleSheet.cssRules || styleSheet.rules;
				var rule = null;
				for( var i=0, len=rules.length; i<len; i++ ) {
					//只修改最后一个样式
					if( rules[i].selectorText.toLowerCase() === cssSelector.toLowerCase() ) {
						rule = rules[i];
					}
				}
				if( !rule ) {
					return addRules( cssSelector, cssText );
				} else {
					var css = ( cssText + "" ).split(';');
					for( var k=0, len2 = css.length; k < len2; k++ ) {
						var d = css[k].split(':');
						rule.style[ $.trim(camelCase(d[0])) ] = d[1];	
					}	
				}
				return $caller;
			}
			return cssSelector ? $caller(cssSelector, cssText, update) : $caller;
		},
		parseUrl : function( url ){
			var urlParseRE = /^\s*(((([^:\/#\?]+:)?(?:(\/\/)((?:(([^:@\/#\?]+)(?:\:([^:@\/#\?]+))?)@)?(([^:\/#\?\]\[]+|\[[^\/\]@#?]+\])(?:\:([0-9]+))?))?)?)?((\/?(?:[^\/\?#]+\/+)*)([^\?#]*)))?(\?[^#]+)?)(#.*)?/;	
			if ( $.type( url ) === "object" ) {
				return url;
			}
			var matches = urlParseRE.exec( url || "" ) || [];
			return {
				href:         matches[  0 ] || "",
				hrefNoHash:   matches[  1 ] || "",
				hrefNoSearch: matches[  2 ] || "",
				domain:       matches[  3 ] || "",
				protocol:     matches[  4 ] || "",
				doubleSlash:  matches[  5 ] || "",
				authority:    matches[  6 ] || "",
				username:     matches[  8 ] || "",
				password:     matches[  9 ] || "",
				host:         matches[ 10 ] || "",
				hostname:     matches[ 11 ] || "",
				port:         matches[ 12 ] || "",
				pathname:     matches[ 13 ] || "",
				directory:    matches[ 14 ] || "",
				filename:     matches[ 15 ] || "",
				search:       matches[ 16 ] || "",
				hash:         matches[ 17 ] || ""
			};
		},
		/*
		*监控一个函数并使得此函数有 before after 回调
		*	examples : 
		*		f = Nex.monitor( fn );
		*		f.before( function(){
		*			console.log('before call')	
		*		} );
		*		f.after( function(){
		*			console.log('after call')	
		*		} )
		*/
		monitor : function( fn ){
			var newFn;
			newFn = function(){
				var rt;
				newFn._callBefore.apply( this, arguments );
				rt = fn.apply( this, arguments );	
				newFn._callAfter.apply( this, arguments );
				return rt;
			}
			
			var q = [];
			
			newFn._callBefore = function(){
				for( var i=0, len=q.length; i<len; i++ ) {
					var cb = q[i];
					if( !cb ) continue;
					if( cb.above ) {
						cb.fn.apply( this, arguments );	
					}
				}	
			};
			newFn._callAfter = function(){
				for( var i=0, len=q.length; i<len; i++ ) {
					var cb = q[i];
					if( !cb ) continue;
					if( !cb.above ) {
						cb.fn.apply( this, arguments );	
					}
				}	
			};
			newFn.before = function( fn ){
				return q.push( {
					above : true,
					fn : fn	
				} ) - 1;
			};	
			newFn.after = function( fn ){
				return q.push( {
					above : false,
					fn : fn	
				} ) - 1;
			};
			newFn.remove = function( i ){
				return q[i] && (q[i] = null);
			};
			newFn.beforeOnce = function( fn ){
				var i;
				i = newFn.before( function(){
					fn.apply( this, arguments );
					newFn.remove(i);	
				} );
			};	
			newFn.afterOnce = function( fn ){
				var i;
				i = newFn.after( function(){
					fn.apply( this, arguments );
					newFn.remove(i);	
				} );
			};
			
			return newFn;
		}
	} );
	Nex.apply( Nex, {
		//数组移动算法
		// pos 要移动的元素下标
		array_move : function(iarr,pos,target,t) {//t 代表是前还是后 1 代表前 0 代表后
	
			if(pos == target) return iarr;
			var __arr = iarr;
			//支持字符下标
			var _iarr = iarr = [].concat(__arr);
			iarr = [];
			var j=0,
				len = _iarr.length;
			for(;j<len;j++) {
				var _i = iarr.push(j);
				if( j == pos) {
					pos = _i-1;
				} else if( j == target ) {
					target = _i-1;
				}
			}
			//core
			var _p = iarr[pos];//记录元副本
			if( pos>target ) {
				if(!t) {
					target++;
				}
				for(var i=pos;i>=0;i--) {
					if(i == target) {
						iarr[i] = _p;
						break;
					}
					iarr[i] = iarr[i-1];
				}
			} else if( pos<target ) {
				if(t) {
					target--;
				}
				for(var i=pos;i<=target;i++) {
					
					if( i == target ) {
						iarr[i] = _p;
					} else {
						iarr[i] = iarr[i+1];
					}	
				}
			}
			//字符下标
			
			var new_arr = __arr;
			new_arr.length = 0;
			//new_arr.push.apply(new_arr,_iarr); //不建议用 因为 _iarr 会有长度限制 63444
			var k=0,
				len = iarr.length;
			for( ;k<len;k++ ) {
				new_arr.push( _iarr[ iarr[k] ] );
			}
			iarr = new_arr;
			return iarr;
		},
		/*
		*删除数组元素 index 为下标或者下标数组 或者回调函数 回调返回true即可
		*/
		array_splice : function(index,arr){
			var self = this,undef;
			if( !$.isArray( arr ) ) return arr;
			
			var call = index;
			
			if( $.isArray( index ) && index.length<=1 ) {
				index = index[0];
			}
			
			if( index === undef ) return arr;
			
			//如果index 不是数组或者不是回调时 直接调用splice;
			if( !$.isArray( index ) && !$.isFunction(index) ) {
				if( isNaN( parseInt( index ) ) ) return arr;
				arr.splice( parseInt(index),1 );
				return arr;
			}
			
			var _arr = self.copy( arr );
			var index = $.isArray( index ) ? index : ($.isFunction(index) ? [] : [index]);
			var _index = {};
			$.each(index,function(i,v){
				_index[v] = true;	
			});
			
			arr.length = 0;
			
			$.each( _arr,function(i,v){
				if( $.isFunction( call ) ) {
					var r = call.call(v,i,v);	
					if( r === true ) {
						_index[i] = true;	
					}
				}
				if( !(i in _index) ) {
					arr.push(v);	
				}	
			} );
			
			return arr;
		},
		/*				
		*数组插入 index 需要插入的位置 arr源数组,_arr需要插入的值可以是数组,t 0后面  1前面 _arr 长度不要超过6W+
		*/
		array_insert : function(index,_arr,arr,t){//t=before
			var self = this,
				undef,
				t = t === undef ? 0 : t;
			if( !$.isArray( arr ) ) return arr;
			
			var call = index;
			
			if( !$.isArray( _arr ) ) _arr = [ _arr ];
			
			if( index === undef ) return arr;
			
			var len = arr.length;
			if( index<len ) {
				if( t )	{
					_arr = _arr.concat( [ arr[index] ] );	
				} else {
					_arr = [ arr[index] ].concat( _arr );
				}
			}
			_arr = [index,1].concat( _arr );
			arr.splice.apply(arr,_arr);
			return arr;
		},
		array_clear : function(arr){
			arr.length = 0;
			return arr;
		},
		array_copy : function(arr){
			return [].concat( arr );	
		},
		//解决数组迭代时使用splice问题方案,在迭代之前应该使用copyArray复制出来
		copyArray : function(arr){
			return [].concat( arr );
		},
		//copy只是对数组或对象只是增加一个引用计数，并不是深复制
		copy : function(data){
			if( $.isArray( data ) ) {
				return  [].concat(data);	
			} else if( $.isPlainObject(data) ) {
				return $.extend({},data);
			} else {
				return data;	
			}
		},
		//只接受 字符串 number 
		inArray : function(elem,arr){
			if( $.type( elem ) === 'number' ) {
				elem = elem+'';	
			}
			if ( arr ) {
				var len = arr.length;
				var i = 0;
				for ( ; i < len; i++ ) {
					// Skip accessing in sparse arrays
					var v = arr[ i ];
					if( $.type( v ) === 'number' ) {
						v = v+'';	
					}
					if ( i in arr && (v === elem) ) {
						return i;
					}
				}
			}
			return -1;
		},
		str_number : function(num,elc){//elc 截取的小数位
			var num = num + '';
			if( $.type( num ) === 'string' ) {
				var n = num.split('.');
				if( n.length>1 ) {
					var ext = n[1].substring(0,elc);	
					if( ext !== '' ) {
						num = [n[0],ext].join('.');	
					} else {
						num = n[0];
					}
				}	
			}
			return Number(num);
		},
		/*
		*判断元素垂直滚动条是否滚动到底 @dom
		*/
		_checkYScrollEnd : function( el ){
			var scrollTop = 0;
			var clientHeight = 0;
			var scrollHeight = 0;	
			if( el === document.body || el === document || el === window ) {
				if (document.documentElement && document.documentElement.scrollTop) {
					scrollTop = document.documentElement.scrollTop;
				} else if (document.body) {
					scrollTop = document.body.scrollTop;
				}
				if (document.body.clientHeight && document.documentElement.clientHeight) {
					clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
				} else {
					clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
				}
				scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
			} else {
				if( !el.nodeType ) return false;
				scrollTop = el.scrollTop;
				clientHeight = el.clientHeight;
				scrollHeight = el.scrollHeight;
			}
			if( clientHeight >= scrollHeight ) {
				return false;
			} else if (scrollTop + clientHeight >= scrollHeight) {//必须要使用>= 因为缩放后会大于scrollHeight
				return true;
			} else {
				return false;
			}	
		},
		/*
		*判断元素水平滚动条是否滚动到底 @dom
		*/
		_checkXScrollEnd : function( el ){
			var scrollLeft = 0;
			var clientWidth = 0;
			var scrollWidth = 0;	
			if( el === document.body || el === document || el === window ) {
				if (document.documentElement && document.documentElement.scrollLeft) {
					scrollLeft = document.documentElement.scrollLeft;
				} else if (document.body) {
					scrollLeft = document.body.scrollLeft;
				}
				if (document.body.clientWidth && document.documentElement.clientHeight) {
					clientWidth = (document.body.clientWidth < document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
				} else {
					clientWidth = (document.body.clientWidth > document.documentElement.clientWidth) ? document.body.clientWidth: document.documentElement.clientWidth;
				}
				scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
			} else {
				if( !el.nodeType ) return false;
				scrollLeft = el.scrollLeft;
				clientWidth = el.clientWidth;
				scrollWidth = el.scrollWidth;
			}
			if( clientWidth >= scrollWidth ) {
				return false;
			} else if (scrollLeft + clientWidth >= scrollWidth) {//必须要使用>= 因为缩放后会大于scrollWidth
				return true;
			} else {
				return false;
			}		
		},
		/*
		*验证是否滚动到低 @el dom @a left/top
		*/
		isScrollEnd : function( el,a ){
			var self = this,
				undef;
			if( a == 'left' ) {
				return self._checkXScrollEnd( el );	
			} else {
				return self._checkYScrollEnd( el );		
			}
		},
		/*
		*判断是否出现滚动条
		* @param el dom
		* @param a left top
		* @param t boolean defalut:false 如果t=true则只要超出宽度就会认定有滚动条，但是未必有滚动条一般拿来检测是否子节点的宽度大于父节点
		*/
		hasScroll: function( el, a, t ) {
			
			var el = $(el)[0];//el 是dom
			
			//If overflow is hidden, the element might have extra content, but the user wants to hide it
			/*
			//IE下 只要overflow-x/overflow-y设置了hidden那么获得的overflow就是hidden 所以我们要只取-x -y
			if ( $( el ).css( "overflow" ) === "hidden") {
				return false;
			}
			*/
			if( t !== true ) {
				if( a === "left" ) {
					if ( $( el ).css( "overflow-x" ) === "hidden") {
						return false;
					}
				} else {
					if ( $( el ).css( "overflow-y" ) === "hidden") {
						return false;
					}	
				}
			}
			var scroll = ( a && a === "left" ) ? "scrollLeft" : "scrollTop",
				has = false;
			if ( el[ scroll ] > 0 ) {
				return true;
			}
			// TODO: determine which cases actually cause this to happen
			// if the element doesn't have the scroll set, see if it's possible to
			// set the scroll
			el[ scroll ] = 1;
			has = ( el[ scroll ] > 0 );
			el[ scroll ] = 0;
			return has;
		},
		/*
		* 获取浏览器滚动条大小
		*/
		getScrollbarSize: function () {
			if (!Nex.scrollbarSize) {
				var db = document.body,
					div = document.createElement('div');

				div.style.width = div.style.height = '100px';
				div.style.overflow = 'scroll';
				div.style.position = 'absolute';

				db.appendChild(div); 
				
				Nex.scrollbarSize = {
					width: div.offsetWidth - div.clientWidth,//竖
					height: div.offsetHeight - div.clientHeight//横
				};
				//IE下 出现过有一边获取不到的情况 就是为0
				Nex.scrollbarSize.width = Nex.scrollbarSize.width || Nex.scrollbarSize.height;
				Nex.scrollbarSize.height = Nex.scrollbarSize.height || Nex.scrollbarSize.width;
				
				Nex.scrollbarSize.x = Nex.scrollbarSize.height;
				Nex.scrollbarSize.y = Nex.scrollbarSize.width;
				
				db.removeChild(div);
				
			}
			return Nex.scrollbarSize;
		},
		//工具集合
		util : {},
		addUtil : function(n,v){
			return this.util[n] = v;	
		},
		getUtil : function(n){
			return this.util[n];	
		},
		extendUtil : function(n,v){
			return this.apply( this.util[n],v );
		},
		removeUtil : function(){
			this.util[n] = null;
			delete this.util[n];
			return this;
		},
		//所有组合mixins
		mixins : {},
		addMixins : function( n,v ){
			v = $.isFunction( v ) ? v.call( this ) : v;
			return this.mixins[n] = v;	
		},
		getMixins : function(n){
			return this.mixins[n];	
		},
		extendMixins : function(n,v){
			return this.apply( this.mixins[n],v );
		},
		removeMixins : function(){
			this.mixins[n] = null;
			delete this.mixins[n];
			return this;
		},
		/*直接使用jquery 的Deferred对象 所以要使用when需要确定jquery版本支持Deferred*/
		when : function(){
			var arr = [].slice.apply(arguments);
			var deferreds = [];
			for( var i=0,len=arr.length;i<len;i++ ) {
				var cmp;
				var deferred = arr[i];
				if( Nex.isXtype( deferred ) || Nex.isString( deferred ) ) {
					var cmp = Nex.create( deferred );
					if( cmp && cmp.getDeferred ) {
						deferred = cmp.getDeferred();	
					} else {
						deferred = null;
					}
				}
				
				if( Nex.isInstance( deferred ) ) {
					deferred = deferred.getDeferred ? deferred.getDeferred() : null;
				}
				if( deferred ) {
					deferreds.push( deferred );
				}
			}
			return $.extend($.when.apply( $, deferreds ),{
				success : function(){
					this.done.apply( this,arguments )	
				},
				error : function(){
					this.fail.apply( this,arguments )	
				},
				complete : function(){
					this.always.apply( this,arguments )	
				}	
			});	
		},
		emptyFn : $.noop,
		error : function( msg ){
			var undef,
				e = new Error((msg===undef?'':msg));
			throw e;
			return e;	
		}	
	} );	
	Nex.apply( Nex, {
		/*类的别名*/
		aliases : {},
		/*
		*xtype对应的类
		*/
		xtypes : {},
		/*类*/
		classes : {},
		getClass : function( name ){
			return this.classes[name] || this.aliases[name] || this.xtypes[name];
		},
		addClass : function( name,cls ){
			this.classes[name] = cls;
			return this;
		},
		addXtype : function( name,cls ){
			this.xtypes[name] = cls;
			return this;	
		},
		addAlias : function( name,cls ){
			this.aliases[name] = cls;
			return this;	
		},
		/*
		*创建类
		*	examples:
		*		function Class( age,name ){
		*			this.age = age;
		*			this.name=name;	
		*		}
		*		Class.prototype = {
		*			getAge : function(){
		*				return this.age; 	
		*			},
		*			getName : function(){
		*				return this.name; 	
		*			}
		*		}
		*		var obj = new Class( 21, nobo );
		*		or
		*		var obj = Nex.createClass( Class, 21, 'nobo' );
		*/
		createClass : (function(){
			function cloneFn( fn ){
				var constructor = function(){};
				constructor.prototype = fn.prototype;
				return constructor;
			}
			return 	function(){//Class, argv1,argv2,...
				var Class = arguments[0];
				var Args  = [].slice.call( arguments, 1 );	
				
				if( typeof Class != 'function' ) {
					return null;	
				}
				
				var instance = new (cloneFn( Class ));
				Class.apply( instance, Args );
				return instance;
			};
		})(),
		/*
		*实例化Nex类
		*	examples:
		*		Nex.define('MyApp',{
		*			age : null,
		*			name : null,
		*			constructor : function( age, name ){
		*				if( Nex.isObject( age ) ) {
		*					this.age = age.age;
		*					this.name=age.name;	
		*				} else {
		*					this.age = age;
		*					this.name=name;
		*				}
		*			},
		*			say : function(){
		*				alert('Hello '+this.name);	
		*			}	
		*		});
		*		new MyApp(21, 'nobo');
		*		or
		*		Nex.create('MyApp', 21, 'nobo');
		*		or
		*		Nex.create(MyApp, 21, 'nobo');
		*		or
		*		Nex.create({
		*			xtype : 'MyApp',
		*			age : 21,
		*			name : 'nobo'	
		*		});
		*/
		create : function(){
			var self = this,undef;
			var argvs = [].slice.apply(arguments);
			
			var Class = argvs[0];
			var params = argvs.slice(1);
			
			var len = argvs.length;
			if( len<=0 ) return false;
			
			if( Nex.isInstance( Class ) ) {
				return Class;	
			}
			
			if( Nex.isClass( Class ) ) {
				return Nex.createClass.apply( Nex, [ Class ].concat( params ) );
			}
			
			if( Nex.isXtype(Class) ) {
				var opts = Class;
				var xtype = opts.xtype;
				delete opts.xtype;	
				Class = Nex.getClass( xtype );
				if( Class ) {
					if( Nex.isInstance( Class ) ) {
						return Class;			
					}
					return Nex.createClass.apply( Nex, [ Class,opts  ].concat( params ) ); 	
				} else {
					return false;	
				}
			}
			
			if( Nex.isString( Class ) ) {
				Class = Nex.getClass( Class );	
				if( !Class ) {
					return false;	
				}
				if( Nex.isInstance( Class ) ) {
					return Class;			
				}
				return Nex.createClass.apply( Nex, [ Class ].concat( params ) );
			}
			
			return false;
		},
		Create : function(){
			return this.create.apply( this, arguments );	
		},
		getLoader : function(){
			return  null;	
		},
		isReady : false,
		//需要改进如果define没有加载任何依赖时 不会触发complete
		onReady : function(fn){
			if( !Nex.isFunction(fn) ) return this;
			var loader = this.getLoader();
			Nex.isReady = false;
			var startReady = function(){
				if( loader && !loader.isLoading() ) {
					Nex.isReady = true;	
				} else if( !loader ) {
					Nex.isReady = true;		
				}
				if( Nex.isReady ) {
					fn();	
				} else {
					var $call = function(s){
						var args = [].slice.apply( arguments, [0] );
						var isCache = args.pop();
						if( !isCache ) {
							fn();
						} else {
							loader.complete( $call );
						}	
					};
					loader.complete( $call );
				}	
			};
			$(function(){
				startReady();
			});	
		}	
	} );
})(window,jQuery);
(function(){
var noArgs = [],
	enumerables = Nex.enumerables,
	TC = function() {},
	chain = function(object) {
		TC.prototype = object;
		var result = new TC();
		TC.prototype = null;
		return result;
	},
    Base = function(){};
	
	Nex.chain = chain;
	
	Nex.apply( Base, {
		$className: 'Nex.Base',
        $isClass: true,	
		superclass : null,
		extend: function(superClass) {
            var superPrototype = superClass.prototype,
                basePrototype, prototype, name;
			var className = this.$className || '';	
			//isObject....	
			if( Nex.isObject(superClass) ) {
				this.override( superClass );
				return;
			}
			for (name in superClass) {
				//this[name] = Nex.clone(superClass[name]);
				this[name] = superClass[name];
			}
			this._optionsList = [];	
			
			/*
			* var F = function(){};
			* F.prototype = superPrototype;
			* prototype = this.prototype = new F();
			*/
            prototype = this.prototype = chain(superPrototype);
            this.superclass = prototype.superclass = superPrototype;
			prototype.self = this;

            if (!superClass.$isClass) {
                basePrototype = Base.prototype;
                for (name in basePrototype) {
                    if (name in prototype) {
                        prototype[name] = basePrototype[name];
                    }
                }
            }
			this.$className = className;
			prototype.$className = className;
        },
		override: function(members) {
            var prototype = this.prototype,
                names = [],
                i, ln, name, member,
				cloneFunction = function(method){
					return function() {
						return method.apply(this, arguments);
					};	
				};
				
			var className = this.$className || '';	
			
            for (name in members) {
                names.push(name);
            }
			
            if (enumerables) {
                names.push.apply(names, enumerables);
            }
			
            for (i = 0,ln = names.length; i < ln; i++) {
                name = names[i];

                if (members.hasOwnProperty(name)) {
                    member = members[name];
					
                    if (typeof member == 'function' && !member.$isClass) {
						if (typeof member.$owner != 'undefined') {
							member = cloneFunction(member);
						}
                        member.$owner = this;
                        member.$name = name;
                    }

                    prototype[name] = member;
                }
            }
			
			prototype.$className = className;	
			prototype.self = this;	
			
            return this;
        },
		addStatics: function(members) {
            var member, name;

            for (name in members) {
                if (members.hasOwnProperty(name)) {
                    member = members[name];
                    this[name] = member;
                }
            }

            return this;
        },
		addMembers: function(members) {
            var prototype = this.prototype,
                names = [],
                i, ln, name, member;
				
			var className = this.$className || '';	
			
            for (name in members) {
                names.push(name);
            }

            if (enumerables) {
                names.push.apply(names, enumerables);
            }

            for (i = 0,ln = names.length; i < ln; i++) {
                name = names[i];

                if (members.hasOwnProperty(name)) {
                    member = members[name];

                    if (typeof member == 'function' && !member.$isClass) {
                        member.$owner = this;
                        member.$name = name;
                    }

                    prototype[name] = member;
                }
            }
			
			prototype.$className = className;	
			prototype.self = this;	
			
            return this;
        },
		addMember: function(name, member) {
			var m = {};
			m[name] = member;
           	this.addMembers(m);
            return this;
        },
		implement: function() {
            this.addMembers.apply(this, arguments);
        },
		
        /**
         * Borrow another class' members to the prototype of this class.
         *
         *     Nex.define('Bank', {
         *         money: '$$$',
         *         printMoney: function() {
         *             alert('$$$$$$$');
         *         }
         *     });
         *
         *     Nex.define('Thief', {
         *         ...
         *     });
         *
         *     Thief.borrow(Bank, ['money', 'printMoney']);
         *
         *     var steve = new Thief();
         *
         *     alert(steve.money); // alerts '$$$'
         *     steve.printMoney(); // alerts '$$$$$$$'
         *
         * @param {Nex.Base} fromClass The class to borrow members from
         * @param {Array/String} members The names of the members to borrow
         * @return {Nex.Base} this
         * @static
         * @inheritable
         * @private
         */
        borrow: function(fromClass, members) {
            var prototype = this.prototype,
                fromPrototype = fromClass.$isClass ? fromClass.prototype : 
				( (fromClass = Nex.getClass(fromClass)) ? fromClass.prototype : {} ),
                i, ln, name, fn, toBorrow;

            members = $.isArray( members ) ? [].concat(members) : [ members ];

            for (i = 0,ln = members.length; i < ln; i++) {
                name = members[i];

                toBorrow = fromPrototype[name];

                if (typeof toBorrow == 'function') {
                    fn = function() {
                        return toBorrow.apply(this, arguments);
                    };

                    fn.$owner = this;
                    fn.$name = name;

                    prototype[name] = fn;
                }
                else {
                    prototype[name] = toBorrow;
                }
            }
			
			prototype.self = this;	
				
            return this;
        },
		setXtype : function(xtype){
			var undef;
			if( xtype === undef ) return this;
			
			this.xtype = xtype;
			
			//Nex.classes[ xtype ] = this;
			Nex.addXtype( xtype, this );
			
			return this;	
		},
		setAliasName : function( aliasName ){
			var self = this;
			if( aliasName ) {
				var aliasNames = $.trim(aliasName).split(/\s+/g);
				$.each( aliasNames,function(i,n){
					Nex.setNamespace( n,self );
					Nex.addAlias( n,self );
				} );
			}	
			return self;
		},
		_optionsList : [],
		setOptions : function( options ){
			if( Nex.isObject( options ) ) {
				var _opts = options;
				options = function(){
					return Nex.clone(_opts);
				}
			}
			if( Nex.isFunction( options ) ) {
				this._optionsList.push( function( opt, scope ){
					return options.call( this, opt, scope );
				} );
			}
			return this;
		},
		getOptions : function( scope ){
			var list = this._optionsList || [];
			var opt = this.getSuperClassOptions( scope ) || {};
			var len = list.length;
			if( len ) {
				for( var i = 0; i < len; i++ ) {
					var o = list[i];
					Nex.apply( opt, o.call( this, opt, scope || this ) );	
				}
			}
			return opt;
		},
		getSuperClass : function(){
			return this.superclass ? this.superclass.self : null;	
		},
		getSuperClassOptions : function( scope ){
			var subClass = this,
				superClass = null,
				opts = [],
				opt = {};
			while( superClass = subClass.getSuperClass() ) {
				opts.push( superClass.getOptions( scope ) );	
				subClass = superClass;
			}
			
			opts.reverse();
			
			$.each( opts,function( i, d ){
				Nex.apply( opt, d );	
			} );
			
			return opt;
		},
		create : function(){
			return Nex.create.apply( Nex, [ this ].concat( [].slice.apply( arguments ) ) );	
		}
	} );
	Nex.apply( Base.prototype, {
		isInstance : true,
		$className : 'Nex.Base',
		self 	   : Base,
        superclass : null,
        callParent : function(args) {
            var method,
                superMethod = (method = this.callParent.caller) && 
                              (method = method.$owner ? method : method.caller) &&
                               method.$owner.superclass[method.$name];
				superMethod = superMethod || TC;	
            return superMethod.apply(this, args || noArgs);
        },
		extend : function( data ){
			var self = this;
			var Class = self.self;	
			if( data && $.isPlainObject( data ) ) {
				Class.override.call( self, data );
			}
			return self;
		},
		/*
		*动态添加组合
		*	obj.addMixins( mixin1,mixin2,... )
		*/
		addMixins : function(){
			var self = this;
			var opt = this.configs;
			
			var mixs = [].slice.call( arguments, 0);
			
			var configs = [], properties = {}, i=0, len = mixs.length;
			
			if( !len ) return self;
			
			for( ;i<len;i++ ) {
				var m = mixs[i];
				if( Nex.isString( m ) ) {
					m = Nex.getClass( m );	
					if( !m ) continue;
				}
				if( Nex.isClass( m ) ) {
					configs.push( function( opt, scope ){
						return m.getOptions( scope );	
					} );	
					Nex.apply( properties, m.prototype || {} );
				} else if( Nex.isObject( m ) ){
					if( m.configs ) {
						configs.push( m.configs );
					}
					delete m.configs;
					Nex.apply( properties, m );
				}
			}
			//组合成员
			Nex.applyIf( self, properties );
			//组合参数
			if( configs.length ) {
				var mopts = {};	
				for( var i=0, len=configs.length; i<len; i++ ) {
					var cfg = configs[i];
					if( Nex.isFunction( cfg ) ) {
						Nex.apply( mopts, cfg( mopts, self ) || {} );	
					} 	
					if( Nex.isObject( cfg ) ) {
						Nex.apply( mopts, Nex.clone( cfg ) );		
					}
				}
				Nex.applyIf( opt, mopts );
			}
			return self;
		},
		initConfigs : function( cfg ){
			var self = this;
			var Class = self.self;
			var opts = Class.getOptions( self );
			if( Nex.isFunction( cfg ) ) {
				cfg = cfg.call( self,opts ) || {};	
			}
			var configs = Nex.apply( {}, cfg, opts );//$.extend({},opts,cfg);
			//事件只初始化一次把， 会被后面的覆盖
			//self.initEvents(configs);//初始化用户自定义事件
			/*
			if( Nex.isNex(configs.parent) ) {
				var pid = configs.parent.C('id');
				configs.parent = pid;	
			}
			*/
			self.configs = configs;
			
			if( 'mixins' in configs ) {
				var mixins = configs.mixins;
				delete configs.mixins;
				
				var mixs = [];
			
				if( Nex.isPlainObject( mixins ) ) {
					$.each( mixins, function(i,v){
						mixs.push( v );	
					} );
				} else {
					mixs = Nex.isArray( mixins ) ? mixins : [ mixins ];	
				}
				self.addMixins.apply( self, mixs );
			}
			
			/*如果参数中有properties,则当前属性会赋值到当前对象的properties*/
			var properties = [ configs.properties, configs.override ];
			configs.properties = null;
			configs.override = null;
			delete configs.properties;
			delete configs.override;
			$.each( properties,function(i,proto){
				if( !proto ) return;
				if( $.isFunction( proto ) ) {
					proto = proto.call( self,configs );
				}
				if( !proto ) return;
				if( Nex.isObject( proto ) ) {
					self.extend( proto );
				}	
			} );
			
			return configs;
		},
		/*
		*组件参数设置和获取
		*/
		C : function(key,value){
			if( typeof key == 'undefined') {
				return this.configs;	
			}
			if( typeof value == 'undefined' && typeof key !== 'object' ) {
				return this.configs[key];
			}
			if( $.isFunction( value ) ) {
				this.configs[key] = value.call( this,this.configs[key] );	
			} else if( $.isPlainObject( key ) ) {
				var conf = key;
				var opt = this.configs;
				
				if( value ) {
					$.extend( opt,conf );
					return this;	
				}
				
				for (var k in conf) {
					var newValue = conf[k];
					var oldValue = opt[k];
	
					if ( $.isArray( oldValue ) ) {
						oldValue.push.apply(oldValue, newValue);
					} else if ($.isPlainObject( oldValue )) {
						$.extend( oldValue, newValue)
					} else {
						opt[k] = newValue;
					}
				}
			} else {
				this.configs[key] = value;
			}
			return this;
		},
		set : function(){
			return this.C.apply(this,arguments);	
		},
		get : function(){
			return this.C.apply(this,arguments);	
		},
		setConfig : function(){
			return this.C.apply(this,arguments);		
		},
		getConfig : function(){
			return this.C.apply(this,arguments);		
		},
        // Default constructor, simply returns `this`
        constructor: function( cfg ) {
			this.initConfigs.apply( this,arguments );
            return this;
        }	
	} );
	
	Nex.Base = Base;
	
	Nex.classes['Nex.Base'] = Base;
})();
/*Base Class*/
(function(win){
var makeCtor = function() {
		function constructor() {
			return this.constructor.apply(this, arguments);
		}
		return constructor;
	},
	Base = Nex.Base
	;
	Nex.apply( Nex, {
		baseChain : function(className){
			var basePrototype = Base.prototype;
			var cls = makeCtor();
			
			Base.extend.call( cls,Base );
			
			if( className ) {
				cls.$className = className;	
				cls.prototype.$className = className;	
			}
			return cls;
		},
		extend : function(className, superName, members){
			var subClass,
				superClass,
				extendClass;
			if( arguments.length === 2 && Nex.isObject(superName) ) {
				members = superName;	
				superName  = null;
			}
			if( typeof className === 'function' && className.$isClass ) {
				subClass = className;
			} else {
				subClass = Nex.getClass( className );
			}
			
			if( subClass.isInstance ) {
				throw new Error("class is isInstance");		
			}
			
			if( !subClass ) {
				throw new Error("class not defined");	
			}
			if( arguments.length === 1 ) return subClass;
			members = Nex.apply({},members) || {};
			extendClass = members.extend || superName;
			
			delete members.extend;
			
			if( extendClass && typeof extendClass === 'function' && extendClass.$isClass ) {
				superClass = extendClass;
			} else {
				superClass = extendClass ? Nex.getClass( extendClass ) : extendClass;
			}
			if( superClass ) {
				subClass.extend( superClass );
			}
			
			var aliasName,xtype,configs,mixins;
			if( 'alias' in members && members.alias ) {
				aliasName = members.alias + "";
				delete members.alias; 	
			}
			if( 'xtype' in members && members.xtype ) {
				xtype = members.xtype + "";
				delete members.xtype; 
			}
			if( 'configs' in members && members.configs ) {
				configs = members.configs;
				delete members.configs; 	
			}
			if( 'mixins' in members && members.mixins ) {
				mixins = members.mixins;
				delete members.mixins; 	
			}
			
			if( configs ) {
				subClass.setOptions(configs);		
			}	
			
			subClass.override( members );
			
			this._setMixins( mixins, subClass );
			
			var isSingleton = !!subClass.prototype.singleton;
			//判断是否单例模式 singleton = true
			if( isSingleton ) {
				subClass = new subClass();	
			}
			//别名设置
			if( aliasName ) {
				this._setAliasName( aliasName, subClass );
			}
			if( !isSingleton && subClass.$isClass ) {
				this._setClassXtype( xtype, subClass );	
			}
			
			return subClass;
		},
		/*
		* 组合是不会覆盖原有成员
		*/
		_setMixins : function( mixins, subClass ){
			var mixs = [];
			
			if( Nex.isPlainObject( mixins ) ) {
				$.each( mixins, function(i,v){
					mixs.push( v );	
				} );
			} else {
				mixs = Nex.isArray( mixins ) ? mixins : [ mixins ];	
			}
			
			var configs = [], properties = {}, i=0, len = mixs.length;
			
			if( !len ) return;
			
			for( ;i<len;i++ ) {
				var m = mixs[i];
				if( Nex.isString( m ) ) {
					m = Nex.getClass( m );	
					if( !m ) continue;
				}
				if( Nex.isClass( m ) ) {
					configs.push( function( opt, scope ){
						return m.getOptions( scope );	
					} );	
					Nex.apply( properties, m.prototype || {} );
				} else if( Nex.isObject( m ) ){
					if( m.configs ) {
						configs.push( m.configs );
					}
					delete m.configs;
					Nex.apply( properties, m );
				}
			}
			//组合成员
			Nex.applyIf( subClass.prototype, properties );
			//组合参数
			if( configs.length ) {
				subClass.setOptions( function( opts,scope ){
					var opts = opts || {};
					var scope = scope || this;
					
					var mopts = {};	
					for( var i=0, len=configs.length; i<len; i++ ) {
						var cfg = configs[i];
						if( Nex.isFunction( cfg ) ) {
							Nex.apply( mopts, cfg( mopts, scope ) || {} );	
						} 	
						if( Nex.isObject( cfg ) ) {
							Nex.apply( mopts, Nex.clone( cfg ) );		
						}
					}
					return Nex.applyIf( opts, mopts );
				} );
			}
		},
		_setAliasName : function( aliasName, subClass ){
			var aliasNames = $.trim(aliasName).split(/\s+/g);	
			$.each( aliasNames,function(i,n){
				if( !n ) return;
				Nex.setNamespace( n,subClass );
				Nex.addAlias( n,subClass );
			} );
		},
		_setClassXtype : function( xtype, subClass ){
			var xtypes = $.trim(xtype).split(/\s+/g);
			$.each( xtypes,function(i,t){
				if( !t ) return;
				subClass.setXtype(t);		
			} );	
		},
		namespace : function( str ){
			var undef,
				t = win,
				s = str+'';	
			s = s.split('.');
			for( var i=0,len=s.length-1;i<len;i++ ) {
				var e = s[i];
				if( !(e in t) || !t[e] ) {
					t[e] = {};	
				}
				t = t[e];	
			}	
			return t[s[i]] = t[s[i]] === undef ? {} : t[s[i]];
		},
		setNamespace : function(str,v){
			var undef,
				t = win,
				s = str+'';	
			v = v === undef ? {} : v;	
			s = s.split('.');
			for( var i=0,len=s.length-1;i<len;i++ ) {
				var e = s[i];
				if( !(e in t) || !t[e] ) {
					t[e] = {};	
				}
				t = t[e];	
			}	
			return t[s[i]] = v;
		},
		getNamespace : function( str ){
			var undef,
				t = win,
				s = str+'';	
			s = s.split('.');
			for( var i=0,len=s.length-1;i<len;i++ ) {
				var e = s[i];
				if( !(e in t) || !t[e] ) {
					return undef;
				}
				t = t[e];	
			}	
			return t[s[i]];
		},
		ns : function(){
			return this.namespace.apply( this, arguments );	
		},
		/*
		*定义类
		*	extend 继承
		*	alias  别名
		*	xtype 设置组件的xtype 注意实际中  alias和xtype的唯一区别是 alias会自动生成命名控件
		*	configs 参数
		*	mixins  组合
		*	singleton 单例模式	
		*/		
		define : function(className, superName, overrides){
			if( !arguments.length ) {
				throw new Error('className not exists!');	
			}
			var subClass = Nex.baseChain(className);
			
			//this.setNamespace( className, subClass );
			
			this.classes[ className ] = subClass;
			
			this.setNamespace( className, this.extend.apply(this, arguments) );
			//this.extend.apply(this, arguments);
			return subClass;
		}
	} );
})(window);
(function(){
	Nex.define('Nex.EventObject',{
		xtype : 'eventobject',
		configs : {
			context : null,
			stopOnFalse : true,
			/*
			*事件名映射：
			*	expamles : 
			*	Event.eventMaps.onWindowClick = 'onClick';
			*	Event.fireEvent('onWindowClick'); //实际触发的是onClick
			*	Event.bind('onWindowClick',func); //实际绑定的是onClick
			*/
			eventMaps : {},
			/*
			*事件列表
			* examples:
			*	events.onClick = [ {}... ]
			*/
			events : {},
			listeners : {}		
		},
		initConfigs : function(cfg){
			var cfg = this.callParent(arguments);	
			cfg.self = this;
			this.initEvents(cfg);
			this.sysEvents();//系统事件
			this.bindConfigsEvnet();//自定义事件
			return cfg;
		},
		initEvents : function(opt){
			var self = this;
			var ev = opt.events ? opt.events : {};
			opt.events = {};
			var events = {};
			function bind(e){
				if( $.isPlainObject(e) && !$.isEmptyObject(e) ) {
					for(var i in e){
						var _evt = String(i),
							fn = e[i],
							context = null;	
						if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
							context = fn.scope || fn.context || null;
							fn = fn.func || fn.fn || fn.callBack || fn.callback;
						}
						if( $.isFunction( fn ) && fn !== $.noop ) {
							self.bind(_evt,fn,context);	
						}
					}
				}	
			}
			bind.call(self,ev);
			bind.call(self,opt.listeners || {});
			//opt.events = events;
		},
		/*
		*系统事件
		*/
		sysEvents : function(){
			var self = this;
			var opt = self.configs;
		},
		bindConfigsEvnet : function(){
			var self = this;
			var opt = self.configs;
			var e = opt.events ? opt.events : {};
			var reg = /^@?on[A-Z][\S|\.]*$/;///^@?on[A-Z][\w|\.]*$/
			for(var x in opt ) {
				if( reg.test(x) ) {
					var fn = opt[x],
						context = null;
					
					if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
						context = fn.context || fn.scope || null;	
						fn = fn.func || fn.fn || fn.callBack || fn.callback;
					}
					if( $.isFunction(fn) && fn !== $.noop ){
						self.bind(x,fn,context);	
					}
				}
			}
		},
		$eventIndex : 1,
		/*
		* 事件绑定
		*  @eventType {String} 事件名
		*  @func      {Function|{ scope,fn }} 事件回调
		*  @scope     {Object} this对象(可选)
		*  @return    {int} 事件ID or false
		*/
		bind : function(eventType, func, scope){
			if( typeof eventType == "undefined" ) {
				return false;	
			}
			if( eventType === '' || eventType === '@' ) {
				return false;	
			}
			var self = this;
			var opt = self.configs;
			var event = opt.events;
			//批量绑定支持
			if( $.type( eventType ) === 'object' ) {
				var ids = [];
				for( var ev in eventType ) {
					var context = scope;
					var fn = eventType[ev];
					if( $.isPlainObject( fn ) && !$.isEmptyObject( fn ) ) {
						context = fn.scope || fn.context || context;
						fn = fn.func || fn.fn || fn.callBack || fn.callback;
					}
					var _i = self.bind( ev,fn,context );	
					ids.push( _i );
				}
				return ids;
			} else {//字符串 
				var _ev = String(eventType).split(/\s+|,/);	
				if( _ev.length>1 ) {
					var len = _ev.length;
					var ids = [];
					for( var _e=0;_e<len;_e++ ) {
						if( !_ev[_e] ) continue;
						ids.push( self.bind( _ev[_e],func,scope ) );
					}
					return ids;
				}					
			}
			
			var _f1 = eventType.charAt(0);
			if( _f1 === '@' ) {
				scope = self;
				eventType = eventType.slice(1);	
			}	
			
			var _type = eventType.split(".");
			eventType = _type[0];
			_type = _type.slice(1);
			var ext = _type.join('.');//_type.length == 2 ? _type[1] : '';
			
			if( !eventType ) {
				return false;	
			}
			
			//事件名映射处理
			//eventMaps
			if( eventType in opt.eventMaps ) {
				eventType = opt.eventMaps[eventType];
			}
			
			event[eventType] = event[eventType] || [];
			
			if( $.isFunction( event[eventType] ) ) {
				event[eventType] = [];
			}
			
			if( !$.isFunction( func ) || func === $.noop ) {
				return false;	
			}
			
			var _e = {
					scope : !!scope ? scope : null,
					func : func,
					ext : ext,
					_index : self.$eventIndex++
				};
			
			var id = event[eventType].push(_e);
		
			return _e._index;
		},
		on : function(){
			return this.bind.apply(this,arguments);	
		},
		/*
		*同bind 区别在于只执行一次
		*/
		one : function(eventType, func, scope){
			if( typeof eventType == "undefined" ) {
				return false;	
			}
			var func = func || $.noop;
			var self = this;
			var scope = !!scope ? scope : self;
			
			var _ = function(){
					self.unbind(_.id);
					var r = func.apply(this, arguments);
					return r;
				},
				id = null;
				
			id = self.bind( eventType, _, scope );
			_.id = id;
			return id;
		},
		/*
		* 取消事件绑定
		*  @eventType {String} 事件名,
		*  @id        Number 事件ID
		*/
		unbind : function(eventType,id){
			var self = this;
			var undef;
			var opt = self.configs;
			//...unbind('onClick onClick2.yrd')
			var _ev = String(eventType).split(/\s+|,/);	
			if( _ev.length>1 ) {
				var len = _ev.length;
				for( var _e=0;_e<len;_e++ ) {
					if( !_ev[_e] ) continue;
					self.unbind( _ev[_e] );
				}
				return self;
			}					
			
			var event = opt.events;
			var id = id === undef ? false : id;
			
			//...unbind(3)
			if( typeof eventType === 'number' ) {
				for( var tp in event ) {
					self.unbind( tp,eventType );	

				}
				return self;		
			}
			
			var _type = String(eventType).split(".");
			eventType = _type[0];
			_type = _type.slice(1);
			var ext = _type.join('.');
			//...unbind('.test')
			if( eventType === '' && ext !== '' ) {
				for( var tp in event ) {
					self.unbind( [tp,ext].join('.') );	
				}
				return self;	
			}
			
			//事件名映射处理
			//eventMaps
			if( eventType in opt.eventMaps ) {
				eventType = opt.eventMaps[eventType];
			}
			
			if( !(eventType in event) ) {
				return self;	
			}
			
			if( $.isFunction( event[eventType] ) ) {
				event[eventType] = [];
				return self;
			}
			var ves = [];
			if(id === false) {
				if( ext === '' ) {
					event[eventType] = [];
				} else {
					for(var i=0;i<event[eventType].length;i++) {
						var _e = event[eventType][i];
						if( (typeof _e === 'object') && _e.ext === ext ) {
							///event[eventType][i] = null;	
							continue;
						}
						ves.push( _e );
					}
				}
			} else {
				for(var i=0;i<event[eventType].length;i++) {
					var _e = event[eventType][i];
					if( (typeof _e === 'object') && _e._index === id ) {
						continue;
					}
					ves.push( _e );
				}
			}
			event[eventType] = ves;
			return self;
		},
		off : function(){
			return this.unbind.apply(this,arguments);	
		},
		/*
		* 锁定事件
		*  @eventType {String} 事件名
		*/
		lockEvent : function(eventType){
			var self = this;	
			//事件锁
			var eventLocks = self._eventLocks || {};
			eventLocks[eventType] = true;
			self._eventLocks = eventLocks;
			return true;
		},
		/*
		* 取消锁定事件
		*  @eventType {String} 事件名
		*/
		unLockEvent : function(eventType){
			var self = this;	
			//事件锁
			var eventLocks = self._eventLocks || {};
			eventLocks[eventType] = false;
			self._eventLocks = eventLocks;
			return true;
		},
		_denyEvent : false,
		_eventLocks : null,
		_executeEventMaps : null,//正在的执行的事件
		/*
		* 事件触发
		*  @eventType {String} 事件名 如果事件名带@开头 说明当前事件是系统事件 不会因为睡眠而阻止
		*  @data      {Array} 事件参数(可选)
		*/
		fireEvent : function(eventType,data){
			var self = this;
			var undef;
			if( self._denyEvent ) {
				return;	
			}
			var opt = self.configs;
			
			var context = opt.context || self;
			
			var ct = String(eventType).charAt(0);
			var _sys = false;
			if( ct === '@' ) {
				_sys = true;
				eventType = String(eventType).slice(1);	
			}	
			
			if( !eventType ) {
				return;	
			}
			//事件名映射处理
			//eventMaps
			if( eventType in opt.eventMaps ) {
				eventType = opt.eventMaps[eventType];
			}
			
			var events = opt.events[eventType];
			var data = data === undef ? [] : data;
			
			//判断data 是否 arguments
			if( $.isArray( data ) ) {
				data = data;	
			} else if( $.type( data ) === 'object' ){
				if( 'callee' in data && 'length' in data ) {
					data = data	
				} else {
					data = [data];	
				}
			} else {
				data = [data];
			}
			//data = $.isArray( data ) ? data : [data];
			//添加事件锁
			var eventLocks = self._eventLocks || {};
			if( eventLocks[eventType] ) {
				return;	
			}
			self._executeEventMaps = self._executeEventMaps || {};
			//防止死循环事件
			if( self._executeEventMaps[eventType] ) {
				return;	
			}
			self._executeEventMaps[eventType] = true;
			
			var r = true;
			if($.isArray(events) ) {
				var len = events.length;
				for(var i=0;i<len;i++) {
					var _e = events[i];
					if( $.isPlainObject( _e ) ) {
						r = _e.func.apply(_e.scope || context,data);
					} else if( $.isFunction( _e ) ){
						r = _e.apply(self,data);
					}
					if( opt.stopOnFalse ) {
						if(r === false) break;	
					}
				}	
				
			} else if($.isFunction(events)) {
				r = events.apply(self,data);
			}
			
			self._executeEventMaps[eventType] = false;
			
			return r;
		},
		fire : function(){
			return this.fireEvent.apply(this,arguments);	
		}
	});	
})();
(function(){
	Nex.apply(Nex, {
		GET_CMPS_CLEAR : false,
		RESIZE_DELAY   : 100,
		MAX_REMOVE_NUM : 5	
	});
	Nex.define('Nex.ComponentManager',{
		singleton : true,//单例模式
		//alias : 'Nex.ComponentManager',
		extend : 'Nex.EventObject',
		//构造函数
		constructor : function(){
			this.callParent( arguments );	
			this.compRoot = 'root';
			this.components = {};
			this._levelCmps = {};
			this._autoResizeLevelCmps = {};
			this.fireEvent('onCreate',[this.configs]);
		},
		sysEvents : function(){
			this.callParent( arguments );	
			var self = this;
			$(function(){
				var winSize = {
					width : $(window).width(),	
					height : $(window).height()
				};	
				var wt = 0;	
				$(window).unbind("resize.ComponentManager");
				$(window).bind("resize.ComponentManager",function(){
					if( wt ) {
						clearTimeout( wt );	
						wt = 0;
					}
					wt = setTimeout(function(){
						clearTimeout( wt );	
						wt = 0;
						var win_w = $(window).width();
						var win_h = $(window).height();
						if( winSize.width === win_w && winSize.height === win_h ) {
							return;	
						}
						winSize.width = win_w;
						winSize.height = win_h;
						
						self.fireEvent("onResize");	
						self.fireEvent("onBrowserResize");	
					},Nex.RESIZE_DELAY);			
				});
								 
			});
			self.bind( 'onResize._sys',self._resize,self );
			return self;
		},
		//清理comps 删除无用的cmp
		_refreshCmps : function( m ){
			var self = this,undef;	
			var cmps = self.components;
			var i = 0;
			for( var id in cmps ) {
				if(!self.isExists( id )) {
					i++;	
				}
			}
			if( m || (i && i>=Nex.MAX_REMOVE_NUM) ) {
				self.cmpChange();	
			}
			return i;
		},
		/*
		*获取组件 获取所有组件时 每次都会调用_refreshCmps清空无效的组件
		*/
		getCmp : function(id){
			var self = this,undef;
			if( id === undef ) {
				if( Nex.GET_CMPS_CLEAR ) {
					self._refreshCmps();
				}
				return self.components;
			}
			self.isExists( id );	
			return Nex.unDefined(self.components[id],null);	
		},
		//获取当前分组名的所有组件
		getGroup : function(name){
			var self = this,undef;
			if( name === undef ) {
				return [];
			}
			var c = [];
			var comps = self.getCmp();
			if( name === '*' ) {
				$.each( comps,function(i,d){
					c.push(d);					   
				} );
				return c;	
			}
			
			name = $.trim(name+'').split(/\s+/g);
			
			if( !name ) return c;
			
			for( var id in comps ) {
				var obj = comps[id];
				if( obj ) {
					var gname = $.trim(obj.C('groupName')+'').split(/\s+/g);
					var str_gname = String(gname);
					for( var i=0,len=name.length;i<len;i++ ) {
						var n = name[i];
						if( gname.length && str_gname.indexOf(n)!== -1 ) {// name === gname
							c.push( obj );
							break;
						}	
					}
				}
			}
			return c;
		},
		register : function( id, cmp ){
			if( Nex.isInstance( id ) ) {
				cmp = id;
				id = cmp.configs.id;	
			}
			this.components[id] = cmp;
			this.cmpChange();	
		},
		addCmp : function(id,cmp){
			this.register.apply( this, arguments );
		},
		/*
		*组件有变动 如 增 删 位置变动时应该调用 特别是 "增"其次是"位置变动"再次是"删" 
		*/
		cmpChange : function(){
			this.__disposed1 = false;	
		},
		//删除组件
		removeCmp : function(id){
			//this._cmps[id] = null;
			var cmp = this.components[id];
			if( cmp ) {
				if( cmp.isInstance ) {
					cmp.onDestroy();
					cmp.fireEvent('onDestroy');	
				}
				this.components[id] = null;
				delete this.components[id];
			}
		},
		//判断id是否存在 如果不存在则删除
		isExists : function(id){
			var self = this;
			var cmp = self.components[id];
			
			if( cmp && (cmp.getDom()).length ) {
				return true;	
			}
	
			//autoDestroy 如果清除dom后组件就不再用，autoDestroy设置为true autoResize 应该也是为true的
			//这里可能存有bug 例如window按关闭后会销毁dom但是window组件还是存在的  --components
			//self._cmps[id] = null;//不再设置为null，而是获取dom是否存在
			if( cmp && cmp.C('autoDestroy') ) {
				self.removeCmp(id);	
			}
			//如果组件找不到dom 那么就从resize列表移除
			//delete self._cmps[id];	
			return false;
		},
		_getDomCmps : function( el ){//待更新
			var el = $(el);
			if( !el.length ) return false;
			var self = this	
				,undef
				,rlist = []
				,cmp = el.closest('.nex-component-item')
				,pid;
				
			pid = cmp.length ? cmp.attr('id') : self.compRoot;
			
			var cmps = self.components;
			var levelCmps = self.getLevelCmps();
			var list = levelCmps[pid] || [];
			
			for( var i=0,len=list.length;i<len;i++ ) {
				var d = list[i];
				var cmp = cmps[d.id];
				if( !cmp ) continue;
				rlist.push( cmp )	;
			}
			return rlist;	
		},
		//更新指定dom下的组件大小
		resizeDom : function(el){////待更新
			var rlist = this._getDomCmps( el );
			if( rlist === false ) return this;
			for( var i=0;i<rlist.length;i++ ) {
				var cmp = rlist[i];
				if( cmp && cmp.isAcceptResize() ) {
					cmp.resize();	
				}
			}
			return this;
		},
		//更新所有组件大小 如果指定cid 只更新指定组件下的所有组件的大小
		resize : function( cid ){
			this._resize( cid );	
			return this;
		},
		//更新组件的层级关系
		refreshComponents : function(){
			this.refreshLevelCmps();
		},
		//获取当前ID组件下的子组件 
		getChildrens : function( id ){//待更新
			var self = this,undef;
			var rlist = [];
			var cmps = self.components;
			var levelCmps = self.getLevelCmps();
			
			var pid = id || this.compRoot;
			
			var list = levelCmps[pid] || [];
			
			for( var i=0,len=list.length;i<len;i++ ) {
				var d = list[i];
				var cmp = cmps[d.id];
				if( !cmp ) continue;
				rlist.push( cmp );
			}
			return rlist;
		},
		//获取当前ID组件下的所有子组件 
		getAllChildrens : function( id ){//待更新
			var self = this,undef;
			var list = [];
			var _list = self.getChildrens( id );
			list = list.concat( _list );
			for( var i=0,len=_list.length;i<len;i++ ) {
				var cmp = _list[i];
				if( !cmp ) continue;
				var id = cmp.C( 'id' );
				list = list.concat(self.getAllChildrens( id ));	
			}
			return list;
		},
		//获取当domID下的子组件
		getChildrensByDom : function( el ){
			var self = this,undef;
			return self._getDomCmps( el ) || [];
		},
		//获取当前domID组件下的所有子组件 
		getAllChildrensByDom : function( el ){
			var self = this,undef;
			//self.refreshComponents();
			var list = [];
			var _list = self._getDomCmps( el ) || [];
			list = list.concat( _list );
			for( var i=0,len=_list.length;i<len;i++ ) {
				var cmp = _list[i];
				if( !cmp ) continue;
				var id = cmp.C( 'id' );
				list = list.concat(self.getAllChildrens( id ));	
			}
			return list;
		},
		/*
		*刷新组件之间的层级关系 
		*/
		refreshLevelCmps : function(){
			this.__disposed1 = false;
			return this.getLevelCmps();	
		},
		/*
		*遍历组件之间的层级关系 
		*/
		__disposed1 : false,
		getLevelCmps : function(){
			var self = this,undef;
	
			if( self.__disposed1 ) {
				return self._levelCmps;	
			}
			
			self._refreshCmps();
			
			var cmps = self.components;
			var list = cmps;
			
			self._levelCmps = {};
			
			var lcs = self._levelCmps;
	
			for( var id in list ) {
				var cmp = list[id];
				if( cmp ) {
					
					var pid = self.compRoot;
					
					var parent = $("#"+id).parents(".nex-component-item:first");
					if( parent.length ) {
						var _id = parent.attr('id');
						var  _p = cmps[_id];
						if( _p ) {
							pid = _id;
						}
					}
					var data = {
						id : id,
						pid : pid
					};
					
					lcs[pid] = lcs[pid] === undef ? [] : lcs[pid];
					lcs[pid].push( data );
				}	
			}
			
			self.__disposed1 = true;
	
			return self._levelCmps;
		},
		/*
		*更新当前id下 autoResize=true的子组件大小
		*/
		_resize : function( cid ){
			var self = this,undef;
			var cmps = self.components;
			var cid = cid === undef ? self.compRoot : cid;
			
			var list = self.getChildrens(cid);
			
			if( !$.isArray( list ) ) return;
			
			for( var i=0;i<list.length;i++ ) {
				var cmp = list[i];
				if( cmp ) {
					if( cmp.isAcceptResize() ) {
						cmp.resize();
					} else {
						//不应该开启
						//self._resize( cmp.configs.id );	
					}
				}
			}
		},
		/*
		给组件发送消息 一般当作自定义消息来使用
		@ *ids 发送的组件ID 可以是数组 或者是 组件对象，如果为"*"则发送给所有组件
		@ *evt 发送的消息事件
		@ params 发送的参数 可以是数组
		@ sender 发送者 这个参数可以通过 arguments[ arguments.length-1 ] 获得
		*/
		sendMessage : function( ids,evt,params,sender ){
			var self = this,undef;
			var cmps = self.getCmp();
			var params = Nex.unDefined( params,[] );
			params = $.isArray( params ) ? params : [ params ];
			if( sender ) {
				params.push( sender );		
			}
			if( ids === undef ) return false;
			
			if( ids === '*' ) {
				for( var obj in cmps ) {
					var cmp = cmps[obj];
					if( !cmp.isSleep() ) {
						cmp.fireEvent(evt,params);
					}
				}	
			}
			
			ids = $.isArray( ids ) ? ids : [ ids ];
			
			for( var i=0,len=ids.length;i<len;i++ ) {
				var cmpid = ids[i];
				if( Nex.isInstance( cmpid ) ) {
					if( !cmpid.isSleep() ) {
						cmpid.fireEvent(evt,params);
					}
				} else {
					cmp = cmps[cmpid];
					if( cmp ) {
						if( !cmp.isSleep() ) {
							cmp.fireEvent(evt,params);	
						}
					}
				}
			}
			return true;
		},
		/*作用同sendMessage 只是会立即返回*/
	
		postMessage : function(ids,evt,params,sender){
			var self = this,undef;
			setTimeout(function(){
				self.sendMessage( ids,evt,params,sender );					
			},0);
			return true;
		},
		/*
		给组件发送消息 一般当作自定义消息来使用
		@ *name 组件的groupName
		@ *evt 发送的消息事件
		@ params 发送的参数 可以是数组
		@ sender 发送者 这个参数可以通过 arguments[ arguments.length-1 ] 获得
		*/
		sendMessageByGroupName : function(name,evt,params,sender){
			var self = this,undef;
			
			if( name === undef ) return false;
			
			var cmps = self.getGroup( name );
			
			var params = Nex.unDefined( params,[] );
			params = $.isArray( params ) ? params : [ params ];
			if( sender ) {
				params.push( sender );		
			}
			
			for( var i=0,len=cmps.length;i<len;i++ ) {
				var cmp = cmps[i];
				if( !cmp.isSleep() ) {
					cmp.fireEvent(evt,params);
				}
			}	
				
			return true;	
		},
		sendMessageToGroup : function(){
			return this.sendMessageByGroupName.apply( this,arguments );	
		},
		/*作用同sendMessageByGroupName 只是会立即返回*/
		postMessageByGroupName : function(name,evt,params,sender){
			var self = this,undef;
			setTimeout(function(){
				self.sendMessageByGroupName( name,evt,params,sender );					
			},0);
			return true;	
		},
		postMessageToGroup : function(){
			return this.postMessageByGroupName.apply( this,arguments );	
		}
	});	
	//Nex.ComponentManager = new Nex.ComponentManager();
	$.each( ['gc','removeComponent'
			,'removeServer','get','getCmp','getGroup','getChildrens','getAllChildrens'
			,'getChildrensByDom','getAllChildrensByDom','refreshComponents','resize'
			,'sendMessage','postMessage','sendMessageByGroupName','sendMessageToGroup'
			,'postMessageByGroupName','postMessageToGroup'],function(i,method){
		var m = Nex.ComponentManager;
		var alias = {
			gc 				: '_refreshCmps',
			removeComponent	: 'removeCmp',
			removeServer	: 'removeCmp',
			get				: 'getCmp',
			resize			: '_resize'	
		};
		var returnself = {
			gc 							: true,
			removeComponent 			: true,
			removeServer				: true,
			resize 						: true,
			sendMessage 				: true,
			postMessage 				: true,
			sendMessageByGroupName 		: true,
			sendMessageToGroup 			: true,
			postMessageByGroupName 		: true,
			postMessageToGroup 			: true
		};
		Nex[ method ] = function(){
			var tmp = m[ alias[method] || method ].apply( m,arguments );
			return returnself[method] ? this : tmp;
		};
	} );
	jQuery.fn.extend({
		resizeCmp : function() {
			return this.each(function(){
				Nex.ComponentManager.resizeDom( this );	
			});
		},
		sendMessage : function( eventType,params,sender ){
			var arg = [].slice.apply(arguments);
			
			if( !arg.length ) return this;
			
			var everyone = true;
			if( $.type(arg[ arg.length-1 ]) === 'boolean' ) {
				everyone = arg[ arg.length-1 ];
				arg.pop();
			}
			return this.each(function(){
				
				var cmps = everyone ? Nex.ComponentManager.getAllChildrensByDom( this ) : Nex.ComponentManager.getChildrensByDom( this );
				
				Nex.ComponentManager.sendMessage.apply( Nex.ComponentManager,[ cmps ].concat( arg ) );
			});	
		},
		postMessage : function( eventType,params,sender ){
			var arg = [].slice.apply(arguments);
			
			if( !arg.length ) return this;
			
			var everyone = true;
			if( $.type(arg[ arg.length-1 ]) === 'boolean' ) {
				everyone = arg[ arg.length-1 ];
				arg.pop();
			}
			return this.each(function(){
				
				var cmps = everyone ? Nex.ComponentManager.getAllChildrensByDom( this ) : Nex.ComponentManager.getChildrensByDom( this );
				
				Nex.ComponentManager.postMessage.apply( Nex.ComponentManager,[ cmps ].concat( arg ) );
			});		
		}
	});
})();
(function(){
	Nex.define('Nex.AbstractComponent',{
		extend : 'Nex.EventObject',
		xtype : 'abstractcomponent',
		_isInit : false,
		configs : function(){
			return {
				prefix : 'nex',
				id : '',
				renderTo : document.body,
				autoDestroy : true,
				autoRender : true,
				denyManager : false,
				init : $.noop,
				renderTpl : '',
				renderData : {},
				renderSelectors : {},
				groupName : '',
				cacheData : {},
				tpl : {},
				template  : Nex.getTemplate(),
				parent : null,
				deferred : $.Deferred ? $.Deferred() : null,
				views : {},
				plugins : [],
				defalutxType : 'panel',
				defaults : {},
				html : '',
				items : []
			}	
		},
		getScrollbarSize : Nex.getScrollbarSize,
		//判断当前是否正在初始化
		isInit : function(){
			return 	this._isInit;
		},
		constructor : function(){
			this.callParent( arguments );
			var opt = this.configs;
			opt.id = this.getId();
			if( opt.autoRender ) {
				this.initRender();
			}
		},
		rendered : false,
		initRender : function( el,after ){
			var self = this;
			var opt = this.configs;
			
			//如果已经渲染则不能重复渲染
			if( this.rendered ) {
				return this;	
			}
			
			self._isInit = true;
			
			self.initPlugins();
			
			//系统初始化调用
			/*if( $.isFunction( opt.init ) && opt.init!==$.noop ) {
				opt.init.call(self,opt);
			}*/
			
			opt.renderTo = this._undef( el,opt.renderTo );
			opt.renderAfter = this._undef( after,opt.renderAfter );
			
			this.fireEvent("onStart",[opt]);
			this.onStart( opt );
			
			//设置状态， 已经渲染
			this.rendered = true;
			//添加组件到组件管理器
			if( !opt.denyManager ) {
				Nex.ComponentManager.register( self );//register
			}
			
			this.initInstance( opt );
			
			return this;	
		},
		_initPlugins : false,
		initPlugins : function(){
			var self = this;
			var opt = this.configs;
			
			var plugins = opt.plugins || [];
			
			if( self._initPlugins ) {
				return self;	
			}
			
			self._initPlugins = true;
			
			for( var i=0, len=plugins.length; i<len; i++ ) {
				self.constructorPlugin( plugins[i] );
			}
			
			return self;
		},
		constructorPlugin : function( plugin ){
			var _plugin = plugin;
			var plugin = Nex.create( plugin );
			if( plugin && typeof plugin.init == 'function' ) {
				plugin.init( this );	
			} else {
				if( typeof _plugin == 'function' ) {
					_plugin( this );		
				}	
			}	
			return this;
		},
		onStart : function(){},
		initInstance : function(cfg){
			var self = this;
			var opt = self.configs;	
			
			self.onInitComponent(opt);
			self.fireEvent('onInitComponent',[opt]);
			
			self.initContainer();
			//initRenderTpl
			self.initRenderTpl();
			
			self.initComponent(opt);
			//初始化组件大小
			self.initComponentSize(opt);
			
			self.initRenderContent(opt);//initRenderContent
			//渲染完成
			self.onAfterRender();
			self.fireEvent('onAfterRender',[opt]);
			
			self.onCreate(opt);
			self.fireEvent('onCreate',[opt]);
			this._isInit = false;	
		},
		initContainer : function(){},
		initRenderTpl : function(){},
		initComponent : function(){
			this.constructPlugins();	
		},
		initComponentSize : function(){
			this.setSize();
		},
		initRenderContent : function(){},
		onInitComponent : function(){},
		onAfterRender : function(){},
		onCreate : function(){},
		constructPlugins : function(){},
		setSize : function(){},
		render : function( el,after ){
			if( this.rendered ) {
				this.renderTo.apply( this,arguments );
			} else {
				this.initRender.apply( this,arguments );	
			}
			return this;	
		},
		//判断是否render
		isRendered : function(){
			return this.rendered;	
		},
		_checkToRender : function(){
			if( !this.rendered ) {
				this.render();	
			}	
		},
		renderTo : function(){},
		_getId : function(){
			var opt = this.configs;
			return opt.prefix + (++Nex.aid);	
		},
		getId : function(){
			var opt = this.configs;
			if( Nex.isEmpty( opt.id ) ) {
				return this._getId();	
			}
			return opt.id;	
		},
		/*
		* @m default=false true(更新层级关系)
		*/
		enableAutoResize : function(  ){	
			this.configs.autoResize = true;
			return this;
		},
		/*
		* @m default=false true(更新层级关系)
		*/
		disabledAutoResize : function( m ){
			this.configs.autoResize = false;
			return this;
		},
		_undef : function (val, d) {
			return val === undefined ? d : val;
		},
		resize : function(){
			var self = this;
			var opt = self.configs;
			//if( Nex.ComponentManager ) {
				setTimeout(function(){
					Nex.ComponentManager.fireEvent("onResize",[opt.id]);		
				},0);
			//}	
		},	
		__ars : true,
		//判断当前组件是否接受autoResize
		isAcceptResize : function(){
			var opt = this.configs;
			return opt.autoResize && this.__ars;	
		},
		setAcceptResize : function(m){
			var m = m === undefined ? true : m;
			this.__ars = !!m;
			return this;	
		},
		/**
		 * 模板处理函数(用户自定义模版级别最高,其次模板函数,最后_Tpl中的模版)
		 *  @tpl {String,Function} 模板内容
		 *  @data {Object} 模板数据 如果tpl是Function data不一定需要Object
		 *  @return {String} 模板内容
		 */
		tpl : function( tpl, data ){
			var self = this;
			var opt = self.configs;
			var undef;
			
			if( tpl === undef ) tpl = "";
			if( data === undef ) data = {};
			
			if( tpl === "" ) return tpl;
			
			var argvs = [].slice.apply( arguments, [ 1 ] );
			
			var renderer = self.getTplFn( tpl );
			
			return renderer.apply(self,argvs);
			
		},
		getTplFn : function( str, extParams ){
			var self = this;
			var opt = self.configs;
			var undef;
			if( !opt.template ) {
				if( $.isFunction(str) ){
					return str;
				} else if( str in self ) {
					return self[str];
				} else {
					return function(){
						return str;	
					};
				}
			}
			if( $.isFunction( str ) ){
				return str;
			}else if( str in opt.tpl && opt.tpl[str] ) {
				return opt.template.compile( opt.tpl[str], null, extParams );
			} else if( str in self ) {
				return self[str];
			} else {
				return opt.template.compile( str + "", null, extParams );
			}
		},
		/*
		*  调用当前对象里的某个API，但是不会触发里面的事件(部分函数除外例如setGridBody,因为里面事件通过计时器触发)
		*  @param1 {String} 需要调用的API
		*  @param2~N 被调用的API参数(可选)
		*/
		denyEventInvoke : function(){//method,arg1,arg2....
			var self = this;
			var r;
			if( arguments.length ){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push(arguments[i]);	
				}
				var method = argvs[0];
				if( method in self ) {
					self._denyEvent = true;
					argvs.splice(0,1);
					r = self[method].apply(self,argvs);
					self._denyEvent = false;
				}
			}
			return r;
		},
		/*
		* API调用管理,作用在于通过该函数调用的会过滤被锁定的函数
		*  @param1 {String} 需要调用的API
		*  @param2~N 被调用的API参数(可选)
		*/
		methodInvoke : function(){//method,arg1,arg2....
			var self = this;
			var r;
			
			var methodLocks = self._methodLocks || {};
			
			if( arguments.length ){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push(arguments[i]);	
				}
				var method = argvs[0];
				
				if( methodLocks[method] ) {
					return;	
				}
				
				if( method in self ) {
					argvs.splice(0,1);
					r = self[method].apply(self,argvs);
				}
			}
			return r;
		},
		/*
		* 锁定API
		*  @method {String} API名
		*/
		lockMethod : function(method){
			var self = this;	
			//事件锁
			var methodLocks = self._methodLocks || {};
			methodLocks[method] = true;
			self._methodLocks = methodLocks;
			return true;	
		},
		/*
		* 取消锁定API
		*  @method {String} API名
		*/
		unLockMethod : function(method){
			var self = this;	
			//事件锁
			var methodLocks = self._methodLocks || {};
			methodLocks[method] = false;
			self._methodLocks = methodLocks;
			return true;	
		},
		__sleep : false,
		isSleep : function(){
			return this.__sleep;	
		},
		//睡眠 睡眠后无法通过sendMessageToGroup给组件发送消息 并不会影响fireEvent
		sleep : function(){
			this.__sleep = true;
			return this;	
		},
		//唤醒
		wakeup : function(){
			this.__sleep = false;
			return false;
		},
		//获取组件的父级组件
		getParent : function(){
			var opt = this.configs;
			if( opt.parent !== null ) {
				if( Nex.isInstance( opt.parent ) ) {
					return opt.parent;	
				}
				var _p = Nex.get(opt.parent);
				if( _p ) return _p;
			}
			return null;
		},
		removeCmp :  function( m ){
			//var self = this,undef;
			var opt = this.configs;
			//if( Nex.ComponentManager && m !== false ) {
			Nex.ComponentManager.removeCmp( opt.id );
			//}
		},
		/*
		*移除组件 最好需要重载
		*/
		destroy : function(){
			this.removeCmp();
			return this;
		},
		onDestroy : function(){},
		getDom : function(){
			return [];	
		},
		getDeferred : function(){
			var opt = this.configs;
			return opt.deferred;
		}
	});	
})();
/***************************************************
****************AMD 组件加载(单例模式)****************
****************************************************
****************************************************/
var require,$require,$module,$import,$define,$exports,Module,define,Define,Require,exports,Exports;
;(function($){
	var Loader = Nex.define('Nex.Loader',{
		xtype : 'loader',
		extend : 'Nex.AbstractComponent',
		configs : function( opt ){
			var head = document.getElementsByTagName('head')[0] ||  document.documentElement;
			return {
				prefix : 'nexloader-',
				denyManager : true,//不需要Manager管理
				singleModel : true,//默认开启单例模式
				debug : false,
				strictDeps : true,//严格依赖 如果依赖加载失败就不会执行回调
				commentRegExp : /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg,
       			cjsRequireRegExp : /[^.]\s*(?:\$require|\$include)\s*\(\s*["']([^'"\s]+)["']\s*\)/g,
				exportsName : '_$export',// 做导出用 最好是没创建一个Loader exportsName都应该设置不同 因为在IE下会有onload 通知不及时问题
				exportsApi : '$exports',//全局导出api 最好用这个因为支持IE
				requireApi : '$require $include',//全局加载api 
				defineApi : '$define $module $import',
				head : head,
				baseElement : head.getElementsByTagName("base")[0],
				//是否检测文件类型后缀
				checkExt : true,
				defaultExt : '.js',
				//显示指定可以加载的文件类型后缀 eg：['json','xml'] 新增对josn xml的支持 如果不设置 当加载 a.json时会变成a.json.js
				loadExts : [],
				//默认支持的文件后缀 如果不存在则默认会使用 defaultExt来填充到后面
				_checkExtReg : /(\.css|\.js|\.php|\.jsp|\.py|\.txt|\.htm|\.html|\.php4|\.php5|\.php3|\.do|\.asp|\.aspx)$/,
				//显示指定当前路径采用那种扩展来加载 默认只支持 js css txt eg: 'lib/a.php?loadExt=txt'
				loadTypeName : 'loadExt',
				//强制统一所有加载都用该过程
				//自定义加载方法 function 或者指定当前对象的 api名称来加载
				//loadType定义后loadMaps无效
				loadType : '',
				//自定义模块或脚本的加载过程 {'a.json':function(url,s,f,c,m){},'b.txt2':'txt'}
				//做扩展用
				loadMaps : {},
				//对路径提前做写处理
				//例如:如果加载的模块都是以Nex.开头 那么我们就直接把"."替换"/"
				// [{ regexp : /^Nex./,process : function(path){ return path.repalce(/\./ig,'/'); } }]
				pathProcess : [],
				baseUrl : '',
				loadOrder : false,//是否按顺序加载脚本(串联加载，阻塞加载) 默认 false 
				scriptType : 'text/javascript',
				charset : 'utf-8',
				items : [],
				_list : [],//缓存list
				loadQueues : [],
				_loadCache : {},//判断是否加载ok
				module2path : {},//路径对应模块 
				currScriptAliasName : null,
				currScriptName : null,
				total : 0,//当前加载脚本数
				completeNum : 0,//脚本完成数
				progress : 0,//进度百分比
				_sysPaths : {
					'_nex_' : Nex.baseUrl
				},//Nex默认路径
				paths : {},//路径别名 eg:{ app:'lib/app' } items使用 {{app}}/a.js
				alias : {},//加载别名 eg:{ nex : '{{app}}/nex.js' }
				param : {},
				urlArgs : {},
				shim : {},//依赖机制
				template : Loader.template,
				autoLoad : false//初始化后自动加载
				//pending : null,
				//events : {}
			}; 	
		}	
	});
	
	Loader.addStatics({
		template : Nex.getTemplate({ ltag : '{',rtag:'}',simple:true }),
		__NexLoader : null,//Nex的Loader
		__loader : null,//单例模式的缓存
		_loadCache : {},//加载缓存
		exports : {},//所有加载的模块
		_getLoader : function(){
			var self = this,undef;
			if( !self.__NexLoader ) {
				self.__NexLoader = Nex.Create('Nex.Loader',{
					autoLoad : false,
					loadOrder : false,
					cjsRequireRegExp : /[^.]\s*(?:Require|require|\$require|Nex\.require)\s*\(\s*["']([^'"\s]+)["']\s*\)/g,
					exportsName : '_export',
					exportsApi : '$exports Exports',
					requireApi : '$require Require',
					defineApi : '$module $define Module Define $import',
					pathProcess : [
						{
							regexp : function( path ){
								if( path === 'Nex' ) {
									return true;	
								}	
								if( /^Nex\./.test( path ) 
									&& !/\.css/.test( path )
									&& !/\.js/.test( path )
								   ) {
									return true;	   
								}
								return false;
							},
							process : function(path){
								var p = path.split('.');
								if( p.length === 1 ) {
									p.push( p[0] );	
								}
								return p.join('/');	
							}		
						}
					],
					/*'onBeforeParseScriptName.require' : function( name,moduleName,opt ){
						var classPath = Nex.getClassPath( name );
						if( classPath )	{
							classPath = classPath + '';
							classPath = classPath.split('.').join('/');
							opt.currScriptName = classPath;
						}
					},*/
					/*
					*加载组件时检测当前组件如果已经存在则不需要设置缓存
					*/
					'onBeforeLoadScript.require' : function( deps,opt ){
						var loader = this;
						$.each( deps,function(i,v){
							if( Nex.getClass(v) ) {
								if( !Nex.Loader.isLoad( v ) ) {
									Nex.Loader.setLoadCache( v,Nex.getClass(v) );
								} 
							} else {
								//var nexReg = /^Nex\./;
								//if( nexReg.test( v ) ) {
									//如果加载的文件 命名空间已经存在 不需要加载文件
									var ns =  Nex.getNamespace( v );
									if( ns ) {
										if( !Nex.Loader.isLoad( v ) ) {
											Nex.Loader.setLoadCache( v, ns );
										}		
									}
								//}
								/*
								var s = (v+'').replace(/^Nex\.util\./,'');
								if( Nex.getUtil( s ) ) {
									if( !Nex.Loader.isLoad( v ) ) {
										Nex.Loader.setLoadCache( v,Nex.getUtil(s) );
									}	
								}
								
								var s = (v+'').replace(/^Nex\.mixins\./,'');
								if( Nex.getMixins( s ) ) {
									if( !Nex.Loader.isLoad( v ) ) {
										Nex.Loader.setLoadCache( v,Nex.getMixins(s) );
									}	
								}
								*/
							}		
						} );
					},
					nex : Nex.baseUrl
				});
				if( !self.__NexLoader ) {
					return null;	
				}
				self.__NexLoader.setPath('baseUrl',Nex.baseUrl)
							    .setPath('Nex',Nex.baseUrl);
			}
			return self.__NexLoader;
		},
		getLoader : function(){
			return this._getLoader();	
		},
		/*
		*判断模块是否已经加载
		*@param {String} 模块
		*/
		isLoad : function(moduleName){
			var self = this,
				undef;
			if( moduleName === undef ) {
				return false;	
			}	
			if( Nex.Loader._loadCache[ moduleName ]===true 
				//|| Nex.Loader.exports[ moduleName ] !== undef 
			  ) {
				return true;	
			}
			return false;
		},
		/*
		*获取导出对象
		*/
		getExports : function( name ){
			var self = this,undef;
			var exports = this.exports;
			
			if( name === undef ) {
				return exports;	
			}
			
			if( !(name in exports) || exports[name] === undef ) {
				if( Nex.getClass( name ) ) {
					exports[ name ] = Nex.getClass( name );	
				} else {
					
					var ns =  Nex.getNamespace( name );
					if( ns ) {
						exports[ name ] = ns;			
					}
				
					/*
					var s = (name+'').replace(/^Nex\.util\./,'');	
					if( Nex.getUtil( s ) ) {
						exports[ name ] = Nex.getUtil( s );		
					}
					
					var s = (name+'').replace(/^Nex\.mixins\./,'');
					if( Nex.getMixins( s ) ) {
						exports[ name ] = Nex.getMixins( s );	
					}
					*/
				}
			}		
			
			return exports[ name ];
		},
		getModule : function( n ){
			return this.getExports( n );	
		},
		/*
		*设置模块加载缓存 
		*@param {String} 需要设置的模块缓存
		*@param {...} 模块对象
		*/
		setLoadCache : function(moduleName,exports){
			var self = this,
				undef;
			if( moduleName === undef ) {
				return self;	
			} else {
				moduleName = moduleName + '';	
			}
			Nex.Loader._loadCache[ moduleName ]	= true;
			Nex.Loader.exports[ moduleName ] = exports;
			return self;
		},
		/*
		*清空模块加载缓存 
		*@param {moduleName} 需要设置的模块缓存
		*/
		unsetLoadCache : function( moduleName ){
			var self = this,
				undef;
			if( moduleName === undef ) {
				return self;	
			} else {
				moduleName = moduleName + '';	
			}
			delete Nex.Loader._loadCache[ moduleName ];
			delete Nex.Loader.exports[ moduleName ];
			return self;	
		},
		/*
		*清空所有加载缓存
		*/
		clearLoadCache : function(){
			var self = this,
				undef;
			Nex.Loader._loadCache = {};	
			Nex.Loader.exports = {};
			return self;	
		}
	});
	
	Loader.override({
		initComponent : function() {
			var self = this;
			var opt = this.configs;
			
			if( Loader.__loader && opt.singleModel ) {
				$.extend( self,Loader.__loader );
				return;
			}
			if( opt.singleModel ) {
				Loader.__loader = Loader.__loader ? Loader.__loader : self;
			}
			
			window[opt.exportsName] = {};
			window[opt.exportsName+'CallBack'] = {};
			
			var config = function(){
				var conf = arguments[0];
				if( $.isPlainObject(conf) ) {
					conf.urlArgs = $.isPlainObject( conf.urlArgs ) ? conf.urlArgs : { '*':conf.urlArgs };
				}
				 return self.C.apply( self,arguments );
			};
			
			$.each( opt.requireApi.split(/\s+/),function(i,v){
				window[v] = function(){
					return self.require.apply( self,arguments );	
				};	
				window[v]['config'] = config;
			} );
			$.each( opt.exportsApi.split(/\s+/),function(i,v){
				window[v] = function(){
					return self.exports.apply( self,arguments );	
				};	
			} );
			$.each( opt.defineApi.split(/\s+/),function(i,v){
				window[v] = function(){
					return self.define.apply( self,arguments );	
				};	
			} );
			
			$.extend(opt.paths,opt._sysPaths);
			opt.items = $.isArray( opt.items ) ? opt.items : [ opt.items ];
		},
		/*添加加载扩展*/
		addExts : function( iarr ){
			var opt = self.configs;
			iarr = iarr && $.isArray( iarr ) ? iarr : [ iarr ];
			
			opt.loadExts.push.apply( opt.loadExts,iarr );	
			
			return this;	
		},
		__loaderCallBack : [],
		resetExports : function(){
			var self = this,
				opt = self.configs;	
			window[opt.exportsName] = {};
			window[opt.exportsName+'CallBack'] = {};
			return self;
		},
		sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.callParent();
			self.bind("onCreate",self._autoLoad,self);
			
			return self;
		},
		getExports : function( name ){ 
			var self = this;
			var opt = this.configs;
			self.fireEvent('onRequireModule',[ name,Nex.Loader.exports,opt ]);
			return Nex.Loader.getExports( name );
		},
		_checkLoad : function(){
			var self = this,
				opt = self.configs;
				
			self._checkLoad1();		
			/*
			if( opt.loadOrder ) {
				self._checkLoad2();	//无效
			} else {
				self._checkLoad1();	
			}	
			*/
			return self;
		},
		//回调实现方式1 ，等所有脚本加载完后才执行 适合所有模式
		/*
		*回调使用了延时机制，解决内嵌require死循环问题但是不再支持模块打包
		*/
		_checkLoad1 : function(){
			var self = this,
				opt = self.configs;
			var cache = opt._loadCache;
			var callbacks = self.__loaderCallBack;
			self.__loaderCallBack = [];
			//成功后回调执行状态
			var exec = {};
			var maps = {};
			var maps2 = {};
			$.each( callbacks,function(i,d){
				if( d.moduleName ) {
					maps[ d.moduleName ] = { deps : [].concat(d.deps) };
					maps2[ d.moduleName ] = d;
				}	
			} );
			/*
			*计算依赖的执行顺序算法草稿:
			eg:
			var exec = {};
			var maps = {
					A : {
						deps : [ 'C','E','F','B' ],
						callBack : function (){
							console.log('A');	
						}	
					},
					B : {
						deps : [ 'A' ],
						callBack : function (){
							console.log('B');	
						}	
					},
					C : {
						deps : [ 'F' ],
						callBack : function (){
							console.log('C');	
						}	
					},
					D : {
						deps : [ 'T' ],
						callBack : function (){
							console.log('D');	
						}		
					},
					E : {
						deps : [ 'C','D','F' ],
						callBack : function (){
							console.log('E');	
						}	
					},
					F : {
						deps : [  ],
						callBack : function (){
							console.log('F');	
						}	
					}
				};
				var execDeps = function(){
					var i = 0;
					$.each( maps,function( mod,data ){
						var  deps = data.deps;
						if( mod in exec ) {
							return;	
						}
						Nex.array_splice( function(i,v){
							if( v in exec ) {
								return true;	
							}
							if( !(v in maps) ) {
								return true;	
							}	
						},deps );	
						if( !deps.length ) {
							data.callBack();
							exec[mod] = true;
							console.log( mod,'--执行ok' );	
						} else {
							//console.log( mod,'--执行' )	
							i++;
						}
					} )	;
					return i;
				};
				var t = 0;
				var x = 0;
				while( t=execDeps() ) {
					if( t == x ) {
						break;	
					}	
					x = t;
				}
				console.log( '剩余的（循环依赖）：',t );
				if( t>0 ) {
					$.each( maps,function( mod,data ){
							var  deps = data.deps;
							if( mod in exec ) {
								return;	
							}
							data.callBack();
							console.log( mod,'--执行ok' );	
					} )	;
				}
				step1:应该先执行 没有依赖的模块，那应该是 D和F 注：D 所依赖的T 因为不是在本次加载中，所以早就已经加载好了
				step2:C,E可以执行
				step3:A,B出现了循环引用，那么我们就不要寻找了 直接执行A , B
			*/
			/***********依赖的执行顺序代码实现***********/
			var execQueues = [];
			var execDeps = function(){
				var i = 0;
				//这里的mod是指module  deps是指依赖
				$.each( maps,function( mod,data ){
					var  deps = data.deps;
					//如果已经执行，就跳过
					if( mod in exec ) {
						return;	
					}
					//在deps中删除已经执行好了的模块
					Nex.array_splice( function(i,v){
						if( v in exec ) {
							return true;	
						}
						if( !(v in maps) ) {
							return true;	
						}	
					},deps );
					//如果deps已经没有依赖，那就可以执行当前模块	
					if( !deps.length ) {
						execQueues.push( maps2[mod] );
						exec[mod] = true;	
					} else {//记录当前还有多少待计算的依赖模块，用于下次循环
						i++;
					}
				} )	;
				return i;
			};
			var t = 0;
			var x = 0;
			//循环计算依赖模块的执行顺序
			while( t=execDeps() ) {
				if( t == x ) {
					break;	
				}	
				x = t;
			}
			//如果t>0 说明出现了循环依赖
			//这个时候 我们不再计算，直接执行
			if( t>0 ) {
				$.each( maps,function( mod,data ){
					if( mod in exec ) {
						return;	
					}
					execQueues.push( maps2[mod] );
					exec[mod] = true;	
				} )	;	
			}
			//把没有moduleName($require(...))的模块放到最后执行
			$.each( callbacks,function(i,d){
				if( !d.moduleName ) {
					execQueues.push( d );
				}	
			} );
			//以上已经把依赖执行顺序存放execQueues，后续只要执行
			//console.log( execQueues );
			/***********执行所有模块的回调***********/
			$.each( execQueues,function(i,data){
				var isSuccess = true,
					errDeps = [],
					deps = data.deps;	
				//检测是否所有依赖都加载成功	
				$.each( deps,function(i,d){				 
					if( (d in cache) && cache[d] === false ) {
						isSuccess = false;
						errDeps.push( d );
					}					 
				} );	
				//如果严格模式下 当前模块应该是没有加载成功
				if( opt.strictDeps && !isSuccess ) {
					Nex.Loader.unsetLoadCache( data.moduleName );
				}
				isSuccess = opt.strictDeps ? isSuccess : true;
				if( isSuccess ) {
					if( $.isFunction( data.callBack ) ) {
						data.callBack.call(data);	
					}
				} else {
					if( $.isFunction( data.errBack ) ) {
						data.errBack.call(data,errDeps);
					}	
				}
			} );
			
			return self;
		},
		//以废弃
		_checkLoad2 : function(){},
		_autoLoad : function(){
			var self = this,
				opt = self.configs;
			
			if( opt.autoLoad ) {
				self.load( opt.items );	
			}	
		},
		//判断当前状态是否加载完
		_isLoadScript : function( status ){
			return ( status === true || status === false ) ? true : false;	
		},
		_isLoadPending : function( status ){
			return status === 'pending' ? true : false;	
		},
		/*
		*计算当前的加载进度
		*/
		getProgress : function(){
			var self = this,
				opt = this.configs;
			var cache = opt._loadCache,total=0,completeNum=0;
			for( var n in cache ) {
				total++;
				completeNum =  !self._isLoadScript( cache[n] ) ? completeNum : ++completeNum;
			}
			opt.total = total;
			opt.completeNum = completeNum;
			opt.progress = completeNum*100/total;
			return opt.progress;
		},
		/*
		*新增一个路径变量
		*@param string 路径变量名称 eg nex
		*@param string 路径地址 eg ./src/nex/
		*/
		setPath : function(/* name,value */){
			var self = this,
				argvs = arguments,
				opt = this.configs;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( opt.paths,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					opt.paths[argvs[0]] = argvs[1];
				}	
			}
			return self;
		},
		/*
		*新增需要加载的脚本别名
		*@param string 别名 eg Nex.Html
		*@param string 实名路径 eg {{nex}}/Html/Html 此处的{{nex}}引用 path里的
		*/
		setAlias : function(/* name,value */){
			var self = this,
				argvs = arguments,
				opt = this.configs;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( opt.alias,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					opt.alias[argvs[0]] = argvs[1];
				}	
			}
			return self;
		},
		/*设置包名和路径*/
		package : function( pkg,path ){
			var self = this,
				opt = this.configs;	
			Nex.Loader.setPath(pkg,path);	
			Nex.Loader.setPathProcess( new RegExp('/^'+pkg+'\./') );
			//Nex.Loader.setPathProcess( new RegExp('/^'+Com+'$/') );
			return self;
		},
		setPackage : function(){
			return this.package.apply( this,arguments );	
		},
		/*
		*设置强制依赖
		*@param string 需要加载的脚本
		*@param string 强制依赖的脚本
		*/
		setShims : function(/* name,value */){
			var self = this,
				argvs = arguments,
				opt = this.configs;
			if( argvs.length === 1 && $.isPlainObject( argvs[0] ) ) {
				$.extend( opt.shim,argvs[0] );	
			} else {	
				if( argvs[0] && argvs[1] ) {
					opt.shim[argvs[0]] = argvs[1];
				}	
			}
			return self;
		},
		/*
		*脚本加载失败时调用
		*@param object 事件对象
		*@param func 成功后调用
		*@param func 失败后调用
		*@param func 完成后调用
		*@param string 当前脚本名
		*/
		onScriptLoad : function(evt,s,f,c,_currName){
			var node = evt.currentTarget || evt.srcElement,
				opt = this.configs;
			if (evt.type === 'load' ||
                        (/^(complete|loaded)$/.test(node.readyState))) {
				if($.isFunction(s)) {
					s(null,c);	
				}	
             }
			 return this;
		},
		/*
		*脚本加载失败时调用
		*@param object 事件对象
		*@param func 成功后调用
		*@param func 失败后调用
		*@param func 完成后调用
		*@param string 当前脚本名
		*/
		onScriptError : function(evt,s,f,c,_currName){
			var node = evt.currentTarget || evt.srcElement,
				opt = this.configs;
			if($.isFunction(s)) {
				f();	
			}	
			return this;
		},
		/*
		*单个脚本加载完后必须调用，检测是否所有脚本都已经加载完
		*@param func 回调
		*@param string 当前脚本名
		*/
		onScriptComplete : function(c,_currName){
			var self = this,
				opt = this.configs,
				cache = opt._loadCache,
				complete = true,
				successDeps = [],
				errDeps = [],
				success = true;	
			//此事件一定不能用延迟 
			self.fireEvent('onLoadScriptComplete',[_currName,opt]);	
			//如果所有模块都已经缓存，那么通过.progress()不会触发 如果需要触发这里需要延迟执行 setTimeout
			var _pr = self.getProgress();
			//还是不要设置延迟执行 缓存本来就是从内存总加载 没有进度一说 瞬间完成
			//setTimeout(function(){
				self.fireEvent('onProgress',[ _pr,_currName,opt ]);	
			//},0);
			//检测是否所有脚本加载完成
			for( var k in cache ) {
				if( !self._isLoadScript(cache[k]) ) {
					complete = false;
					break;	
				}
			}
			
			if( $.isFunction(c) ) {
				c();
			}
			
			if( opt.loadOrder ) {
				self._load();
			} else {
				//BUG代码注释 _clearLoadCache提前释放了_loadCache，导致_checkLoad检查的时候 _loadCache已经被清空
				//if( complete ) {
//					self._clearLoadCache();	
//				}
			}
			
			if( complete ) {
				//清空
				opt.items.length = 0;	
				//checkLoad机制检查
				self._checkLoad();
				
				for( var k in cache ) {
					if( cache[k]===false ) {
						success = false;
						errDeps.push( k );
					} else if( cache[k]===true ) {
						successDeps.push( k );
					}	
				}
				
				var isAllCache = self.isAllCache;
				//重置
				self.isAllCache = true;
				
				var sback = function(){
					self.fireEvent('onSuccess',[successDeps,opt,isAllCache]);	
					if( opt.deferred ) {
						opt.deferred.resolve([ opt ]);	
					}	
					/*if( !isAllCache ) {
						self._isLoading = false;	
					}*/
					self.fireEvent('onComplete',[successDeps,errDeps,opt,isAllCache]);	
				};
				var eback = function(){
					self.fireEvent('onError',[errDeps,opt,isAllCache]);	
					if( opt.deferred ) {
						opt.deferred.reject([ opt ]);
					}	
					/*if( !isAllCache ) {
						self._isLoading = false;	
					}*/
					self.fireEvent('onComplete',[successDeps,errDeps,opt,isAllCache]);		
				};
				//if( isAllCache ) {
				self._isLoading = false;	
				//}
				if( success ) {
					//解决缓存问题导致链式调用的.done 无效
					//2015-08-13 还是决定不要延迟执行
					//setTimeout(function(){
						sback();	
					//},0);
				} else {
					//setTimeout(function(){
						eback();	
					//},0);
				}
				//修改BUG 注意此处_clearLoadCache应该在调用sback之前调用，但是使用了计时器所以可以在此执行
				if( !opt.loadOrder && complete ) {
					self._clearLoadCache();	
				}
			}	
			
			return self;
		},
		/*
		*添加自定义加载函数
		*/
		setExtFunction : function( ext,func ){
			function replaceReg(reg,str){
				str = str.toLowerCase();
				return str.replace(reg,function(m){return m.toUpperCase()})
			}
			if( ext === 'js' || ext === 'css' ) {
				return this;	
			}
			ext = replaceReg( /\b(\w)|\s(\w)/g,ext );
			this['load'+ext] = func;
			
			return this;
		},
		/*
		*设置自定义加载过程 eg :
		*Nex.getLoader().setLoadMaps('a.json',function( url,success,error,complete,module ){自定义加载过程});
		*/
		setLoadMaps : function(k,v){
			var self = this,
				opt = this.configs;
			if( arguments.length>1 ) {
				opt.loadMaps[ arguments[0] ] = arguments[1]	
			}else if( $.isPlainObject( arguments[0] ) ) {
				$.extend( opt.loadMaps,arguments[0] );
			}
			return self;	
		},
		/*
		*设置路径处理流程
		*@param {RegExp,Function} 检测当前路径是否需要处理 true则需要处理
		*@process 处理过程
		*/
		setPathProcess : function( regexp, process ){
			var self = this,
				opt = this.configs;	
			return opt.pathProcess.push( {
				regexp : regexp,
				process : process || null	
			} );	
		},
		unsetPathProcess : function( id ){
			var self = this,
				opt = this.configs,
				id = parseInt(id) - 1;
			if( opt.pathProcess[id] ) {
				opt.pathProcess[id] = null;	
			}
			return this;
		},
		/*
		*加载脚本
		*@param string 脚本地址
		*@param func 成功后调用
		*@param func 失败后调用
		*@param string 当前脚本名称
		*/
		loadScript : function(name,s,f,c,_currName){
			var self = this,
				undef,
				node,
				isOpera = Nex.isOpera,
				url = name,
				opt = this.configs,
				head = opt.head || document.getElementsByTagName('head')[0] ||  document.documentElement
				;	
				
			node = document.createElement('script');	
			node.type = opt.scriptType || 'text/javascript';
            node.charset = opt.charset || 'utf-8';
            node.async = true;
			/*
			*IE下有脚本执行的onload触发时，未必是当前脚本直接结束。可能是好几个脚本同时执行结束后才触发。。。
			*/
			node.scriptName = _currName;
			
			var complete = function(){
				opt.head.removeChild(node);
				if( $.isFunction(c) ) {
					c();
				}
			};
			
			if (node.attachEvent &&
                    !(node.attachEvent.toString && node.attachEvent.toString().indexOf('[native code') < 0) &&
                    !isOpera) {
                node.attachEvent('onreadystatechange', function(evt){
					self.onScriptLoad(evt,s,f,complete,_currName);	
				});
            } else {
                node.addEventListener('load', function(evt){
					self.onScriptLoad(evt,s,f,complete,_currName);
				});
                node.addEventListener('error', function(evt){
					self.onScriptError(evt,s,f,complete,_currName);
					if( opt.debug ) {
						Nex.error(name+' load error!');
					}
				});
            }
			self.currentlyAddingScript = node;
			//baseElement
            node.src = url;
			// ref: #185 & http://dev.jquery.com/ticket/2709
		    opt.baseElement ?
			  	head.insertBefore(node, opt.baseElement) :
			 	head.appendChild(node)
			//head.appendChild(node);
			
			self.currentlyAddingScript = null;
			
			return node;
		},
		/*
		*加载样式
		*@param string 脚本地址
		*@param func 成功后调用
		*@param func 失败后调用
		*@param string 当前脚本名称
		*/
		loadCss : function(name,s,f,c,_currName){
			var self = this,
				undef,
				url = name,
				node,
				opt = this.configs,
				head = opt.head || document.getElementsByTagName('head')[0] ||  document.documentElement
				;	
				
			node = document.createElement("link");
			node.charset = opt.charset || 'utf-8';
			node.rel = "stylesheet";
    		node.href = url;
			head.appendChild(node);
			
			setTimeout(function() {
			 	 if($.isFunction(s)) {
					 s();	
			 	 }
			}, 1);
			return node;
		},
		/*
		*ajax扩展类型加载
		*@param string 脚本地址
		*@param func 成功后调用
		*@param func 失败后调用
		*@param string 当前脚本名称
		*/
		loadAjax : function( url,success,fail,complete,alias ){
			var self = this,
				undef,
				opt = this.configs
				;
				
			var ajax = Nex.Create('Nex.Ajax',{
				url : url,
				'onSuccess._sys' : function(data){
					if($.isFunction(success)) {
						success(data);	
					}
				},
				'onError._sys' : function(){
					if($.isFunction(fail)) {
						fail();	
					}
				}
			});
			
			return ajax;
		},
		loadTxt : function(){
			return this.loadAjax.apply( this,arguments );	
		},
		/*
		*获取模块加载顺序
		*/
		getLoadQueues : function(){
			return this.configs.loadQueues.reverse();	
		},
		isLoading : function(){
			return this._isLoading;	
		},
		_isLoading : false,
		/*
		*开始加载脚本
		*/
		startLoad : function(){
			var self = this,
				undef,
				opt = this.configs;
			//opt.loadOrder = true;//只支持依赖加载 按顺序加载	
			opt.items = $.isArray( opt.items ) ? opt.items : [ opt.items ];
			opt._list = opt.items.concat([]);	
			opt._loadCache = {};

			//opt.pending = true;
			
			if( !opt.items.length ) {
				return self;	
			}
			
			var r = self.fireEvent('onBeforeStartLoad',[ opt ]);
			if( r === false ) {
				return self;	
			}
			
			for( var i=0,len=opt._list.length;i<len;i++ ) {
				if( opt._list[i] === '' ) continue;
				opt._loadCache[opt._list[i] + ''] = null;
			}
			opt.loadQueues.length = 0;	
			self._load();
			//self.isAllCache =  true;
			//console.log('reset isAllCache');
			//self._isLoading = true;
			return self;
		},
		_clearLoadCache : function(){
			var self = this,
				undef,
				opt = this.configs;
			opt.currScriptAliasName = null;
			opt.currScriptName = null;
			opt._list.length = 0;	
			opt._loadCache = {};
			return self;
		},
		/*
		*判断当前当前脚本是否都加载完
		*/
		isLoadComplete : function(){
			var self = this,
				undef,
				finish = true,
				opt = this.configs;
			if( !opt._list.length ) {
				return true;	
			}
			$.each( opt._list,function(i,d){
				if( d in opt._loadCache && !self._isLoadScript(opt._loadCache[d]) ) {
					finish = false;	
					return false;
				}						   
			} );
			return finish;
		},
		/*
		*判断当前队里是否还有正在等待的脚本
		*/
		isAllPending : function(){
			var self = this,
				undef,
				pending = true,
				opt = this.configs;
			$.each( opt._list,function(i,d){
				if( opt._loadCache[d] === null ) {
					pending = false;	
					return false;
				}						   
			} );
			return pending;	
		},
		//获取下一个需要加载的脚本
		getNextLoadScript : function(){
			var self = this,
				undef,
				script = null,
				opt = this.configs;
			if( !opt._list.length ) {
				return script;	
			}
			$.each( opt._list,function(i,d){
				if( d in opt._loadCache && !self._isLoadScript(opt._loadCache[d]) && !self._isLoadPending(opt._loadCache[d]) ) {
					script = d;	
					return false;
				}
			} );
			return script;
		},
		//扩展用
		loadExtension : function(name,success,error,complete,_currName){
			var self = this;
			return self.loadScript( name,success,error,complete,_currName );	
		},
		/*
		*判断模块是否已经加载
		*@param {String} 模块
		*/
		isLoad : function(moduleName){
			return Nex.Loader.isLoad(moduleName);		
		},
		/*
		*设置模块加载缓存 
		*@param {String} 需要设置的模块缓存
		*@param {...} 模块对象
		*/
		setLoadCache : function(moduleName,exports){
			return Nex.Loader.setLoadCache(moduleName,exports);		
		},
		/*
		*清空模块加载缓存 
		*@param {moduleName} 需要设置的模块缓存
		*/
		unsetLoadCache : function( moduleName ){
			return Nex.Loader.unsetLoadCache(moduleName);		
		},
		/*
		*清空所有加载缓存
		*/
		clearLoadCache : function(){
			return Nex.Loader.clearLoadCache();	
		},
		_getShim : function( moduleName ){
			var self = this,
				undef,
				opt = this.configs,
				deps = [];
			
			var modules = $.isArray( moduleName ) ? moduleName : [moduleName];
			$.each( modules,function( i,n ){
				var shim = opt.shim[ n ] === undef ? "" : opt.shim[ n ];
				if( shim ) {
					shim = $.isArray( shim ) ? shim : [shim];	
				} else {
					shim = [];	
				}
				deps.push.apply( deps,shim );
			} );
			
			//清除为空的模块或者以及加载的模块
			Nex.array_splice( function(i,v){
				if( $.trim( v ) === '' ) return true;	
				if( Nex.Loader._loadCache[v] === true || Nex.Loader._loadCache[v] === false ) {
					return true;	
				}
			},deps );
			
			return deps;	
		},
		_addDeps : function( deps ){
			var self = this,
				undef,
				opt = this.configs;
				
			$.each( deps,function(i,d){
				if( !(d in opt._loadCache) ) {
					opt._loadCache[d + ''] = null;
				}
			} );
			
			Nex.array_insert( 0,deps,opt._list,1 );
			
			return self;
		},
		_currentPath : null,
		isAllCache : true,//是否全部是缓存 Nex.OnReady中有用
		/*
		*加载单个脚本
		*因为需要加载的文件都会存入一个堆栈(后进先出) 文件加载成功后都会出堆 直到堆栈为空则停止
		*/
		_load : function(){
			var self = this,
				undef,
				opt = this.configs,
				ext = opt.defaultExt.replace('.',"");
			
			if( !opt.loadOrder && self.isAllPending() ) {
				return self;	
			}
			
			if( self.isLoadComplete() ) {
				if( opt.loadOrder ) {
					self._clearLoadCache();
				}
				return self;	
			}
			
			var _currName = self.getNextLoadScript();
			
			_currName = _currName + '';
			var name = _currName;
			opt.currScriptAliasName = name;
			
			//是否加上baseUrL
			var baseUrl = true;
			
			if( name in opt.alias ) {
				name = opt.alias[name];	
				baseUrl = false;
			} else {
				//name = opt.baseUrl + name;	
			}
			
			var _extReg = null;
			if( opt.loadExts.length ) {
				_extReg = new RegExp('\.('+opt.loadExts.join('|')+')$','i');	
			}
			
			function getScriptExt(url){
				var _url = url;
				
				url = url.replace(/[?#].*/, "");
				
				if( opt._checkExtReg.test( url ) 
					|| ( _extReg ? _extReg.test( url ) : false ) 
				) {
					return url.split('.').pop();	
				}
				
				if( opt._checkExtReg.test( _url ) 
					|| ( _extReg ? _extReg.test( _url ) : false ) 
				) {
					return _url.split('.').pop();	
				}
				
				return '';
			}
			
			opt.currScriptName = name;//当前脚本名
			
			opt.loadQueues.push( _currName );
			//{ module : _currName,path : name }
			var r = self.fireEvent('onBeforeParseScriptName',[ name,_currName,opt ]);
			
			name = opt.currScriptName;
			
			if( r !== false ) {
				//处理用户自定义模块路径解析
				//if( !((name in opt.paths) && opt.paths[name]) ) {
				var pathProcess = opt.pathProcess.concat([]).reverse();
				$.each( pathProcess , function(i,d){
					if( d && $.isPlainObject( d ) ) {
						var c = false;
						if( $.type(d.regexp) === 'regexp' ) {
							c = d.regexp.test( name );	
						} else if( $.isFunction( d.regexp ) ) {
							c = d.regexp.call( self,name );
						} else if( d.regexp === name ) {
							c = true;	
						}
						if( c ) {
							var _path;
							if( $.isFunction( d.process ) ) {
								_path = d.process.call( self,name,_currName,opt );	
							} else if( $.type( d.process ) === 'string' ) {
								_path = d.process;	
							} else {
								var p = name.split('.');
								if( p.length === 1 ) {
									p.push( p[0] );	
								}
								_path = p.join('/');		
							}
							name = _path ? _path+'' : name;
							return false;//跳出 break
						}
					}	
				} );
				//}
				//paths 替换
				name = name.split('/');
				if( name[0] === '.' && name[1] !=='' ) {
					if( name[1] in opt.paths ) {
						name[1] = opt.paths[name[1]];	
						baseUrl = false;
					}	
					name.splice(0,1);
				}
				if( name[0] !== '..' && name[0] !== '' ) {
					if( name[0] in opt.paths ) {
						name[0] = opt.paths[name[0]];	
						baseUrl = false;
					}	
				}
				name = name.join('/');
				
				try{
					name = opt.template.compile( name,opt.paths );
				} catch(e) {}
				
				var _ext = getScriptExt( name );
				
				//检测如果最后没有.css .js .php ...会自动加上默认后缀
				if( opt.checkExt 
					&& !opt._checkExtReg.test( name ) 
					&& (_extReg ? !_extReg.test( name ) : true)
					&& !_ext 
				) {
					name += opt.defaultExt;	
				}
				
				//opt.currScriptName = name;//当前脚本名
				
				var _paths = {
					path : _currName,
					url : name,
					module : _currName
				};
				
				self.fireEvent('onParseScriptName',[ _paths,opt ]);
				
				name = _paths.url;
				//name = opt.currScriptName;
				
				var ishttp = /^(http|\/\/)/;
				if( !ishttp.test( name ) && baseUrl ) {
					name = opt.baseUrl+	name;
				}
			}
			
			ext = getScriptExt( name ) || 'js';
			
			var complete = function(){};
			var _complete = complete;
			var success = function(data,complete){
				var name = _currName;
				//扩展加载时用到
				if( data ) {
					self._exports( name,data );		
				}
				
				opt._loadCache[name] = true;	
				Nex.Loader._loadCache[ name ] = true;
				
				if( !Nex.isIE ) {//如果不是IE 保存导出对象
					var ep = $.isPlainObject( window[opt.exportsName] ) && $.isEmptyObject( window[opt.exportsName] ) ? undef : window[opt.exportsName];
					if( ep ) {
						Nex.Loader.exports[ name ] =  ep;
					}
					window[opt.exportsName+'CallBack']['moduleName'] = name;
					//window[opt.exportsName+'CallBack'] = {};
				}
				
				self.resetExports();
				self.fireEvent('onLoadScriptSuccess',[name,opt]);
				self.onScriptComplete( complete || _complete,name );
			};
			var error = function(complete){
				var name = _currName;
				opt._loadCache[name] = false;	
				Nex.Loader._loadCache[ name ] = false;
				//window[opt.exportsName+'CallBack'] = {};
				self.fireEvent('onLoadScriptError',[name,opt]);
				self.onScriptComplete( complete || _complete,name );
			};
			
			var query = $.param( $.extend(opt.param,opt.params,opt.urlArgs) );
			if( query ) {
				query = name.indexOf('?') === -1 ? '?'+query : '&'+query;
			}
			
			//再次获取扩展名 以确定调用对应的扩展函数加载
			var extReg = new RegExp( opt.loadTypeName+'=[^&]+','ig' );
			if( $.isArray( extReg ) && extReg.length ) {
				ext = extReg.pop().replace('.','');
			}
			var __ext = {
				ext : ext,
				url : name,
				module : _currName	
			};
			self.fireEvent('onGetExtName',[ __ext,opt ]);
			ext = __ext.ext;
			
			name = opt.currScriptName = $.trim(name + query);
			
			opt.module2path[ opt.currScriptAliasName ] = name;
			/********************************/
			var loadType = opt.loadType;
			
			var _map = opt.loadMaps[ _currName ];
			if( _map ) {
				if( $.isFunction( _map ) ) {
					loadType = _map;
				} else {
					loadType = null;
					ext = _map;	
				}
			}
			
			var __d = {
				url : name,
				module : _currName,
				ext : ext,
				loadType : 	loadType,
				success : success,
				error : error,
				complete : complete,
				cache : false
			};
			
			var cache = false;
			//检查加载缓存
			if( self._isLoadScript(opt._loadCache[_currName])                 
				|| ((_currName in Nex.Loader._loadCache) && (Nex.Loader._loadCache[_currName]===true)) 
				//|| (_currName in Nex.Loader.exports) 
			  ) {
				cache = true;
			}
			
			/*缓存加载流程*/
			if( cache ) {
				self._isLoading = true;
				opt._loadCache[_currName] = true;//必须
				//缓存 不触发 onLoadScriptStart onLoadScriptSuccess
				self.onScriptComplete( function(){
					self._load();	
				},_currName );
				if( !opt.loadOrder ) {
					self._load();	
				}
				return self;
				__d.cache = true;
				var __r = self.fireEvent('onLoadScriptStart',[__d,opt]);
				if( __r !== false ) {
					self._isLoading = true;
					opt._loadCache[_currName] = true;//必须
					self.fireEvent('onLoadScriptSuccess',[_currName,opt]);
					
					self.onScriptComplete( function(){
						self._load();	
					},_currName );
				}
				if( !opt.loadOrder ) {
					self._load();	
				}
				return self;
			}
			
			self.isAllCache = false;
			
			//设置默认值 这一步或许不必要 但是按理来说都应该有导出模块 只是默认是{}
			//Nex.Loader.exports[ _currName ] = {};
			//首字母大写
			function replaceReg(reg,str){
				str = str.toLowerCase();
				return str.replace(reg,function(m){return m.toUpperCase()})
			}
			
			if( !opt.loadOrder ) {
				opt._loadCache[opt.currScriptAliasName] = 'pending';	
			}	
			
			var __r = self.fireEvent('onLoadScriptStart',[__d,opt]);
			if( __r !== false ) {
				self._isLoading = true;
				loadType = __d.loadType;
				ext = __d.ext;
				if( !loadType ) {
					//加载css
					if( ext === 'css' ) {
						self.loadCss( name,success,error,complete,_currName );	
					} else if( ext === 'js' ) {//加载js
						self.loadScript( name,success,error,complete,_currName );		
					} else {
						var method = 'load'+replaceReg( /\b(\w)|\s(\w)/g,ext );
						if( (method in self) && $.isFunction( self[method] ) ) {
							self[method].call( self,name,success,error,complete,_currName );
						} else {
							self.loadExtension( name,success,error,complete,_currName );		
						}
					}
				} else {
					if( $.isFunction( loadType ) ) {
						loadType.call(self,name,success,error,complete,_currName);
					} else {
						if( loadType in self ) {
							self[loadType].call( self,name,success,error,complete,_currName );
						} else {
							self.loadScript( name,success,error,complete,_currName );	
						}
					}
				}
			}
			
			if( !opt.loadOrder ) {
				self._load();	
			}
			return self;
		},
		//取消加载
		abort : function(){
			var self = this,
				undef,
				errDeps = [],
				successDeps = [],
				opt = this.configs,
				cache = opt._loadCache,
				pendings = [], //正在加载的脚本
				_pendings = {}
				;
			for( var k in cache ) {
				if( cache[k]===false ) {
					success = false;
					errDeps.push( k );
				} else if( cache[k]===true ) {
					successDeps.push( k );
				} else if( cache[k]==='pending' ) {
					pendings.push( k ); 
					_pendings[k] = true;	
				}
			}	
			if( pendings.length ) {
				opt._isAbort = true;
				var eid,eid2;
				eid = self.bind('onLoadScriptComplete._abort',function(module){
					_pendings[ module ] = false;
					var end = true;
					$.each( _pendings,function(k,v){
						if( v ) {
							end = false;
							return false;	
						}	
					} );
					if( end ) {
						opt._isAbort = false;	
						self.unbind('onLoadScriptComplete',eid);	
						self.unbind('onBeforeLoadScript',eid2);	
					}
				});	
				eid2 = self.bind('onBeforeLoadScript._abort',function(list,fn,errback){
					var currExports = Nex.isIE ? self.getInteractiveName() : null;
					$.each( list,function(i,m){
						cache[m] = false;	
					} );
					if( $.isFunction(fn) ) {
						var exports = list.concat([]);
						window[opt.exportsName+'CallBack'] = {
							moduleName : currExports,
							deps : exports,
							errBack : errback,
							callBack : function(){
								var argvs = [];
								$.each( this.deps,function(i,v){
									//argvs.push( Nex.Loader.exports[v] );				
									argvs.push( self.getExports( v ) );				  
								} );
								argvs.push( window[opt.exportsName] );
								fn.apply(self,argvs);	
								var ep = $.isPlainObject( window[opt.exportsName] ) && $.isEmptyObject( window[opt.exportsName] ) ? undef : window[opt.exportsName];
								//如果模块存在 执行回调 并且回调里面的exports保持到当前模块中
								if( this.moduleName ) {//&& !( this.moduleName in Nex.Loader.exports ) 
									Nex.Loader.exports[ this.moduleName ] = ep;	//window[opt.exportsName];	
								}
								//清空exports
								self.resetExports();
							}
						};
						Nex.array_insert( 0,[ window[opt.exportsName+'CallBack'] ],self.__loaderCallBack,1 );
					}
					return false;	
				});
			}
			$.each( opt._list,function(i,m){
				if( cache[m] === null ) cache[m] = false;	
			} );
			self.fireEvent('onAbort',[opt]);	
			return self;
		},
		/*
		*加载脚本
		*@param {Array} 组件列表 eg ['Nex.Ajax','Nex.Html']
		*@param {func} 回调
		*/
		"load" : function( list,fn,errback,module ){//deps,callback,errback
			var self = this,
				undef,
				opt = this.configs;
			
			if( $.isFunction(list) ) {
				var __list = self.getInlineDeps( list );
				fn = list;
				errback = fn;
				module = errback;
				list = __list;
			}	
		
			var r = self.fireEvent('onBeforeLoadScript',[list,fn,errback,opt]);
			if( r === false ) return self;
			
			if( $.type( errback ) === 'string' && module === undef ) {
				module = errback;
				errback = undef;
			}
				
			//由于IE的onload事件回调不准确，我们只能在执行脚本的时候 确定当前执行的脚本名称
			var currExports = Nex.isIE ? self.getInteractiveName() : null;
			
			if( list !== undef ) {	
				list = $.isArray( list ) ? list : [ list ];	
			} else {
				list = opt.items;	
			}
			
			var exports = list.concat([]);
			
			//如果有强制依赖 就检测是否有多级依赖
			var checkCircle = {};//检测环形回路 暂时没有处理
			var shimDeps = [];
			function checkToShimLoad( deps ){
				var _shimLoadCache={},
					eid,
					//是否有强制依赖
					nlist = [];
				$.each( deps,function(i,m){
					var shims = self._getShim( m );	
					if( shims.length ) {
						nlist.push.apply( nlist,shims );	
						$.each( shims,function(i,d){
							checkCircle[d] = true;
							_shimLoadCache[d] = false;	
						} )
					}
				} );
				//简单检测一下
				/*Nex.array_splice(function(i,d){
					if( checkCircle[d] ) {
						return true;	
					}	
				},nlist);*/
				
				if( nlist.length ) {
					list = nlist;
					shimDeps = nlist;
					var eventType = opt.strictDeps ? 'onLoadScriptSuccess' : 'onLoadScriptComplete';
					eid = self.bind( eventType+'._load',function( m ){
						_shimLoadCache[m] = true;
						var complete = true;
						$.each( _shimLoadCache,function(m,r){
							if( !r ) {
								complete = false;
								return false;	
							}		
						} );
						if( complete ) {
							self._addDeps( deps );
							self.load( deps );
							self.unbind( eventType,eid );	
						}
					} );
					checkToShimLoad( nlist );
				}	
			}
			//检测是否设置了shim 强依赖
			if( list.length ) {
				checkToShimLoad( list );	
				//清除为空的模块
				Nex.array_splice( function(i,v){
					if( $.trim( v ) === '' ) return true;	
				},list );
				Nex.array_splice( function(i,v){
					if( $.trim( v ) === '' ) return true;	
				},exports );
			}
			
			if( $.isFunction(fn) ) {
				window[opt.exportsName+'CallBack'] = {
					loader : self,
					moduleName : currExports,
					_module : module,//显示定义的模块名称
					deps : exports,
					errBack : errback,
					callBack : function(){
						var argvs = [];
						$.each( this.deps,function(i,v){
							//argvs.push( Nex.Loader.exports[v] );	
							argvs.push( self.getExports( v ) );					  
						} );
						argvs.push( window[opt.exportsName] );
						var r = fn.apply(this,argvs);	
						if( r !== undef ) {
							window[opt.exportsName] = r;	
						}
						//如果模块存在 执行回调 并且回调里面的exports保持到当前模块中
						var ep = $.isPlainObject( window[opt.exportsName] ) && $.isEmptyObject( window[opt.exportsName] ) ? undef : window[opt.exportsName];
						if( this.moduleName && ep ) {
							Nex.Loader.exports[ this.moduleName ] = ep;
						}
						
						if( this._module && ep ) {
							var mextra = this._module.split(/\s+/);
							$.each( mextra,function(i,v){
								Nex.Loader.exports[ v ] = ep;	
								Nex.Loader._loadCache[ v ] = true;	
							} );
						}
						//清空exports
						self.resetExports();
					}
				};
				Nex.array_insert( 0,[ window[opt.exportsName+'CallBack'] ],self.__loaderCallBack,1 );
			} else {
				window[opt.exportsName+'CallBack'] = {};	
			}
			
			if( opt._list.length ) {
				$.each( list,function(i,d){
					if( !(d in opt._loadCache) ) {
						opt._loadCache[d + ''] = null;
					}
				} );
				if( opt.loadOrder ) {
					Nex.array_insert( 0,list,opt._list,1 );
				} else {
					opt._list.push.apply( opt._list,list );	
					//如果考虑./是相对路径的话 就要考虑用延迟，当前Loader不考虑./ 所有路径都是相对当前页面路径
					//setTimeout(function(){
						self._load();//如果这里能确定是文件形式加载 可以考虑用延迟	
					//},0);
				}
			} else {
				opt.items = list;

				self.startLoad();
			}
			return self;	
		},
		/*
		*获取内置加载模块
		*param {func} 回调
		*/
		getInlineDeps : function(callback){
			var self = this,
				undef,	
				deps = [],
				opt = this.configs;
			if( $.isFunction( callback ) ) {
				callback
						.toString()
						.replace(opt.commentRegExp, '')
						.replace(opt.cjsRequireRegExp, function (match, dep) {
							deps.push(dep);
						});
			} 	
			return deps;
		},
		/*
		*加载模块
		*@param {Array} 需要加载的依赖 {String} 直接获取已经加载的模块 {func} 定义一个模块
		*@param {func} 依赖加载完回调
		*@param {func} 依赖加载失败回调
		*/
		require : function( deps,callback,errback ){
			var self = this,
				undef,	
				opt = this.configs;
			if( !arguments.length ) {
				return self;	
			}	
			var args = arguments;
			if( $.isArray( deps ) ) {
				if( deps.length ) {
					if( self.isLoading() ) {
						self.one('onComplete._rsys',function(){
							self.load.apply( self,args );	
							window[opt.exportsName+'CallBack'] = {};	
						});	
					} else {
						this.load.apply( this,arguments );	
						window[opt.exportsName+'CallBack'] = {};
					}
				} else {
					if( $.isFunction( callback ) ) {
						self.require( callback );	
					}	
				}
			} else if( $.type( deps ) === 'string' ) {
				if( $.isFunction( callback ) ) {
					return self.require( [ deps ],callback,errback );
				}
				
				var __export =  self.getExports( deps );
				
				return __export;	
			} else if( $.isFunction( deps ) ) {
				var _deps = self.getInlineDeps( deps );
				if( _deps.length ) {
					self.require( _deps,deps );	
				} else {
					deps();	
				}
			}
			return self;
		},
		/*
		*定义一个模块
		*@param {Array} deps 依赖模块
		*@param {Function} callback 依赖加载后调用回调
		*@param {Function} errback 依赖加载失败后调用回调 不建议用
		*/
		define : function(deps,callback,errback){
			var self = this,
				undef,
				argvs = arguments,	
				opt = this.configs;
			if( !argvs.length ) {
				return self;	
			}	
			if( argvs.length === 1 && !$.isFunction( argvs[0] ) ) {
				self.exports( argvs[0] );
			} else if( $.isArray( deps ) /*&& deps.length*/ ) {
				if( deps.length ) {
					this.load.apply( this,arguments );
				} else {
					if( $.isFunction( callback ) ) {
						var d = callback();
						if( d !== undef ) {
							self.exports( d );	
						}		
					}	
				}
			} else if( $.type( deps ) === 'string' ) {
				//定义模块
				if( argvs.length>2 && $.isArray( callback ) ) {
					var exports = argvs[1].concat([]),
						currExports = argvs[0],
						errBack = argvs[3],
						fn = argvs[2];
					self.load( exports,fn,undef,currExports );
				} else if( callback!==undef ) {
					Nex.Loader.setLoadCache(deps,callback);	
				}
			} else if( $.isFunction( deps ) ) {
				var _deps = self.getInlineDeps( deps );
				if( _deps.length ) {
					self.define( _deps,deps );	
				} else {
					var d = deps();
					if( d !== undef ) {
						self.exports( d );	
					}	
				}
			} else {
				self.exports( deps );		
			}
			return self;
		},
		//IE下获取currScriptAliasName
		currentlyAddingScript : null,
		interactiveScript : null,
		getInteractiveName : function(){
			var self = this,	
				opt = this.configs;
			if (self.currentlyAddingScript) {
				return self.currentlyAddingScript.scriptName;
			}
			else if (
				self.interactiveScript
				&& self.interactiveScript.readyState === 'interactive'
			) {
				return self.interactiveScript.scriptName;
			}
			//var name = Nex.getcwd(true);	
			var nodes = opt.head.getElementsByTagName("script");
			for (var i = nodes.length, node; node = nodes[--i]; ) {
			  if ( node.readyState === "interactive") {
				  self.interactiveScript = node;
				  return node.scriptName;
			  }
			}
			return null;
		},
		include : function(){
			return this.require.apply( this,arguments );
		},
		//主要是针对IE 导出模块
		exports : function(o){
			var self = this,
				undef,
				opt = this.configs;
			if( Nex.isIE ) {
				var currExports = self.getInteractiveName();
				if( !currExports ) {
					window[opt.exportsName] = o;		
				} else {
					Nex.Loader.exports[ currExports ] = o;	
					window[opt.exportsName] = o;	
					self.resetExports();
				}
			} else {
				window[opt.exportsName] = o;
			}
		},
		/*
		*对特殊导出的接口非IE
		*/
		_exports : function(currExports,o){
			var self = this,
				undef,
				opt = this.configs;	
			Nex.Loader.exports[ currExports ] = o;	
		},
		/*返回Deferred对象 Nex.when会用到*/
		getDeferred : function(){
			return this.configs.deferred;	
		},
		done : function(){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.one('onSuccess._deferred',argvs[i]);
				}		
			}
			return this;	
		},
		success : function(){
			this.done.apply(this,arguments);	
			return this;	
		},
		fail : function(){	
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.one('onError._deferred',argvs[i]);
				}		
			}
			return this;	
		},
		error : function(){
			this.fail.apply(this,arguments);	
			return this;	
		},
		then : function(s,f,p){	
			if( $.isFunction( s ) ) {
				this.one('onSuccess._deferred',argvs[i]);
			}	
			if( $.isFunction( argvs[i] ) ) {
				this.one('onError._deferred',f);
			}		
			return this;	
		},
		always : function(){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.one('onComplete._deferred',argvs[i]);
				}		
			}
			return this;
		},
		progress : function(){
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					this.bind('onProgress._deferred',argvs[i]);
				}		
			}
			this.always('onComplete._deferred',function(){
				this.unbind('onProgress._deferred');
			});
			return this;	
		},
		complete : function(){
			return this.always.apply(this,arguments);	
		}
	});
	//扩展Nex
	Nex.apply( Nex,{
		_getLoader : function(){
			return this.Loader._getLoader();	
		},
		getLoader : function(){
			return this.Loader._getLoader();	
		},
		/*
		*新增一个路径变量
		*@param string 路径变量名称 eg nex
		*@param string 路径地址 eg ./src/nex/
		*/
		setLoaderPath : function(){
			this.Loader.setPath.apply( this.Loader,arguments );	
			return this;
		},
		/*
		*新增需要加载的脚本别名
		*@param string 别名 eg Nex.Html
		*@param string 实名路径 eg {{nex}}/Html/Html 此处的{{nex}}引用 path里的
		*/
		setLoaderAlias : function(){
			this.Loader.setAlias.apply( this.Loader,arguments );	
			return this;
		},
		setLoaderShims : function(){
			this.Loader.setShims.apply( this.Loader,arguments );	
			return this;
		},
		/*
		*加载组件或脚本
		*如果加载的是组件 则 如果组件存在则不会加载 如果你加载的是组件，名称一定要对上
		*@param {Array} 组件列表 eg ['Nex.Ajax','Nex.Html']
		*@param {func} 回调
		*@param {boolean} 是否强制加载 默认 false  
		*/
		require : function(deps,callback,errback){
			var loader = this._getLoader();
			return loader.require( deps,callback,errback );
		},
		module : function(){
			var loader = this._getLoader();
			return loader.define.apply( loader,arguments );	
		},
		exports : function(o){
			var loader = this._getLoader();
			return loader.exports( o );	
		},
		setLoaderConfig : function(){
			this.Loader.setConfig.apply( this.Loader,arguments );	
			return this;	
		},
		getLoaderConfig : function(){
			return this.Loader.getConfig.apply( this.Loader,arguments );	
		}
	} );
	$.each(['setConfig','getConfig','setPath','setAlias','package','setPackage','setShims','setExtFunction'
			,'setLoadMaps','bind','one','unbind','fireEvent','off','on','fire','abort'
			,'setPathProcess','unsetPathProcess'],function(i,method){
		Loader[ method ] = function(){
			var returnref = {
				getConfig 		: true,
				bind 			: true,
				one				: true,
				on 				: true
			};
			var loader = Nex._getLoader();	
			if( loader ) {
				var tmp = loader[method].apply( loader,arguments );	
				return returnref[ method ] ? tmp : this;
			}
			return method === 'getConfig' ? null : this;
		};
	});
	//创建Loader
	var _loader = Nex.getLoader();
	_loader.complete( function(){
		Nex.isReady = true;
	} );
	//不要占用其他加载器的require
	if( !define ) {
		if( !require ) {
			require = function(){
				_loader.require.apply( _loader,arguments );	
			};
			require.config = function(){
				var conf = arguments[0];
				if( $.isPlainObject(conf) ) {
					conf.urlArgs = $.isPlainObject( conf.urlArgs ) ? conf.urlArgs : { '*':conf.urlArgs };
				}
				return _loader.C.apply( _loader,arguments );	
			}
		}
		
		define = function(){
			_loader.define.apply( _loader,arguments );	
		};
		
		if( !exports ) {
			exports = function(){
				_loader.exports.apply( _loader,arguments );	
			};
		}
	}
})(jQuery);
/*
*SubmitForm处理工具 SubmitForm
*Nex.util.SubmitForm
*/
Nex.addUtil('SubmitForm',{
	frame : function(f, c, isXML, doc) {
		var n = 'sf'+(Nex.aid++);//'f' + Math.floor(Math.random() * 99999);
		var d = document.createElement('DIV');
		d.innerHTML = '<iframe style="display:none" src="about:blank" id="'+n+'" name="'+n+'" onload="Nex.getUtil(\'SubmitForm\').loaded(\''+n+'\')"></iframe>';

		document.body.appendChild(d);

		var i = document.getElementById(n);
		
		f.setAttribute('target', n);
		
		i.isXML = !!isXML;
		i.docRoot = doc || 'body';
		i.onComplete = function(s){
			if (c && typeof c == 'function') {
				c(s);
			}	
			if ( d.parentNode ) {
				d.parentNode.removeChild( d );
			}
		};
		d.abort = function(){
			if ( this.parentNode ) {
				this.parentNode.removeChild( this );
			}	
		}
		return d;
	},
	/*
	* isXML=true服务器返回的是xml,格式eg:
	*   @header("Content-type: application/xml; charset=$_SC[charset]");
	*	<?xml version="1.0" encoding="UTF-8"?>";
	*	<root><![CDATA[<strong>Hello Nex!</strong>]]></root>;
	* isXML=false
	* 数据的根节点 eg:
	*	docRoot=textarea 默认 body
	*	<textarea>
	*		<strong>Hello Nex!</strong>
	*	</textarea>
	*/
	'submit' : function(f, func, isXML, doc) {
		if( typeof f !== 'object' ) {
			f = document.getElementById(f);	
		}
		
		var d = this.frame(f, func, isXML, doc);
		
		f.submit();
		return d;
	},
	//返回格式是text/html
	loaded : function(id) {
		function getDoc(frame) {
			var doc = frame.contentWindow ? frame.contentWindow.document : frame.contentDocument ? frame.contentDocument : frame.document;
			return doc;
		}
		var i = document.getElementById(id);
		
		if( !i ) return;
		
		var s = '';
		var doc;
		try{
			doc = getDoc( i );
		} catch(e) {
			//cross-origin error
			s = "无法显示此内容,可能错误：cross-origin";
		}
		if( doc ) {
			if (doc.location.href == "about:blank") {
				return;
			}
			
			if( !i.isXML ) {
				//var docRoot = doc.body ? doc.body : doc.documentElement;
		
				var pre = doc.getElementsByTagName(i.docRoot)[0];
				
				if (pre) {
					s = pre.textContent ? pre.textContent : pre.innerText;
				}
			} else {
				try {
					s = i.contentWindow.document.XMLDocument.text;
				} catch(e) {
					try {
						s = i.contentWindow.document.documentElement.firstChild.wholeText;
					} catch(e) {
						try {
							s = i.contentWindow.document.documentElement.firstChild.nodeValue;
						} catch(e) {
								s = "无法显示此内容,可能错误：cross-origin";//如果出现这个请检查域名是否相同 
						}
					}
				}	
			}
			/*else if (b) {
			 s = b.textContent ? b.textContent : b.innerText;
			 }*/
		}
		if (typeof(i.onComplete) == 'function') {
			i.onComplete(s);
		}
	}
});
/*
Nex.Ajax
*/
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([
			'Nex.util.SubmitForm'
		], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	var ajax = Nex.define('Nex.Ajax',{
		extend : 'Nex.AbstractComponent',
		xtype : 'ajax',
		configs : function(opt){
			return {
				prefix : 'nexajax-',
				autoDestroy : false,
				/*
				*sendType 可选值 ajax(默认) form file
				*/
				sendType : 'ajax',//ajax默认 form 定义发送类型 默认使用$.ajax发送数据
				/*
				* sendType=form
				* responseXML=true服务器返回的是xml,格式eg:
				*   @header("Content-type: application/xml; charset=$_SC[charset]");
				*	<?xml version="1.0" encoding="UTF-8"?>";
				*	<root><![CDATA[<strong>Hello Nex!</strong>]]></root>;
				*/
				responseXML : false,
				/*
				* sendType=form
				* responseXML=false
				* 数据的根节点 eg:
				*	docRoot=textarea
				*	<textarea>
				*		<strong>Hello Nex!</strong>
				*	</textarea>
				*/
				docRoot : 'body',
				/*
				* sendType=form
				* injectFields = $('.myform input') or '.myform input'
				* 在提交表单之前把injectFields的元素移到表单内一起提交到服务器,最后还原
				*/
				injectFields : '',
				fileFields : '',
				//contentType : 'application/x-www-form-urlencoded',//application/x-www-form-urlencoded默认 multipart/form-data text/plain ...
				ajax : null,
				_data : {},
				data : {},
				_qdata : {},
				dataFilter : null,
				events : {}
			};		
		}
	});
	$.each( [ "get", "post" ], function( i, method ) {
		ajax[ method ] = function( url, data, callback, type ) {
			if ( $.isFunction( data ) ) {
				type = type || callback;
				callback = data;
				data = undefined;
			}
	
			return this.create({
				type: method,
				url: url,
				data: data,
				success: callback,
				dataType: type
			});
		};
	});
	ajax.addStatics({
		/*直接使用jquery 的Deferred对象 所以要使用when需要确定jquery版本支持Deferred*/
		when : function(){
			return Nex.when.apply(Nex,arguments);	
		},
		getScript : function( url, callback ) {
			return $.get( url, undefined, callback, "script" );
		},
		getJSON : function( url, data, callback ) {
			return $.get( url, data, callback, "json" );
		},
		request : function( d ){
			return this.create( d );	
		}
	});
	ajax.override({
		initComponent : function() {
			var self = this,undef;
			var opt = this.configs;
			self.callParent(arguments);
			opt._beforeSend = opt.beforeSend || null;
			opt._error = opt.error || null;
			opt._success = opt.success || null;
			opt._abort = opt.abort || null;
			opt._complete = opt.complete || null;
			
			if( $.isPlainObject(opt.data) ) {
				opt.data = $.extend( {},opt._data,opt.data,opt._qdata );
			} else if( typeof opt.data === 'string' && typeof opt._qdata === 'string' ) {
				opt.data = opt.data.length ? '&'+opt._qdata : opt._qdata;
			}
			
			var firstUpperCase = function(string){
				return (string+"").replace( /(^|\s+)\w/g, function(s){
					return s.toUpperCase();	
				} );	
			};
			var Deferred = self.getDeferred();
			/*opt.abort = function(){
				var argvs = [];
				for( var i=0;i<arguments.length;i++ ) {
					argvs.push( arguments[i] );	
				}
				argvs.push( this );
				var r = self.fireEvent('onAbort',argvs);	
				if( r === false ) return r;	
				if( $.isFunction( opt._abort ) ) {
					return opt._abort.apply( self,argvs );
				}
			}*/
			opt.beforeSend = function(){
				self.doBeforeSend.apply(self, arguments);	
			};
			opt.success = function(){
				self.doSuccess.apply(self, arguments);	
			};
			opt.error = function(){
				self.doError.apply(self, arguments);	
			};
			opt.complete = function(){
				self.doComplete.apply(self, arguments);		
			};
			
			self.fireEvent('onAjaxReady',[ opt ]);	
			
			opt.sendType = (opt.sendType + "").toLowerCase();
			
			//检测url是否是用户自定义函数
			if( $.isFunction( opt.url ) ) {
				opt.ajax = $.Deferred ? $.Deferred() : opt.url;	
				var success = function( data ){
					var status =  Nex.unDefined(status,'success');
					var xhr =  Nex.unDefined(xhr, null);
					opt.success.apply( self,[ data, 'success', null ] );
					opt.complete.call( self, xhr, status );
				}; 
				var error = function( statusText, error ){//statusText
					var status =  Nex.unDefined(statusText,'error');
					var error =  Nex.unDefined(error,null);
					opt.error.apply( self,[ null, status, error ] );
					opt.complete.call( self, null, status );
				};
				var rf = opt.beforeSend.call( self,null,opt );
				if( rf !== false ) {
					var _opt = $.extend( {dataFilter:null},opt );
					delete _opt.beforeSend; 
					delete _opt.dataFilter;
					delete _opt.success; 
					delete _opt.error; 
					delete _opt.complete; 
					setTimeout( function(){
						var xhr = {
							abort : function(){
								error(this, 'canceled' , null);	
							}	
						};
						opt.ajax = xhr;
						var undef,d = opt.url.apply( self,[_opt.data,success,error,_opt] );	 
						if( d !== undef ) {
							if( d===false ) {
								error( 'error', null);	
							} else {
								success( d, 'success');		
							}
						}
					},0 );
				}
			} else {
				var _opt = $.extend( {},opt );
				//_opt.sendType = null;
				delete _opt.sendType; 
				_opt.beforeSend = function(xhr){
					return opt.beforeSend.call( self,xhr,opt );	
				};
				_opt.dataFilter = null;
				delete _opt.dataFilter;
				
				var xhr = {
					abort : function( TS ){
						_opt.error(this, 'canceled' , null);	
						_opt.complete(this, TS , null);	
					}	
				};
				
				function parseAjax(ajax){
					var ajax = ajax && typeof ajax === 'object' ? ajax : xhr;
					return Nex.applyIf( ajax,xhr );	
				}
				
				var _method = Nex.isFunction(opt.sendType) ? opt.sendType : self[opt.sendType+'Send'];
				if( Nex.isFunction(opt.sendType) ) {
					setTimeout(function(){
						opt.ajax = parseAjax( _method.call(self,_opt) );	
					},0);
				} else {
					opt.ajax = parseAjax( (_method||self.sendAjax).call(self,_opt) );	
				}
			}
			
		},
		doBeforeSend : function(){
			var self =  this;
			var opt = this.configs;
			
			var argvs = [];
			for( var i=0;i<arguments.length;i++ ) {
				argvs.push( arguments[i] );	
			}
			//argvs.push( this );
			var r = self.fireEvent('onBeforeSend',argvs);	
			if( r === false ) return r;
			var rf;
			if( $.isFunction( opt._beforeSend ) ) {
				rf = opt._beforeSend.apply( self,argvs );
			}
			if( rf === false ) return false;
			self.fireEvent('onAjaxStart',argvs);	
		},
		isSuccess : false,
		//data textStatus
		doSuccess : function(){
			var self =  this;
			var opt = this.configs;
			var Deferred = self.getDeferred();
			var argvs = [];
			//var argvs = [].slice.apply(arguments);
			for( var i=0;i<arguments.length;i++ ) {
				argvs.push( arguments[i] );	
			}
			
			if( self.isSuccess ) {
				return;	
			}
			
			self.isSuccess = true;
			
			if( self._customAbort === true ) {
				return;
			}
			
			if( self.fireEvent('onSuccessHook',argvs)===false ) {
				return;	
			}
			
			if( $.isFunction( opt.dataFilter ) ) {
				argvs[0] = opt.dataFilter.call( self,argvs[0],opt.dataType || 'html' );	
			}
			
			if( self.isError ) {
				return;	
			}
			
			//argvs.push( this );
			var r = self.fireEvent('onSuccess',argvs);	
			//if( r === false ) return r;	
			if( r!==false && $.isFunction( opt._success ) ) {
				opt._success.apply( self,argvs );
			}
			if( Deferred ) {
				Deferred.resolveWith.apply( Deferred, [ opt.context || self, argvs ] );	
			}
		},
		//当前请求失败
		isError : false,
		//xhr statusText throw
		doError : function(){
			var self =  this;
			var opt = this.configs;
			var Deferred = self.getDeferred();
			var argvs = [];
			for( var i=0;i<arguments.length;i++ ) {
				argvs.push( arguments[i] );	
			}
			//argvs.push( this );
			//不可重复执行
			if( self.isError ) {
				return;	
			}
			
			self.isError = true;
			
			if( self._customAbort === true ) {
				return;
			}
			
			var statusText = argvs[1];//abort 的状态信息 canceled timeout
			/*if( self._customAbort === true ) {
				opt.abort.apply( this,argvs );
				return;
			}*/
			if( $.inArray( statusText, [ 'timeout', 'canceled' ] ) !== -1 ) {
				var new_argvs = [].concat(argvs);
				new_argvs[1] = statusText;
				if( self.fireEvent('onAbort',new_argvs) !== false ) {
					$.isFunction( opt._abort ) && opt._abort.apply( self,new_argvs );	
				}
			}
			var r = self.fireEvent('onError',argvs);	
			//if( r === false ) return r;
			if( r !== false && $.isFunction( opt._error ) ) {
				opt._error.apply( self,argvs );
			}
			if( Deferred ) {
				Deferred.rejectWith.apply( Deferred, [ opt.context || self, argvs ] );	
			}	
		},
		isComplete : false,
		//xhr textStatus
		doComplete : function(){
			var self =  this;
			var opt = this.configs;
			var argvs = [];
			for( var i=0;i<arguments.length;i++ ) {
				argvs.push( arguments[i] );	
			}
			//argvs.push( this );
			if( self.isComplete ) {
				return;	
			}
			
			self.isComplete = true;
			
			if( self._customAbort === true ) {
				return;
			}
			
			self.fireEvent('onAjaxStop',argvs);
			var r = self.fireEvent('onComplete',argvs);	
			if( r !== false && $.isFunction( opt._complete ) ) {
				opt._complete.apply( self,argvs );
			}		
		},
		//设置是否用户自己调用abort来取消请求
		_customAbort : false,//--可以取消当前状态。。。
		//如果传递了参数则说明是绑定取消事件
		abort : function(fn){
			var self = this;
			var argvs = arguments;
			if( argvs.length && $.isFunction(fn) ) {
				for( var i=0,len = argvs.length;i<len;i++ ) {
					if( $.isFunction( argvs[i] ) ) {
						this.bind('onAbort.deferred',argvs[i]/*,this*/);
					}		
				}
			} else {
				var ajax = self.getAjax();
				if( ajax && ajax.abort ) {
					ajax.abort( fn || 'canceled' );	
				}
				//设置取消状态
				self._customAbort = true;
			}
			return self;
		},
		/*
		*自定义发送接口
		* opt.sendType = ajax;
		* prototype.sendAjax = Function
		* examples:
		*	sendAjax = function(opt){
		*		var xhr = new Http();
		*		if( opt.beforeSend(xhr) === false ) {
		*			return null;	
		*		}
		*		xhr.send(opt.url,opt.data);	
		*		xhr.success = function(data){
		*			opt.success(data, 'success', xhr );	
		*		};
		*		xhr.error = function(xhr,statueText , errorObject){
		*			opt.error(xhr, msg, errorObject);	
		*		}
		*		//opt.complete 必须要调用。。。
		*		xhr.complete = function(){
		*			opt.complete(xhr, 'success or error');	
		*		}
		*		如果xhr 不会触发abort 我们要自己实现 abort的 eg:
		*		xhr.abort = function( statueText ){//statueText=timeout|canceled
		*			opt.error(xhr, statueText, errorObject);
		*		//	opt.complete(xhr, 'success or error'); //??		
		*		}
		*		setTimeout(function(){
		*			xhr.abort('timeout');
		*		},timeout);
		*		return xhr;
		*	}	  
		*/
		//通过ajax方式提交
		ajaxSend : function(options){
			return $.ajax( options );	
		},
		//application/x-www-form-urlencoded multipart/form-data text/plain
		formEnctypeReg : /^\s*(application\/x-www-form-urlencoded|multipart\/form-data|text\/plain)/i,
		getFormEnctype : function(type){
			var matches = this.formEnctypeReg.exec( type+"" );
			return matches ? matches[1] : 'application/x-www-form-urlencoded';
		},
		//通过动态创建表单方式提交
		formSend : function(opt){
			var self = this;
			var _opt = this.configs;
			var timeoutTimer = 0;
			var opt = $.extend({ timeout:0 },$.ajaxSettings,opt);
			var fid = _opt.id+'_submitform';
			var method = (opt.type+"").toLowerCase();
			method = Nex.inArray( method, ['get','post'] ) === -1 ? 'post' : method;
			console.log(self.getFormEnctype(opt.contentType));
			var tpl = [
				'<div class="nex-hidden" style="width:0px;height:0px;overflow:hidden;">',
					'<form id="',fid,'" autocomplete="off" novalidate="novalidate" method="',method,'" action="',$.trim(opt.url),'" enctype="',self.getFormEnctype(opt.contentType),'"></form>',
				'</div>'
			];
			var fwrap = $(tpl.join(''));
			$(document.body).append( fwrap );
			var form = document.getElementById(fid);	
			//触发beforeSend
			if( opt.beforeSend(form) === false ) {
				fwrap.remove();
				return null;	
			}
			//解析URL地址取得search字符串
			var parseUrl = Nex.parseUrl(opt.url);
			var queryString = [];
			if( parseUrl.search ) {
				queryString.push( parseUrl.search );
			}
			//param数据
			if( Nex.isObject(opt.data) ) {
				var query = $.param(opt.data,!!opt.traditional);
				if( query ) {
					queryString.push( query );
				}
			} else if( opt.data && !Nex.isEmpty(opt.data) ) {
				queryString.push( opt.data );	
			}
			//生成Input
			var inputs = [];
			if( queryString.length ) {
				$.each( (queryString.join('&')).split('&'), function(i, str){
					var str = str.split('=');
					if( !str.length ) return;
					
					inputs.push(['<input type="hidden" autocomplete="off" name="',decodeURIComponent(str[0]),'" value="',decodeURIComponent(Nex.unDefined(str[1],'')),'">'].join(''));
				} );
			}
			var $form = $(form);
			if( inputs.length ) {
				$form .append( $(inputs.join('')) );	
			}
			//injectFields
			var $restoreFields = null;
			if( opt.injectFields ) {
				$restoreFields = $(opt.injectFields);
				$restoreFields.each( function(){
					var field = $(this);
					var cfield = field.clone();	//removeData
					field.data('_$restore',cfield);
					field.after( cfield );
					$form.append( field );
				} );	
			}
			function restoreFields(){
				if( $restoreFields ) {
					$restoreFields.each( function(){
						var field = $(this);
						var cfield = field.data('_$restore');	//removeData
						field.removeData('_$restore');
						cfield.after( field );
						cfield.remove();
					} );		
				}
			}
			//表单提交
			var utilsSubmit = Nex.getUtil('SubmitForm');
			
			var xhr;
			xhr = utilsSubmit.submit(form, function( data ){
				if( timeoutTimer ) {
					clearTimeout(timeoutTimer);	
				}
				
				var response = self.ajaxConvert( data, opt.dataType || 'html' );
				
				if( response.state === 'parsererror' ) {
					opt.error( xhr, 'parsererror', response.error );	
				} else {
					opt.success( response.data, 'success', xhr );		
				}
				
				opt.complete( xhr, response.state );
				
				restoreFields();
				
			}, _opt.responseXML, _opt.docRoot );
			//abort
			form.abort = function( TS ){
				if( timeoutTimer ) {
					clearTimeout(timeoutTimer);	
				}
				xhr.abort();	
				opt.error( xhr, TS, null );
				opt.complete( xhr, TS );
			}
			//timeout
			if( opt.timeout>0 ) {
				timeoutTimer = setTimeout(function(){
					timeoutTimer = 0;
					form.abort('timeout');
				}, opt.timeout);	
			}
			return form;
		},
		/*
		*上传文件
		* eg fileFields = ".file"
		*/
		fileSend : function( opt ){
			var self = this;
			if( opt.fileFields ) {
				opt.injectFields = $( opt.injectFields ).add( $(opt.fileFields) );
			}
			opt.type = "post";
			opt.contentType = "multipart/form-data";
			return self.formSend(opt);	
		},
		getAjax : function(){
			return this.C('ajax');	
		},
		getXHR : function(){
			return this.C('ajax');	
		},
		//用于Nex.when
		/*getDeferred : function(){
			return this.configs.deferred;	
		},*/
		getConverters : function(){
			var converters = $.ajaxSettings.converters;
			var conv = {
				'*' : converters['* text'],
				'text' : converters['* text'],
				'html' : function(res){return res;},
				'json' : converters['text json'],
				'xml' : converters['text xml'],
				'script' : converters['text script']
			};
			return conv;	
		},
		ajaxConvert : function(s, dataType){
			var conv = this.getConverters();
			var dataType = (dataType+"").toLowerCase();
			var response;
			dataType = conv[dataType] ? dataType : '*';
			try {
				response = conv[dataType]( s );
			} catch ( e ) {
				return { state: "parsererror", error: e };
			}
			return { state: "success", data: response };
		},
		sysEvents : function(){
			var self = this;
			var opt = self.configs;
			self.callParent(arguments);
			self.bind("onComplete",self._removeAjax,self);
			return self;
		},
		_removeAjax : function(){
			this.configs.autoDestroy = true;
			this.configs.context = null;
			this.removeCmp();	
		},
		done : function(func){
			var defered = this.getDeferred();
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					if( defered.state() === 'pending' ) {
						this.bind('onSuccess.deferred',argvs[i]/*,this*/);
					} else {
						defered.done(argvs[i]);		
					}
				}		
			}
			return this;	
		},
		success : function(){
			this.done.apply(this,arguments);	
			return this;	
		},
		fail : function(){	
			var defered = this.getDeferred();
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					if( defered.state() === 'pending' ) {
						this.bind('onError.deferred',argvs[i]/*,this*/);
					} else {
						defered.fail(argvs[i]);	
					}
				}		
			}
			return this;	
		},
		error : function(){
			this.fail.apply(this,arguments);	
			return this;	
		},
		then : function(s,f,p){	
			var defered = this.getDeferred();
			if( $.isFunction( s ) ) {
				if( defered.state() === 'pending' ) {
					this.bind('onSuccess.deferred',s);
				} else {
					defered.done( s );	
				}
			}	
			if( $.isFunction( f ) ) {
				if( defered.state() === 'pending' ) {
					this.bind('onError.deferred',f);
				} else {
					defered.fail( s );		
				}
			}		
			return this;	
		},
		always : function(){
			var defered = this.getDeferred();
			var argvs = arguments;
			for( var i=0,len = argvs.length;i<len;i++ ) {
				if( $.isFunction( argvs[i] ) ) {
					if( defered.state() === 'pending' ) {//pending
						this.bind('onComplete.deferred',argvs[i]/*,this*/);
					} else {
						defered.always(argvs[i]);	
					}
				}		
			}
			return this;
		},
		complete : function(){
			return this.always.apply(this,arguments);	
		}
	});
}));
(function(){
	Nex.define('Nex.Component',{
		extend : 'Nex.AbstractComponent',
		xtype : 'component',
		_isInit : false,
		configs : function(){
			return {
				prefix : 'component-',
				tag : 'div',
				renderTo : document.body,
				renderAfter : true,
				autoDestroy : true,//自动回收 ，如果el 不存在时会触发
				autoResize : false,//如果你的组件大小都是一个固定值应该设置为false 如果可以是百分比或者auto 则应该设置true
				selectionable : true, 
				autoSize : false,
				width : '', 
				height : '',
				realWidth : null,//实际 ,width=auto时 如果max min width height 没起作用那么realWidth = auto
				realHeight : null,//同上
				_width : null,//和realWidth 不同的是 _width是一个数值
				_height : null,
				__width : 0,
				__height : 0,
				maxWidth : 0,
				maxHeight : 0,
				minHeight : 0,
				minWidth : 0,
				disabledItems : false,
				focusable : true,
				tabIndex : false,
				attrs : {},
				style : {},
				'class' : '',
				containerCls : 'nex-component',
				borderCls    : '',
				uiPrefix  : 'nex-ui',
				ui : 'defalut',//default = nex-ui-default
				uiCls : [],//icon = nex-ui-default-icon
				cls : '',
				cssText : ''
			}	
		},
		onStart : function( opt ){
			this.callParent(arguments);
			opt.__width = opt.width;
			opt.__height = opt.height;
		},
		renderedContainer : false,
		initContainer : function(){
			var self = this;
			var opt = self.configs;	
			
			self.callParent(arguments);
			
			if( self.renderedContainer ) {
				return self;	
			}
			
			var render = $( $.isWindow(opt.renderTo) ? document.body : opt.renderTo );
			var container;
			
			var cls = [
				opt.containerCls,
				'nex-component-item'
			];
			
			if( opt.border === true ) {
				cls.push( opt.borderCls );	
			}
			
			if( opt.ui ) {
				var ui = [opt.uiPrefix,opt.ui].join('-')
				cls.push(ui);	
				var uiCls = $.isArray(opt.uiCls) ? opt.uiCls : [ opt.uiCls ];
				$.each( uiCls,function(i,uc){
					if( !uc ) return;
					cls.push( [ui,uc].join('-') );	
				} );
			}
			if( opt['cls'] ) {
				cls.push( opt['cls'] );	
			}
			if( opt['class'] ) {
				cls.push( opt['class'] );	
			}
			var tag = opt.tag || 'div';
			
			container = $( document.createElement( tag ) );
			container.attr({
				id : opt.id,
				"class" : cls.join(' ')	
			});
		
			if( opt.renderAfter ) {
				render.append(container);
			} else {
				render.prepend(container);
			}
			opt.views['container'] = container;
			
			self.el = container;
			
			if( opt.cssText ) {
				container[0].style.cssText = opt.cssText;
			}
			container.attr( opt.attrs )
				     .css( opt.style );
			if( !opt.selectionable ) {
				self._disableSelection();	
			}
			
			if( opt.focusable && opt.tabIndex !== false ) {
				//设置tabIndex=-1 
				container.attr( {
					tabIndex : opt.tabIndex	   
				} );
			}
			
			self.renderedContainer = true;
			
			return self;
		},
		onContainerCreate : function(){},
		initRenderTpl : function(){
			var self = this;
			var opt = self.configs;	
			
			self.callParent(arguments);
			
			var el = self.el;
			
			var renderData = Nex.apply( {}, opt.renderData, opt );
			
			var tpl = opt.renderTpl;
			if( Nex.isFunction(tpl) ) {
				tpl = tpl.call(self,renderData);	
			} else if( Nex.isArray(opt.renderTpl) ) {
				tpl = self.tpl( tpl.join(''), renderData );	
			} else {
				tpl = self.tpl( tpl + "", renderData );		
			}
			
			el.html(tpl);
			
			$.each( opt.renderSelectors, function(k,s){
				opt.views[k] = $(s,el);	
				self[k] = opt.views[k];
			} );
			
			self.onContainerCreate(el, opt);
			
			self.fireEvent("onContainerCreate",[el,opt]);
			
			return self;	
		},
		initRenderContent : function(){
			this.doRenderContent();
			return this;	
		},
		//_appendContent
		doRenderContent : function(){
			var self = this;
			var opt = self.configs;	
			var lbody = self.getBody();
			if( opt.disabledItems ) return lbody;
			var items = opt['html'];
			self.addComponent( lbody,items,null,opt.defaults );
			var items = opt['items'];
			self.addComponent( lbody,items,null,opt.defaults );
			return lbody;
		},
		setSize : function(){
			return this.setContainerSize.apply(this,arguments);	
		},
		setContainerSize : function(width, height){
			var self = this,
				opt = self.configs;
			opt.width = Nex.unDefined(width, opt.width);
			opt.height = Nex.unDefined(height, opt.height);	
			var wh ={
				width : opt.width,
				height : opt.height	
			};
			self.fireEvent('onSetContainerSize',[wh,opt]);
			self.el.css({
				width : wh.width,
				height : wh.height	
			});
			return this;	
		},
		getContainer : function(){
			var self = this,
				opt = self.configs;
			return opt.views['container'];	
		},
		getBody : function(){
			var self = this,
				opt = self.configs;
			return opt.views['container'];
		},
		_disableSelection : function(){
			this.el.disableSelection();	
		},
		//判断当前对象是否还存在
		isExists : function(){
			var self = this,
				opt = self.configs,
				dom = self.getDom();
			if( !self.isRendering() ) {
				return true;	
			}	
			if( dom.length ) {
				return true;	
			} else {
				if( opt.autoDestroy ) {
					self.removeCmp(opt.id);	
				}	
			}
			return false;
		},
		/*
		*解析xtype 到容器
		*@param {String,Dom} 容器
		*@param {Array,Nex,Xtype} 组件列表 
		*@param {Boolean}  true:append(默认) false:prepend,
		*@param {Object} defaults
		*/
		parseItems : function(renderTo,items,after,def){
			var self = this,
				opt = self.configs,
				undef;
			var after = (after === undef) || (after === null) ? true : after;
			
			var def = $.extend({ xtype : opt.defalutxType }, def || {});
			
			var ac = after ? 'append' : 'prepend';
			if( $.isFunction( items ) && !Nex.isClass( items ) ) {
				items = items.call( self,renderTo );
			}
			var components = [];
			var items = Nex.isArray( items ) ? items : [items];
			if( renderTo && items.length ) {
				for( var i=0;i<items.length;i++ ) {
					var _item = items[i];
					if( _item === '' || _item === undef ) continue;
					if( Nex.isFunction( _item ) && !Nex.isClass( _item ) ) {
						_item = _item.call(self,renderTo,opt);	
						if( _item === '' 
							|| $.type( _item ) === 'boolean' 
							|| $.type( _item ) === 'null' 
							|| $.type( _item ) === 'undefined' 
						) {
							continue;	
						}
					}
					if( Nex.isPlainObject( _item ) && !Nex.isInstance( _item ) ) {
						_item = $.extend( {}, def, _item );	
					}
					if( Nex.isInstance( _item ) ) {
						//$( renderTo )[ac]( _item.getDom() );
						_item.render( renderTo,ac );
						components.push( _item );
						//self.addChildCmpList( _item );
					} else if( Nex.isClass( _item ) || Nex.isXtype( _item ) ){
						if( !Nex.Create ) continue;
						var cmp;
						if( Nex.isXtype( _item ) ) {
							cmp = Nex.Create( $.extend( { parent : opt.id }, _item, {renderTo:renderTo,autoRender:true} ) );	
						} else {
							cmp = Nex.Create( _item,$.extend({},def,{renderTo:renderTo,parent : opt.id,autoRender:true}) );		
						}
						components.push( cmp );
						//self.addChildCmpList( cmp );
						//这里可以改成设置参数 renderAfter : after
						if( !after ) {
							$( renderTo )[ac]( cmp.getDom() );	
						}
					} else if( Nex.isjQuery( _item ) || Nex.isElement( _item ) ) {
						$( renderTo )[ac]( _item );	
						components.push( _item );
					} else {
						_item = _item + '';
						var html = $._parseHTML( _item );//修正相同字符 不创建bug
						html = $(html).clone();
						components.push( html );
						$( renderTo )[ac]( html );				
					}	
				}
			}
			return components;
		},
		addComponent :　function( renderTo,items,after ){
			return this.parseItems.apply(this,arguments);
		},
		addCmp :　function( renderTo,items,after ){
			return this.parseItems.apply(this,arguments);
		},
		/*
		*解析xtype 到容器
		*@param {Array,Nex,Xtype} 组件列表 
		*@param {String,Dom} 容器
		*@param {Boolean} 内部插入 默认是 后 
		*/
		renderComponent : function( items,renderTo,after,def ){
			return this.parseItems( renderTo,items,after,def );	
		},
		//应该放到Html组件 因为有部分组件没有继承Html 所以先放在这里
		renderTo : function( obj,after ){
			var self = this;
			var opt = this.configs;
			var undef;
			var after = after === undef ? true : after;
			var ac = after ? 'append' : 'prepend';
			if( !obj ) return self;
			if( !self.isExists() ) return self;
			var _st = false;
			if( Nex.isInstance( obj ) && obj.isExists() ) {
				var bd = obj.getBody();
				bd[ac]( self.getEl() );
				_st = true;
			} else {
				var el = $(obj);
				if( el.length ) {
					el[ac]( self.getEl() );	
					_st = true;
				}	
			}
			if( opt.autoResize && _st ) {
				self.resize();
				//if( Nex.ComponentManager ) {
					Nex.ComponentManager.cmpChange();	
				//}
			}
			return self;
		},
		getDom : function(){
			var self = this,
				opt = self.configs;
			return $('#'+opt.id);
		},
		getEl : function(){
			return this.el || this.getDom();	
		},
		getChildrens : function(){
			var opt = this.configs;
			return Nex.ComponentManager.getChildrens( opt.id );	
		},
		getAllChildrens : function(){
			var opt = this.configs;
			return Nex.ComponentManager.getAllChildrens( opt.id );	
		},
		//获取组件的父级组件
		getParent : function(){
			var el = this.getDom(),
				opt = this.configs,
				cmp = null;
			if( !el.length ) return cmp;
			if( opt.parent !== null ) {
				if( Nex.isInstance( opt.parent ) ) {
					return opt.parent;	
				}
				var _p = Nex.get(opt.parent);
				if( _p ) return _p;
			}
			var p = el.parent('.nex-component-item'),
				_id = p.attr('id');
			cmp = _id ? Nex.get(id) : null;
			return cmp ? cmp : null;
		},
		
		/*
		*判断元素垂直滚动条是否滚动到底 @dom
		*/
		_checkYScrollEnd : function( el ){
			return Nex._checkYScrollEnd( el );
		},
		/*
		*判断元素水平滚动条是否滚动到底 @dom
		*/
		_checkXScrollEnd : function( el ){
			return Nex._checkXScrollEnd( el );	
		},
		/*
		*验证是否滚动到低 @el dom @a left/top
		*/
		isScrollEnd : function( el,a ){
			return Nex.isScrollEnd( el,a );	
		},
		//应该放到html
		//计算 max/min/cut width height 
		__getCalcSize : function( size,t ){
			var self = this,
				undef,
				opt = this.configs;	
			if( $.isFunction( size ) ) {
				size = size.call( self );	
			}
			if( size === undef ) size = 0;
			//暂不提供百分比支持
			size = parseInt(size);
			return 	isNaN(size)?0:size;	
		},
		_getCutWidth : function(){
			var self = this,
				opt = this.configs;	
			//var pw = opt.pWidth;
			var size = opt.cutWidth;
			return 	self.__getCalcSize(size,0);
		},
		_getCutHeight : function(){
			var self = this,
				opt = this.configs;	
			var size = opt.cutHeight;
			return 	self.__getCalcSize(size,1);
		},
		_getMinWidth : function(){
			var self = this,
				opt = this.configs;	
			var size = opt.minWidth;
			return 	self.__getCalcSize(size,0);
		},
		_getMaxWidth : function(){
			var self = this,
				opt = this.configs;	
			var size = opt.maxWidth;
			return 	self.__getCalcSize(size,0);	
		},
		_getMinHeight : function(){
			var self = this,
				opt = this.configs;	
			var size = opt.minHeight;
			return 	self.__getCalcSize(size,1);		
		},
		_getMaxHeight : function(){
			var self = this,
				opt = this.configs;	
			var size = opt.maxHeight;
			return 	self.__getCalcSize(size,1);			
		},
		/*
		* 把自己从管理从删除 会触发onDestroy 
		*/
		removeCmp :  function(){
			this.callParent(arguments);
			Nex.gc();
		},
		destroy : function(){
			this.el.remove();
			this.callParent();
			return this;
		}
	});	
})();
/*
*注：自定义加载扩展时 使用toUrl需要明确指出
* expamles:
*	var url = require.toUrl(name+'.js');
*	require([url],function(d){
*		onload(d)	
*	});
*/
/*扩展require*/
!(function(){
	var req = require;
	/*模块加载状态*/
	var STATUES = {
		FETCHING  : 1,
		LOADED    : 2,
		LOADERROR : 3	
	};	
	var fetchingList = {};
	function getCount(){
		var i = 0;
		for( var k in fetchingList ) {
			i++	
		}	
		return i;	
	}
	function getFetchedCount(){
		var i = 0;
		for( var k in fetchingList ) {
			if( fetchingList[k] == STATUES.LOADED ) {
				i++	
			}
		}	
		return i;	
	}
	function getFetchProgress(){
		return getFetchedCount()*100/getCount();
	}
	function checkComplete(){
		var i = 0;
		for( var k in fetchingList ) {
			if( fetchingList[k] > STATUES.FETCHING ) {
				i++	
			}
		}
		if( getCount() == i ) {
			req.emit('complete', fetchingList);	
		}		
	}
	req.on('loaderror', function( name ){
		fetchingList[name] = STATUES.LOADERROR;	
		req.emit('progress', getFetchProgress());	
		checkComplete();
	});
	req.on('fetch', function( id ){
		fetchingList[name] = STATUES.FETCHING;	
	});
	req.on('load', function( id ){
		fetchingList[name] = STATUES.LOADED;	
		req.emit('progress', getFetchProgress());	
		checkComplete();
	});
});
(function( factory ) {
	if ( typeof $define === "function" ) {
		
		$define([
			'Nex.Ajax',
			'Nex.panel.Panel'
		], function(){
			
			factory( jQuery );	
		} );
	} else {

		factory( jQuery );
	}
}(function( $ ) {
	var table = Nex.define('Nex.grid.AbstractGrid',{
		extend : 'Nex.panel.Panel',
		xtype : 'abstractgrid',
		alias : 'Nex.AbstractGrid',
		configs : function(opt){
			return {
				prefix : 'absgrid_',
				autoResize : true,
				disabledItems : true,
				border : true,
				containerCls : [opt.containerCls,'nex-grid'].join(' '),
				borderCls : [opt.borderCls,'nex-grid-border'].join(' '),
				autoScrollCls : [opt.autoScrollCls,'nex-grid-auto-scroll'].join(' '),
				autoWidthCls : [opt.autoWidthCls,'nex-grid-auto-width'].join(' '),
				autoHeightCls : [opt.autoHeightCls,'nex-grid-auto-height'].join(' '),
				autoScroll : false,
				cls : '',//自定义CSS
				nowrap : true,//是否换行
				rowTpl : '',//grid 自定义行模板
				showHeader : true,//显示header
				showFooter : false,
				clsOverRow : 'datagrid-row-over',
				clsSelectRow : 'datagrid-row-selected',
				stripeRows : false,//开启隔行变色
				clsSingleRow : 'datagrid-row-single',
				clsDoubleRow : 'datagrid-row-double',
				border : true,//开启后会 给grid添加 containerCss 的样式
				
				tableLayout : 'fixed',
				
				/**
				 * @cfg {String/Boolean} scroll
				 * Scrollers configuration. Valid values are 'both', 'horizontal' or 'vertical'.
				 * True implies 'both'. False implies 'none'.
				 */
				scroll : true,//--
				
				showRowLineV : true,//显示竖向表格线条
				showRowLineH : true,//显示横向表格线条
				
				multiColumns : false,
				mulitEngine : 1,//第一种方法 可设置 1 2
				multiColumnsAlign : 'center',
				multiColumnFromStr : true,//开启支持以字符串形式的方式实现 。multiColumns必须开启
				multiColumnSplitStr : '_',//分割字符
				multiColumnFromStrData : {},//multiColumnFromStr 字符串开启后 可以为不同层数的单元格设置配置信息
				
				columns : [],//
				_columnsHash : {},//field=>column 这里包含所有的 会通过getColumns填充
				_colid : 1,//col 自增 参数 --
				moveColumnTm : 500,//按下多少秒后开始移动列
				moveColumns : true,
				forceFit:false,//自动设置列宽
				forceFitVisible : true,//列是否始终保持可见
				_headerRowCls : 'nex-grid-absgrid',
				_columnMetaData : {//默认列信息
					field : '',
					dataIndex : '',//数据索引，默认==field
					title : '',
					width : '',//默认的列宽,
					_fieldWidth : 0,//如果width是百分比 那么这个就是计算百分比后的宽度
					minWidth : 20,//默认最小宽度
					maxWidth : null,
					align : 'left',
					valign : 'middle',//body里的垂直居中
					_expand : false,//自定义列内容
					callBack : $.noop,
					hcls : '',//header cell自定义css
					bcls : '',//body cell自定义css
					fcls : '',//footer cell自定义css
					_icon : '',
					iconCls : '',
					icon : '',
					sortable : false, 
					textLimit : false,//当处理大数据的时候 性能消耗比较厉害， 不建议开启了
					fitColumn : true,//改变列大小
					casePerChange : true,//如果当前列设置的是百分比大小，手动修改列大小后 设置为true:grid刷新会失去百分比作用,false:grid刷新时不会失去百分比作用，而是失去手动修改后的宽度
					reader : {},//映射 可直接使用Function 效果同formatter
					forceFit : true,//接受forceFit开启时自动设置列大小 checkbox edit 列会设置为false
					disabled : false//当前列不可用
				},
				columnDefaults : {},
				//用户可针对某一列设置默认信息
				customColumnData : {},
				readerDef : '_default_',
				autoScrollToField : true,
				autoScrollToRow : true,
				fitColumns : true,//移动列总开关
				data : [],//列表数据 含有_expand的将作为扩展列 如果有 _openExpand=true 则会自动展开
				emptyGridMsg : '',//grid数据为空是的显示数据 可以是模板 opt 作为参数
				showEmptyGridMsg : true,
				pk : '_pk',//主键名称
				hideColumns : [],//已经隐藏的列
				selectRows : [],//设置默认选中的行
				_selectRows : {},//选择的行
				isCreate : false,//废弃
				isShow : false,
				views : {},
				//method : 'post',
				//url : '',
				loadMsg : '加载中,请稍后...',
				loadErrorMsg : '数据加载错误！',
				showErrorTime : 2000,
				_lmt : 0,//loadMsg 计时器id
				_colWidthExt : 0,//列宽精确位数
				//cache : true,//缓存,
				pageNumber : 1,
				pageSize : 10,
				url : '',
				_ajaxOptions : {},
				ajaxOptions : {},
				ajaxClass : 'Nex.Ajax',//定义Nex.Ajax组件来发送请求
				ajaxCache : true,
				ajaxPageNumberField : 'pageNumber',
				ajaxPageSizeField : 'pageSize',
				ajaxOptions : {},
				ajaxMethod : 'GET',
				ajaxDataType : 'json',
				ajaxDataFilter : null,
				ajaxData : {},
				ajaxSend : null,//自定义ajax发送函数
				asyncDataMaps : {
					total : 'total',
					pageSize : 'pageSize',
					pageNumber : 'pageNumber',
					data : 'data'
					//columns : 'columns',//--尚未实现
					//url : 'url'	
				},
				//dataType : 'json',
				//queryParams : {},
				singleSelect : false,//是否可以多选
				rowStyler : "",//行style 字符串作为 class function(rowid,rowdata)
				rowCallBack : $.noop,
				methodCall : {},//内部函数的回调函数
				denyRowEvents : false,//禁止触发的事件
				tpl : {
					'stylesheet' : '<style id="<%=id%>_stylesheet" type="text/css"></style>',
					'view' : '<table id="<%=id%>_dataview" class="nex-grid-table" cellpadding="0" cellspacing="0" border="0"><thead id="<%=id%>_dataview_header" class="nex-grid-dataview-header"></thead><tbody id="<%=id%>_dataview_body" class="nex-grid-dataview-body"></tbody></table>'
				}
			};	
		}	
	});
	table.override({
		//当前grid显示的数据
		currentPageData : [],
		initComponent : function(){
			this.callParent(arguments);
			this.currentPageData = [];
			this.initAbstractGrid();	
		},	
		initAbstractGrid : function(){
			var self = this;
			self._setGridStyleSheet();
			self._setGridLayout();
		},
		_setGridStyleSheet : function(){
			var self = this;
			var el = self.el;
			var opt = this.configs;	
			if( opt.views['stylesheet'] ) return self;
			var $sheet = $(self.tpl('stylesheet', {id:opt.id}));
			opt.views['stylesheet'] = $sheet;
			el.prepend($sheet);
			return self;
		},
		_setGridLayout : function(){
			var self = this;
			var opt = this.configs;
			var bd = self.getBody();
			var d = {
				id : opt.id	
			};
			bd.addClass('nex-grid-view');
			//创建一个style样式表
			var $view = $(self.tpl('view', d));
			bd.append($view);
			opt.views['dataView'] = $view;
			opt.views['dataViewHeader'] = $('#'+opt.id+'_dataview_header');
			opt.views['dataViewBody'] = $('#'+opt.id+'_dataview_body');
			
			if( !opt.showHeader ) {
				//this.initGridCss();		
				//self.hideHeader();
			}
			
			return self;
		},
		_setGridLayoutCss : function(){
			var self = this;
			var opt = this.configs;	
			self.addCssRules(
				'.nex-grid-table',
				'table-layout: '+opt.tableLayout
			);
			return self;
		},
		getStyleSheet : function(){
			return this.configs.views['stylesheet'];	
		},
		addCssRules : function(selector,cssText){
			var self = this;
			var opt = this.configs;
			var style = self.getStyleSheet().get(0);
			if( style ) {
				selector = selector.split(',');
				$.each(selector, function(i, s){
					selector[i] = '#'+opt.id+' '+s;	
				});
				Nex.addCssRules(
					style,
					selector.join(','),
					cssText
				);
			}	
			return self;	
		},
		getGridView : function(){
			return this.getBody();	
		},
		getDataView : function(){
			return this.configs.views['dataView'];	
		},
		getDataViewHeader : function(){
			return this.configs.views['dataViewHeader'];	
		},
		getDataViewBody : function(){
			return this.configs.views['dataViewBody'];		
		},
		/*
		*布局大小设置
		*/
		doSetViewSize : function(){
			var self = this;
			var opt = this.configs;
			var bd = self.getBody();	
			
			self.callParent(arguments);
			
			var dataView = self.getDataView();
			
			if( !self.isAutoWidth() ) {
				dataView.css('width','100%');	
			} else {
				dataView._removeStyle('width');	
			}
		},
		dataViewRendered : false,
		//设置GRID视图数据 如 表头...
		doRenderContent : function(){
			var self = this;
			var opt = this.configs;
			
			if( self.dataViewRendered ) {
				return self;	
			}
			
			self._setGridLayoutCss();
			
			self.dataViewRendered = true;
			//处理columns数据
			self.initGridColumns();
			//设置grid的列宽
			self.initColumnsWidth();
			//设置grid数据表头
			self.setGridViewHeader();
			
			self.setGridViewBody();
			
		},
		/*
		*解析columns数据
		*/
		initGridColumns : function(){
			var self = this;
			var opt = this.configs;
			var columns = self._parseColumns(opt.columns);	
			var column;
			var i = 0,
				len = columns.length;
			for(;i<len;i++) {
				column = columns[i];
				if( column['disabled'] === true ) continue;
				
				column['field'] = Nex.isEmpty(column['field']) ?  i : column['field'];
				
				if( column['field'] in opt.customColumnData ) {
					$.extend( column,opt.customColumnData[column['field']] );
				}
				
				column['title'] = Nex.isEmpty(column['title']) ?  column['field'] : column['title'];
				//column['index'] = Nex.isEmpty(column['index']) ?  column['field'] : column['index'];
				column['dataIndex'] = Nex.isEmpty(column['dataIndex']) ?  column['field'] : column['dataIndex'];
				column['_colid'] = Nex.isEmpty(column['_colid']) ? 'col'+(Nex.aid++) : column['_colid'];
			}
			opt.columns = columns;
			self.onInitColumns(columns);
			self.fireEvent( 'onInitColumns',[columns] );
			return self;
		},
		onInitColumns : function(){},
		initColumnsWidth : function(){
			var self = this;
			var opt = this.configs;	
			var columns = self.getLeafColumns();
			$.each(columns, function(i, column){
				self.addCssRules(
					'.nex-column-width-'+column._colid,
					'width:'+(Nex.isNumeric(column.width) ? (column.width+"px") : column.width)
				);
			});
		},
		_parseColumns : function(columns){
			var self = this;
			var opt = this.configs;
			var undef;
			var columns = columns || opt.columns;
			var listMap = function(column, pid){
				
				if( Nex.isEmpty(column.field) ) {
					column.field = ['field',++Nex.aid].join('');	
				}
				
				if( Nex.isEmpty(pid) ) {
					  pid = null;	
				} else {
					pid = $.isPlainObject( pid ) && !Nex.isEmpty(pid.field) ? pid.field : null;
				}
				
				if( opt.multiColumns && opt.multiColumnFromStr && opt.multiColumnSplitStr != '' ) {
					//对列名有"_"的进行处理
					var _sp = opt.multiColumnSplitStr;
					var _md = opt.multiColumnFromStrData;
					var _field = String(column.field);
					column._ofield =  column._ofield===undef ? _field : column._ofield;
					
					var sl = column._hasSet?[]:_field.split(_sp);
					if( sl.length>1 ) {
						 column._hasSet = true;
						 column.field = sl[0];
						 var of = column._ofield.split(_sp);
						 var index = $.inArray( column.field,of );
						 column.field = of.slice(0,index+1).join(_sp); 
						 var tls = column.field.split(_sp);
						 var _realField = tls.pop();
						 column.title = column.title||_realField;
						 //eg:field=year_month_day
						 if( _realField in _md ) {
							$.extend( column,_md[ _realField ] ); 
						 }
						 //eg:经过上一步处理后可能是field=maxDay
						 if( column.field in _md ) {
							$.extend( column,_md[ column.field ] ); 
						 }
						 sl.splice(0,1);//删除第一个
						 column.columns = column.columns === undef ? [] : column.columns;
						 column.columns.push( { field : sl.join(_sp),_ofield:column._ofield } );
					} else {
						if( !column._hasSet && sl.length ) {
							   column._hasSet = true;
							   var of = column._ofield.split(_sp);
							   var index = $.inArray( column.field,of );
							   column.field = of.slice(0,index+1).join(_sp); 
							   var tls = column.field.split(_sp);
							   var _realField = tls.pop();
							   column.title = column.title||_realField;
							   
							   if( _realField in _md ) {
									$.extend( column,_md[ _realField ] ); 
							   }
							   if( column.field in _md ) {
									$.extend( column,_md[ column.field ] ); 
							   }
						}
					}
				}
				
				//设置默认值
				column = $.extend({},opt._columnMetaData,opt.columnDefaults,column);
				column['_colid'] = Nex.isEmpty(column['_colid']) ? 'col'+(Nex.aid++) : column['_colid'];
				//_fieldWidth ??
				if( column.disabled===true  ) return;
				
				opt._columnsHash['nsort'+column.field] = column;
				column.__pid = column.__pid===undef ?  pid : column.__pid;
				
				if( ('columns' in column) && Nex.isArray( column.columns ) && column.columns.length ) {
					var ls = column.columns;
					var len = ls.length;
					for( var i=0;i<len;i++ ) {
						listMap( ls[i],column );	
					}
				} else {
					//list.push( column );	
				}
			}	
			var i = 0,
				len = columns.length;
			for(;i<len;i++) {
				listMap( columns[i],null );
			}	
			return self._getLeafColumns();
		},
		getColumnData : function(field){
			var self = this
				,opt = self.configs;	
			//nsort	
			var columns = opt._columnsHash;	
			return columns['nsort'+field] || null;
		},
		getColumnColId : function(field){
			return (this.getColumnData(field) || {})['_colid'] || null;	
		},
		getLeafColumns : function(){
			return this._getLeafColumns.apply(this,arguments);	
		},
		//获取grid显示的列
		getColumns : function(){
			//应该去除锁定的列
			return this.configs.columns;	
		},
		getLockColumns : function(){
			return this.configs.lockColumns;	
		},
		_getColumnChildrens : function( name ){
			var self = this
				,undef
				,opt = self.configs;	
			var list = [];
			if( Nex.isEmpty(name) ) {
				return self._getRootColumns();	
			}
			var columns = opt._columnsHash;	
			for( var key in columns ) {
				var field = columns[key];	
				if( field.__pid === name ) {
					list.push( field );
				}		
			}		
			return list;	
		},
		_getColumnAllChildrens : function( name ){
			var self = this
				,undef
				,opt = self.configs;	
			var list = [];
			var name = name;
			var _loop = function( n ){
				var childs = self._getColumnChildrens(n);
				for( var i=0,len=childs.length;i<len;i++ ) {
					list.push( childs[i] );	
					_loop( childs[i]['field'] );
				}
			};
			_loop(name);
			return list;	
		},
		/*获取当前单元格下 还有多少层次*/
		_getColumnAllLevel : function( name ){
			var self = this
				,undef
				,opt = self.configs;	
			if( name === undef || name === null || name === '' ) {
				name = null;
			}	
			var columns = opt._columnsHash;	
			var childs = self._getLeafColumns( name );
			var level = 1;
			var getTop = function( n ){
				var n = 'nsort'+n;
				if( n in columns ) {
					var column = columns[n];
					if( column.__pid !== name ) {
						level++;
						return getTop( column.__pid );	
					} else {
						return level++;	
					}	
				}	
			};
			var _max = 0;
			$.each( childs,function(i,field){
				var i = getTop( field['field'] );
				_max = Math.max( _max,i );	
				level = 1;
			} );
			
			return _max;	
		},
		_isRootColumn : function( field ){
			var field = field || {};
			return Nex.isEmpty(field.__pid) ? true : false;	
		},
		_isLeafColumn : function(name){
			var list = this._getColumnChildrens( name );
			return list.length ? false : true;
		},
		/**
		*获取指定单元格下的叶子节点	
		*/
		_getLeafColumns : function( name ){
			var self = this
				,undef
				,opt = self.configs;
			var list = [];
			var columns = opt._columnsHash;	
			var childs = self._getColumnAllChildrens( name );
			for( var i=0,len=childs.length;i<len;i++ ) {
				if( self._isLeafColumn( childs[i]['field'] ) ) {
					list.push( childs[i] );	
				}
			}
			return list;	
		},
		//返回指定单元格的最顶层
		_getTopColumn : function(name){
			var self = this
				,undef
				,opt = self.configs;
			var columns = opt._columnsHash;	
			var name = 'nsort'+name;
			if( name in columns ) {
				var column = columns[name];
				if( column.__pid !== null && column.__pid !== undef ) {
					return self._getTopColumn( column.__pid );	
				} else {
					return column;	
				}	
			}	
		},
		//返回最顶层的单元格列表
		_getRootColumns : function(){
			var self = this
				,undef
				,opt = self.configs;
			var list = [];
			var columns = opt._columnsHash;
			for( var key in columns ) {
				var field = columns[key];	
				if( field.__pid === null || field.__pid===undef ) {
					list.push( field );
				}	
			}	
			return list;		
		},
		getGridHeaderHtml : function(){
			var self = this
				,undef
				,opt = self.configs;
			var hlist = [];
			var hhash = {};
			
			var tdTpl = '<td rowspan="<%=rowSpan%>" colspan="<%=colSpan%>" id="<%=gridId%>_cols_<%=_colid%>" class="nex-grid-col nex-grid-header-col nex-grid-<%=_colid%> nex-grid-header-<%=_colid%> <%=$isroot ? "nex-grid-header-col-root":""%> <%=$isleaf ? "nex-grid-header-col-leaf":""%>" field="<%=field%>" align="<%=align%>">'
							+'<div class="nex-grid-cell-wrap" field="<%=field%>" >'
								+'<div id="<%=gridId%>_header_cell_<%=_colid%>" class="nex-grid-cell nex-grid-header-cell <%=hcls%>" >'
									+'<span class="nex-grid-cell-text nex-grid-header-cell-text"><%=title%></span>'
								+'</div>'
							+'</div>'
						+'</td>';
			
			function getTD( field, level ){
				var level = level || 0;
				var name = field['field'];
				var colSpan = self._getLeafColumns( name );
				var rowSpan = 1;
				colSpan = colSpan.length;
				//rowSpan += 1;
				rowSpan = maxRow-level;
				var fieldText = field.title === undef ? field.field : field.title ;
				field.title = fieldText;
				var tplData = $.extend({},field,{
						gridId:opt.id,
						$isleaf  : false,
						$isroot  : !field.__pid
					});
				if( self._isLeafColumn(name) ) {
					colSpan = 1;
					tplData.colSpan = colSpan;
					tplData.rowSpan = rowSpan;
					tplData.$isleaf = true;
					var tds = self.tpl(tdTpl, tplData);	
					trs[level].push( tds );
					return;
				} else {
					rowSpan = 1;
					tplData.colSpan = colSpan;
					tplData.rowSpan = rowSpan;
					tplData.align = opt.multiColumnsAlign; 
					var tds = self.tpl( tdTpl, tplData);	
					trs[level].push( tds );
					var childs = self._getColumnChildrens( name );
					$.each( childs,function(i,f){
						var _level = level;
						getTD(f, ++_level);
					} );
				}	
			}
			
			//更新_columnsHash
			var columns = opt._columnsHash;
			var maxRow = self._getColumnAllLevel();
			var cols = self._getRootColumns();
			//header-row 用来分配列宽
			var firstRow = ['<tr class="nex-grid-rows-header" style="height:0px;border:0;">'];
			var _columns = self.getLeafColumns();
			$.each(_columns,function(i,col){
				firstRow.push('<td class="nex-column-width-'+col._colid+'" style="border:0;padding:0;margin:0;height:0px;"></td>');	
			});
			firstRow.push('</tr>');
			var trs = [];//每层td内容
			//初始化内容
			for(var i=0;i<maxRow;i++) {
				trs[i] = [];	
			}
			$.each( cols,function(i,field){
				getTD(field, 0);	
			} );
			
			var html = [firstRow.join('')];
			$.each(trs,function(i,tr){
				var tds = ['<tr class="',opt._headerRowCls,' nex-grid-header-row">'];
				tds.push(tr.join(''));
				tds.push('</tr>');
				html.push( tds.join('') );	
			});
			return html.join('');
		},
		setGridViewHeader : function(){
			var self = this
				,opt = self.configs;	
			var vheader = self.getDataViewHeader();
			vheader.html( self.getGridHeaderHtml() );	
			self.refreshGVHColumnsCls();
			self.fireEvent('onGridViewhHeaderCreate',[vheader,opt]);
		},
		onGridViewhHeaderCreate : function(){},
		//refreshGridViewHeaderColumnsCls
		refreshGVHColumnsCls : function(columns,vheader){
			var self = this
				,opt = self.configs;	
			var rootColumns = columns || self._getRootColumns();		
			
			if( !rootColumns.length ) {
				return self;	
			}
			
			var vheader = vheader || self.getDataViewHeader();
			$('.nex-grid-header-col',vheader).removeClass('nex-grid-col-first nex-grid-col-last');
			
			var first_column = rootColumns[0];
			var last_column = rootColumns.pop();
			
			function loop_first(column){
				var el = self.getGVHColumnEl(column.field);
				el.addClass('nex-grid-col-first');
				var childs = self._getColumnChildrens(column.field);
				if( childs.length ) {
					loop_first(childs[0]);	
				}	
			}
			function loop_last(column){
				var el = self.getGVHColumnEl(column.field);
				el.addClass('nex-grid-col-last');
				var childs = self._getColumnChildrens(column.field);
				if( childs.length ) {
					loop_last(childs.pop());	
				}	
			}
			loop_first(first_column);
			loop_last(last_column);
			return self;
		},
		getGVHColumnEl : function(field){
			var opt = this.configs;
			var colid = this.getColumnColId(field);
			if( !colid ) return $();
			return $('#'+opt.id+'_cols_'+colid);
		},
		setColumnWidth : function(field,width){
			var self = this
				,opt = self.configs;	
			var column = self.getColumnData(field);
			if( !column ) return self;
			column.width = width;
			self.addCssRules(
				'.nex-column-width-'+column._colid,
				'width:'+(Nex.isNumeric(column.width) ? (column.width+"px") : column.width)
			);
			return self;
		},
		setGridViewBody : function(){
			var self = this
				,opt = self.configs;	
			var vbody = self.getDataViewBody();		
			
			self.showGrid();
		},
		/*
		*显示grid数据
		*/
		showGrid : function(pageNumber, pageSize){
			var self = this
				,opt = self.configs;	
			//set	pageNumber
			if( self.fireEvent('onBeforeShowGrid',[opt]) === false) {
				return self;	
			}	
			//var vbody = self.getDataViewBody();
			self.showLoading();
			self.loadPageData(function(data){
				if(self.isAjaxAsync()) {
					opt.data.length = 0;
					self.parseAsyncData(data);	
				}
				self.createGridRows();
			}, function(data){
				console.log(data);	
			}, function(data){
				self.hideLoading();	
			});	
			return self;			
		},
		//创建GRID
		createGridRows : function(){
			var self = this
				,opt = self.configs;	
			var vbody = self.getDataViewBody();		
			vbody.html(self.getGridRowsHtml(self.getCurrentPageData()));	
			return self;
		},
		getGridRowsHtml : function(datas){
			var self = this;
			var trs = [];
			for(var i=0,len=datas.length;i<len;i++) {
				trs.push(self.getGridRowHtml(i,datas[i] || {}));	
			}	
			return trs.join('');
		},
		getGridRowHtml : function(rid,data){
			var self = this
				,opt = self.configs;	
			var data = self.parseRowData(data);	
			var columns = self.getColumns();
			var tds = [];
			var html = [
				'<tr class="nex-grid-row">'
				];
					for(var i=0,len=columns.length;i<len;i++) {
						var column = columns[i];
						var style = [
							opt.showRowLineV ? '' : 'border-right-width:0;border-left-width:0;',
							opt.showRowLineH ? '' : 'border-bottom-width:0;border-top-width:0;'
						];
						//因为grid的border-collapse: separate;在ie6 7 下如果为空时单元格td不会显示，只有设置为collapse才会显示
						tds.push(
							'<td class="nex-grid-col nex-grid-',column._colid,[i===0 ? 'nex-grid-col-first':'',i===(len-1) ? 'nex-grid-col-last':''].join(' '),'" valign="',column.valign,'" align="',column.align,'" style="',style.join(''),'">',
								'<div id="" class="',['nex-grid-cell',opt.nowrap ? 'nex-grid-cell-nowrap' : ''].join(' '),'">',
								Nex.isEmpty(data[column.dataIndex]) ? '&nbsp;' : data[column.dataIndex],
								'</div>',
							'</td>'
						);	
					}
				html.push(tds.join(''),'</tr>');	
			return html.join('');
		},
		parseRowData : function(data){
			var self = this
				,opt = self.configs;	
			var data = data || {};
			if( !data._uuid ) {
				data._uuid = Nex.uuid();	
			}	
			return data;		
		},
		//解析服务器数据到本地
		parseAsyncData : function(data){
			var self = this
				,opt = self.configs;	
			if(Nex.isArray(data)) {
				opt.data = data;	
			} else if(Nex.isObject(data)) {
				var maps = opt.asyncDataMaps;
				$.each(maps, function(k,v){
					if(v in data) {//data.hasOwnProperty(k)
						opt[k] = data[v];
					}
				});	
			}
			return self;
		},
		isAjaxAsync : function(){
			return !!this.configs.url && !Nex.isEmpty(this.configs.url);	
		},
		getAjaxAsync : function(){
			return this.isAjaxAsync();	
		},
		emptyGridData : function(){
			this.configs.data.length = 0;
			return this;	
		},
		/*
		*获取GRID所有数据
		*/
		getData : function(){
			return this.configs.data || [];	
		},
		/*
		*获取当前页数据
		*/
		getCurrentPageData : function(){
			return this.isAjaxAsync() ? this.getData() : this.loadLocalPage();	
		},
		/*
		*加载当前页数据
		*/
		loadPageData : function(success,error,complete){
			var self = this
				,opt = self.configs;
			if( self.fireEvent('onBeforeLoadPageData',[success,error,complete]) === false) {
				return self;	
			}	
			var s = function(){
				self.fireEvent('onLoadPageDataSuccess',arguments);
				if( $.isFunction(success) ) {
					success.apply(self,arguments);	
				}	
			}
			var f = function(){
				self.fireEvent('onLoadPageDataError',arguments);
				if( $.isFunction(error) ) {
					error.apply(self,arguments);	
				}	
			}
			var c = function(){
				self.fireEvent('onLoadPageDataComplete',arguments);
				if( $.isFunction(complete) ) {
					complete.apply(self,arguments);	
				}	
			}
			if( self.isAjaxAsync() ) {
				self.loadAsyncPage(s,f,c);	
			} else {
				s(self.loadLocalPage());	
				c(self);	
			}
			return self;
		},
		//从本地data数据源中加载当前页数据
		loadLocalPage : function(){
			var self = this
				,opt = self.configs
				,data = opt.data || [];	
			var pageNumber = opt.pageNumber;	
			var pageSize = opt.pageSize;
			if( !data.length ) {
				return [];	
			}	
			var index = (pageNumber-1)*pageSize;
			return data.slice(index, pageNumber*pageSize);	
		},
		//从服务器中加载当前页数据
		loadAsyncPage : function(success, error, complete){
			var self = this,
				opt = self.configs;
			
			var ajaxData = opt.ajaxData || {};
			ajaxData[opt.ajaxPageNumberField] = opt.pageNumber;
			ajaxData[opt.ajaxPageSizeField] = opt.pageSize;
			
			var ajaxOptions = $.extend({},{
					type 		: opt.ajaxMethod,
					cache 		: opt.ajaxCache,
					dataType	: opt.ajaxDataType,
					dataFilter	: opt.ajaxDataFilter
				});
				
			$.extend(ajaxOptions, opt.ajaxOptions);
			
			ajaxOptions.data = $.extend(ajaxOptions.data || {},ajaxData);
			ajaxOptions.$caller = self;
			ajaxOptions.url = opt.url;
			
			ajaxOptions.success = function(data){
				if( $.isFunction(success) ) {
					success(data);	
				}
				self.fireEvent('onLoadAsyncDataSuccess',[data,opt]);
			};
			ajaxOptions.error = function(xmlHttp){
				if( $.isFunction(error) ) {
					error(xmlHttp);	
				}
				self.fireEvent('onLoadAsyncDataError',[xmlHttp,opt]);
			};
			
			ajaxOptions.complete = function(data){
				if( $.isFunction(complete) ) {
					complete(data);	
				}
				self.fireEvent('onLoadAsyncDataComplete',[data,opt]);	
			};
			
			if( self.fireEvent('onBeforeLoadAsyncData',[ajaxData,ajaxOptions,opt]) === false ) {
				return;	
			}	
			
			self.ajaxSend(ajaxOptions);
			
			return self;
		},
		ajaxSend : function(ajaxOptions){
			var self = this;
			var opt = self.configs;
			if( $.isFunction( opt.ajaxSend ) ) {
				opt.ajaxSend.call(self, ajaxOptions);
			} else {
				Nex.Create(opt.ajaxClass, ajaxOptions);
			}
			return self;
		},
		setPageNumber : function(num){
			var opt = this.configs;
			opt.pageNumber = Math.max(parseInt(num) || opt.pageNumber,1);
			return this;	
		},
		setPageSize : function(num){
			var opt = this.configs;
			opt.pageSize = Math.max(parseInt(num) || opt.pageSize,1);
			return this;	
		},
		setTotal : function(num){
			var opt = this.configs;
			opt.total = parseInt(num) || opt.total;
			return this;		
		},
		//camelCase
		/*css style管理*/
		test : function(){}
	});
}));
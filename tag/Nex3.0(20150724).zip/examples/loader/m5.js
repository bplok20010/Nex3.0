
Define( 'm5',['m6'],function(m5){
	console.log(m5)
	return 'm5'	;
} );
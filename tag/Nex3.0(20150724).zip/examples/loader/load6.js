console.log(6)
define( ['load4'],function(){ 
				 exports('6');
} );

<textarea>
<div>NOBO</div>
</textarea>